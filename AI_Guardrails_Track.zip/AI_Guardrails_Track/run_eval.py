"""Week-6 deliverable in miniature: score the corpus, derive the threshold.

    python run_eval.py [--cfn 100] [--cfp 1]
"""
from __future__ import annotations

import argparse
import asyncio
import json

from aegis.detectors.deterministic import (
    CanaryLeakDetector, InvisibleTextDetector,
    RegexInjectionDetector, SecretsDetector,
)
from aegis.eval.harness import load_corpus, report, score_corpus
from aegis.pipeline import GuardrailPipeline
from aegis.policy.engine import PolicyEngine

CANARY = "AEGIS-CANARY-7f3a91c4"


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="data/redteam/seed.jsonl")
    ap.add_argument("--cfp", type=float, default=1.0)
    ap.add_argument("--cfn", type=float, default=100.0)
    a = ap.parse_args()

    pipeline = GuardrailPipeline(
        detectors=[RegexInjectionDetector(), InvisibleTextDetector(),
                   SecretsDetector(), CanaryLeakDetector(CANARY)],
        policy=PolicyEngine(),
    )
    scored = await score_corpus(pipeline, load_corpus(a.corpus))
    rep = report(scored, a.cfp, a.cfn)

    at = rep["at_threshold"]
    print(f"n={rep['n']} ({rep['n_attacks']} attacks)  "
          f"cost ratio FN:FP = {rep['cost_ratio_fn_over_fp']:.0f}:1")
    print(f"chosen threshold : {rep['chosen_threshold']:.2f}")
    print(f"precision {at['precision']:.3f} | recall {at['recall']:.3f} "
          f"| F2 {at['f2']:.3f} | TP {at['tp']} FP {at['fp']} FN {at['fn']} TN {at['tn']}")
    print("\nerror taxonomy by family:")
    for fam, b in sorted(rep["error_taxonomy"].items()):
        print(f"  {fam:26s} ok={b['ok']:2d} fn={b['fn']:2d} fp={b['fp']:2d}")

    with open("eval_report.json", "w") as fh:
        json.dump(rep, fh, indent=2)
    print("\nfull report -> eval_report.json")


if __name__ == "__main__":
    asyncio.run(main())
