# Project AEGIS — Guardrailed Agentic Credit Document Intelligence

**One-line pitch:** *An agentic pipeline that reads private-credit documents and extracts covenants — wrapped in a production guardrail layer that detects prompt injection hidden inside those documents, with a measured, cost-derived threshold policy and a bank-grade audit trail.*

## Why this project and not another chatbot

It is the only design I can find that satisfies **both JDs with one repo**:

| JD bullet | Where AEGIS satisfies it |
|---|---|
| JD-A: multi-agent architectures, Supervisor Agent | LangGraph supervisor routing 4 sub-agents |
| JD-A: document intelligence, structured outputs, schema validation, traceability | PDF → Pydantic `CreditFacility`, span-level citations, checkpointed replayable runs |
| JD-A: assurance-by-design, reflection, LLM-vs-LLM validation | `Reviewer` node + `LLMJudgeDetector` on the response surface |
| JD-A: policy intelligence, operational memory | YAML policy engine + LangGraph checkpoint store |
| JD-A: explainability, auditability, regulatory compliance | Immutable audit log, model card, SR 11-7 framing |
| JD-B: injection/jailbreak/PII/leakage/agent-risk detectors | `detectors/` — six detectors across three tiers |
| JD-B: rules + ML + LLM-judge + third-party, confidence scoring | Tiered hybrid ensemble with weighted confidence |
| JD-B: protection across upload/retrieval/prompt/response/tool layers | Five enforcement surfaces, one engine, config-driven |
| JD-B: allow/block/redact/mask/escalate/human-approval | `policy/actions.py` |
| JD-B: offline + online eval, thresholds, FP/FN analysis | `eval/` — PR curves, cost-derived thresholds, error taxonomy, CI regression |
| JD-B: parallel execution, tiered detection, graceful degradation, timeout isolation | `pipeline.py` async orchestration |
| JD-B: observability, audit trails, review workflows, red-team loops | OTel traces + Streamlit review dashboard + garak loop |
| JD-B: first-party detectors, fine-tuning pipelines | Week 8 LoRA classifier vs off-the-shelf baseline |
| JD-B: K8s, Docker, cloud, API/service dev | FastAPI + Docker + kind manifests + load test |

And the domain — private credit, covenants, trade finance — is **yours**. Every other candidate will demo an insurance-claims or customer-support bot. You demo the thing HSBC AM actually does, with a threat model that only someone who has read a credit agreement would think of.

## Architecture

```
                    ┌─────────────── AEGIS POLICY ENGINE ───────────────┐
                    │  YAML policy · per-surface actions · audit log     │
                    └───┬────────┬────────┬─────────┬──────────┬────────┘
                        │        │        │         │          │
   PDF upload ──────► [S1]       │        │         │          │
                     UPLOAD      │        │         │          │
                        │        │        │         │          │
                        ▼        │        │         │          │
                 ┌──────────┐    │        │         │          │
                 │  Ingest  │    │        │         │          │
                 │  parse   │    │        │         │          │
                 │  chunk   │    │        │         │          │
                 │  embed   │    │        │         │          │
                 └────┬─────┘    │        │         │          │
                      ▼          │        │         │          │
                 ┌──────────┐    │        │         │          │
                 │  Vector  │──►[S2] RETRIEVAL      │          │
                 │  store   │    │        │         │          │
                 └──────────┘    ▼        │         │          │
                            ┌─────────────────┐     │          │
   user question ──►[S3]───►│   SUPERVISOR    │     │          │
                    PROMPT  │   (LangGraph)   │     │          │
                            └────┬───┬───┬────┘     │          │
                                 │   │   │          │          │
              ┌──────────────────┘   │   └───────┐  │          │
              ▼                      ▼           ▼  │          │
      ┌──────────────┐   ┌──────────────────┐  ┌────────────┐  │
      │  Extractor   │   │ CovenantAnalyst  │  │ RiskScorer │  │
      └──────┬───────┘   └────────┬─────────┘  └─────┬──────┘  │
             │                    │                  │         │
             └──────────┬─────────┴──────────────────┘         │
                        ▼                                      │
                 ┌─────────────┐                               │
                 │  Reviewer   │  LLM-vs-LLM validation        │
                 │ (reflection)│                               │
                 └──────┬──────┘                               │
                        │      tool calls ──────────►[S5] TOOL │
                        ▼                                      │
                      [S4] RESPONSE ──────────────────────────►│
                        │
                        ▼
                   answer + citations + decision record
```

**Five enforcement surfaces.** The point of this design — and the sentence to say out loud in the interview — is that *the same policy engine enforces at five different points with different actions and different latency budgets, because the threat is different at each one.* Injection arrives at S1/S2 (hidden in a document) far more dangerously than at S3, since S2 content is implicitly trusted by the model. PII leaks out at S4. Excessive agency shows up at S5.

## Detector inventory

| Detector | Tier | Technique | Catches | Breaks down when |
|---|---|---|---|---|
| `RegexDetector` | 1 (deterministic) | patterns, entropy | known payload strings, secrets | any paraphrase |
| `PIIDetector` | 1 | Presidio: NER + regex + checksums | names, accounts, IDs | context-dependent sensitivity (MNPI) |
| `CanaryLeakDetector` | 1 | canary token in system prompt | system prompt leakage | attacker summarises rather than quotes |
| `InjectionDetector` | 2 (ML) | classifier (baseline → first-party LoRA) | direct + indirect injection | novel attack families, domain shift |
| `GroundednessDetector` | 2 | NLI / citation-span check | hallucinated covenant terms | subtle numeric drift |
| `LLMJudgeDetector` | 3 (LLM) | structured rubric, LLM-vs-LLM | policy violations, harmful content, agent-risk | cost, latency, judge bias, non-determinism |

**Tiering rule:** tier 1 runs always (sub-10ms, in parallel). Tier 2 runs unless tier 1 already blocked. Tier 3 fires **only** in the uncertainty band — which is exactly why the eval work in Week 6 matters: the band's boundaries are the thing you tune, and they are what makes the system affordable.

## Threat model (write this up properly — it is a differentiator)

Primary threat: **indirect prompt injection via ingested documents.** A counterparty submits a credit agreement containing instructions invisible to a human reader (white text, zero-width characters, metadata, footnote at 1pt) that manipulate covenant extraction — e.g. suppressing a breach or inflating a headroom figure. The output feeds a credit decision. That is a *financial-loss* path, not a reputational one, and framing it that way is how you make a security control sound like a risk control.

Secondary: PII/MNPI leakage into logs or responses. Tertiary: excessive agency at the tool layer. Fourth: system-prompt leakage exposing the control logic itself.

## Demo script (5 minutes, screen-recorded)

1. **(45s)** Upload a clean credit agreement. Aegis extracts covenants with page citations. Show the schema-valid JSON. *"Structured, validated, traceable."*
2. **(90s)** Upload the *same* agreement with a white-text injection on page 12. Show that a human reader sees nothing. Aegis blocks at the **retrieval** surface, quotes the payload as evidence, logs the decision. *"Filtering the user prompt would never have caught this — the payload never touches the prompt surface."*
3. **(45s)** Ask a question whose honest answer includes a counterparty's PII. Show redaction, not blocking — *the action is proportionate to the risk, and that's a policy decision, not an engineering one.*
4. **(90s)** Open the eval report. PR curves per detector. The cost model. *"The threshold is 0.62 because a false negative on covenant suppression costs roughly 100x a false positive, and here's the curve where that lands."*
5. **(30s)** Dashboard: firing rates, escalation queue, human review, latency table with guardrail overhead by tier.

Close on: *"A detector is a model. So it has a model card, an eval report, a monitoring plan and a challenge process — SR 11-7 applies to guardrails, and most people building these haven't noticed yet."*

## Scope discipline

Build in this order and **stop when the demo works**: extraction → supervisor → retrieval → tier-1 detectors → policy engine → injection detector → eval harness → async/latency → observability → deploy. If time runs short, cut the fine-tuned first-party detector (Week 8) and the k8s deploy (Week 9) — cut *nothing* from the eval harness, because that's the half nobody else brings.
