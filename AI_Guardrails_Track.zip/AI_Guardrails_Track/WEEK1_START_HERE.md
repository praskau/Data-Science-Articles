# Week 1 — start here

You said you weren't clear how to begin. This file is the whole answer. Everything is already written and tested except the one step only you can do.

---

## Step 1 — Get an API key (10 minutes, the only blocker)

You have no `ANTHROPIC_API_KEY` set and no `ant` CLI. Nothing else works until this is done.

1. Go to **console.anthropic.com** → sign in → **API keys** → *Create key*.
2. Add credit under **Billing**. Put **$20** on it. That is far more than these 10 weeks need.
3. Set a **monthly spend cap** while you're in there — Billing → Limits. Set it to $50. Do this now, not later.
4. Put the key in your shell:

```bash
echo 'export ANTHROPIC_API_KEY="sk-ant-..."' >> ~/.zshrc
source ~/.zshrc
```

**Do not** paste the key into any file in this folder. `.gitignore` already excludes `.env`, but the repo goes public in Week 0 and a leaked key is the kind of mistake that is embarrassing in an AI *safety* interview.

## Step 2 — Confirm it works (1 minute)

```bash
cd ~/Desktop/Claude/AI_Guardrails_Track
python3 week1/00_check_setup.py
```

It checks your packages, checks the key, makes one real call, and prints what it cost. Expect roughly $0.0004. If it prints `You're ready`, you're ready.

## Step 3 — Run the extractor on one document (2 minutes)

```bash
python3 week1/extract.py data/agreements/meridian_foods_sfa.pdf
```

You'll see each attempt with its latency, cost, and whether the output passed schema validation — then the extracted borrower, facilities and covenants with page citations.

## Step 4 — Run the batch, get your exit test (5 minutes, ~$0.30)

```bash
python3 week1/run_batch.py
```

This is the Week 1 deliverable: documents extracted, **schema failure rate**, citation coverage, cost per document, mean latency. It writes `week1_report.json`.

## Step 5 — The part that actually teaches you (60–90 minutes)

Open the three PDFs in `data/agreements/` and check the extracted JSON in `data/extracted/` against them **by hand**. Every field. This is not busywork — it is the entire point of Week 1, and it is the step people skip.

You are building the instinct for *where a model is reliable and where it quietly isn't*, which is the instinct the whole rest of the plan depends on. Keep a running note of every error. Those notes become your Week 5 detectors and your Week 6 eval corpus.

Things I would bet money the model gets at least partly wrong:

- **The Calder table has no table.** Its covenants are in prose across clauses 6.1–6.3, with step-downs at two future dates. Does it catch both step-downs?
- **Aldermere is the hard one.** Leverage was *breached* at 31 March 2026 and then *waived*. Does it mark that `waived`, or does it see "Complied" in the June table and call the whole thing fine? A model that reports Aldermere as clean is exactly the failure mode that motivates this entire project.
- **Aldermere's June interest cover is 1.38x against a 1.50x floor — a live breach.** Easy to miss because it sits in a table row while the prose is about a different, older breach.
- **Page citations.** Check `source_page` is really the page the quote is on. Confident wrong citations are worse than no citations, and they're a detector in Week 5.
- **`extraction_notes`.** Did it flag the Calder super-senior RCF sitting under a separate agreement? A good extraction says what it *couldn't* determine.

---

## What each file does

| File | Purpose |
|---|---|
| `week1/00_check_setup.py` | Environment + key + one live call |
| `week1/schema.py` | The `CreditAgreement` Pydantic schema — the contract |
| `week1/extract.py` | PDF → validated object, with repair loop and cost accounting |
| `week1/run_batch.py` | All documents → the exit-test report |
| `week1/make_samples.py` | Regenerates the sample PDFs (already run) |
| `data/agreements/` | 3 synthetic agreements — clean, prose-only, and distressed |

## The three ideas to actually absorb this week

**1. The schema is a control, not a convenience.** Every enum and constraint in `schema.py` is a check the model's output must pass before anything downstream sees it. Loosen the schema and you've moved the validation burden onto a human who won't do it. This is the same argument you'd make about a risk limit, and it's the first place your existing instincts transfer directly.

**2. A repair loop beats a retry.** When validation fails, `extract.py` shows the model its own output *and the specific error*. A blind retry just re-rolls the same dice at the same price. Watch the failure rate in the report — that number is your reliability baseline, and you'll quote it later.

**3. Measure every call.** Tokens, latency, cost, validity, on every attempt. You cannot govern what you don't measure, and in Week 6 you will need exactly this data to argue about thresholds. Building the accounting in from call one is why Week 6 will be easy.

## Cost expectations

About **$0.09 per document**, so a full batch run is roughly **$0.30**. Week 1 in total, including your experimentation, should land under **$5**. If you see materially more than that, something is looping — check `week1_report.json` for a document eating repair attempts.

## When you're done

You've finished Week 1 when you can say: *"I extract covenants from credit agreements into a validated schema, my schema failure rate is X%, it costs $Y per document, and here are the four things the model gets wrong."*

That last clause is worth more than the first three. Then go to Week 2 in `01_LEARNING_PLAN.md` — LangGraph and the supervisor topology.
