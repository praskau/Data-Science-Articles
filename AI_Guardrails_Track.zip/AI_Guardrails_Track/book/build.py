#!/usr/bin/env python3
"""Assemble the book fragments into one HTML file and render it to PDF.

Chrome headless is used rather than weasyprint (broken on this machine).
--generate-pdf-document-outline turns the h1/h2 structure into real PDF
bookmarks, which is how a document this long stays navigable.
"""
import glob, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_HTML = os.path.join(HERE, "_book.html")
OUT_PDF = os.path.abspath(os.path.join(HERE, "..",
    "AI_Systems_From_First_Principles.pdf"))
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

def main():
    css = open(os.path.join(HERE, "style.css")).read()
    parts = sorted(glob.glob(os.path.join(HERE, "part_*.html")))
    if not parts:
        sys.exit("no part_*.html fragments found")
    body = "\n".join(open(p).read() for p in parts)
    html = (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<title>AI Systems From First Principles</title>'
            f'<style>{css}</style></head><body>{body}</body></html>')
    open(OUT_HTML, "w").write(html)

    subprocess.run([CHROME, "--headless", "--disable-gpu",
                    "--no-pdf-header-footer", "--generate-pdf-document-outline",
                    f"--print-to-pdf={OUT_PDF}", "--virtual-time-budget=15000",
                    f"file://{OUT_HTML}"],
                   check=True, capture_output=True)

    try:
        from pypdf import PdfReader
    except ImportError:
        from PyPDF2 import PdfReader
    r = PdfReader(OUT_PDF)
    words = sum(len((p.extract_text() or "").split()) for p in r.pages)
    print(f"{os.path.basename(OUT_PDF)}: {len(r.pages)} pages, ~{words:,} words, "
          f"{os.path.getsize(OUT_PDF)/1024:.0f} KB")
    print(f"  fragments: {len(parts)} -> {', '.join(os.path.basename(p) for p in parts)}")

if __name__ == "__main__":
    main()
