# AI Guardrails Track — HSBC GCB4

Everything for the two GCB4 roles in `Photos-1-001 (7)`: a 10-week plan, a curated source list, and a working project.

| File | What it is |
|---|---|
| `00_JD_EXTRACT.md` | Both JDs transcribed from the photos (they are **two** different jobs) |
| `01_LEARNING_PLAN.md` | The 10-week plan, 10+ hrs/wk, starting 2026-08-25 |
| `02_LEARNING_MATERIAL.md` | Curated sources mapped to weeks — plus what to deliberately skip |
| `03_PROJECT_AEGIS.md` | Project spec, architecture, threat model, JD-coverage matrix, demo script |
| `04_INTERVIEW_PREP.md` | Question bank with the answers that win |
| `05_BASELINE_RESULT.md` | The Week-4 baseline result and why its failures are the point |
| `aegis/` | Working scaffold — Weeks 4, 6 and 7 already built |
| `data/redteam/seed.jsonl` | 26-example seed corpus, domain-specific to private credit |

## Run it now

```bash
cd ~/Desktop/Claude/AI_Guardrails_Track
python3 run_eval.py                  # scores the corpus, derives the threshold
python3 run_eval.py --cfn 500        # watch the threshold move with risk appetite
```

Service (needs `pip install fastapi uvicorn`):
```bash
make dev      # http://localhost:8080
make smoke    # posts an injection at the retrieval surface
```

## What's already built vs what you build

**Built** — the parts that are easier to read than to write, so you start from a working spine:
- `aegis/types.py` — Surface / Action / Tier / Finding / Decision
- `aegis/detectors/` — `Detector` ABC + 4 tier-1 detectors (regex injection, invisible text, canary leak, secrets)
- `aegis/policy/` — config-driven policy engine + 5-surface YAML policy with per-surface fail modes
- `aegis/pipeline.py` — tiered + parallel + timeout-isolated orchestration
- `aegis/eval/harness.py` — PR sweep, cost-derived thresholds, error taxonomy
- `aegis/api/app.py` — FastAPI guardrail service
- Dockerfile, Makefile, seed corpus

**Yours** — the parts where the learning actually happens:
- W1–3: extraction agent, LangGraph supervisor, hybrid retrieval, citation grounding
- W5: `InjectionDetector` (tier 2), `GroundednessDetector`, `LLMJudgeDetector` (tier 3)
- W6: grow the corpus to 300+, produce the PR curves as charts, wire the CI regression gate
- W7: load test and the real latency table
- W8: OTel tracing, review dashboard, model card, first-party LoRA detector
- W9: k8s manifests, `garak` red-team loop

## Start here, in this order

1. Read `05_BASELINE_RESULT.md` — it's short and it tells you what the project is really about.
2. Run `python3 run_eval.py` and look at the error taxonomy.
3. Read `03_PROJECT_AEGIS.md` for the architecture.
4. Then Week 0 in `01_LEARNING_PLAN.md`.

## The through-line

Every candidate for JD-B can build a detector. Almost none can tell you what their detector is *worth* — precision and recall under class imbalance, a threshold derived from an explicit loss function, and a governance wrapper that survives a regulator. You already think that way about credit risk. This project moves that instinct across to AI, and the eval harness is where it shows.

## Week 1

Start with **`WEEK1_START_HERE.md`** — it is the step-by-step for getting going.

```bash
python3 week1/00_check_setup.py    # needs ANTHROPIC_API_KEY
python3 week1/run_batch.py         # the Week 1 exit test, ~$0.30
```

## Reading

**`Weeks_0-1_Reading_Pack.pdf`** — 18pp, self-contained. Part I is Week 0 (OWASP LLM Top 10, Building Effective Agents, MITRE ATLAS). Part II is Week 1 (structured outputs, repair loops, tool use, cost accounting) plus a current API reference card. Source HTML in `docs/` if you want to regenerate it.
