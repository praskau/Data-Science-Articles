# Source JDs — transcribed from Photos-1-001 (7)

Both are HSBC internal postings at **GCB 4**, India HTC / IND HSDI.

---

## JD-A — job 563774612122322
**Shape:** Head of AI-driven Analytics for Operations

**Principal Accountabilities and Responsibilities** (for Business, Customers and Stakeholders; internal control environment):
- Lead the global strategy and operating model for AI-driven analytics across operations, defining value, risk, and performance KPIs aligned with enterprise priorities.
- Shape and govern multi-agent architectures (e.g. LangGraph), including **Supervisor Agent** frameworks to manage execution, prioritisation, and safe autonomy at scale.
- Build a reusable **capability stack for document intelligence**, validation, and decision reasoning, ensuring structured outputs, schema validation, and full traceability across functions such as collections and underwriting.
- Establish **assurance-by-design**, incorporating reflection, **LLM-vs-LLM validation**, safety controls, and quality standards to deliver reliable, repeatable outcomes across regions.
- Embed **policy intelligence and operational memory** components to drive consistency, reduce operational risk, and strengthen resilience throughout the analytics lifecycle.
- Drive production adoption in collaboration with platform, orchestration and DevOps teams, ensuring explainability, auditability, and compliance with regulatory, data security and internal control requirements.

**Leadership & Teamwork:** analytical vision for operations; stakeholder relationships; strategic problem-solving and innovation; ownership of strategic direction, operational performance and measurable business impact.

**To be successful you will:**
- 13+ years in Analytics or Data Science within financial services, leading large-scale AI / advanced analytics / data transformation programmes.
- Deep expertise shaping and executing Data Science and GenAI strategies — deployment of ML models (deep learning, NLP, RL) and enterprise integration of LLM-based solutions. Highly skilled in prompt engineering, including Chain-of-Thought and advanced prompting frameworks.
- Hands-on designing, institutionalising and scaling **experimentation frameworks (A/B testing)** to validate models and quantify business impact.
- Advanced ML: classification, clustering, ensembles, neural networks; Python and SQL. Well-versed in **model governance, responsible AI, regulatory compliance**.
- Comprehensive understanding of banking operations, regulatory expectations and risk management frameworks; lead high-performing teams; influence senior stakeholders in matrixed environments.
- Exceptional analytical, problem-solving and executive communication; translate complex AI insight into business strategy.

**Functional Knowledge and Leadership:**
- Strategic vision; end-to-end lifecycle of advanced analytical models (development → deployment → validation → optimisation) with robust data governance and data quality.
- Technology acumen: cloud (GCP, AWS, Azure), big data (Spark, Hadoop), analytical tools (Python, R, SQL, SAS). Guide technical architecture and tool selection for **agentic AI** initiatives.
- Hands-on with LLMs, agentic architectures (LangChain, LangGraph), **retrieval-augmented generation, vector databases, knowledge retrieval patterns**.
- Practical exposure to cloud-native engineering, microservices, DevOps tooling, containers (Docker/Kubernetes), ideally within **regulated AI environments**.
- Postgraduate qualification in a quantitative discipline or equivalent experience in DS, ML, NLP or deep learning.

---

## JD-B — job 563774612054236
**Shape:** AI Safety / Guardrails Engineering

**Responsibilities:**
- Design, implement and operate **AI safety detectors** for enterprise AI use cases: prompt injection and jailbreak detection, PII and sensitive data detection, data leakage prevention, content safety and harmful content detection, policy violation checks, **system prompt leakage detection**, and **agent / tool-use risk controls**.
- Implement **detector pipelines** combining rules, ML models, LLM-based evaluators and third-party safety services, with clear interfaces, **confidence scoring** and policy-driven actions.
- Deliver **evaluation workflows for guardrails**: offline test sets, online validation, **threshold tuning**, regression checks, and **false positive / false negative analysis** to measure detector effectiveness in production.
- Design end-to-end **protection patterns** for enterprise RAG, coding assistants and agent systems across **upload, retrieval, prompt, response, logging and tool-execution layers**.
- Build **policy enforcement and decisioning services** with configurable actions: allow, block, redact, mask, escalate for review, require human approval.
- Build **observability and governance** for AI safety: telemetry, tracing, dashboards, audit trails, review workflows, **red team feedback loops**, operational controls.
- Partner with platform / infra / security / AI teams to productionise guardrails with performance controls: **parallel detector execution, tiered detection, graceful degradation, timeout isolation, scalable rollout**.

**Requirements:**
- Bachelor's+ in CS/SWE/AI/ML or equivalent, with strong SWE experience building and operating **distributed, cloud-native backend systems in production**.
- Strong hands-on experience building and operating **production** AI safety / guardrail / content safety / trust & safety / AI risk detection systems — *"rather than only providing architectural guidance, high-level solution design, or developing general-purpose AI applications."*
- Practical experience in several of: prompt injection detection, jailbreak defence, PII detection, sensitive data / data leakage prevention, content safety, policy violation or response validation, system prompt leakage detection, agent safety controls.
- Detection approaches: **rule engines, regex/pattern matching, NER, classifiers, LLM-as-judge, hybrid detector ensembles** — and understanding where each is effective and where it breaks down.
- Evaluation and measurement for safety systems: **precision, recall, threshold design, FP/FN trade-offs, offline and online evaluation, human review workflows**. Safety controls for RAG, enterprise search, coding assistants, copilots, agent-based systems.
- Demonstrated **direct ownership** of implementation and productionisation: developing/integrating detectors, tuning thresholds, building eval workflows, troubleshooting production issues, supporting rollout and operational governance.
- Preferred: developing **first-party detectors**, building **fine-tuning pipelines** for safety/detector use cases, evaluating and productionising industry detector solutions. Strong production engineering: observability, troubleshooting, incident response, performance tuning, reliability engineering under **latency and throughput constraints**.
- Service and API development, data stores, async processing, cloud-native platforms: Kubernetes, Docker, at least one public cloud.
