# Interview prep — question bank with the answers that win

Answers below are compressed to the *shape* of a good response. Rehearse them out loud until the structure is automatic and the words are yours.

## The three sentences to get in early, whatever they ask

1. *"I built a guardrail layer for an agentic document pipeline — five enforcement surfaces, hybrid detector ensemble, and an eval harness that derives thresholds from a cost model rather than picking 0.5."*
2. *"A detector is a model. So under SR 11-7 and PRA SS1/23 it needs development standards, independent validation, ongoing monitoring and a challenge process — and almost nobody building guardrails today treats them that way."*
3. *"My background is risk, so the part I'm strongest on is the part most teams are weakest on: what a false negative actually costs, and who signs off on that number."*

---

## Technical: guardrails

**Q. How would you detect prompt injection?**
Don't answer with a tool. Answer with a layered position. Start with the distinction that matters: *direct* injection arrives at the prompt surface where you at least know it's untrusted; *indirect* injection arrives inside retrieved content the model implicitly trusts, and that's the dangerous one. Then the tiers: deterministic patterns catch the naive case at near-zero latency and fail on paraphrase; a classifier generalises across phrasing and fails on novel families and domain shift; an LLM judge reasons about intent and costs you latency, money and non-determinism. Then the senior point: **detection alone is structurally insufficient.** You also need architectural containment — least-privilege tools, no un-approved side effects on untrusted input, and breaking the "lethal trifecta" of private data + untrusted content + an exfiltration channel. Cite your own numbers: *"my tier-1-only baseline got 0.67 recall and missed every paraphrase attack — here's the table."*

**Q. Rules vs classifiers vs LLM-as-judge — when does each break?**
Rules: exact, auditable, free, and blind to paraphrase; worse, in a legal-document domain the attack vocabulary *is* the business vocabulary, so tightening them costs you true positives. Classifiers: generalise within their training distribution, degrade silently under drift, need retraining and their own validation. LLM judges: strongest at intent, but they carry position bias, verbosity bias and self-preference bias, they're non-deterministic, and — the line to land — *the judge is itself an unvalidated model making a control decision, so it needs a model card and a challenge process too.*

**Q. Your detector has 95% accuracy. Is that good?**
No, and accuracy is the wrong metric. Attacks are rare, so a detector that blocks nothing scores 99%+ on a realistic base rate. Use precision/recall, and use **PR curves rather than ROC**, because under heavy class imbalance ROC is flattered by the large true-negative count. Then pick the operating point from an explicit loss function, not from F1 — F1 silently asserts FP and FN cost the same, which for a safety detector is almost never true.

**Q. Why is your threshold 0.62?**
*(The answer that gets you hired.)* Because a false negative on covenant suppression corrupts a credit decision, a false positive sends one clean document to a human reviewer, and the business owner put that ratio at roughly 100:1. Sweep the threshold, compute expected cost `c_fp·FP + c_fn·FN` at each point, take the minimum. The number falls out of the curve. And the ratio isn't mine to choose — getting the business owner to sign it is what turns a threshold into a risk-appetite statement.

**Q. Guardrails add latency. How do you keep them deployable?**
This is a safety question disguised as a performance question: a guardrail that blows the latency budget gets switched off, so the performance engineering *is* the safety work. Tiered detection — the expensive tier fires only in the uncertainty band, so most traffic never touches the judge. Parallel execution within a tier. Per-detector timeout isolation so a slow detector degrades itself, not the request. Caching. And an explicit fail mode.

**Q. Fail open or fail closed?**
Depends on the surface and on reversibility. On the response and tool surfaces, closed — a leak or an unauthorised action can't be recalled. On low-severity input checks, open — availability matters and the damage is recoverable. What's non-negotiable is that degradation is *logged and alerted*: a guardrail silently failing open is worse than not having one, because it manufactures false assurance.

**Q. How do you handle a novel attack family found in production?**
Closed loop, and I'd walk through it: contain (tighten the threshold on the affected surface — a lever the config already exposes), then add the sample to the eval corpus, then measure whether existing detectors generalise, then retrain or add a detector, then run the regression suite to confirm nothing else regressed, then re-derive the threshold, then roll out with monitoring. The corpus growing is the point — that's the red-team feedback loop, and I'd show the diagram.

## Technical: agentic / JD-A

**Q. When is an agent the right choice?**
When control flow genuinely depends on content that isn't known in advance. Otherwise a pipeline is faster, cheaper and vastly more debuggable. Most "agent" projects are pipelines with worse observability. In AEGIS the supervisor earns its place because document type determines which analysts run.

**Q. How do you make agentic output trustworthy?**
Four things, in order of leverage: structured output with schema validation and a repair loop, so malformed output can't propagate; citation grounding so every claim carries a span reference; a reflection/reviewer node doing LLM-vs-LLM validation; and checkpointing so any run is replayable — which is simultaneously the debugging story and the audit story.

**Q. Multi-agent systems and safe autonomy at scale?**
Autonomy is a spectrum you set per action, not a property of the system. Bound it by blast radius: read-only tools run free, state-changing tools require approval above a value threshold, and the tool surface gets its own guardrail. That's why AEGIS has a tool-execution enforcement point.

## Governance / risk — your home ground

**Q. How do you govern an LLM system in a regulated bank?**
Map it onto model risk management, because that machinery already exists and the regulator already accepts it. Every detector is a model: development standards, independent validation, ongoing performance monitoring, a challenge process. Layer NIST AI RMF's Govern/Map/Measure/Manage for structure, and where EU AI Act high-risk classification bites, Article 15's accuracy/robustness/cybersecurity obligations. The point to make: *most GenAI governance failures are not novel — they're old model-risk failures with new vocabulary.*

**Q. Board asks "is our AI safe?" — what do you say?**
Refuse the binary, then give them something better. Safe against what, at what residual risk, at what cost. Present the control inventory, the measured detector effectiveness with confidence intervals, the known gaps (paraphrase attacks, novel families), the monitoring in place, and the residual risk against appetite. Then the killer: *"here is the specific attack class we currently do not catch, and here is what closing it costs."* Naming your own gap is what makes the rest credible.

## Behavioural — map to your existing work

Draw the hands-on stories from AEGIS; draw these from your HSBC record:
- **Stakeholder influence:** the private credit stress framework built for the Head of Credit, including defending the regression-validity position.
- **Regulatory complexity:** BoE SWES via FIS APT — external mandate, internal constraints, real deadline.
- **Building something new:** the venture debt stress framework and its collateral-melt thesis — a framework where none existed.
- **Translating technical to executive:** the CRO risk metrics map across AIFMD/UCITS/ESMA/CSSF/DFSA.

Each in STAR form, each ending in a number.

## Questions to ask them

- What's the current detector inventory, and what's measured about it today?
- Who owns the FP/FN cost trade-off — engineering, risk, or the business?
- Are guardrails treated as models under the model risk framework, and do they go through validation?
- What's the guardrail latency budget, and has anything ever been switched off to meet it?
- How does a novel attack found in production get back into the eval set?

*These questions are themselves a credential — they're the questions of someone who has run the thing.*

## The gap to name before they find it

You do not have production SWE experience shipping distributed backend systems, and JD-B asks for it explicitly. Don't hide it and don't over-apologise. Say it once, plainly, then redirect: *"I've built and deployed this stack myself, so I'm credible on the engineering — but I won't claim I've run a platform at HSBC scale. What I bring that's scarcer is the measurement and governance layer: I can tell you what your detectors are actually worth and defend it to a regulator."* Naming it first converts your weakest point into evidence of self-assessment, which is a GCB4 competency in its own right.
