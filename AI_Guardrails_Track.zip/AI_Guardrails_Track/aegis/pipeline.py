"""Tiered, parallel, timeout-isolated detector orchestration.

Three production controls JD-B names explicitly live in this file:
  * parallel detector execution   — asyncio.gather within a tier
  * tiered detection              — expensive tiers run only in the
                                    uncertainty band
  * timeout isolation + graceful  — per-detector wait_for; a slow detector
    degradation                     degrades itself, never the request
"""
from __future__ import annotations

import asyncio
import time

from aegis.detectors.base import Detector
from aegis.policy.engine import PolicyEngine
from aegis.types import Decision, Finding, Surface, Tier

# Per-tier timeouts. A guardrail that blows the latency budget gets switched
# off in production — so the performance engineering *is* the safety work.
TIER_TIMEOUT_MS = {Tier.DETERMINISTIC: 50, Tier.MODEL: 300, Tier.JUDGE: 2500}


class GuardrailPipeline:
    def __init__(self, detectors: list[Detector], policy: PolicyEngine) -> None:
        self.detectors = detectors
        self.policy = policy

    async def evaluate(self, text: str, surface: Surface) -> Decision:
        t0 = time.perf_counter()
        findings: list[Finding] = []

        for tier in (Tier.DETERMINISTIC, Tier.MODEL, Tier.JUDGE):
            batch = [
                d for d in self.detectors
                if d.tier is tier and d.applies_to(surface)
            ]
            if not batch:
                continue

            findings += await self._run_tier(batch, text, surface, tier)

            score = self.policy.score(findings, surface)
            if not self._should_escalate_tier(score, surface, tier):
                break

        decision = self.policy.decide(text, findings, surface)
        decision.total_latency_ms = (time.perf_counter() - t0) * 1000
        return decision

    async def _run_tier(
        self, batch: list[Detector], text: str, surface: Surface, tier: Tier
    ) -> list[Finding]:
        timeout = TIER_TIMEOUT_MS[tier] / 1000

        async def guarded(d: Detector) -> Finding:
            try:
                return await asyncio.wait_for(d.run(text, surface), timeout)
            except asyncio.TimeoutError:
                return Finding(
                    detector=d.name, tier=d.tier, fired=False, confidence=0.0,
                    evidence=f"timeout after {timeout * 1000:.0f}ms",
                    degraded=True, latency_ms=timeout * 1000,
                )

        return list(await asyncio.gather(*(guarded(d) for d in batch)))

    def _should_escalate_tier(
        self, score: float, surface: Surface, tier: Tier
    ) -> bool:
        """Run the next (more expensive) tier only inside the uncertainty band.

        Confidently-clean and confidently-dirty inputs are resolved by the
        cheap tier. Everything else buys a more expensive opinion. Widening
        this band trades cost for recall — an explicit, tunable dial, and the
        thing Week 6's cost model actually calibrates.
        """
        if tier is Tier.JUDGE:
            return False
        t = self.policy.thresholds_for(surface)
        low = min(t.values()) if t else 0.35
        high = max(t.values()) if t else 0.85
        return low * 0.5 <= score < high
