"""Offline evaluation: PR curves, cost-derived thresholds, error taxonomy.

This module is the heart of the interview case. Everything here answers one
question a hiring manager will absolutely ask:

    "Why is your threshold 0.62?"

The wrong answer is "it worked well." The right answer is: because false
negatives cost ~100x false positives in this use case, attacks are rare, and
that is where the expected-cost curve bottoms out. That reasoning is standard
practice in risk management and almost absent from guardrail engineering,
which is precisely the gap this project exploits.
"""
from __future__ import annotations

import asyncio
import json
from dataclasses import asdict, dataclass
from pathlib import Path

from aegis.pipeline import GuardrailPipeline
from aegis.types import Surface


@dataclass
class Example:
    id: str
    text: str
    surface: Surface
    label: int          # 1 = attack, 0 = benign
    family: str         # attack family, or "hard_negative" / "benign"
    notes: str = ""


@dataclass
class Metrics:
    threshold: float
    tp: int
    fp: int
    tn: int
    fn: int

    @property
    def precision(self) -> float:
        return self.tp / (self.tp + self.fp) if (self.tp + self.fp) else 0.0

    @property
    def recall(self) -> float:
        return self.tp / (self.tp + self.fn) if (self.tp + self.fn) else 0.0

    def fbeta(self, beta: float = 2.0) -> float:
        """F-beta, beta>1 weights recall.

        F1 is the wrong default here: it implicitly asserts that a false
        positive and a false negative cost the same, which is almost never
        true for a safety detector.
        """
        p, r = self.precision, self.recall
        if p == 0 and r == 0:
            return 0.0
        b2 = beta ** 2
        return (1 + b2) * p * r / (b2 * p + r)

    def expected_cost(self, c_fp: float, c_fn: float) -> float:
        return c_fp * self.fp + c_fn * self.fn


def load_corpus(path: Path | str) -> list[Example]:
    rows = [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]
    return [Example(surface=Surface(r.pop("surface")), **r) for r in rows]


async def score_corpus(
    pipeline: GuardrailPipeline, corpus: list[Example]
) -> list[tuple[Example, float]]:
    async def one(ex: Example) -> tuple[Example, float]:
        d = await pipeline.evaluate(ex.text, ex.surface)
        return ex, d.score

    return list(await asyncio.gather(*(one(e) for e in corpus)))


def sweep(
    scored: list[tuple[Example, float]], steps: int = 101
) -> list[Metrics]:
    out = []
    for i in range(steps):
        t = i / (steps - 1)
        m = Metrics(t, 0, 0, 0, 0)
        for ex, s in scored:
            # s == 0 means no detector fired at all; that is never a positive,
            # otherwise the t=0 sweep point degenerates to "block everything"
            # and the cost model happily picks it.
            pred = s > 0 and s >= t
            if pred and ex.label:
                m.tp += 1
            elif pred and not ex.label:
                m.fp += 1
            elif not pred and ex.label:
                m.fn += 1
            else:
                m.tn += 1
        out.append(m)
    return out


def optimal_threshold(
    curve: list[Metrics], c_fp: float = 1.0, c_fn: float = 100.0
) -> Metrics:
    """Pick the threshold that minimises expected cost.

    Defaults encode the covenant-suppression case: missing an injection that
    corrupts a credit decision is ~100x worse than sending one clean document
    to a human reviewer. Change these numbers per use case — and make the
    business owner sign off on them. That sign-off *is* the risk appetite
    statement, and putting it in front of a business owner rather than
    choosing it yourself is the governance point.
    """
    return min(curve, key=lambda m: m.expected_cost(c_fp, c_fn))


def error_taxonomy(
    scored: list[tuple[Example, float]], threshold: float
) -> dict[str, dict[str, int]]:
    """Bucket errors by attack family. Counting errors tells you how bad you
    are; bucketing them tells you what to fix next."""
    tax: dict[str, dict[str, int]] = {}
    for ex, s in scored:
        b = tax.setdefault(ex.family, {"fn": 0, "fp": 0, "ok": 0})
        pred = s > 0 and s >= threshold
        if ex.label and not pred:
            b["fn"] += 1
        elif not ex.label and pred:
            b["fp"] += 1
        else:
            b["ok"] += 1
    return tax


def report(scored: list[tuple[Example, float]], c_fp: float, c_fn: float) -> dict:
    curve = sweep(scored)
    best = optimal_threshold(curve, c_fp, c_fn)
    return {
        "n": len(scored),
        "n_attacks": sum(1 for e, _ in scored if e.label),
        "cost_ratio_fn_over_fp": c_fn / c_fp,
        "chosen_threshold": best.threshold,
        "at_threshold": {
            **asdict(best),
            "precision": round(best.precision, 4),
            "recall": round(best.recall, 4),
            "f2": round(best.fbeta(2.0), 4),
            "expected_cost": best.expected_cost(c_fp, c_fn),
        },
        "pr_curve": [
            {"t": round(m.threshold, 3), "p": round(m.precision, 4),
             "r": round(m.recall, 4)}
            for m in curve
        ],
        "error_taxonomy": error_taxonomy(scored, best.threshold),
    }
