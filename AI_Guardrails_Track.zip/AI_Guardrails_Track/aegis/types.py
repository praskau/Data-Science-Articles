"""Core types for the AEGIS guardrail layer."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Surface(str, Enum):
    """The five enforcement points. Threat profile differs at each."""

    UPLOAD = "upload"
    RETRIEVAL = "retrieval"
    PROMPT = "prompt"
    RESPONSE = "response"
    TOOL = "tool"


class Action(str, Enum):
    """Policy outcomes, ordered by severity."""

    ALLOW = "allow"
    REDACT = "redact"
    MASK = "mask"
    ESCALATE = "escalate"
    REQUIRE_APPROVAL = "require_approval"
    BLOCK = "block"


class Tier(int, Enum):
    """Detection tiers. Cheap first, expensive only when uncertain."""

    DETERMINISTIC = 1  # regex, NER, canary   — target < 10ms
    MODEL = 2          # classifiers, NLI     — target < 150ms
    JUDGE = 3          # LLM-as-judge         — target < 2000ms


@dataclass
class Finding:
    """One detector's verdict on one payload."""

    detector: str
    tier: Tier
    fired: bool
    confidence: float          # 0.0-1.0, calibrated where possible
    evidence: str = ""         # the span that triggered it — required for audit
    latency_ms: float = 0.0
    degraded: bool = False     # True if detector timed out / errored
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class Decision:
    """The auditable record. Everything a reviewer or regulator needs."""

    surface: Surface
    action: Action
    score: float
    findings: list[Finding]
    policy_version: str
    thresholds: dict[str, float]   # thresholds *in force at decision time*
    transformed_text: str | None = None   # after redact/mask
    trace_id: str = ""
    total_latency_ms: float = 0.0

    @property
    def blocked(self) -> bool:
        return self.action in (Action.BLOCK, Action.REQUIRE_APPROVAL)
