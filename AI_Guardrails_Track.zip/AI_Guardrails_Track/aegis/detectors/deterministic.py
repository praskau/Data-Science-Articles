"""Tier-1 detectors: deterministic, cheap, always-on.

These catch the naive case with certainty and near-zero latency. They are
*not* sufficient — every one of them fails against paraphrase — which is
exactly why tiers 2 and 3 exist. Know where each breaks down.
"""
from __future__ import annotations

import math
import re
import unicodedata

from aegis.detectors.base import Detector
from aegis.types import Finding, Surface, Tier

# Known injection phrasings. Catches lazy attacks; misses everything creative.
_INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?(previous|prior|above)\s+instructions?",
    r"disregard\s+(the\s+)?(system|previous)\s+(prompt|instructions?)",
    r"you\s+are\s+now\s+(a|an|in)\s+",
    r"</?(system|instruction|admin)>",
    r"reveal\s+(your|the)\s+(system\s+)?prompt",
    r"print\s+(your|the)\s+(instructions?|system\s+prompt)",
    r"do\s+anything\s+now|\bDAN\b",
]

# Invisible-text tricks — the ones that matter for document ingestion.
_ZERO_WIDTH = re.compile(r"[​-‏⁠-⁯﻿]")
_TAG_CHARS = re.compile(r"[\U000E0000-\U000E007F]")  # Unicode tag block smuggling


class RegexInjectionDetector(Detector):
    name = "regex_injection"
    tier = Tier.DETERMINISTIC
    surfaces = (Surface.UPLOAD, Surface.RETRIEVAL, Surface.PROMPT)

    def __init__(self) -> None:
        self._rx = [re.compile(p, re.I) for p in _INJECTION_PATTERNS]

    async def _detect(self, text: str, surface: Surface) -> Finding:
        for rx in self._rx:
            if m := rx.search(text):
                return Finding(
                    detector=self.name,
                    tier=self.tier,
                    fired=True,
                    # Deliberately not 1.0: a pattern match is strong evidence
                    # of intent, not proof. Reserve 1.0 for tautologies.
                    confidence=0.85,
                    evidence=_span(text, m.start(), m.end()),
                    meta={"pattern": rx.pattern},
                )
        return Finding(self.name, self.tier, False, 0.0)


class InvisibleTextDetector(Detector):
    """The document-ingestion threat: payloads a human reviewer cannot see.

    Zero-width chars, Unicode tag-block smuggling, and (via meta) a hook for
    the PDF layer to report white-on-white or sub-2pt text.
    """

    name = "invisible_text"
    tier = Tier.DETERMINISTIC
    surfaces = (Surface.UPLOAD, Surface.RETRIEVAL)

    async def _detect(self, text: str, surface: Surface) -> Finding:
        zw = _ZERO_WIDTH.findall(text)
        tags = _TAG_CHARS.findall(text)
        if not zw and not tags:
            return Finding(self.name, self.tier, False, 0.0)
        decoded = "".join(
            chr(ord(c) - 0xE0000) for c in tags if 0xE0020 <= ord(c) <= 0xE007E
        )
        return Finding(
            detector=self.name,
            tier=self.tier,
            fired=True,
            confidence=0.9 if tags else 0.6,
            evidence=f"{len(zw)} zero-width, {len(tags)} tag chars"
            + (f"; decoded: {decoded[:120]!r}" if decoded else ""),
            meta={"zero_width": len(zw), "tag_chars": len(tags)},
        )


class CanaryLeakDetector(Detector):
    """System-prompt leakage, detected deterministically.

    Seed a unique token in the system prompt; if it appears in output, the
    prompt leaked. Cheap, exact, zero false positives. Breaks down when the
    attacker asks the model to *paraphrase* its instructions rather than
    quote them — which is why the LLM judge also covers this surface.
    """

    name = "canary_leak"
    tier = Tier.DETERMINISTIC
    surfaces = (Surface.RESPONSE,)

    def __init__(self, canary: str) -> None:
        self.canary = canary

    async def _detect(self, text: str, surface: Surface) -> Finding:
        if self.canary in text:
            return Finding(
                self.name, self.tier, True, 1.0,
                evidence="canary token present in model output",
            )
        return Finding(self.name, self.tier, False, 0.0)


class SecretsDetector(Detector):
    """High-entropy strings and known credential shapes."""

    name = "secrets"
    tier = Tier.DETERMINISTIC
    surfaces = (Surface.RESPONSE, Surface.TOOL, Surface.UPLOAD)

    _KNOWN = re.compile(
        r"\b(sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{36}|AKIA[0-9A-Z]{16})\b"
    )

    async def _detect(self, text: str, surface: Surface) -> Finding:
        if m := self._KNOWN.search(text):
            return Finding(
                self.name, self.tier, True, 0.95,
                evidence=f"credential-shaped token at {m.start()}",
            )
        for tok in re.findall(r"[A-Za-z0-9+/=_\-]{32,}", text):
            if _shannon(tok) > 4.2:
                return Finding(
                    self.name, self.tier, True, 0.55,
                    evidence=f"high-entropy token (H={_shannon(tok):.2f})",
                    meta={"note": "entropy heuristic — expect false positives on hashes"},
                )
        return Finding(self.name, self.tier, False, 0.0)


def _shannon(s: str) -> float:
    if not s:
        return 0.0
    counts = {c: s.count(c) for c in set(s)}
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _span(text: str, start: int, end: int, pad: int = 40) -> str:
    lo, hi = max(0, start - pad), min(len(text), end + pad)
    return unicodedata.normalize("NFKC", text[lo:hi]).replace("\n", " ")
