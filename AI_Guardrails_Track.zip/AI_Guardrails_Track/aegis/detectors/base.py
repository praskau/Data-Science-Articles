"""Detector ABC. Every detector returns the same shape so the ensemble
can weight, compare and audit them uniformly."""
from __future__ import annotations

import abc
import time

from aegis.types import Finding, Surface, Tier


class Detector(abc.ABC):
    name: str = "unnamed"
    tier: Tier = Tier.DETERMINISTIC
    surfaces: tuple[Surface, ...] = tuple(Surface)

    #: measured precision on the eval corpus; used to weight the ensemble.
    #: Deliberately starts at None so an unvalidated detector cannot silently
    #: acquire influence — an unmeasured detector is an ungoverned model.
    measured_precision: float | None = None

    def applies_to(self, surface: Surface) -> bool:
        return surface in self.surfaces

    @abc.abstractmethod
    async def _detect(self, text: str, surface: Surface) -> Finding:
        """Implement in subclass. Do not time it — run() handles that."""

    async def run(self, text: str, surface: Surface) -> Finding:
        t0 = time.perf_counter()
        try:
            finding = await self._detect(text, surface)
        except Exception as exc:  # graceful degradation, never break the caller
            finding = Finding(
                detector=self.name,
                tier=self.tier,
                fired=False,
                confidence=0.0,
                evidence=f"detector error: {type(exc).__name__}",
                degraded=True,
            )
        finding.latency_ms = (time.perf_counter() - t0) * 1000
        return finding
