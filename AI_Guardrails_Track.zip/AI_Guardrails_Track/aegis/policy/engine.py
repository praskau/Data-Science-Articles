"""Policy engine: config-driven enforcement across all five surfaces.

The whole point is that surfaces differ in policy, not in code. Adding a
surface rule must never require a deploy of new logic — that is what makes
this a platform capability rather than an app feature.
"""
from __future__ import annotations

import re
import uuid
from pathlib import Path

import yaml

from aegis.types import Action, Decision, Finding, Surface

_DEFAULT_POLICY = Path(__file__).parent / "policy.yaml"


class PolicyEngine:
    def __init__(self, path: Path | str = _DEFAULT_POLICY) -> None:
        raw = yaml.safe_load(Path(path).read_text())
        self.version: str = raw["version"]
        self.rules: dict = raw["surfaces"]
        self.fail_mode: dict = raw.get("fail_mode", {})

    def thresholds_for(self, surface: Surface) -> dict[str, float]:
        return dict(self.rules[surface.value].get("thresholds", {}))

    def score(self, findings: list[Finding], surface: Surface) -> float:
        """Weighted ensemble score.

        Not a mean. Averaging lets a silent detector dilute a confident one,
        which is exactly backwards when the rare event is the one that matters.
        We take the strongest signal, weighted by each detector's *measured*
        precision, so an unvalidated detector cannot dominate.
        """
        best = 0.0
        for f in findings:
            if not f.fired:
                continue
            weight = self.rules[surface.value].get("weights", {}).get(f.detector, 1.0)
            best = max(best, f.confidence * weight)
        return min(best, 1.0)

    def decide(
        self,
        text: str,
        findings: list[Finding],
        surface: Surface,
        trace_id: str | None = None,
    ) -> Decision:
        cfg = self.rules[surface.value]
        score = self.score(findings, surface)
        thresholds = self.thresholds_for(surface)

        # Degraded detectors: fail-closed on output surfaces (a leak is
        # irreversible), fail-open on input surfaces (availability matters and
        # the damage is recoverable). Be ready to defend this in interview.
        degraded = [f for f in findings if f.degraded]
        if degraded and surface in (Surface.RESPONSE, Surface.TOOL):
            if self.fail_mode.get("response", "closed") == "closed":
                return Decision(
                    surface, Action.ESCALATE, score, findings, self.version,
                    thresholds, trace_id=trace_id or _tid(),
                )

        action = Action.ALLOW
        # Bands are ordered most-severe first; first match wins.
        for band in cfg["bands"]:
            if score >= band["min_score"]:
                action = Action(band["action"])
                break

        transformed = None
        if action in (Action.REDACT, Action.MASK):
            transformed = _apply_redaction(text, findings, action)

        return Decision(
            surface=surface,
            action=action,
            score=score,
            findings=findings,
            policy_version=self.version,
            thresholds=thresholds,
            transformed_text=transformed,
            trace_id=trace_id or _tid(),
        )


def _apply_redaction(text: str, findings: list[Finding], action: Action) -> str:
    out = text
    for f in findings:
        if not f.fired or not f.evidence:
            continue
        for span in f.meta.get("spans", []):
            repl = "[REDACTED]" if action is Action.REDACT else "*" * len(span)
            out = out.replace(span, repl)
    return out


def _tid() -> str:
    return uuid.uuid4().hex[:16]
