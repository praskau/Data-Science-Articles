"""FastAPI surface. Guardrails as a *service*, not a library import —
that is what makes it reusable across use cases, and what JD-B means by
'policy enforcement and decisioning services'."""
from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel, Field

from aegis.detectors.deterministic import (
    CanaryLeakDetector,
    InvisibleTextDetector,
    RegexInjectionDetector,
    SecretsDetector,
)
from aegis.pipeline import GuardrailPipeline
from aegis.policy.engine import PolicyEngine
from aegis.types import Surface

CANARY = "AEGIS-CANARY-7f3a91c4"

app = FastAPI(title="AEGIS Guardrail Service", version="0.1.0")

_policy = PolicyEngine()
_pipeline = GuardrailPipeline(
    detectors=[
        RegexInjectionDetector(),
        InvisibleTextDetector(),
        SecretsDetector(),
        CanaryLeakDetector(CANARY),
        # Week 5: InjectionDetector, GroundednessDetector, LLMJudgeDetector
    ],
    policy=_policy,
)


class GuardRequest(BaseModel):
    text: str
    surface: Surface = Field(default=Surface.PROMPT)


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok", "policy_version": _policy.version}


@app.post("/v1/guard")
async def guard(req: GuardRequest) -> dict:
    d = await _pipeline.evaluate(req.text, req.surface)
    return {
        "action": d.action,
        "score": round(d.score, 4),
        "blocked": d.blocked,
        "trace_id": d.trace_id,
        "policy_version": d.policy_version,
        "thresholds_in_force": d.thresholds,
        "latency_ms": round(d.total_latency_ms, 2),
        "transformed_text": d.transformed_text,
        "findings": [
            {
                "detector": f.detector, "tier": int(f.tier), "fired": f.fired,
                "confidence": round(f.confidence, 4), "evidence": f.evidence,
                "latency_ms": round(f.latency_ms, 2), "degraded": f.degraded,
            }
            for f in d.findings
        ],
    }
