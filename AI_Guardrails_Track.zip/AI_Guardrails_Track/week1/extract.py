"""Week 1 deliverable: PDF -> validated CreditAgreement, with cost accounting.

Three things here are the actual lesson, and all three are what separates
enterprise LLM work from notebook LLM work:

  1. SCHEMA VALIDATION AS A GATE. The model's output either conforms or it
     does not reach the caller. No "mostly right" JSON downstream.
  2. A REPAIR LOOP. When validation fails, feed the error back rather than
     retrying blind. Blind retries burn money re-making the same mistake.
  3. COST AND LATENCY ACCOUNTING PER CALL. You cannot govern what you do not
     measure, and in Week 6 you will need this data to argue about thresholds.

Usage:
    python week1/extract.py data/agreements/meridian_foods_sfa.pdf
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path

import anthropic
from pydantic import ValidationError
from pypdf import PdfReader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from schema import CreditAgreement  # noqa: E402

MODEL = "claude-opus-5"

# Published rates for claude-opus-5, USD per million tokens.
# Keep these in one place — a hardcoded price buried in a log line is how
# cost reporting silently goes stale.
PRICE_IN_PER_MTOK = 5.00
PRICE_OUT_PER_MTOK = 25.00

SYSTEM = """You extract structured data from private credit and leveraged finance \
documents for a credit risk team.

Rules you must follow:
- Extract only what the document states. Never infer a covenant level, a margin, \
or a test result that is not written down.
- Quote verbatim in `source_quote` and give the 1-indexed `source_page`. If you \
cannot locate a supporting sentence, leave both null rather than inventing one.
- Where a document is ambiguous, conflicting, or silent on something a credit \
analyst would expect, record it in `extraction_notes` instead of guessing.
- Margins: convert to basis points. "6.75 per cent per annum" is 675.
- Amounts: numeric only, no separators or currency symbols.
- A covenant that is stated but not yet tested has status `not_tested`. A \
covenant breached and then waived has status `waived`, not `complied`."""


@dataclass
class CallRecord:
    """One API call, measured. This is the raw material for every later
    conversation about cost, latency and reliability."""

    attempt: int
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    latency_ms: float
    valid: bool
    error: str | None = None

    @property
    def cost_usd(self) -> float:
        return (
            self.input_tokens / 1_000_000 * PRICE_IN_PER_MTOK
            + self.output_tokens / 1_000_000 * PRICE_OUT_PER_MTOK
        )


@dataclass
class ExtractionResult:
    source: str
    agreement: CreditAgreement | None
    calls: list[CallRecord] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.agreement is not None

    @property
    def total_cost_usd(self) -> float:
        return sum(c.cost_usd for c in self.calls)

    @property
    def total_latency_ms(self) -> float:
        return sum(c.latency_ms for c in self.calls)

    @property
    def repair_attempts(self) -> int:
        return max(0, len(self.calls) - 1)


def read_pdf(path: Path) -> str:
    """Page-tagged text so the model can cite a page number honestly.

    Note how crude this is — pypdf flattens tables into column-order runs, which
    is precisely the failure Week 3 exists to fix. Seeing it break here first is
    the point; do not reach for a better parser yet.
    """
    reader = PdfReader(str(path))
    return "\n\n".join(
        f"<page number=\"{i}\">\n{(p.extract_text() or '').strip()}\n</page>"
        for i, p in enumerate(reader.pages, start=1)
    )


def extract(
    path: Path,
    client: anthropic.Anthropic,
    max_repairs: int = 2,
    verbose: bool = True,
) -> ExtractionResult:
    text = read_pdf(path)
    result = ExtractionResult(source=path.name, agreement=None)

    messages: list[dict] = [{
        "role": "user",
        "content": (
            f"Extract the credit agreement below into the required schema.\n\n"
            f"<document name=\"{path.name}\">\n{text}\n</document>"
        ),
    }]

    for attempt in range(max_repairs + 1):
        t0 = time.perf_counter()
        response = client.messages.create(
            model=MODEL,
            max_tokens=16000,
            system=SYSTEM,
            thinking={"type": "adaptive"},
            output_config={
                "format": {
                    "type": "json_schema",
                    "schema": CreditAgreement.model_json_schema(),
                }
            },
            messages=messages,
        )
        latency_ms = (time.perf_counter() - t0) * 1000

        raw = "".join(b.text for b in response.content if b.type == "text")

        try:
            agreement = CreditAgreement.model_validate_json(raw)
            err = None
        except ValidationError as exc:
            agreement, err = None, _compact_errors(exc)
        except json.JSONDecodeError as exc:
            agreement, err = None, f"not valid JSON: {exc}"

        record = CallRecord(
            attempt=attempt,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            cache_read_tokens=getattr(response.usage, "cache_read_input_tokens", 0) or 0,
            latency_ms=latency_ms,
            valid=agreement is not None,
            error=err,
        )
        result.calls.append(record)

        if verbose:
            state = "valid" if record.valid else f"INVALID — {err[:70]}"
            print(f"    attempt {attempt}: {latency_ms:6.0f}ms  "
                  f"${record.cost_usd:.4f}  {state}")

        if agreement is not None:
            result.agreement = agreement
            return result

        if attempt == max_repairs:
            break

        # The repair loop. Show the model its own output and the specific
        # validation failure — a blind retry just re-rolls the same dice.
        messages += [
            {"role": "assistant", "content": raw},
            {"role": "user", "content":
                f"That output failed schema validation:\n\n{err}\n\n"
                "Return the corrected JSON. Fix only the invalid fields; keep "
                "everything else identical."},
        ]

    return result


def _compact_errors(exc: ValidationError, limit: int = 6) -> str:
    lines = []
    for e in exc.errors()[:limit]:
        loc = ".".join(str(p) for p in e["loc"])
        lines.append(f"  {loc}: {e['msg']}")
    extra = len(exc.errors()) - limit
    if extra > 0:
        lines.append(f"  ... and {extra} more")
    return "\n".join(lines)


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    path = Path(sys.argv[1])
    client = anthropic.Anthropic()

    print(f"\n  {path.name}")
    result = extract(path, client)

    if not result.succeeded:
        print("\n  FAILED after all repair attempts.")
        sys.exit(1)

    a = result.agreement
    print(f"\n  {a.borrower_name} — {a.agreement_type} ({a.agreement_date})")
    print(f"  {a.reference_rate} + {a.margin_bps}bps, maturity {a.maturity_date}")
    print(f"  {len(a.facilities)} facilities, {len(a.covenants)} covenants")
    for c in a.covenants:
        page = f"p.{c.source_page}" if c.source_page else "no cite"
        print(f"    · {c.covenant_type.value:22s} {str(c.level):18s} "
              f"{c.status.value:10s} [{page}]")
    if a.extraction_notes:
        print("  notes:")
        for n in a.extraction_notes:
            print(f"    ! {n}")

    print(f"\n  {len(result.calls)} call(s), {result.repair_attempts} repair(s), "
          f"${result.total_cost_usd:.4f}, {result.total_latency_ms:.0f}ms")

    out = Path("data/extracted") / f"{path.stem}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "agreement": a.model_dump(mode="json"),
        "calls": [asdict(c) | {"cost_usd": c.cost_usd} for c in result.calls],
    }, indent=2))
    print(f"  -> {out}")


if __name__ == "__main__":
    main()
