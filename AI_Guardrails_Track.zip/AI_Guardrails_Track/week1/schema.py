"""The extraction target.

Design note worth internalising: this schema is a *control*, not a convenience.
Every constraint here — the enums, the ranges, the required fields — is a check
the model's output must pass before anything downstream sees it. Loosen the
schema and you have moved the validation burden to a human who will not do it.

Notice `source_page` and `source_quote` on every covenant. Traceability is not
a feature you add later; if it isn't in the schema it will never exist.
"""
from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


class Currency(str, Enum):
    GBP = "GBP"
    EUR = "EUR"
    USD = "USD"
    OTHER = "OTHER"


class CovenantType(str, Enum):
    TOTAL_NET_LEVERAGE = "total_net_leverage"
    SENIOR_LEVERAGE = "senior_leverage"
    INTEREST_COVER = "interest_cover"
    FIXED_CHARGE_COVER = "fixed_charge_cover"
    CASHFLOW_COVER = "cashflow_cover"
    CAPEX_LIMIT = "capex_limit"
    MINIMUM_LIQUIDITY = "minimum_liquidity"
    MINIMUM_EBITDA = "minimum_ebitda"
    OTHER = "other"


class TestStatus(str, Enum):
    COMPLIED = "complied"
    BREACHED = "breached"
    WAIVED = "waived"
    NOT_TESTED = "not_tested"
    UNKNOWN = "unknown"


class Covenant(BaseModel):
    covenant_type: CovenantType
    description: str = Field(description="The covenant as described in the document")
    level: str | None = Field(
        default=None,
        description="Threshold as written, e.g. '4.00:1.00' or 'GBP 4,500,000'",
    )
    direction: Literal["maximum", "minimum", "absolute", "unknown"] = Field(
        default="unknown",
        description="Whether the borrower must stay below, above, or at the level",
    )
    test_date: str | None = Field(default=None, description="Most recent test date as written")
    actual_value: str | None = Field(default=None, description="Actual as at test date")
    status: TestStatus = TestStatus.UNKNOWN
    step_downs: list[str] = Field(
        default_factory=list,
        description="Future changes to the level, each as a single sentence",
    )
    # Traceability — never optional in spirit, even though the model may miss it.
    source_page: int | None = Field(default=None, description="1-indexed page number")
    source_quote: str | None = Field(
        default=None, description="Verbatim sentence supporting this covenant"
    )


class Facility(BaseModel):
    name: str = Field(description="e.g. 'Facility A', 'Revolving Facility'")
    facility_type: str = Field(description="e.g. term loan, delayed draw, RCF, unitranche")
    commitment_amount: float | None = Field(default=None, description="Numeric, no separators")
    currency: Currency = Currency.OTHER


class CreditAgreement(BaseModel):
    """One extracted agreement. This object is what a credit decision would consume."""

    borrower_name: str
    agreement_type: str = Field(description="e.g. Senior Facilities Agreement, Amendment")
    agreement_date: str | None = Field(default=None, description="As written in the document")
    governing_lender: str | None = Field(default=None, description="Agent or original lender")

    facilities: list[Facility] = Field(default_factory=list)
    total_commitment: float | None = None
    currency: Currency = Currency.OTHER

    margin_bps: int | None = Field(
        default=None, description="Margin over the reference rate, in basis points"
    )
    reference_rate: str | None = Field(default=None, description="e.g. SONIA, EURIBOR, SOFR")
    maturity_date: str | None = None

    covenants: list[Covenant] = Field(default_factory=list)
    has_equity_cure: bool | None = None
    equity_cure_terms: str | None = None

    # The model must say when it is unsure. A field it cannot populate honestly
    # is more useful than a field it guesses.
    extraction_notes: list[str] = Field(
        default_factory=list,
        description="Ambiguities, conflicts, or anything a human should verify",
    )
