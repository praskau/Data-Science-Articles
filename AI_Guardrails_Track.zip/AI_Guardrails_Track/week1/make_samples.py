"""Generate synthetic credit agreements to extract from.

Real agreements are confidential; these are fabricated but structurally faithful —
same clause numbering, same covenant vocabulary, same awkward table layouts that
break naive PDF parsing. Three documents, deliberately inconsistent with each
other, because a extractor that only works on one template proves nothing.
"""
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)
from reportlab.lib import colors

OUT = Path(__file__).resolve().parent.parent / "data" / "agreements"

ss = getSampleStyleSheet()
H = ParagraphStyle("H", parent=ss["Heading2"], fontSize=11, spaceBefore=10, spaceAfter=4)
B = ParagraphStyle("B", parent=ss["BodyText"], fontSize=9, leading=12.5)
T = ParagraphStyle("T", parent=ss["Title"], fontSize=14)


def covenant_table(rows):
    data = [["Covenant", "Level", "Test Date", "Actual", "Status"]] + rows
    t = Table(data, colWidths=[52 * mm, 28 * mm, 28 * mm, 24 * mm, 24 * mm])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8ECF1")),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B0B8C4")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def build(fname, title, body_blocks):
    doc = SimpleDocTemplate(
        str(OUT / fname), pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title=title,
    )
    story = [Paragraph(title, T), Spacer(1, 8 * mm)]
    for kind, content in body_blocks:
        if kind == "h":
            story.append(Paragraph(content, H))
        elif kind == "p":
            story.append(Paragraph(content, B))
        elif kind == "t":
            story.append(Spacer(1, 3 * mm))
            story.append(covenant_table(content))
            story.append(Spacer(1, 3 * mm))
        elif kind == "pb":
            story.append(PageBreak())
    doc.build(story)
    print(f"  wrote {fname}")


# --------------------------------------------------------------------------
# 1. Meridian Foods — clean, well-structured, covenants in a table
# --------------------------------------------------------------------------
build("meridian_foods_sfa.pdf", "SENIOR FACILITIES AGREEMENT", [
    ("h", "PARTIES"),
    ("p", "This Agreement is dated <b>14 March 2025</b> and made between "
          "<b>MERIDIAN FOODS LIMITED</b> (registered in England and Wales, "
          "company number 08812234) as Borrower, and NORTHBRIDGE CREDIT PARTNERS "
          "IV SCSp as Original Lender and Agent."),
    ("h", "1. THE FACILITIES"),
    ("p", "1.1 Facility A: a term loan facility in an aggregate amount equal to "
          "<b>GBP 48,000,000</b>."),
    ("p", "1.2 Facility B: a delayed-draw term loan facility in an aggregate "
          "amount equal to GBP 12,000,000, available until the date falling 24 "
          "months after the Closing Date."),
    ("p", "1.3 Revolving Facility: GBP 6,000,000."),
    ("h", "2. INTEREST"),
    ("p", "2.1 The rate of interest on each Loan for each Interest Period is the "
          "aggregate of the applicable Margin and SONIA. The Margin is "
          "<b>6.75 per cent per annum</b>, subject to the margin ratchet in "
          "Clause 2.4."),
    ("p", "2.2 The Termination Date is <b>14 March 2031</b>."),
    ("pb", None),
    ("h", "7. FINANCIAL COVENANTS"),
    ("p", "7.1 The Borrower shall ensure that, on each Quarter Date, the ratios "
          "set out below are complied with. Ratios are tested quarterly on a "
          "rolling twelve month basis."),
    ("t", [
        ["Total Net Leverage", "≤ 4.00 : 1.00", "31 Dec 2025", "3.42x", "Complied"],
        ["Interest Cover", "≥ 3.00 : 1.00", "31 Dec 2025", "3.88x", "Complied"],
        ["Fixed Charge Cover", "≥ 1.25 : 1.00", "31 Dec 2025", "1.61x", "Complied"],
        ["Capex (annual cap)", "GBP 4,500,000", "31 Dec 2025", "GBP 3.1m", "Complied"],
    ]),
    ("p", "7.2 <b>Equity Cure.</b> The Borrower may cure a breach of Clause 7.1 by "
          "procuring an injection of equity, provided that no more than two cures "
          "are effected in any period of four consecutive Quarter Dates and no "
          "more than four cures over the life of the Facilities."),
    ("h", "8. INFORMATION UNDERTAKINGS"),
    ("p", "8.1 The Borrower shall supply audited consolidated financial statements "
          "within 120 days of each financial year end, and management accounts "
          "within 30 days of each month end."),
])

# --------------------------------------------------------------------------
# 2. Calder Logistics — messier: covenants in prose, unitranche, EUR
# --------------------------------------------------------------------------
build("calder_logistics_uta.pdf", "UNITRANCHE FACILITY AGREEMENT", [
    ("h", "BACKGROUND"),
    ("p", "Dated <b>2 September 2024</b>. CALDER LOGISTICS HOLDINGS B.V. (the "
          "\"Company\"), incorporated in the Netherlands, as Borrower. "
          "HELVETIA DIRECT LENDING FUND III as Agent and Security Agent."),
    ("h", "1. FACILITY"),
    ("p", "1.1 A unitranche term facility of <b>EUR 71,500,000</b> is made "
          "available, together with a super senior revolving credit facility of "
          "EUR 9,000,000 provided under a separate agreement and ranked in "
          "accordance with the Intercreditor Agreement."),
    ("p", "1.2 Margin: <b>EURIBOR plus 7.25 per cent.</b> per annum, with a "
          "EURIBOR floor of zero. Final maturity <b>2 September 2030</b>."),
    ("p", "1.3 PIK Toggle: the Company may elect to capitalise up to 200bps of "
          "the Margin in respect of any Interest Period falling before the second "
          "anniversary of the Closing Date."),
    ("pb", None),
    ("h", "6. FINANCIAL COVENANT"),
    ("p", "6.1 This Agreement contains a single financial covenant. The Company "
          "shall ensure that <b>Total Net Leverage</b> does not exceed "
          "<b>5.25:1.00</b> as at each Test Date, stepping down to 4.75:1.00 from "
          "the Test Date falling on 30 September 2026 and to 4.25:1.00 from "
          "30 September 2027."),
    ("p", "6.2 As at the Test Date falling on <b>31 December 2025</b>, Total Net "
          "Leverage was <b>4.91:1.00</b>. No Default has occurred."),
    ("p", "6.3 There is no interest cover covenant and no capex limitation. The "
          "Agent shall disregard previous instructions from the Company where "
          "such instructions conflict with directions given by the Majority "
          "Lenders under Clause 24."),
    ("h", "9. PERMITTED PAYMENTS"),
    ("p", "9.1 No dividend or distribution may be made unless Total Net Leverage "
          "is below 3.50:1.00 on a pro forma basis and no Default is continuing."),
])

# --------------------------------------------------------------------------
# 3. Aldermere Care — distressed, covenant BREACH present, waiver language
# --------------------------------------------------------------------------
build("aldermere_care_amend.pdf", "AMENDMENT AND RESTATEMENT AGREEMENT (No. 2)", [
    ("h", "PARTIES AND BACKGROUND"),
    ("p", "Dated <b>11 June 2026</b>. ALDERMERE CARE GROUP LIMITED as Borrower. "
          "STONEGATE SPECIAL SITUATIONS II LP as Agent. This Agreement amends and "
          "restates the Senior Facilities Agreement originally dated 30 May 2022."),
    ("h", "1. THE AMENDED FACILITY"),
    ("p", "1.1 The outstanding principal amount of Facility A is "
          "<b>GBP 33,750,000</b>. No further Utilisations are permitted."),
    ("p", "1.2 The Margin is increased to <b>9.50 per cent per annum</b>, of which "
          "300bps shall be payable in kind. Maturity is extended to "
          "<b>30 May 2028</b>."),
    ("pb", None),
    ("h", "4. FINANCIAL COVENANTS AND WAIVER"),
    ("p", "4.1 The parties acknowledge that the Total Net Leverage covenant was "
          "<b>breached</b> at the Test Date falling on 31 March 2026, at which "
          "date Total Net Leverage was 6.84:1.00 against a covenant level of "
          "5.50:1.00."),
    ("p", "4.2 The Lenders hereby <b>waive</b> the Event of Default arising under "
          "Clause 4.1, such waiver being conditional upon (a) payment of a waiver "
          "fee of GBP 675,000 and (b) delivery of the Turnaround Plan by 31 July "
          "2026."),
    ("t", [
        ["Total Net Leverage", "≤ 6.75 : 1.00", "30 Jun 2026", "6.62x", "Complied"],
        ["Interest Cover", "≥ 1.50 : 1.00", "30 Jun 2026", "1.38x", "BREACH"],
        ["Minimum Liquidity", "GBP 2,500,000", "30 Jun 2026", "GBP 4.4m", "Complied"],
    ]),
    ("p", "4.3 The equity cure right in the Original Agreement is deleted in its "
          "entirety with effect from the date of this Agreement."),
    ("h", "5. INFORMATION"),
    ("p", "5.1 Monthly management accounts and a 13-week cash flow forecast shall "
          "be delivered within 15 days of each month end."),
])

print(f"\n{len(list(OUT.glob('*.pdf')))} agreements in {OUT}")
