"""Week 1 exit test: extract every agreement, report cost and failure rate.

The exit test is not "it worked once." It is a measured failure rate over a
corpus, because that is the number you will be asked for.

    python3 week1/run_batch.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import anthropic

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import extract  # noqa: E402

AGREEMENTS = Path("data/agreements")


def main() -> None:
    paths = sorted(AGREEMENTS.glob("*.pdf"))
    if not paths:
        print(f"No PDFs in {AGREEMENTS}. Run: python3 week1/make_samples.py")
        sys.exit(1)

    client = anthropic.Anthropic()
    results = []

    print(f"\nExtracting {len(paths)} agreements\n" + "=" * 62)
    for p in paths:
        print(f"\n  {p.name}")
        results.append(extract(p, client))

    ok = [r for r in results if r.succeeded]
    total_cost = sum(r.total_cost_usd for r in results)
    total_calls = sum(len(r.calls) for r in results)
    repairs = sum(r.repair_attempts for r in results)
    cited = sum(
        1 for r in ok for c in r.agreement.covenants if c.source_page is not None
    )
    covenants = sum(len(r.agreement.covenants) for r in ok)

    print("\n" + "=" * 62)
    print("WEEK 1 EXIT TEST")
    print("=" * 62)
    print(f"  documents               {len(ok)}/{len(paths)} extracted")
    print(f"  schema failure rate     {repairs}/{total_calls} calls "
          f"({repairs / total_calls * 100:.0f}%)")
    print(f"  covenants found         {covenants}")
    print(f"  citation coverage       {cited}/{covenants} "
          f"({cited / covenants * 100:.0f}%)" if covenants else "  covenants found  0")
    print(f"  total cost              ${total_cost:.4f}")
    print(f"  cost per document       ${total_cost / len(paths):.4f}")
    print(f"  mean latency            "
          f"{sum(r.total_latency_ms for r in results) / len(results):.0f}ms")

    report = {
        "documents": len(paths),
        "succeeded": len(ok),
        "total_calls": total_calls,
        "repair_calls": repairs,
        "schema_failure_rate": repairs / total_calls if total_calls else 0,
        "covenants_extracted": covenants,
        "covenants_with_citation": cited,
        "total_cost_usd": round(total_cost, 6),
        "per_document": [
            {"source": r.source, "ok": r.succeeded, "calls": len(r.calls),
             "cost_usd": round(r.total_cost_usd, 6),
             "latency_ms": round(r.total_latency_ms)}
            for r in results
        ],
    }
    Path("week1_report.json").write_text(json.dumps(report, indent=2))
    print("\n  -> week1_report.json")
    print("\n  Now go and check the JSON against the PDFs by hand. Every number")
    print("  the model got right is a number you can trust it on; every number")
    print("  it got wrong is a Week 5 detector.\n")


if __name__ == "__main__":
    main()
