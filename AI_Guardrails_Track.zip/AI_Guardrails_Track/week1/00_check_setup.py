"""Run this first. Confirms your environment can make one real API call.

    python3 week1/00_check_setup.py
"""
import os
import sys

print("\nWeek 1 setup check\n" + "-" * 46)

ok = True

print(f"  python           {sys.version.split()[0]}")

for mod, why in [("anthropic", "API client"), ("pydantic", "schema validation"),
                 ("pypdf", "PDF text"), ("reportlab", "sample docs")]:
    try:
        __import__(mod)
        print(f"  {mod:16s} installed        ({why})")
    except ImportError:
        print(f"  {mod:16s} MISSING          -> pip install {mod}")
        ok = False

key = os.environ.get("ANTHROPIC_API_KEY")
if key:
    print(f"  ANTHROPIC_API_KEY set ({len(key)} chars)")
else:
    print("  ANTHROPIC_API_KEY NOT SET")
    print("\n  Get one at console.anthropic.com -> API keys, then:")
    print('    echo \'export ANTHROPIC_API_KEY="sk-ant-..."\' >> ~/.zshrc')
    print("    source ~/.zshrc")
    ok = False

if not ok:
    print("\n  Fix the above, then run this again.\n")
    sys.exit(1)

print("\n  Making one test call...")
import anthropic

client = anthropic.Anthropic()
r = client.messages.create(
    model="claude-opus-5",
    max_tokens=64,
    messages=[{"role": "user",
               "content": "Reply with exactly: setup works"}],
)
text = "".join(b.text for b in r.content if b.type == "text")
cost = r.usage.input_tokens / 1e6 * 5 + r.usage.output_tokens / 1e6 * 25

print(f"  model replied: {text.strip()!r}")
print(f"  tokens: {r.usage.input_tokens} in / {r.usage.output_tokens} out")
print(f"  cost:   ${cost:.6f}")
print("\n  You're ready. Next: python3 week1/run_batch.py\n")
