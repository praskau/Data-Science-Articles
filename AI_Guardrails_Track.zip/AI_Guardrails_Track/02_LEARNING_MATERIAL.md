# Learning material — curated, not exhaustive

Rule: **one primary source per topic, read it properly, then build.** The failure mode for a plan like this is collecting bookmarks. Everything below is mapped to a week, and anything not mapped to a week is deliberately excluded.

Items marked ★ are the ones to actually read cover-to-cover. Everything else is reference — consult when the build needs it.

---

## Tier 0 — Read in Week 0, before any code (3 hrs total)

- ★ **OWASP Top 10 for LLM Applications** (owasp.org, GenAI Security Project). The shared vocabulary for every guardrails conversation you will have. LLM01 Prompt Injection, LLM02 Sensitive Information Disclosure, LLM06 Excessive Agency and LLM07 System Prompt Leakage map directly onto JD-B's detector list. Know the numbers by heart; interviewers use them as shorthand.
- ★ **Anthropic — "Building effective agents"** (anthropic.com/engineering). Short. The workflow-vs-agent distinction in it is the single most useful framing for JD-A's multi-agent bullet, and it will keep you from over-engineering Aegis.
- **MITRE ATLAS** (atlas.mitre.org) — skim the matrix. This is the adversarial-tactics taxonomy; cite it when discussing threat modelling.

## Weeks 1–2 — LLM engineering and agents

- ★ **Anthropic docs**: tool use, structured outputs, prompt engineering (esp. chain-of-thought and long-context tips), extended thinking. These are the reference for the model you'll build against.
- ★ **LangGraph docs** — the conceptual guides on state, persistence/checkpointing, and the **multi-agent supervisor** tutorial. JD-A names Supervisor Agent explicitly; build that exact topology.
- **Papers, read the abstract + method only:** ReAct (Yao et al. 2022) · Reflexion (Shinn et al. 2023) · Toolformer (Schick et al. 2023). You need the patterns, not the benchmarks.
- **Book:** ★ *AI Engineering* — Chip Huyen (O'Reilly, 2025). The best single book for exactly this transition. Chapters on evaluation and on inference optimisation are the ones that pay off.
- **Course (optional, if you like structure):** DeepLearning.AI short courses on LangGraph / agentic design. Cheap, a few hours each, decent for pattern exposure.

## Week 3 — Document intelligence and RAG

- **"Lost in the Middle"** (Liu et al. 2023) — read it, then stop believing that a bigger context window solves retrieval.
- **Anthropic — "Introducing Contextual Retrieval"** (engineering blog). Practical, measurable, and it's the technique to actually implement.
- **Reference:** LlamaIndex or Docling docs for PDF/table parsing; `rank_bm25` + a dense embedder for hybrid search. Pick one vector store (Qdrant or pgvector) and don't shop around.
- **Ragas** — RAG evaluation metrics (faithfulness, context precision/recall). Groundedness scoring here becomes a *detector* in Week 5.

## Weeks 4–5 — Guardrails, the core of JD-B

**Threat understanding (read first):**
- ★ **Greshake et al., "Not what you've signed up for: Compromising Real-World LLM-Integrated Applications with Indirect Prompt Injection"** (2023). The foundational indirect-injection paper. Your Week 5 demo is a direct descendant of it. If you read one paper this whole plan, read this one.
- ★ **Simon Willison's prompt-injection writing** (simonwillison.net, tag: prompt-injection). Years of accumulated practitioner reasoning on why filtering alone cannot work, and on the "lethal trifecta" (private data + untrusted content + exfiltration channel) — a framing that lands extremely well in interviews because it turns a fuzzy risk into a checkable condition.
- **Zou et al., "Universal and Transferable Adversarial Attacks on Aligned Language Models"** (2023, GCG). Read for the *conclusion*: suffix attacks transfer, so detector robustness cannot assume attack-string novelty.
- **Beurer-Kellner et al., "Design Patterns for Securing LLM Agents against Prompt Injections"** (2025) and Google DeepMind's **CaMeL** work — architectural (capability/data-flow) defences rather than detector-only defences. This is the *senior* answer to "how would you actually stop this," and it's what separates a GCB4 answer from a GCB6 answer. Verify current versions when you get there.

**Tools to use and to have opinions about** — JD-B asks you to know "where each approach is effective and where it breaks down," so use each at least once:
- **Microsoft Presidio** — PII detection/anonymisation (NER + regex + checksum validators). Your Week 4 PII detector.
- **Meta Llama Guard / Prompt Guard** — off-the-shelf content-safety and injection classifiers. Your Week 5 baseline, and the thing your first-party detector must beat in Week 8.
- **NVIDIA NeMo Guardrails** and **Guardrails AI** — two different philosophies (dialogue-flow rails vs output validators). Try both, form a view, be able to say which you'd deploy and why.
- **Cloud-native comparators:** Azure AI Content Safety (incl. Prompt Shields), AWS Bedrock Guardrails. JD-B says "third-party safety services" — know what the platform gives you free before building.

**Datasets for the red-team corpus:** `deepset/prompt-injections` (HuggingFace) · JailbreakBench · AdvBench · HackAPrompt · Lakera's Gandalf levels (play it — an hour here builds real intuition). **Then write your own**, in HSBC's domain: injections hidden in credit agreements, term sheets, and trade-finance docs. Domain-specific attacks are what make your eval set yours.

## Week 6 — Evaluation (your differentiator)

- ★ Chip Huyen, *AI Engineering*, evaluation chapters — re-read properly here.
- **Zheng et al., "Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena"** (2023) — the canonical LLM-judge paper. Know its documented biases (position, verbosity, self-preference); the mitigations are interview gold.
- **promptfoo** — eval + red-team harness, config-driven, CI-friendly. This is the one to standardise on.
- **DeepEval** and **Giskard** — alternatives; Giskard's LLM scanner is good for automated vulnerability sweeps.
- **On imbalanced-class metrics:** Saito & Rehmsmeier, "The Precision-Recall Plot Is More Informative than the ROC Plot When Evaluating Binary Classifiers on Imbalanced Datasets" (PLOS ONE, 2015). Short, decisive, and directly applicable — attacks are rare events, so PR beats ROC. Being able to explain this crisply will separate you from most candidates instantly.
- Your own advantage: you already think in loss functions and asymmetric costs from stress testing. **Import that vocabulary wholesale.** A detector threshold is a risk appetite statement.

## Weeks 7–9 — Production, observability, governance

- **OpenTelemetry GenAI semantic conventions** — the emerging standard for LLM telemetry. Also look at Langfuse or Arize Phoenix for LLM-specific tracing UIs.
- **Kubernetes:** don't take a course. Learn exactly: Deployment, Service, HPA, probes, resource limits, ConfigMap/Secret. That is the whole surface area you'll be asked about.
- **`garak`** (NVIDIA) — LLM vulnerability scanner; your automated red-team loop in Week 9.
- ★ **NIST AI RMF (AI 100-1)** + **Generative AI Profile (NIST AI 600-1)**. The Govern/Map/Measure/Manage structure gives you a ready-made way to organise any answer about AI risk.
- ★ **SR 11-7** (Fed, Supervisory Guidance on Model Risk Management) and **PRA SS1/23** (Model Risk Management Principles for Banks). **You likely already know these.** The move is to apply them to detectors: a detector is a model, so it needs development standards, independent validation, ongoing monitoring, and a challenge process. Say this in the interview. It is the highest-leverage sentence in the whole plan, because the engineers can't say it and the risk people can't build the thing.
- **EU AI Act** — high-risk classification, Article 15 (accuracy/robustness/cybersecurity), GPAI obligations. Skim the obligations, not the recitals.
- **UK/HK/regional:** FCA/BoE AI discussion papers and HKMA GenAI guidance, since HSBC's footprint means these come up.

## Books, ranked (buy two, not five)

1. ★ **Chip Huyen — *AI Engineering*** (2025). The core text for this transition.
2. **Alammar & Grootendorst — *Hands-On Large Language Models*** (2024). Best for filling mechanical gaps quickly, visually.
3. Chip Huyen — *Designing Machine Learning Systems* (2022). For the production/monitoring instincts if you want more depth in Week 7.

## Deliberately excluded

Transformer internals and pretraining (you wrote 83 pages on it). Spark/Hadoop (JD-A boilerplate; won't be probed). RLHF theory. Anything about training foundation models. Kubernetes beyond the seven objects listed. Agent framework tourism — pick LangGraph because JD-A names it, and stop.
