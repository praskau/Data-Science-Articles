"""Measure the numeric-grounding check by attacking it.

Generates invented figures and counts how many each design accepts. This is the
only way to find out whether a grounding check does anything: testing it against
valid commentary tells you nothing, because a function that accepts everything
passes that test too.

Run:  python3 -m eval.measure_provenance
"""

from __future__ import annotations

import random
import sys

from engine import analyze, catalogue, context as ctxmod, crosssection, findings
from engine.verify import Provenance, _match, _rounding_forms, allowed_numbers

BUCKETS = {
    "2dp < 1":   lambda r: round(r.uniform(0.01, 0.999), 2),
    "2dp < 10":  lambda r: round(r.uniform(1.0, 9.99), 2),
    "4dp":       lambda r: round(r.uniform(0.0001, 9.9999), 4),
    "large":     lambda r: round(r.uniform(10.0, 5000.0), 2),
}
N = 25_000
TOL = 0.02      # a naive "close enough to something real" band


def _fuzzy(ctx: dict) -> set[float]:
    """Design 1: every number anywhere in the context, matched within a band."""
    out: set[float] = set()

    def walk(node):
        if isinstance(node, dict):
            for v in node.values():
                walk(v)
        elif isinstance(node, (list, tuple)):
            for v in node:
                walk(v)
        elif isinstance(node, bool):
            return
        elif isinstance(node, (int, float)):
            out.add(float(node))
    walk(ctx)
    return out


def _accept_fuzzy(x: float, pool: set[float], tol: float) -> bool:
    """Design 1: accept if within a tolerance band of ANY ledger number.

    `tol` is both an absolute floor and a relative width, which is how such a
    check is naturally written -- "close enough to something real".
    """
    return any(abs(x - v) <= max(tol, abs(v) * tol) for v in pool)


def main() -> int:
    cat = catalogue.load()
    book = analyze.load_book("data")
    t0, t1 = book.dates
    allr = analyze.analyse_all(book, cat, t0, t1)
    cross = crosssection.analyse(cat, allr)

    rows = []
    for fund, a in allr.items():
        ctx = ctxmod.build(a, cat, cross)
        fuzzy_pool = _fuzzy(ctx)
        doc_allow = allowed_numbers(ctx)                       # design 2
        prov = Provenance(ctx)                                 # design 3

        targets = findings.coverage_targets(cat, a.changes, a.profile.headline_metric)
        # a representative claim: cites 2 items of the headline metric
        cited = [i for i in list(targets)[:2]]
        metric = a.profile.headline_metric
        claim_allow = prov.allow_for(metric, cited)

        for name, draw in BUCKETS.items():
            r = random.Random(f"{fund}|{name}")
            f1 = f2 = f3 = 0
            for _ in range(N):
                x = draw(r)
                if _accept_fuzzy(x, fuzzy_pool, TOL):
                    f1 += 1
                if _match(x, doc_allow) is not None:
                    f2 += 1
                if _match(x, claim_allow) is not None:
                    f3 += 1
            rows.append((fund, name, f1 / N, f2 / N, f3 / N))

        # Recall: every figure a valid claim would legitimately quote must pass.
        # Rounded from the CONTEXT value, not the raw ledger value -- the narrator
        # only ever sees the context, so that is the only thing it can copy. (An
        # earlier version of this check rounded the raw value and reported a
        # spurious rejection; the verifier was right and the measurement was wrong.)
        ctx_values = {d["item_id"]: d["value"]
                      for m in ctx["metrics"] for d in m["drivers"]}
        rejected = checked = 0
        for iid, it in targets.items():
            v = ctx_values.get(iid)
            if v is None:
                continue
            allow = prov.allow_for(it.metric, [iid])
            for form in (v, round(v, 3), round(v, 2), round(v, 1)):
                checked += 1
                if _match(form, allow) is None:
                    rejected += 1
                    print(f"  RECALL MISS {iid} {it.entity_label} {form}", file=sys.stderr)
        print(f"{fund}: recall check -- {checked - rejected}/{checked} legitimate "
              f"figures accepted", file=sys.stderr)

    agg: dict[str, list[float]] = {}
    for _, name, f1, f2, f3 in rows:
        agg.setdefault(name, [0.0, 0.0, 0.0, 0])
        a_ = agg[name]
        a_[0] += f1; a_[1] += f2; a_[2] += f3; a_[3] += 1

    print()
    print(f"{'bucket':<12} {'fuzzy band':>12} {'exact, doc':>12} {'per-claim':>12}")
    print("-" * 52)
    for name in BUCKETS:
        s1, s2, s3, n = agg[name]
        print(f"{name:<12} {s1/n:>11.1%} {s2/n:>12.1%} {s3/n:>12.1%}")
    print()
    print(f"{N:,} invented figures per bucket per fund, {len(allr)} funds. "
          f"Fuzzy band tolerance {TOL:.0%}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
