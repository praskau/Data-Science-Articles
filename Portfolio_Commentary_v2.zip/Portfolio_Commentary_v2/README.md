# Portfolio Commentary v2

Exact risk attribution across two COB dates, and commentary that is machine-verified
against it before anyone reads it.

**The whole design in one line:** no language model computes a number, and no Python
function writes a sentence.

## Run it

```bash
python3 -m engine.cli gen                       # regenerate the synthetic 3-fund book
python3 -m engine.cli selftest                  # reconciliation + gates
python3 -m pytest tests/ -q                     # 54 tests
```

Then, in Claude Code, from this folder:

> read prompt.md and run it for FI001, 2026-06-30 vs 2026-07-31

## The four files that are the framework

| File | Governs |
|---|---|
| `config/fields.json` | what each field **means** and how it is compared |
| `config/logic.md` | **thresholds and sequencing** — gates, ladder, loops |
| `config/guardrails.md` | what may and may not be **written** |
| `prompt.md` | the **orchestration** — entry point, references the other three |

Precedence: `fields.json` on field semantics, `logic.md` on thresholds and sequencing,
`guardrails.md` on output.

A new portfolio field is added by editing `fields.json` only. A test asserts this
(`tests/test_catalogue.py`), and another asserts no engine module hardcodes a
portfolio field name.

## Commands

```
gen        regenerate the synthetic book
triage     R0 -- which funds are in scope, and which gate caught them
analyse    the full ledger for one fund, with reconciliation
context    write the exact JSON the narrator is given   (--redact to pseudonymise)
drill      one rung of the ladder in isolation          (--rung R5)
verify     check a draft against the ledger             (exit 1 = revise)
render     markdown from verified drafts
selftest   reconciliation + gates across the book
```

## What is actually guaranteed

- Every decomposition reconciles to the headline change within 1e-9. Asserted per
  fund, per metric, and the residual check excludes the item that records the
  residual, so it can fail.
- Every figure in the commentary exists in the context that was sent, checked per
  claim against the ledger items that claim cites.
- Every material driver is covered, by set arithmetic on ids — never an LLM judge.
- The short form names the driver the engine computed, and that driver is always
  something the long form was required to discuss.
- The loop terminates: on coverage, on a defect signature that stops changing, or
  on the iteration cap.

`config/guardrails.md` §8 states what this does **not** protect against.
