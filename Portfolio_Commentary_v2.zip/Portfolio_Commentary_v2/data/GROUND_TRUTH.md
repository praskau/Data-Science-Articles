# Ground truth

Planted deliberately by `data/synth.py`. The engine is never told any of it.

Dates: **2026-06-30** to **2026-07-31**.

## Factor volatilities (annualised %)

| factor | t0 | t1 |
|---|---:|---:|
| RATES_LVL | 5.6 | 5.9 |
| RATES_SLP | 2.4 | 2.6 |
| CREDIT_IG | 3.1 | 4.9 |
| CREDIT_HY | 7.0 | 11.2 |
| EQ_MKT | 13.8 | 12.9 |
| EQ_VAL | 5.2 | 5.0 |
| EQ_GRW | 6.4 | 6.9 |
| FX | 7.5 | 7.6 |
| COMMOD | 17.0 | 17.4 |

## Factor correlations

| pair | t0 | t1 |
|---|---:|---:|
| RATES_LVL / EQ_MKT | -0.35 | 0.28 |
| CREDIT_IG / EQ_MKT | 0.45 | 0.52 |
| CREDIT_IG / CREDIT_HY | 0.82 | 0.88 |
| EQ_MKT / EQ_GRW | 0.55 | 0.58 |
| EQ_MKT / EQ_VAL | 0.4 | 0.36 |
| RATES_LVL / CREDIT_IG | -0.2 | -0.05 |

## Planted trades (multiplier on t0 units)

| fund | predicate | x | intent |
|---|---|---:|---|
| FI001 | `rating in ('BB','B')` | 1.55 | added high yield into a widening spread market |
| FI001 | `asset_class == 'govt_bond' and duration_t0 > 15` | 1.8 | extended duration at the long end |
| FI001 | `asset_class == 'corp_bond' and duration_t0 < 3` | 0.35 | sold the short-dated IG carry book |
| FI001 | `asset_class == 'irs'` | 1.4 | increased the pay-fixed hedge |
| MA001 | `asset_class == 'equity'` | 0.86 | cut the equity sleeve by ~5pp |
| MA001 | `asset_class == 'option'` | 3.2 | tripled the index put protection |
| MA001 | `asset_class == 'govt_bond'` | 1.22 | recycled into duration |
| EQ001 | `sector == 'Technology'` | 1.24 | rotated into technology |
| EQ001 | `sector == 'Energy'` | 0.62 | cut energy |

## Position entries and exits

| fund | opened (target weight) | closed |
|---|---|---|
| FI001 | CB0135 (2.1%), CB0136 (1.4%) | CB0112, CB0118 |
| MA001 | EQ0031 (1.2%) | EQ0009 |
| EQ001 | EQ0047 (1.6%), EQ0051 (1.1%) | EQ0021, EQ0033 |

## Rating migrations

| instrument | t0 | t1 |
|---|---|---|
| CB0107 | BBB | BB |
| CB0123 | BB | B |

## Curve reassignment (a MODEL INPUT change, not a market move)

- FI001: `USD_SWAP` -> `USD_OIS` at 2026-07-31

## Benchmark reweights

- EQ001: Technology x1.18, Energy x0.8

## Curves

- Bear steepening at 2026-07-31: +10bp parallel, +20bp additional at the long end
- Curves: EUR_SWAP, GBP_SWAP, USD_OIS, USD_SWAP
- `USD_OIS` does not change relative to `USD_SWAP` between the dates. What
  changes is which positions point at it.

