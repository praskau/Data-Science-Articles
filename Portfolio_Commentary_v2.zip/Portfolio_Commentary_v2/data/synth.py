"""Generate a synthetic three-fund book across two COB dates.

Why synthetic: to validate an attribution engine you must know the true answer.
This generator plants specific, deliberate drivers between the two dates, so the
engine's output can be checked against ground truth (see GROUND_TRUTH.md,
which this module writes itself so it can never drift from the generator).

v2 additions over v1: a per-position `yield_curve_id` (so a curve REASSIGNMENT
is detectable as a model-input event, distinct from the curve moving), a rating
migration, and explicit position entries and exits -- all things a real book
does between two dates and none of which v1 could represent.

Internally it uses a factor covariance model to produce realistic
contribution-to-volatility numbers -- then *discards the covariance matrix*.
The engine only ever sees what a real risk system emits: per-position weight,
standalone vol and contribution to vol. Everything else is inferred.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

RNG = np.random.default_rng(20260630)


def _h(s: str) -> int:
    """Stable string hash. Python's builtin _h() is salted per process."""
    from zlib import crc32
    return crc32(str(s).encode())

T0 = "2026-06-30"
T1 = "2026-07-31"

FACTORS = ["RATES_LVL", "RATES_SLP", "CREDIT_IG", "CREDIT_HY",
           "EQ_MKT", "EQ_VAL", "EQ_GRW", "FX", "COMMOD"]

# Annualised factor vols (%), t0 -> t1.
# Planted driver #1: IG and HY credit spread vol rises hard (a spread widening
# regime). Planted driver #2: equity market vol falls slightly.
FACTOR_VOL = {
    T0: dict(RATES_LVL=5.6, RATES_SLP=2.4, CREDIT_IG=3.1, CREDIT_HY=7.0,
             EQ_MKT=13.8, EQ_VAL=5.2, EQ_GRW=6.4, FX=7.5, COMMOD=17.0),
    T1: dict(RATES_LVL=5.9, RATES_SLP=2.6, CREDIT_IG=4.9, CREDIT_HY=11.2,
             EQ_MKT=12.9, EQ_VAL=5.0, EQ_GRW=6.9, FX=7.6, COMMOD=17.4),
}

# Planted driver #3: the rates/equity correlation flips sign. This is the single
# hardest thing for a human to spot in a risk report and the clearest test of
# whether the engine separates "correlation" from "standalone vol".
FACTOR_CORR_PAIRS = {
    T0: {("RATES_LVL", "EQ_MKT"): -0.35, ("CREDIT_IG", "EQ_MKT"): 0.45,
         ("CREDIT_IG", "CREDIT_HY"): 0.82, ("EQ_MKT", "EQ_GRW"): 0.55,
         ("EQ_MKT", "EQ_VAL"): 0.40, ("RATES_LVL", "CREDIT_IG"): -0.20},
    T1: {("RATES_LVL", "EQ_MKT"): 0.28, ("CREDIT_IG", "EQ_MKT"): 0.52,
         ("CREDIT_IG", "CREDIT_HY"): 0.88, ("EQ_MKT", "EQ_GRW"): 0.58,
         ("EQ_MKT", "EQ_VAL"): 0.36, ("RATES_LVL", "CREDIT_IG"): -0.05},
}

SECTORS = ["Financials", "Industrials", "Technology", "Healthcare",
           "Energy", "Consumer", "Utilities", "Communication"]
RATINGS = ["AAA", "AA", "A", "BBB", "BB", "B"]

# Planted driver #6: a credit migration. The bond is not traded and the market
# does not move it -- its rating changes, which moves it between sleeves and
# widens its spread. v1 could only report this as an unexplained vol change.
RATING_MIGRATION = {"CB0107": ("BBB", "BB"), "CB0123": ("BB", "B")}

# Planted driver #7: FI001's USD book is moved from the swap curve to the OIS
# curve at T1. Nothing was traded and no market moved: someone changed a model
# input. The commentary must say so, and must NOT narrate it as a market event.
CURVE_REASSIGNMENT = {"FI001": {T1: {"USD_SWAP": "USD_OIS"}}}

# Planted driver #8: genuine position entries and exits, as opposed to weight
# changes on things already held. "We bought something we did not own" is a
# different sentence from "we added 20bp", and needs a different effect.
PLANTED_ENTRIES = {          # zero units at T0, real position at T1
    "FI001": {"CB0135": 0.021, "CB0136": 0.014},
    "MA001": {"EQ0031": 0.012},
    "EQ001": {"EQ0047": 0.016, "EQ0051": 0.011},
}
PLANTED_EXITS = {            # held at T0, fully closed at T1
    "FI001": ["CB0112", "CB0118"],
    "MA001": ["EQ0009"],
    "EQ001": ["EQ0021", "EQ0033"],
}


def _corr(date: str) -> np.ndarray:
    n = len(FACTORS)
    c = np.eye(n)
    idx = {f: i for i, f in enumerate(FACTORS)}
    for (a, b), v in FACTOR_CORR_PAIRS[date].items():
        c[idx[a], idx[b]] = c[idx[b], idx[a]] = v
    # nearest-PSD repair: clip eigenvalues, renormalise to unit diagonal
    w, V = np.linalg.eigh(c)
    c = V @ np.diag(np.clip(w, 1e-6, None)) @ V.T
    d = np.sqrt(np.diag(c))
    return c / np.outer(d, d)


def _cov(date: str) -> np.ndarray:
    s = np.array([FACTOR_VOL[date][f] for f in FACTORS])
    return _corr(date) * np.outer(s, s)


# --------------------------------------------------------------------------
# Instrument universe
# --------------------------------------------------------------------------

def _bond(i: int, rating: str, mat_yrs: float, ccy="USD", govt=False):
    sec = "Government" if govt else RNG.choice(SECTORS)
    iss = f"{'SOVEREIGN ' if govt else ''}{sec.upper()[:4]}{i:03d}"
    cpn = round(float(RNG.uniform(2.0, 7.5)), 3)
    return dict(
        instrument_id=f"{'GV' if govt else 'CB'}{i:04d}",
        name=f"{iss} {cpn:.3f}% {2026 + int(mat_yrs)}",
        asset_class="govt_bond" if govt else "corp_bond",
        currency=ccy, sector=sec, rating="AAA" if govt else rating, issuer=iss,
        coupon=cpn, maturity=f"{2026 + int(mat_yrs)}-06-15",
        callable=bool(not govt and RNG.random() < 0.25),
        underlying=None, strike=None, expiry=None, multiplier=1.0,
        pay_receive=None, fixed_rate=None, tenor_years=None,
    )


def _equity(i: int, ccy="USD"):
    sec = SECTORS[i % len(SECTORS)]
    return dict(
        instrument_id=f"EQ{i:04d}", name=f"{sec[:4].upper()} HOLDINGS {i}",
        asset_class="equity", currency=ccy, sector=sec, rating="", issuer=f"{sec[:4].upper()}{i}",
        coupon=None, maturity=None, callable=False,
        underlying=None, strike=None, expiry=None, multiplier=1.0,
        pay_receive=None, fixed_rate=None, tenor_years=None,
    )


def _derivative(kind: str, i: int, ccy="USD", **kw):
    base = dict(instrument_id=f"{kind[:2].upper()}{i:04d}", asset_class=kind,
                currency=ccy, sector="Derivative", rating="", issuer="CCP",
                coupon=None, maturity=None, callable=False, multiplier=1.0,
                underlying=None, strike=None, expiry=None,
                pay_receive=None, fixed_rate=None, tenor_years=None)
    base.update(kw)
    return base


def build_instruments() -> pd.DataFrame:
    rows: list[dict] = []
    for i in range(1, 19):
        rows.append(_bond(i, "AAA", RNG.uniform(1.5, 29), govt=True,
                          ccy=str(RNG.choice(["USD", "USD", "EUR", "GBP"]))))
    for i in range(1, 41):
        rows.append(_bond(100 + i, str(RNG.choice(RATINGS[1:], p=[.12, .28, .34, .18, .08])),
                          RNG.uniform(1.0, 22), ccy=str(RNG.choice(["USD", "USD", "USD", "EUR"]))))
    for i in range(1, 57):
        rows.append(_equity(i, ccy=str(RNG.choice(["USD", "USD", "USD", "EUR", "GBP", "JPY"]))))
    rows += [
        _derivative("future", 1, name="US 10Y NOTE FUT SEP26", underlying="UST 10Y",
                    expiry="2026-09-19", multiplier=1000.0),
        _derivative("future", 2, name="EURO BUND FUT SEP26", underlying="BUND 10Y",
                    ccy="EUR", expiry="2026-09-08", multiplier=1000.0),
        _derivative("future", 3, name="S&P 500 E-MINI SEP26", underlying="SPX",
                    expiry="2026-09-18", multiplier=50.0),
        _derivative("option", 1, name="SPX PUT 5400 SEP26", underlying="SPX",
                    strike=5400.0, expiry="2026-09-18", multiplier=100.0),
        _derivative("option", 2, name="SPX PUT 5000 DEC26", underlying="SPX",
                    strike=5000.0, expiry="2026-12-18", multiplier=100.0),
        _derivative("irs", 1, name="USD IRS PAY FIXED 10Y", pay_receive="pay_fixed",
                    fixed_rate=4.12, tenor_years=10.0, multiplier=1.0),
        _derivative("irs", 2, name="EUR IRS RECEIVE FIXED 5Y", pay_receive="receive_fixed",
                    fixed_rate=2.48, tenor_years=5.0, ccy="EUR", multiplier=1.0),
        _derivative("fx_forward", 1, name="EURUSD FWD 3M", underlying="EURUSD",
                    expiry="2026-09-30", multiplier=1.0),
    ]
    for r in rows:
        r.setdefault("name", r["instrument_id"])
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Factor loadings -- deterministic in the instrument, except duration, which
# rolls down between dates.
# --------------------------------------------------------------------------

def _rating_at(instrument_id: str, base_rating: str, date: str) -> str:
    """Rating as at `date`. Migrations are planted, not random."""
    mig = RATING_MIGRATION.get(instrument_id)
    if not mig:
        return base_rating
    return mig[0] if date == T0 else mig[1]


def _curve_for(fund_id: str, currency: str, date: str) -> str:
    """The curve this position is valued and risked on, as at `date`."""
    cid = {"USD": "USD_SWAP", "EUR": "EUR_SWAP", "GBP": "GBP_SWAP"}.get(currency, "USD_SWAP")
    remap = CURVE_REASSIGNMENT.get(fund_id, {}).get(date, {})
    return remap.get(cid, cid)


def _loadings(inst: pd.Series, dur: float, date: str) -> np.ndarray:
    b = dict.fromkeys(FACTORS, 0.0)
    ac = inst.asset_class
    if ac in ("govt_bond", "corp_bond"):
        b["RATES_LVL"] = dur / 10.0
        b["RATES_SLP"] = (dur - 7.0) / 12.0
        if ac == "corp_bond":
            hy = _rating_at(inst["instrument_id"], inst.rating, date) in ("BB", "B")
            b["CREDIT_HY" if hy else "CREDIT_IG"] = dur * (0.16 if hy else 0.09)
            b["CREDIT_IG"] += 0.02 * dur if hy else 0.0
    elif ac == "equity":
        b["EQ_MKT"] = 0.75 + 0.55 * ((_h(inst["instrument_id"]) % 100) / 100.0)
        growthy = inst.sector in ("Technology", "Communication", "Healthcare")
        b["EQ_GRW" if growthy else "EQ_VAL"] = 0.35 + 0.30 * ((_h(inst["name"]) % 50) / 50.0)
        if inst.sector == "Energy":
            b["COMMOD"] = 0.45
    elif ac == "future":
        b["RATES_LVL"] = dur / 10.0 if "FUT" in inst["name"] and dur else 0.0
        if inst.underlying == "SPX":
            b["EQ_MKT"] = 1.0
    elif ac == "option":
        b["EQ_MKT"] = 1.0          # scaled by delta at the position level
    elif ac == "irs":
        b["RATES_LVL"] = dur / 10.0
        b["RATES_SLP"] = (dur - 7.0) / 12.0
    elif ac == "fx_forward":
        b["FX"] = 1.0
    if inst.currency != "USD" and ac != "fx_forward":
        b["FX"] += 0.35
    return np.array([b[f] for f in FACTORS])


def _idio_vol(inst: pd.Series) -> float:
    return {"govt_bond": 0.4, "corp_bond": 1.8, "equity": 14.0, "future": 0.5,
            "option": 2.0, "irs": 0.5, "fx_forward": 1.0, "cash": 0.0}[inst.asset_class]


# --------------------------------------------------------------------------
# Yield curves. Planted driver #4: a bear steepening -- the whole curve rises
# and the long end rises more, which hurts a fund that just extended duration.
# --------------------------------------------------------------------------

TENORS = [0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0, 20.0, 30.0]
# USD_OIS exists at both dates. Nothing about it changes between them -- what
# changes is which positions are pointed at it. That is the whole point.
_CURVE_BASE = {"USD_SWAP": 4.05, "EUR_SWAP": 2.35, "GBP_SWAP": 4.30, "USD_OIS": 3.97}
_CURVE_SLOPE = {"USD_SWAP": 0.55, "EUR_SWAP": 0.80, "GBP_SWAP": 0.35, "USD_OIS": 0.52}


def build_curves() -> pd.DataFrame:
    rows = []
    for cid, base in _CURVE_BASE.items():
        for date in (T0, T1):
            # bear steepen at T1: +10bp parallel, +20bp extra at the long end
            lvl = 0.0 if date == T0 else 0.10
            slp = 0.0 if date == T0 else 0.20
            for t in TENORS:
                shape = np.log1p(t) / np.log1p(30.0)
                rate = base + _CURVE_SLOPE[cid] * shape + lvl + slp * shape
                rows.append(dict(cob_date=date, curve_id=cid, tenor_years=t,
                                 rate=round(float(rate), 4)))
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Fund construction
# --------------------------------------------------------------------------

FUNDS = {
    "FI001": dict(name="Global Credit Opportunities Fund", fund_type="fixed_income",
                  benchmark="ICE BofA Global Corporate Index",
                  nav={T0: 1_250_000_000.0, T1: 1_148_000_000.0}),
    "MA001": dict(name="Diversified Growth Fund", fund_type="multi_asset",
                  benchmark="60/40 Composite (MSCI ACWI / Bloomberg Global Agg)",
                  nav={T0: 840_000_000.0, T1: 852_500_000.0}),
    "EQ001": dict(name="Global Equity Core Fund", fund_type="equity",
                  benchmark="MSCI World Index",
                  nav={T0: 2_100_000_000.0, T1: 2_143_000_000.0}),
}

# Planted trades, expressed as a multiplier on t0 units (1.0 = untouched).
# Each entry is (predicate, t1_multiplier, note).
PLANTED_TRADES = {
    "FI001": [
        ("rating in ('BB','B')", 1.55, "added high yield into a widening spread market"),
        ("asset_class == 'govt_bond' and duration_t0 > 15", 1.80, "extended duration at the long end"),
        ("asset_class == 'corp_bond' and duration_t0 < 3", 0.35, "sold the short-dated IG carry book"),
        ("asset_class == 'irs'", 1.40, "increased the pay-fixed hedge"),
    ],
    "MA001": [
        ("asset_class == 'equity'", 0.86, "cut the equity sleeve by ~5pp"),
        ("asset_class == 'option'", 3.20, "tripled the index put protection"),
        ("asset_class == 'govt_bond'", 1.22, "recycled into duration"),
    ],
    "EQ001": [
        ("sector == 'Technology'", 1.24, "rotated into technology"),
        ("sector == 'Energy'", 0.62, "cut energy"),
    ],
}

# Planted driver #5: the benchmark itself reweights. Tracking error moves in
# EQ001 partly for reasons the portfolio manager did not cause.
BENCHMARK_REWEIGHT = {"EQ001": {"Technology": 1.18, "Energy": 0.80}}


def _fund_universe(inst: pd.DataFrame, fund_id: str) -> pd.DataFrame:
    ac = inst.asset_class
    if fund_id == "FI001":
        m = ac.isin(["govt_bond", "corp_bond", "irs"]) | inst.instrument_id.isin(["FU0001", "FU0002"])
    elif fund_id == "EQ001":
        m = (ac == "equity") | (inst.instrument_id == "FU0003")
    else:
        m = ((ac == "equity") & (inst.index % 2 == 0)) | \
            ((ac == "govt_bond") & (inst.index % 2 == 0)) | \
            (ac.isin(["option", "fx_forward"])) | (inst.instrument_id == "FU0003")
    return inst[m].reset_index(drop=True)


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------

Z99 = 2.3263478740408408          # one-tailed 99% normal quantile
TRADING_DAYS = 252


def _mod_duration(mat_yrs: float, yld: float) -> float:
    """Modified duration of a par-ish bullet. Monotone in maturity, falls as yields rise."""
    y = max(yld, 1e-4) / 100.0
    return float((1.0 - (1.0 + y) ** (-max(mat_yrs, 0.02))) / y)


def _deriv_analytics(inst: pd.Series, date: str) -> tuple[float, float, float]:
    """Return (duration, spread_duration, delta) for a derivative."""
    ac = inst.asset_class
    if ac == "future":
        if inst.underlying == "SPX":
            return 0.0, 0.0, 1.0
        return (8.1 if inst.currency == "USD" else 9.4), 0.0, 1.0
    if ac == "option":
        # A put's delta is negative and gets more negative as the market falls.
        # Planted: spot drifts down between dates, so the same put is a bigger hedge.
        base = -0.24 if inst.strike == 5400.0 else -0.11
        return 0.0, 0.0, base * (1.0 if date == T0 else 1.28)
    if ac == "irs":
        sign = -1.0 if inst.pay_receive == "pay_fixed" else 1.0
        return sign * float(inst.tenor_years) * 0.87, 0.0, 1.0
    return 0.0, 0.0, 1.0


def _build_fund_date(inst_all: pd.DataFrame, curves: pd.DataFrame,
                     fund_id: str, date: str, units: dict[str, float]) -> pd.DataFrame:
    uni = _fund_universe(inst_all, fund_id).copy()
    cfg = FUNDS[fund_id]
    nav = cfg["nav"][date]
    cmap = {(r.curve_id, r.tenor_years): r.rate
            for r in curves[curves.cob_date == date].itertuples()}

    def yield_for(row) -> float:
        cid = _curve_for(fund_id, row.currency, date)
        mat = 5.0 if not row.maturity else (int(row.maturity[:4]) - 2026) + 0.5
        t = min(TENORS, key=lambda x: abs(x - mat))
        rating = _rating_at(row.instrument_id, row.rating, date)
        spread = {"AAA": 0.15, "AA": 0.35, "A": 0.70, "BBB": 1.35, "BB": 2.90, "B": 4.60}.get(rating, 0.0)
        # Planted driver #1 again, on the cash side: spreads widen at T1
        if date == T1:
            spread *= 1.0 if row.asset_class == "govt_bond" else 1.30
        return cmap[(cid, t)] + spread

    rows = []
    for row in uni.itertuples():
        u = units.get(row.instrument_id, 0.0)
        if abs(u) < 1e-12:
            continue
        ac, dur, sdur, delta, px = row.asset_class, 0.0, 0.0, 1.0, 100.0
        if ac in ("govt_bond", "corp_bond"):
            mat = (int(row.maturity[:4]) - 2026) + 0.5 - (0.0 if date == T0 else 31 / 365)
            y = yield_for(row)
            dur = _mod_duration(mat, y)
            sdur = dur if ac == "corp_bond" else 0.0
            px = 100.0 * (1.0 + (row.coupon - y) * dur / 100.0)
        elif ac == "equity":
            h = (_h(row.instrument_id) % 1000) / 1000.0
            px = 20.0 + 180.0 * h
            if date == T1:                       # equities drift up ~1.8% with dispersion
                px *= 1.0 + 0.018 + 0.09 * (((_h(row.name) % 200) / 200.0) - 0.5)
        else:
            dur, sdur, delta = _deriv_analytics(row, date)
            px = {"future": 112.5 if row.underlying != "SPX" else 5720.0,
                  "option": 46.0, "irs": 0.0, "fx_forward": 0.0}[ac]
            if date == T1 and row.underlying == "SPX":
                px *= 0.972                      # planted: index down 2.8%, puts in the money
        mv = u * px * (row.multiplier if ac in ("future", "option") else 1.0) / \
             (100.0 if ac in ("govt_bond", "corp_bond") else 1.0)
        if ac in ("irs", "fx_forward"):
            mv = u * 0.004                       # near-zero MV, all the risk is notional
        notional = u * (row.multiplier if ac in ("future", "option") else 1.0) * \
            (px if ac in ("future", "option") else 1.0) * (1.0 if ac not in ("irs", "fx_forward") else 1.0)
        if ac in ("irs", "fx_forward"):
            notional = u
        elif ac in ("govt_bond", "corp_bond"):
            notional = u
        elif ac == "equity":
            notional = mv
        rows.append(dict(
            cob_date=date, fund_id=fund_id, instrument_id=row.instrument_id,
            asset_class=ac, currency=row.currency, sector=row.sector,
            rating=_rating_at(row.instrument_id, row.rating, date),
            yield_curve_id=_curve_for(fund_id, row.currency, date),
            units=u, price=round(px, 4), market_value=mv,
            notional=notional, duration=round(dur, 4), spread_duration=round(sdur, 4),
            delta=delta, maturity=row.maturity, name=row.name,
        ))

    df = pd.DataFrame(rows)
    df["nav"] = nav
    df["weight"] = df.market_value / nav
    # Effective (risk) exposure: MV weight for cash instruments, delta-adjusted
    # notional weight for derivatives. Getting this wrong is the single most
    # common error in derivative-holding fund risk reporting.
    is_deriv = df.asset_class.isin(["future", "option", "irs", "fx_forward"])
    df["notional_weight"] = np.where(is_deriv, df.delta * df.notional / nav, df.weight)
    df["risk_weight"] = df.notional_weight
    df["model_date"] = date
    return df


def _factor_risk(df: pd.DataFrame, inst_all: pd.DataFrame, date: str,
                 weight_col: str) -> tuple[float, np.ndarray]:
    """Return (portfolio vol, per-position contribution to vol) via Euler decomposition."""
    imap = inst_all.set_index("instrument_id", drop=False)
    B = np.array([_loadings(imap.loc[r.instrument_id], r.duration, date) for r in df.itertuples()])
    if df.asset_class.eq("option").any():          # scale option loadings by delta
        B = B * np.where(df.asset_class.values[:, None] == "option",
                         np.abs(df.delta.values)[:, None], 1.0)
    D = np.diag(np.array([_idio_vol(imap.loc[r.instrument_id]) for r in df.itertuples()]) ** 2)
    S = B @ _cov(date) @ B.T + D
    w = df[weight_col].to_numpy()
    var = float(w @ S @ w)
    vol = float(np.sqrt(max(var, 1e-12)))
    ctv = w * (S @ w) / vol                        # Euler: sums exactly to vol
    return vol, ctv


def _target_units(inst_all: pd.DataFrame, curves: pd.DataFrame, fund_id: str) -> dict[str, float]:
    """Pick t0 units so that cash weights land on a sensible profile."""
    probe = _build_fund_date(inst_all, curves, fund_id, T0,
                             {i: 1.0 for i in _fund_universe(inst_all, fund_id).instrument_id})
    nav = FUNDS[fund_id]["nav"][T0]
    cash = probe[~probe.asset_class.isin(["future", "option", "irs", "fx_forward"])]
    n = len(cash)
    rng = np.random.default_rng(abs(_h(fund_id)) % (2**32))
    tgt = rng.dirichlet(np.full(n, 12.0)) * (0.965 if fund_id != "MA001" else 0.93)
    units = {}
    for w, r in zip(tgt, cash.itertuples()):
        px_per_unit = r.market_value / r.units
        units[r.instrument_id] = w * nav / px_per_unit
    deriv_contracts = {
        "FI001": {"FU0001": 900.0, "FU0002": 350.0, "IR0001": 120_000_000.0, "IR0002": 60_000_000.0},
        "MA001": {"FU0003": 260.0, "OP0001": 900.0, "OP0002": 500.0, "FX0001": 90_000_000.0},
        "EQ001": {"FU0003": 480.0},
    }[fund_id]
    units.update(deriv_contracts)
    return units


def _open_at_t0(units_t0: dict[str, float], fund_id: str) -> dict[str, float]:
    """Zero out the instruments planted as T1 entries, so they are genuinely absent at T0."""
    u = dict(units_t0)
    for iid in PLANTED_ENTRIES.get(fund_id, {}):
        u[iid] = 0.0
    return u


def _apply_trades(inst_all: pd.DataFrame, curves: pd.DataFrame,
                  fund_id: str, units_t0: dict[str, float]) -> dict[str, float]:
    """Apply the planted trades, entries and exits. Returns t1 units."""
    ref = _build_fund_date(inst_all, curves, fund_id, T0, units_t0)
    ref = ref.rename(columns={"duration": "duration_t0"})
    units_t1 = dict(units_t0)

    for expr, mult, _note in PLANTED_TRADES.get(fund_id, []):
        hit = ref.query(expr)
        for iid in hit.instrument_id:
            units_t1[iid] = units_t1.get(iid, 0.0) * mult

    # Exits: fully closed, so the position does not exist at T1 at all.
    for iid in PLANTED_EXITS.get(fund_id, []):
        units_t1[iid] = 0.0

    # Entries: bought from nothing. Size them to a target weight using a T0
    # price probe, since the position has no T0 row to scale from.
    entries = PLANTED_ENTRIES.get(fund_id, {})
    if entries:
        nav = FUNDS[fund_id]["nav"][T1]
        probe = _build_fund_date(inst_all, curves, fund_id, T1,
                                 {i: 1.0 for i in entries})
        for r in probe.itertuples():
            px_per_unit = r.market_value / r.units
            units_t1[r.instrument_id] = entries[r.instrument_id] * nav / px_per_unit
    return units_t1


def _benchmark(inst_all: pd.DataFrame, positions: pd.DataFrame,
               fund_id: str, date: str) -> pd.Series:
    """Benchmark weights aligned to `positions`, normalised to 1 over cash instruments."""
    cash = ~positions.asset_class.isin(["future", "option", "irs", "fx_forward"])
    pseudo_cap = np.array([1.0 + (abs(_h(i)) % 900) / 100.0
                           for i in positions.instrument_id]) * cash.to_numpy()
    rw = BENCHMARK_REWEIGHT.get(fund_id, {})
    if date == T1 and rw:
        pseudo_cap = pseudo_cap * positions.sector.map(lambda s: rw.get(s, 1.0)).to_numpy()
    return pd.Series(pseudo_cap / pseudo_cap.sum(), index=positions.index)


def generate(outdir: str = "data") -> dict[str, pd.DataFrame]:
    import os
    os.makedirs(outdir, exist_ok=True)
    inst = build_instruments()
    curves = build_curves()

    frames, snaps = [], []
    for fund_id in FUNDS:
        u0 = _open_at_t0(_target_units(inst, curves, fund_id), fund_id)
        u1 = _apply_trades(inst, curves, fund_id, u0)
        for date, units in ((T0, u0), (T1, u1)):
            df = _build_fund_date(inst, curves, fund_id, date, units)
            vol, ctv = _factor_risk(df, inst, date, "risk_weight")
            df["ctv"] = ctv
            # standalone vol of each position's instrument (unit exposure)
            imap = inst.set_index("instrument_id", drop=False)
            sav = []
            for r in df.itertuples():
                b = _loadings(imap.loc[r.instrument_id], r.duration, date)
                if r.asset_class == "option":
                    b = b * abs(r.delta)
                sav.append(float(np.sqrt(b @ _cov(date) @ b + _idio_vol(imap.loc[r.instrument_id]) ** 2)))
            df["standalone_vol"] = sav

            bw = _benchmark(inst, df, fund_id, date)
            df["benchmark_weight"] = bw
            df["active_weight"] = df.risk_weight - bw
            te, ctv_a = _factor_risk(df.assign(_a=df.active_weight), inst, date, "_a")
            df["ctv_active"] = ctv_a

            df["sleeve"] = _sleeve(df, FUNDS[fund_id]["fund_type"])
            frames.append(df)

            nav = FUNDS[fund_id]["nav"][date]
            snaps.append(dict(
                cob_date=date, fund_id=fund_id, nav=nav, model_date=date,
                ex_ante_vol=vol,
                # Money VaR, in millions of base currency. Reporting VaR as a
                # percentage hides the fund-size term: a fund whose volatility
                # rises 35% while it pays out an 8% redemption has less money at
                # risk than the percentage suggests, and that is the number a
                # board reacts to.
                var_99_1d=Z99 * vol / np.sqrt(TRADING_DAYS) / 100.0 * nav / 1e6,
                tracking_error=te,
                duration=float((df.risk_weight * df.duration).sum()),
                spread_duration=float((df.risk_weight * df.spread_duration).sum()),
            ))

    pos = pd.concat(frames, ignore_index=True)
    snap = pd.DataFrame(snaps)
    funds = pd.DataFrame([dict(fund_id=k, fund_name=v["name"], fund_type=v["fund_type"],
                               benchmark_name=v["benchmark"]) for k, v in FUNDS.items()])
    pos.to_csv(f"{outdir}/positions.csv", index=False)
    snap.to_csv(f"{outdir}/risk_snapshots.csv", index=False)
    curves.to_csv(f"{outdir}/curves.csv", index=False)
    inst.to_csv(f"{outdir}/instruments.csv", index=False)
    funds.to_csv(f"{outdir}/funds.csv", index=False)
    return dict(positions=pos, snapshots=snap, curves=curves, instruments=inst, funds=funds)


def _sleeve(df: pd.DataFrame, fund_type: str) -> pd.Series:
    """The roll-up bucket. Chosen per fund type -- this is a risk-reporting
    decision, not a data attribute: you bucket by whatever you would defend."""
    if fund_type == "fixed_income":
        return np.where(df.asset_class.isin(["future", "option", "irs", "fx_forward"]), "Derivative overlay",
               np.where(df.asset_class == "govt_bond", "Government",
                        "Credit " + df.rating.astype(str)))
    if fund_type == "equity":
        return np.where(df.asset_class == "future", "Derivative overlay", df.sector.astype(str))
    return np.where(df.asset_class.isin(["future", "option", "irs", "fx_forward"]), "Derivative overlay",
           np.where(df.asset_class == "equity", "Equity " + df.sector.astype(str),
           np.where(df.asset_class == "govt_bond", "Government bonds", "Credit")))


def write_ground_truth(outdir: str = "data") -> str:
    """Write down what was planted, from the constants themselves.

    Generated rather than hand-written so it cannot drift from the generator.
    Every test that claims the engine "found" a driver is checking against this.
    """
    L = ["# Ground truth", "",
         "Planted deliberately by `data/synth.py`. The engine is never told any of it.",
         "", f"Dates: **{T0}** to **{T1}**.", "",
         "## Factor volatilities (annualised %)", "",
         "| factor | t0 | t1 |", "|---|---:|---:|"]
    for f in FACTORS:
        L.append(f"| {f} | {FACTOR_VOL[T0][f]} | {FACTOR_VOL[T1][f]} |")

    L += ["", "## Factor correlations", "", "| pair | t0 | t1 |", "|---|---:|---:|"]
    for k in FACTOR_CORR_PAIRS[T0]:
        L.append(f"| {k[0]} / {k[1]} | {FACTOR_CORR_PAIRS[T0][k]} | {FACTOR_CORR_PAIRS[T1][k]} |")

    L += ["", "## Planted trades (multiplier on t0 units)", "",
          "| fund | predicate | x | intent |", "|---|---|---:|---|"]
    for fid, rows in PLANTED_TRADES.items():
        for expr, mult, note in rows:
            L.append(f"| {fid} | `{expr}` | {mult} | {note} |")

    L += ["", "## Position entries and exits", "",
          "| fund | opened (target weight) | closed |", "|---|---|---|"]
    for fid in FUNDS:
        e = ", ".join(f"{k} ({v:.1%})" for k, v in PLANTED_ENTRIES.get(fid, {}).items())
        x = ", ".join(PLANTED_EXITS.get(fid, []))
        L.append(f"| {fid} | {e or '-'} | {x or '-'} |")

    L += ["", "## Rating migrations", "", "| instrument | t0 | t1 |", "|---|---|---|"]
    for iid, (a, b) in RATING_MIGRATION.items():
        L.append(f"| {iid} | {a} | {b} |")

    L += ["", "## Curve reassignment (a MODEL INPUT change, not a market move)", ""]
    for fid, per_date in CURVE_REASSIGNMENT.items():
        for date, remap in per_date.items():
            for a, b in remap.items():
                L.append(f"- {fid}: `{a}` -> `{b}` at {date}")

    L += ["", "## Benchmark reweights", ""]
    for fid, rw in BENCHMARK_REWEIGHT.items():
        L.append(f"- {fid}: " + ", ".join(f"{k} x{v}" for k, v in rw.items()))

    L += ["", "## Curves", "",
          f"- Bear steepening at {T1}: +10bp parallel, +20bp additional at the long end",
          f"- Curves: {', '.join(sorted(_CURVE_BASE))}",
          "- `USD_OIS` does not change relative to `USD_SWAP` between the dates. What",
          "  changes is which positions point at it.", ""]

    path = f"{outdir}/GROUND_TRUTH.md"
    open(path, "w").write("\n".join(L) + "\n")
    return path


if __name__ == "__main__":
    out = generate()
    print(out["snapshots"].round(4).to_string(index=False))
    print("wrote", write_ground_truth())
