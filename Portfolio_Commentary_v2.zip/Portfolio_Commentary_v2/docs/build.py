#!/usr/bin/env python3
"""Concatenate part_*.html and render to PDF via headless Chrome.

weasyprint is broken on this machine; Chrome's print pipeline handles the print
CSS, page breaks and the PDF outline correctly.
"""
import glob
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CHROME = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
OUT = os.path.join(HERE, "Portfolio_Commentary_Framework.pdf")
MERGED = os.path.join(HERE, "_merged.html")


def build():
    parts = sorted(glob.glob(os.path.join(HERE, "part_*.html")))
    if not parts:
        sys.exit("no part_*.html found")
    css = open(os.path.join(HERE, "style.css")).read()
    body = "\n".join(open(p).read() for p in parts)
    html = (f"<!doctype html><html><head><meta charset='utf-8'>"
            f"<title>Portfolio Commentary — Framework</title>"
            f"<style>{css}</style></head><body>{body}</body></html>")
    open(MERGED, "w").write(html)

    subprocess.run([
        CHROME, "--headless", "--disable-gpu", "--no-pdf-header-footer",
        "--generate-pdf-document-outline", "--virtual-time-budget=12000",
        f"--print-to-pdf={OUT}", f"file://{MERGED}",
    ], check=True, capture_output=True)
    print(f"{OUT}  ({os.path.getsize(OUT)/1e6:.2f} MB from {len(parts)} parts)")


if __name__ == "__main__":
    build()
