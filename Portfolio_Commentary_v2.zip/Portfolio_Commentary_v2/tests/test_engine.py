"""Engine exactness: does the arithmetic hold, and does it hold for the right reasons."""

import math

import pytest

from engine import analyze, decompose, findings, positions as posmod, triage
from engine.types import Effect, Level, MetricChange


def test_every_decomposition_reconciles(analyses, cat):
    """The claim the whole framework rests on. Additive to floating point."""
    for fund, a in analyses.items():
        for r in analyze.reconciliation(a, cat):
            assert r["reconciles"], f"{fund}/{r['metric']} residual {r['residual']}"
            assert abs(r["residual"]) < 1e-9


def test_residual_check_can_actually_fail(cat):
    """A check that cannot fail is not a check.

    Recording the residual as a ledger item must not close the residual --
    otherwise reconciliation passes by construction and the R9 rung is theatre.
    """
    from engine.types import LedgerItem
    mc = MetricChange(metric="ex_ante_vol", label="vol", unit="pts", precision=2,
                      t0="a", t1="b", value_t0=1.0, value_t1=2.0)
    mc.items = [LedgerItem(metric="ex_ante_vol", level=Level.POSITION, entity="X",
                           entity_label="X", effect=Effect.ALLOCATION, value=0.4)]
    assert mc.residual() == pytest.approx(0.6)
    findings.add_unexplained(mc, cat)
    # the gap is now recorded, and still reported as a gap
    assert mc.residual() == pytest.approx(0.6)
    assert any(i.effect is Effect.UNEXPLAINED for i in mc.items)


def test_effect_rollup_reproduces_the_change(analyses):
    for a in analyses.values():
        for mc in a.changes.values():
            total = sum(v for k, v in mc.by_effect().items()
                        if k != Effect.UNEXPLAINED.value)
            assert total == pytest.approx(mc.change, abs=1e-9)


def test_sleeve_view_reconciles_to_positions(analyses):
    """The sleeve roll-up is a derived view of the same money, never extra money."""
    for a in analyses.values():
        for mc in a.changes.values():
            pos = sum(i.value for i in mc.items if i.level is Level.POSITION)
            sle = sum(i.value for i in mc.items if i.level is Level.SLEEVE)
            assert sle == pytest.approx(pos, abs=1e-9)


def test_sleeve_rows_are_excluded_from_additive_set(analyses):
    for a in analyses.values():
        for mc in a.changes.values():
            assert all(i.level is not Level.SLEEVE for i in mc.additive_items())


def test_benchmark_effect_only_where_there_is_a_benchmark(analyses, cat):
    for a in analyses.values():
        for metric, mc in a.changes.items():
            has_bmk = cat.metric(metric).benchmark_split
            got = any(i.effect is Effect.BENCHMARK for i in mc.items)
            assert got <= has_bmk, f"{metric} produced a benchmark effect without a split"


def test_entries_are_entry_not_allocation(analyses):
    """A position bought from nothing is a different decision from a resize."""
    seen = 0
    for a in analyses.values():
        for iid in a.sets.entered:
            for mc in a.changes.values():
                mine = [i for i in mc.items
                        if i.entity == iid and i.level is Level.POSITION]
                if not mine:
                    continue
                seen += 1
                assert not any(i.effect is Effect.ALLOCATION for i in mine), \
                    f"{iid} entered but was booked as allocation"
                assert any(i.effect is Effect.ENTRY for i in mine)
    assert seen > 0, "the book must contain entries or this test proves nothing"


def test_exits_are_exit_not_allocation(analyses):
    seen = 0
    for a in analyses.values():
        for iid in a.sets.exited:
            for mc in a.changes.values():
                mine = [i for i in mc.items
                        if i.entity == iid and i.level is Level.POSITION]
                if not mine:
                    continue
                seen += 1
                assert not any(i.effect is Effect.ALLOCATION for i in mine)
                assert any(i.effect is Effect.EXIT for i in mine)
    assert seen > 0


def test_entry_exit_labelling_does_not_change_any_value(book, cat, dates):
    """Labelling is a naming decision. If it moved a number, it would be a bug."""
    t0, t1 = dates
    p = book.positions
    for fund in book.fund_ids:
        d0 = p[(p.fund_id == fund) & (p.cob_date == t0)]
        d1 = p[(p.fund_id == fund) & (p.cob_date == t1)]
        real = posmod.split(d0, d1, fund, t0, t1)
        # a set that claims nothing entered or exited: every weight term is ALLOCATION
        flat = posmod.PositionSets(fund, t0, t1, [], [], sorted(
            set(d0.instrument_id) | set(d1.instrument_id)))
        spec = cat.metric("ex_ante_vol")
        a = sum(i.value for i in decompose.decompose_risk(d0, d1, spec, cat, real))
        b = sum(i.value for i in decompose.decompose_risk(d0, d1, spec, cat, flat))
        assert a == pytest.approx(b, abs=1e-12)


def test_cross_impact_means_untouched_and_unchanged(analyses, cat):
    xi = cat.materiality["cross_impact"]
    found = 0
    for a in analyses.values():
        for mc in a.changes.values():
            for i in mc.items:
                # sleeve rows are a roll-up and carry no per-position evidence
                if i.effect is not Effect.CROSS_IMPACT or i.level is not Level.POSITION:
                    continue
                found += 1
                ev = i.evidence
                assert abs(ev["w1"] - ev["w0"]) < xi["weight_unchanged_abs"]
                assert abs(ev["vol1"] - ev["vol0"]) <= xi["vol_unchanged_rel"] * abs(ev["vol0"])
                assert ev["position_state"] == "held"
    assert found > 0, "the book must contain a cross-impact case"


def test_curve_identity_and_curve_move_are_separate_findings(analyses):
    a = analyses["FI001"]
    swaps = a.curves["reassignments"]
    moves = a.curves["market_moves"]
    assert swaps and swaps[0]["available"], "the planted curve reassignment is missing"
    assert swaps[0]["narrative_class"] == "model_input"
    assert all(m["narrative_class"] == "market" for m in moves)
    # the reassignment is measured at a single date, so it cannot contain the move
    assert swaps[0]["from"] != swaps[0]["to"]
    assert any(m["shape"].endswith("steepening") for m in moves)


def test_rating_migration_is_detected_with_direction(analyses):
    mig = [c for c in analyses["FI001"].field_changes if c.field == "rating"]
    assert len(mig) >= 2
    assert all("downgrade" in c.reason for c in mig)
    assert all(c.agency == "issuer" for c in mig)


def test_var_carries_the_fund_size_term(analyses):
    """FI001 paid a redemption. VaR must show it; percentage vol cannot."""
    mc = analyses["FI001"].changes["var_99_1d"]
    nav = [i for i in mc.items if i.effect is Effect.MARKET_VALUE]
    assert nav, "no NAV term in the VaR decomposition"
    assert nav[0].value < 0, "NAV fell, so the fund-size term must reduce money VaR"


def test_curve_decomposition_is_orthogonal_and_fits(analyses):
    for m in analyses["FI001"].curves["market_moves"]:
        assert m["r_squared"] > 0.95
        assert abs(m["level_bp"]) > 3.0


def test_planted_drivers_are_recovered(analyses):
    """Ground truth from data/synth.py, found by the engine without being told."""
    fi = analyses["FI001"]
    eff = fi.changes["ex_ante_vol"].by_effect()
    # credit spread vol spiked -> standalone vol is a positive driver
    assert eff.get("standalone_vol", 0) > 0
    # the manager added high yield and extended duration -> allocation positive
    assert eff.get("allocation", 0) > 0
    # the benchmark reweight was planted in EQ001 only
    eq = analyses["EQ001"].changes["tracking_error"].by_effect()
    assert abs(eq.get("benchmark", 0)) > 0.05
    assert "benchmark" not in fi.changes["ex_ante_vol"].by_effect()
