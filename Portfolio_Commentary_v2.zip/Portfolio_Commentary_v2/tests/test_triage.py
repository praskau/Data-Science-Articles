"""The two gates. Gate 2 is the reason this file exists."""

import pytest

from engine import triage
from engine.types import Effect, LedgerItem, Level, MetricChange


def _mc(metric, v0, v1, terms, cat):
    """A MetricChange with hand-built terms, so a gate can be tested in isolation."""
    mc = MetricChange(metric=metric, label=cat.metric(metric).label,
                      unit=cat.metric(metric).unit, precision=3,
                      t0="t0", t1="t1", value_t0=v0, value_t1=v1)
    mc.items = [LedgerItem(metric=metric, level=Level.POSITION, entity=f"P{i}",
                           entity_label=f"P{i}", effect=Effect.ALLOCATION, value=v)
                for i, v in enumerate(terms)]
    return mc


def test_quiet_headline_busy_portfolio_is_caught_only_by_gate_2(cat):
    """The case gate 1 is structurally blind to.

    Tracking error moves 0.017 on 3.609 of gross activity -- a 212x netting
    ratio. The fund was rebuilt and landed back where it started. Gate 1 sees a
    non-event; gate 2 is the only thing standing between that fund and silence.
    """
    mc = _mc("tracking_error", 1.000, 1.017, [+1.813, -1.796], cat)
    assert mc.netting_ratio > 100
    r = triage.gate(cat, "EQX", {"tracking_error": mc})
    assert r.gate_1_net is False
    assert r.gate_2_gross is True
    assert r.in_scope is True
    assert "rebuilt underneath" in " ".join(r.reasons)


def test_gate_2_does_not_fire_on_a_metric_gate_1_already_flagged(cat):
    """Calling a metric that moved 27% 'quiet' would be incoherent."""
    mc = _mc("tracking_error", 1.000, 1.267, [+2.60, -2.33], cat)
    assert mc.netting_ratio > 3
    r = triage.gate(cat, "EQY", {"tracking_error": mc})
    assert r.gate_1_net is True
    assert r.gate_2_gross is False
    assert not any("looks quiet" in x for x in r.reasons)


def test_a_genuinely_quiet_fund_is_out_of_scope_and_says_why(cat):
    mc = _mc("tracking_error", 1.000, 1.002, [+0.0012, +0.0008], cat)
    r = triage.gate(cat, "EQZ", {"tracking_error": mc})
    assert r.in_scope is False
    assert "out of scope" in " ".join(r.reasons)


def test_gate_2_needs_material_gross_not_just_a_high_ratio(cat):
    """Two tiny offsetting terms produce an enormous ratio and mean nothing."""
    mc = _mc("tracking_error", 1.000, 1.0000001, [+0.004, -0.004], cat)
    r = triage.gate(cat, "EQW", {"tracking_error": mc})
    assert r.gate_2_gross is False
    assert r.in_scope is False


def test_gate_1_requires_the_absolute_floor_too(cat):
    """A 50% move on a near-zero base is not a risk event."""
    mc = _mc("tracking_error", 0.002, 0.003, [0.001], cat)
    r = triage.gate(cat, "EQV", {"tracking_error": mc})
    assert abs(mc.rel_change) > 0.10
    assert r.gate_1_net is False


def test_real_book_triage_runs_and_reports_both_gates(cat, analyses):
    tr = triage.triage_all(cat, {f: a.changes for f, a in analyses.items()})
    assert set(tr["in_scope"]) | set(tr["out_of_scope"]) == set(analyses)
    for f, r in tr["results"].items():
        assert r["in_scope"] == (r["gate_1_net"] or r["gate_2_gross"])
        assert r["reasons"]
