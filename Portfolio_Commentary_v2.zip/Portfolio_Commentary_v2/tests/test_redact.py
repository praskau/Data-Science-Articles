"""Pseudonymisation. The audit runs on what is written, not on what we meant to write."""

import json

from engine import context as ctxmod, redact


def test_no_real_name_survives_in_the_payload(book, cat, analyses, cross):
    a = analyses["FI001"]
    ctx = ctxmod.build(a, cat, cross)
    m = redact.build_map(a, book, "FI001")
    red = redact.redact_context(ctx, m)

    leaks = redact.audit(red, m)
    assert leaks == [], f"names survived redaction: {leaks[:5]}"

    blob = json.dumps(red)
    for probe in ("Global Credit Opportunities", "ICE BofA", "SOVEREIGN", "TECH101"):
        assert probe not in blob


def test_the_economics_survive_redaction(book, cat, analyses, cross):
    a = analyses["FI001"]
    ctx = ctxmod.build(a, cat, cross)
    m = redact.build_map(a, book, "FI001")
    red = redact.redact_context(ctx, m)
    assert red["must_cover_ids"] == ctx["must_cover_ids"]
    for x, y in zip(ctx["metrics"], red["metrics"]):
        assert x["change"] == y["change"]
        assert x["gross_activity"] == y["gross_activity"]


def test_names_are_restored_locally(book, cat, analyses):
    a = analyses["FI001"]
    m = redact.build_map(a, book, "FI001")
    pseudo = next(k for k in m if not k.endswith("#id") and k.startswith("CorpBond"))
    assert redact.restore(f"{pseudo} widened.", m) == f"{m[pseudo]} widened."


def test_mapping_is_deterministic(book, cat, analyses):
    a = analyses["FI001"]
    assert redact.build_map(a, book, "FI001") == redact.build_map(a, book, "FI001")
