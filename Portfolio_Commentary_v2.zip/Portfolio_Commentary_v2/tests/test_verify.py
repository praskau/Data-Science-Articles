"""Adversarial verifier tests.

These prove the verifier CATCHES bad commentary. A suite that only shows it
accepts good output proves nothing -- an empty function passes that test.
"""

import pytest

from engine import findings, verify as V
from engine.schemas import Claim, LongFormCommentary, Section, ShortFormCommentary
from engine.types import Effect, Level


@pytest.fixture
def fi(analyses):
    return analyses["FI001"]


@pytest.fixture
def ctx(contexts):
    return contexts["FI001"]


def _targets(cat, a):
    return findings.coverage_targets(cat, a.changes, a.profile.headline_metric)


def _good(cat, a, ctx):
    """A draft that covers every required item using only grounded figures."""
    t = _targets(cat, a)
    claims = []
    for iid, it in t.items():
        claims.append(Claim(ledger_ids=[iid], metric=it.metric,
                            text=f"{it.entity_label} contributed {it.value:+.4f} "
                                 f"through {it.effect.value}.",
                            figures=[round(it.value, 4)]))
    return LongFormCommentary(
        headline="Volatility rose on credit spread widening.",
        opening="The decomposition is set out below.",
        sections=[Section(title="Drivers", claims=claims)],
        not_the_driver=[], caveats=[])


def test_verifier_accepts_a_valid_draft(cat, fi, ctx):
    res = V.verify_long_form(_good(cat, fi, ctx), fi, cat, ctx)
    assert res.ok, res.report()
    assert res.coverage == 1.0


def test_catches_a_dropped_driver(cat, fi, ctx):
    doc = _good(cat, fi, ctx)
    doc.sections[0].claims = doc.sections[0].claims[:-3]
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert not res.ok
    assert sum(d.kind == "uncovered_driver" for d in res.defects) == 3


def test_catches_an_invented_figure(cat, fi, ctx):
    doc = _good(cat, fi, ctx)
    doc.sections[0].claims[0].text += " This added 8.4471 vol points."
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert any(d.kind == "ungrounded_figure" and d.severity == "error"
               for d in res.defects)


def test_catches_a_figure_that_is_real_but_from_the_wrong_item(cat, fi, ctx):
    """Per-claim provenance. A document-wide allowlist passes this; that is why
    the allowlist is built per claim."""
    t = _targets(cat, fi)
    ids = list(t)
    borrowed = round(t[ids[-1]].value, 4)
    doc = _good(cat, fi, ctx)
    doc.sections[0].claims[0].text += f" It moved {borrowed:+.4f}."
    doc.sections[0].claims[0].figures.append(borrowed)
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert any(d.kind == "ungrounded_figure" for d in res.defects)


def test_catches_a_fake_ledger_id(cat, fi, ctx):
    doc = _good(cat, fi, ctx)
    doc.sections[0].claims[0].ledger_ids = ["deadbeef"]
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert any(d.kind == "unknown_ledger_id" for d in res.defects)


def test_catches_false_stability_under_high_netting(cat, analyses, contexts):
    """Find a metric whose gross activity dwarfs its net move, then claim it was
    broadly unchanged. That sentence is true-looking and wrong."""
    for f, a in analyses.items():
        for metric, mc in a.changes.items():
            if mc.netting_ratio <= float(cat.materiality["netting_alert"]):
                continue
            doc = LongFormCommentary(
                headline="h", opening="o",
                sections=[Section(title="s", claims=[Claim(
                    ledger_ids=[], metric=metric,
                    text=f"{mc.label} was broadly unchanged over the period.",
                    figures=[])])])
            res = V.verify_long_form(doc, a, cat, contexts[f])
            assert any(d.kind == "false_stability" for d in res.defects)
            return
    pytest.fail("no high-netting metric in the book to test against")


def test_catches_an_empty_claim(cat, fi, ctx):
    doc = _good(cat, fi, ctx)
    doc.sections[0].claims[0].text = "   "
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert any(d.kind == "empty_claim" for d in res.defects)


def test_flags_a_reversed_direction(cat, fi, ctx):
    t = _targets(cat, fi)
    iid, it = next((k, v) for k, v in t.items() if v.value > 0)
    doc = LongFormCommentary(
        headline="h", opening="o",
        sections=[Section(title="s", claims=[Claim(
            ledger_ids=[iid], metric=it.metric,
            text=f"{it.entity_label} fell over the period.", figures=[])])])
    res = V.verify_long_form(doc, fi, cat, ctx)
    assert any(d.kind == "direction_mismatch" for d in res.defects)


# --- short form ---------------------------------------------------------

def _short(cat, a):
    mc = a.changes[a.profile.headline_metric]
    kd = findings.key_driver(mc)
    return ShortFormCommentary(
        headline="Volatility rose.",
        body=f"{kd.entity_label} was the largest driver at {kd.value:+.4f}.",
        key_driver_ledger_ids=[kd.item_id], figures=[round(kd.value, 4)])


def test_catches_an_overlong_short_form(cat, fi, ctx):
    doc = _short(cat, fi)
    doc.body = " ".join(["word"] * 71)
    lf = _good(cat, fi, ctx)
    res = V.verify_short_form(doc, fi, cat, lf, ctx)
    assert any(d.kind == "word_limit" for d in res.defects)


def test_catches_a_short_form_naming_the_wrong_driver(cat, fi, ctx):
    """The engine computes the key driver. Naming another is a wrong answer."""
    t = _targets(cat, fi)
    kd = findings.key_driver(fi.changes[fi.profile.headline_metric])
    other = next(k for k in t if k != kd.item_id)
    doc = _short(cat, fi)
    doc.key_driver_ledger_ids = [other]
    res = V.verify_short_form(doc, fi, cat, _good(cat, fi, ctx), ctx)
    assert any(d.kind == "wrong_key_driver" for d in res.defects)


def test_catches_a_short_form_with_two_drivers(cat, fi, ctx):
    t = _targets(cat, fi)
    kd = findings.key_driver(fi.changes[fi.profile.headline_metric])
    doc = _short(cat, fi)
    doc.key_driver_ledger_ids = [kd.item_id, next(k for k in t if k != kd.item_id)]
    res = V.verify_short_form(doc, fi, cat, _good(cat, fi, ctx), ctx)
    assert any(d.kind == "too_many_drivers" for d in res.defects)


def test_catches_a_short_form_with_no_driver(cat, fi, ctx):
    doc = _short(cat, fi)
    doc.key_driver_ledger_ids = []
    res = V.verify_short_form(doc, fi, cat, _good(cat, fi, ctx), ctx)
    assert any(d.kind == "no_driver" for d in res.defects)
