"""The central claim of the rewrite: a new field is a config change, not a code change.

If any test in this file needs a Python edit to pass, the architecture has not
delivered what it promised.
"""

import json
import os
import shutil

import pandas as pd
import pytest

from engine import catalogue, diff, positions as posmod

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@pytest.fixture
def sandbox(tmp_path):
    """A copy of config/ that a test may edit."""
    d = tmp_path / "config"
    shutil.copytree(os.path.join(ROOT, "config"), d)
    return str(d)


def _add_field(sandbox, name, spec):
    p = os.path.join(sandbox, "fields.json")
    doc = json.load(open(p))
    doc["fields"][name] = spec
    json.dump(doc, open(p, "w"), indent=1)
    return catalogue.load(sandbox)


def test_a_new_numeric_field_appears_in_the_diff_with_no_code_change(sandbox, book, dates):
    """Declare `esg_score`, put it in the data, and it becomes a finding."""
    cat = _add_field(sandbox, "esg_score", {
        "dtype": "float", "role": "risk_input", "compare": "abs",
        "abs_floor": 5.0, "additive": False, "aggregate": "none",
        "driver_candidate": True, "agency": "market",
    })
    assert "esg_score" in {f.name for f in cat.diffable()}
    assert "esg_score" in {f.name for f in cat.drivers()}

    t0, t1 = dates
    p = book.positions.copy()
    p["esg_score"] = 50.0
    p.loc[(p.cob_date == t1) & (p.instrument_id == "CB0101"), "esg_score"] = 80.0

    d0 = p[(p.fund_id == "FI001") & (p.cob_date == t0)]
    d1 = p[(p.fund_id == "FI001") & (p.cob_date == t1)]
    sets = posmod.split(d0, d1, "FI001", t0, t1)
    ch = diff.compare_positions(d0, d1, cat, "FI001", t1, sets)

    hits = [c for c in ch if c.field == "esg_score"]
    assert len(hits) == 1
    assert hits[0].entity == "CB0101"
    assert hits[0].delta == pytest.approx(30.0)
    assert hits[0].agency == "market"


def test_a_new_ordered_categorical_reports_direction(sandbox):
    cat = _add_field(sandbox, "liquidity_tier", {
        "dtype": "categorical", "role": "risk_input", "compare": "identity",
        "ordered": ["T1", "T2", "T3"], "driver_candidate": True,
        "direction_labels": {"up": "improved to", "down": "deteriorated to"},
    })
    f = cat.field("liquidity_tier")
    assert f.is_material("T1", "T3") == (True, "deteriorated to T1 to T3")
    assert f.is_material("T3", "T2")[1].startswith("improved to")
    assert f.is_material("T2", "T2") == (False, "")


def test_a_new_euler_metric_is_supported_by_declaration(sandbox):
    """The link is declared on both sides, and the loader enforces that."""
    p = os.path.join(sandbox, "fields.json")
    doc = json.load(open(p))
    doc["fields"]["ctv_liquidity"] = {
        "dtype": "float", "role": "risk_contribution", "compare": "abs",
        "abs_floor": 0.01, "additive": True, "aggregate": "sum",
        "euler_component_of": "liquidity_risk", "driver_candidate": True,
    }
    doc["metrics"]["liquidity_risk"] = {
        "label": "liquidity risk", "unit": "pts", "precision": 2,
        "gate_rel": 0.10, "abs_floor": 0.01, "euler": True,
        "contribution_field": "ctv_liquidity", "weight_field": "risk_weight",
        "vol_field": "standalone_vol",
    }
    json.dump(doc, open(p, "w"), indent=1)
    cat = catalogue.load(sandbox)
    assert cat.components_of("liquidity_risk") == ["ctv_liquidity"]
    assert cat.metric("liquidity_risk").contribution_field == "ctv_liquidity"


# --- the loader must refuse malformed configuration, loudly ---------------

def _expect_error(sandbox, mutate):
    p = os.path.join(sandbox, "fields.json")
    doc = json.load(open(p))
    mutate(doc)
    json.dump(doc, open(p, "w"), indent=1)
    with pytest.raises(catalogue.CatalogueError):
        catalogue.load(sandbox)


def test_rejects_a_comparison_mode_the_engine_cannot_execute(sandbox):
    _expect_error(sandbox, lambda d: d["fields"].update(
        {"x": {"dtype": "float", "compare": "vibes"}}))


def test_rejects_an_abs_comparison_with_no_floor(sandbox):
    _expect_error(sandbox, lambda d: d["fields"].update(
        {"x": {"dtype": "float", "compare": "abs"}}))


def test_rejects_a_one_sided_euler_link(sandbox):
    """The metric claims a contribution field that does not claim it back."""
    def mutate(d):
        d["fields"]["ctv"]["euler_component_of"] = "something_else"
    _expect_error(sandbox, mutate)


def test_rejects_more_than_one_decomposition_weight(sandbox):
    def mutate(d):
        d["fields"]["weight"]["decomposition_weight"] = True
    _expect_error(sandbox, mutate)


def test_catalogue_hash_changes_when_a_rule_changes(sandbox):
    before = catalogue.load(sandbox).version_hash
    p = os.path.join(sandbox, "profiles.json")
    doc = json.load(open(p))
    doc["materiality"]["rel_floor"] = 0.07
    json.dump(doc, open(p, "w"), indent=1)
    assert catalogue.load(sandbox).version_hash != before


def test_nothing_in_the_engine_hardcodes_a_portfolio_field_name():
    """Guards the property the whole design rests on."""
    banned = {"standalone_vol", "risk_weight", "ctv", "ctv_active",
              "benchmark_weight", "spread_duration"}
    offenders = []
    for mod in ("diff.py", "triage.py", "findings.py", "coverage.py"):
        src = open(os.path.join(ROOT, "engine", mod)).read()
        code = "\n".join(l for l in src.splitlines()
                         if not l.strip().startswith("#"))
        for name in banned:
            if f'"{name}"' in code or f"'{name}'" in code:
                offenders.append(f"{mod}: {name}")
    assert not offenders, f"field names hardcoded in the engine: {offenders}"
