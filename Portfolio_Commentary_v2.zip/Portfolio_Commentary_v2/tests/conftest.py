import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from engine import analyze, catalogue, crosssection, context as ctxmod  # noqa: E402


@pytest.fixture(scope="session")
def cat():
    return catalogue.load(os.path.join(ROOT, "config"))


@pytest.fixture(scope="session")
def book():
    return analyze.load_book(os.path.join(ROOT, "data"))


@pytest.fixture(scope="session")
def dates(book):
    return book.dates[0], book.dates[-1]


@pytest.fixture(scope="session")
def analyses(book, cat, dates):
    return analyze.analyse_all(book, cat, *dates)


@pytest.fixture(scope="session")
def cross(cat, analyses):
    return crosssection.analyse(cat, analyses)


@pytest.fixture(scope="session")
def contexts(analyses, cat, cross):
    return {f: ctxmod.build(a, cat, cross) for f, a in analyses.items()}
