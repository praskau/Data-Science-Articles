"""Loop B termination. A loop that cannot stop is not a control."""

import pytest

from engine.coverage import LoopState, missing, report, signature
from engine.verify import Defect


def _d(kind, where=""):
    return Defect(kind, "error", "detail", where)


def test_accepts_when_there_are_no_defects(cat):
    st = LoopState(max_iterations=4)
    go, why = st.should_continue([])
    assert go is False and "accepted" in why


def test_stops_when_the_same_defects_come_back(cat):
    """No progress between iterations means another call is wasted."""
    st = LoopState(max_iterations=99)
    st.record([_d("ungrounded_figure", "claim[0]")])
    go, _ = st.should_continue([_d("ungrounded_figure", "claim[0]")])
    assert go is True                       # first repeat is not yet a stall
    st.record([_d("ungrounded_figure", "claim[0]")])
    go, why = st.should_continue([_d("ungrounded_figure", "claim[0]")])
    assert go is False and "no progress" in why


def test_continues_while_defects_are_changing(cat):
    st = LoopState(max_iterations=99)
    st.record([_d("a"), _d("b")])
    st.record([_d("a")])
    go, why = st.should_continue([_d("a")])
    assert go is True and "outstanding" in why


def test_stops_at_the_iteration_cap(cat):
    st = LoopState(iteration=4, max_iterations=4)
    go, why = st.should_continue([_d("a")])
    assert go is False and "iteration limit" in why


def test_signature_is_order_independent_and_content_sensitive():
    a = [_d("x", "c1"), _d("y", "c2")]
    assert signature(a) == signature(list(reversed(a)))
    assert signature(a) != signature([_d("x", "c1")])


def test_coverage_is_set_arithmetic_not_judgement(cat, analyses):
    from engine.findings import coverage_targets
    a = analyses["FI001"]
    t = coverage_targets(cat, a.changes, a.profile.headline_metric)
    ids = list(t)
    r = report(t, set(ids[:-2]))
    assert r["required"] == len(ids)
    assert len(r["missing"]) == 2
    assert r["coverage"] == pytest.approx((len(ids) - 2) / len(ids), abs=1e-4)
    assert report(t, set(ids))["coverage"] == 1.0


def test_the_unexplained_item_is_never_budgeted_away(cat, analyses):
    """R9 must survive the coverage budget, or the framework can hide its own gap."""
    from engine.findings import add_unexplained, coverage_targets
    from engine.types import Effect
    a = analyses["MA001"]
    mc = a.changes[a.profile.headline_metric]
    # inject a residual by removing a term, then record it
    dropped = mc.items.pop(0)
    it = add_unexplained(mc, cat)
    assert it is not None
    t = coverage_targets(cat, a.changes, a.profile.headline_metric)
    assert it.item_id in t
    mc.items.append(dropped)


def test_the_short_form_driver_is_always_something_the_long_form_must_cover(cat, analyses):
    """Otherwise the two documents can name different drivers and both pass."""
    from engine.findings import coverage_targets, key_driver
    for fund, a in analyses.items():
        t = coverage_targets(cat, a.changes, a.profile.headline_metric)
        kd = key_driver(a.changes[a.profile.headline_metric])
        assert kd is not None
        assert kd.item_id in t, (
            f"{fund}: short form would name {kd.entity_label}/{kd.effect.value}, "
            f"which the long form is not required to discuss")
