# logic.md — analysis rules

**Version 2.0.0.** This file is normative. Where it and `fields.json` disagree,
`fields.json` wins on what a field *means*; this file wins on *thresholds and
sequencing*. `guardrails.md` wins on what may be written.

Everything here is executed by `engine/`. Nothing here is a matter of the
narrator's judgement — if a rule below cannot be computed, it is not a rule, it
is an aspiration, and it does not belong in this file.

---

## 0. The two loops

The instruction "loop until everything is explained" is two loops with different
stopping conditions. Running them as one is the usual reason such a loop either
never terminates or terminates on the model's own say-so.

| | Loop A — drill-down | Loop B — revision |
|---|---|---|
| Question | Does the **data** explain the move? | Does the **commentary** cover what the data found? |
| Runs | `engine/analyze.py` | narrator ↔ `engine/verify.py` |
| Involves an LLM | No | Yes, but it does not decide when to stop |
| Stops when | residual < tolerance, or the ladder is exhausted (R9 fires) | `required_ids − cited_ids = ∅` and no errors |
| Bounded by | 9 rungs, by construction | `max_revisions`, plus a no-progress guard |

Loop A always terminates: it is a fixed ladder. Loop B terminates on set
arithmetic, on a defect signature that stops changing, or on the iteration cap —
never on the narrator asserting it is finished.

---

## 1. Rung R0 — triage. Which funds are in scope?

Both gates run for every fund. A fund is in scope if **either** fires.

**Gate 1 — the net move is large.**
`|metric_t1 − metric_t0| / |metric_t0| ≥ gate_rel` (default 10%), and the
absolute change clears the metric's `abs_floor`. Applied to VaR, tracking error
and volatility.

**Gate 2 — the headline is quiet but the portfolio is not.**
`netting_ratio ≥ 3` **and** `gross_activity ≥ 15% × |metric_t0|`, evaluated
**only on metrics gate 1 did not flag.**

> Gate 2 is the one that earns its place. Gate 1 alone is blind in a specific,
> dangerous way: a fund can be rebuilt from the ground up and land back where it
> started. Gross activity of 3.6 vol points netting to 0.017 passes gate 1 as
> "no change", and nothing in the summary invites anyone to look.
>
> The exclusion matters as much as the rule. A position-level decomposition
> *always* carries high gross activity, because positions routinely offset one
> another; netting on its own is not a signal. The signal is high gross with a
> **small net**. Applying gate 2 to a metric that just moved 27% produces the
> incoherent claim that it "looks quiet".

Funds failing both gates are reported as out of scope, with the numbers that put
them there. Silence is not the same as a decision.

---

## 2. The drill-down ladder (Loop A)

Climb until the unexplained residual falls below tolerance or the ladder ends.
Each rung answers one question and is computed, never inferred.

| Rung | Question | Mechanism | Effects emitted |
|---|---|---|---|
| **R1** | Which sleeve, sector or rating bucket? | `aggregate_to_sleeves` | (roll-up view) |
| **R2** | Do **new and closed positions** explain it? | position set algebra | `entry`, `exit` |
| **R3** | Do **weight changes on held positions** explain it? | `Δw · m₀` | `allocation` |
| **R4** | Did **position metadata** move — standalone vol, price, duration, spread duration, delta? | `w₀ρ₀Δσ`, `w₀·Δa` | `standalone_vol`, `correlation`, `instrument`, `interaction` |
| **R5** | **Cross-impact**: untouched positions whose contribution moved | `w₀σ₀Δρ` with `Δw ≈ 0 ∧ Δσ ≈ 0` | `cross_impact` |
| **R6** | **Model inputs**: curve identity, curve shape, rating migration, model date | categorical + term-structure diffs | `curve_reassignment`, `rating_migration` |
| **R7** | **Fund level**: NAV / redemption scaling, benchmark reweight | `k·σ₀·ΔNAV`, `−Δb·m₀` | `market_value`, `benchmark` |
| **R8** | Is it **market-wide** rather than ours? | same effect, same sign, ≥2 funds | (classification) |
| **R9** | **Residual** | `change − Σ terms` | `unexplained` |

### Why each rung exists

**R2 before R3.** "We bought something we did not own" and "we added 20bp to an
existing holding" are different decisions and get different sentences. Pooling
them — which is what an outer join with zero-fill does — makes a portfolio look
like it was tinkered with when it was rebuilt.

**R5 is the rung no human performs.** A position with unchanged weight and
unchanged standalone volatility, whose risk contribution moved anyway, changed
because *everything around it* changed. It is invisible in a standard risk
report and it is the most interesting sentence in most commentaries.

**R6 is the rung that protects the reader.** A curve reassignment and a curve
move look identical in the risk numbers and are opposite in meaning: one is a
market event, the other is a person changing a model input. See `guardrails.md`.

**R9 must be able to fire.** A framework that cannot say "3bp of the 21bp move is
not attributable" will invent a driver to cover the gap. The residual is computed
excluding the `unexplained` item itself — otherwise recording the gap would close
it, and the check could never fail.

### Exit test for the loop

After each rung, compute `residual = change − Σ(terms emitted so far)`. Stop when
`|residual| ≤ residual_tolerance` (1e-9). If the ladder is exhausted and the
residual is still material, R9 emits an `unexplained` item, which is **always**
a coverage target regardless of budget.

---

## 3. Materiality

An item is material when **both** hold:

```
|value| ≥ max(metric.abs_floor, rel_floor × |total change|)      # rel_floor = 5%
rank    ≤ max_items[level]                                       # fund 4, sleeve 8, position 10
```

The rank cap is not decoration. Requiring every material item once produced 51
coverage targets on a single fund, which yields a list, not commentary.

**Coverage budget:** 6 items for the headline metric, 3 for each other metric.
Plus any `unexplained` item, which is never budgeted away.

---

## 4. Diagnostics the narrator must be told

| Trigger | Warning | Why |
|---|---|---|
| `residual > tolerance` | ENGINE | the decomposition does not reconcile; state the gap |
| `netting ≥ 3` **and** move below gate | NETTING | forbids "broadly unchanged"; name both sides |
| `netting ≥ 3` **and** move above gate | CONTEXT | net understates activity; lead with drivers |
| top item ≥ 60% of the move | CONCENTRATION | one name is the story |
| interaction ≥ 25% | INTERACTION | weight and risk moved together; use `reading` |
| correlation / cross-impact / benchmark ≥ 35% | AGENCY | nobody traded for this |
| model date stale or unchanged | DATA | the risk numbers are that vintage |

**Percentage basis.** Above the netting alert, shares are quoted **of gross
activity**, not of the net change, and the basis is stated. "Correlation was
−102% of the change" is arithmetically true and rhetorically worthless.

---

## 5. Cross-sectional comparison (R8)

Aggregate position items by **instrument attributes** — `asset_class`, `sector` —
across all funds. If the same effect moves the same way in ≥2 funds:

- a market effect (`standalone_vol`, `correlation`, `cross_impact`, `instrument`,
  `price`) → **market-wide**; must not be narrated as a fund decision
- a manager effect (`allocation`, `entry`, `exit`) → **house view**

Never key this on sleeve. Sleeves are a per-fund reporting choice — one fund
buckets by credit rating, another by sector — so a sleeve-keyed comparison
matches nothing and silently reports no findings, which is worse than not doing
it at all.

---

## 6. The short form

One driver, and the engine chooses it: the largest `|value|` among additive
items of the headline metric, excluding `unexplained`. Stable, reproducible and
defensible — three properties a model's judgement does not have. A short form
naming any other item is a **wrong answer**, not a style disagreement, and the
verifier rejects it.

---

## 7. Loop B stopping conditions, precisely

```
accept   when  defects == []                     and  required_ids - cited_ids == ∅
stop     when  defect_signature[-1] == [-2]      # no progress; another pass will not help
stop     when  iteration >= max_revisions        # 4
else     revise, citing only the defects found
```

The defect signature is a hash of `(kind, where)` pairs. Identical two iterations
running means the narrator is not converging, and the correct action is to stop
and report, not to spend another call.
