# guardrails.md — what the narrator may and may not write

**Version 2.0.0.** These are constraints on output, not suggestions about style.
Every one of them is checked by `engine/verify.py`; the table in §7 says which
check enforces which rule and whether it blocks publication.

They are written as prohibitions rather than aspirations because prohibitions
are what survive contact with a model under pressure to fill space.

---

## 1. Never compute a number

Every figure in the commentary must appear in the supplied context. Not "be
consistent with" it — **appear in it**. This includes percentages, ratios, sums
and differences. If you want to state a number that is not there, you may not
state it.

The check is per claim, not per document: a claim may quote figures from the
metric it is about and from the ledger items it cites, and nothing else. A
document-wide allowlist is far too weak — measured on this book, 72% of invented
two-decimal numbers still matched *something*, because there are only a hundred
such numbers and hundreds of ledger rows.

## 2. Never assert a cause that is not an effect in the ledger

The decomposition is exact. The effects listed are the **complete** set of
reasons the metric moved. "Market sentiment", "positioning", "risk-off tone",
"investor caution" and their relatives are not causes and must not appear.

If the ledger says `correlation`, the cause is that the holding's co-movement
with the book changed. That is the sentence. It is allowed to be less
satisfying than a story.

## 3. Attribute agency correctly

Each effect carries an `agency` field. Use it.

| Agency | Effects | Language |
|---|---|---|
| `manager` | entry, exit, allocation, trade | "we bought", "we cut", "the fund added" |
| `market` | standalone_vol, correlation, cross_impact, price, instrument, curve moves | "became more volatile", "began moving with", "repriced" |
| `index` | benchmark | "the index reweighted" |
| `flows` | market_value | "the fund shrank on redemptions" |
| `issuer` | rating_migration | "was downgraded" |
| `model_owner` | curve_reassignment | "positions were moved onto" |
| `mixed` | interaction | use the supplied `reading` field |

Never write "we increased risk" when the effect is `correlation` — nothing was
traded. Never write "the market moved against us" when the effect is
`allocation` — that was a decision.

## 4. Model inputs are not market events

The single most damaging error this framework can make.

A curve reassignment, a stale model date, a change of pricing source: these are
decisions made by a person, and they arrive in `model_input_changes`, kept in
their own block precisely so they cannot be folded into a market story. A reader
told "the discount curve fell 9bp" will conclude rates fell. What happened is
that somebody re-pointed the book from the swap curve to OIS.

Required form: name the change, name that it is a model input, and say it was
not a market move. If the impact is quantified, quote it; if it is not, say it
is not quantified rather than implying it is small.

## 5. Cover every required item

Every id in `must_cover_ids` must be accounted for by at least one claim,
listed in that claim's `ledger_ids`, **and genuinely discussed in that claim's
`text`**. Listing an id without discussing it is a failure, and it is the
failure a model reaches for when it is running out of things to say.

## 6. Specific prohibitions

**No false stability.** Where `netting_ratio` is above 3, the net change
understates what happened. "Broadly unchanged", "little changed", "largely
stable", "broadly flat" and their variants are forbidden for that metric. Say
that large offsetting moves netted out, and name both sides.

**No percentage of a near-zero net.** Where the warnings say to use gross
activity as the basis, use it, and say which basis you used. A driver that is
1,900% of a near-zero net move is not a fact worth printing.

**State the residual.** If an `unexplained` item exists, say so, with its size,
and do not absorb it into a named driver. An honest gap is better than a
confident fiction.

**One driver in the short form.** The engine computes which. Naming a different
one is a wrong answer. Maximum 70 words in the body, 25 in the headline; no
caveats, no data-quality notes, no forward-looking statements.

**No contradiction between the forms.** The short form is compressed from the
*verified* long form, never generated independently. Two documents that disagree
destroy trust faster than any single factual error.

## 7. What is checked, and what blocks

| Rule | Mechanism | Blocks? |
|---|---|---|
| Output shape | Pydantic schema validation | yes |
| Cover every required item | set arithmetic on ids | yes |
| Ledger ids exist | membership test | yes |
| Figures are grounded | per-claim numeric provenance | yes for decimals, warning for integers |
| No false stability | regex, gated on netting > 3 | yes |
| Short form ≤ 70 / 25 words | word count | yes |
| Short form names the computed driver | id comparison | yes |
| One driver only | count | yes |
| Direction matches sign | verb polarity vs item sign | warning |
| Figures declared in `figures` | set difference | warning |
| Short-form figures appear in long form | set membership | warning |

Warnings are reported and do not block. Everything else stops publication.

## 8. What this does not protect against

Stated plainly, because a control inventory that claims completeness is worse
than one with a known gap.

- **A grounded number used in the wrong sentence.** Provenance checks that a
  figure exists in the cited items; it cannot check that it is the *relevant*
  one. Residual false-accept was measured at 0.07% of invented figures at the
  claim level, not zero — a pigeonhole limit, not a bug.
- **Fluent but empty prose.** Nothing here forces a claim to be informative.
- **A wrong ledger.** Every check downstream assumes the decomposition is right.
  Reconciliation to 1e-9 is the only defence, and it tests arithmetic, not
  whether the input risk numbers were correct.
- **Selection bias in the budget.** Six items on the headline metric is a
  judgement; a seventh item that mattered is silently absent.
