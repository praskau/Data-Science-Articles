"""Position set algebra between two COB dates.

The distinction this module exists to make: a position that appeared between
the two dates is not a weight change. v1 outer-joined the dates and zero-filled,
which folded "we bought something we did not own" into the same bucket as "we
added 20bp to an existing holding". They are different decisions, they get
different sentences, and a reader who cannot tell them apart is being misled.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from .catalogue import Catalogue


@dataclass
class PositionSets:
    """Which instruments entered, left, or persisted between the two dates."""

    fund_id: str
    t0: str
    t1: str
    entered: list[str] = field(default_factory=list)
    exited: list[str] = field(default_factory=list)
    held: list[str] = field(default_factory=list)

    @property
    def turnover_count(self) -> int:
        return len(self.entered) + len(self.exited)

    def classify(self, instrument_id: str) -> str:
        if instrument_id in self.entered:
            return "entry"
        if instrument_id in self.exited:
            return "exit"
        return "held"

    def summary(self) -> dict:
        return {
            "fund_id": self.fund_id,
            "entered": len(self.entered),
            "exited": len(self.exited),
            "held": len(self.held),
        }


def split(d0: pd.DataFrame, d1: pd.DataFrame, fund_id: str, t0: str, t1: str) -> PositionSets:
    """Partition the two dates' instrument sets. Zero-unit rows count as absent."""
    a = set(_live(d0).instrument_id)
    b = set(_live(d1).instrument_id)
    return PositionSets(
        fund_id=fund_id, t0=t0, t1=t1,
        entered=sorted(b - a), exited=sorted(a - b), held=sorted(a & b),
    )


def _live(df: pd.DataFrame) -> pd.DataFrame:
    """A row with zero units is not a position, whatever the file says."""
    if "units" not in df.columns:
        return df
    return df[df.units.abs() > 1e-12]


def align(d0: pd.DataFrame, d1: pd.DataFrame, cols: list[str],
          cat: Catalogue) -> pd.DataFrame:
    """Outer-join the two dates on instrument_id, suffixed _t0 / _t1.

    Numeric columns zero-fill (an absent position has zero weight and zero
    contribution -- that is arithmetically correct). Categorical columns fill
    with None, because an absent position has no rating, and pretending it has
    one would manufacture a migration that never happened.
    """
    key = "instrument_id"
    keep = [c for c in cols if c in d0.columns and c in d1.columns]

    a = _live(d0).set_index(key, drop=False)[keep].add_suffix("_t0")
    b = _live(d1).set_index(key, drop=False)[keep].add_suffix("_t1")
    m = a.join(b, how="outer")

    for c in keep:
        try:
            f = cat.field(c)
            numeric = f.dtype == "float"
        except Exception:
            numeric = pd.api.types.is_numeric_dtype(m[f"{c}_t0"])
        if numeric:
            m[f"{c}_t0"] = m[f"{c}_t0"].fillna(0.0)
            m[f"{c}_t1"] = m[f"{c}_t1"].fillna(0.0)
        else:
            m[f"{c}_t0"] = m[f"{c}_t0"].where(m[f"{c}_t0"].notna(), None)
            m[f"{c}_t1"] = m[f"{c}_t1"].where(m[f"{c}_t1"].notna(), None)

    m.index.name = key
    return m


def labels(d0: pd.DataFrame, d1: pd.DataFrame) -> dict[str, str]:
    """instrument_id -> human label, taking whichever date has the instrument."""
    out: dict[str, str] = {}
    for df in (d1, d0):
        if "name" not in df.columns:
            continue
        for r in df.itertuples():
            out.setdefault(r.instrument_id, str(r.name))
    return out


def risk_weight_column(cat: Catalogue, df: pd.DataFrame) -> str:
    """The weight the decomposition runs on, per the catalogue.

    Declared once in fields.json via `decomposition_weight`. If it is missing
    from the data we fail loudly rather than silently falling back to market
    weight, which would make every derivative look like it carried no risk.
    """
    col = cat.decomposition_weight()
    if col not in df.columns:
        raise KeyError(
            f"the catalogue names {col!r} as the decomposition weight but the "
            f"position data has no such column"
        )
    return col
