"""Load and validate the field catalogue.

Everything downstream reads its behaviour from here. No engine module is
allowed to hardcode a field name, a threshold, or a materiality rule: if you
find yourself typing a string literal that names a portfolio field, it belongs
in config/fields.json instead.

The catalogue is hashed on load and the hash travels with every run, so a
commentary can always be traced back to the exact rules that produced it.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")

# compare modes the engine knows how to execute
_MODES = {"abs", "rel", "both", "either", "identity", "staleness", "none"}


class CatalogueError(ValueError):
    """The catalogue is malformed. Always fatal -- never fall back to a default."""


@dataclass(frozen=True)
class Field:
    """One field's algebra."""

    name: str
    dtype: str
    role: str
    compare: str
    spec: dict[str, Any] = field(default_factory=dict)

    # --- comparison ------------------------------------------------------
    @property
    def abs_floor(self) -> float | None:
        return self.spec.get("abs_floor")

    @property
    def rel_floor(self) -> float | None:
        return self.spec.get("rel_floor")

    @property
    def max_lag_days(self) -> int:
        return int(self.spec.get("max_lag_days", 0))

    # --- algebra ---------------------------------------------------------
    @property
    def additive(self) -> bool:
        """Does this field sum across positions to a fund-level total?"""
        return bool(self.spec.get("additive", False))

    @property
    def aggregate(self) -> str:
        return self.spec.get("aggregate", "none")

    @property
    def weight_field(self) -> str | None:
        return self.spec.get("weight_field")

    @property
    def euler_component_of(self) -> str | None:
        """The fund metric this field is an exact Euler component of."""
        return self.spec.get("euler_component_of")

    # --- narrative -------------------------------------------------------
    @property
    def driver_candidate(self) -> bool:
        return bool(self.spec.get("driver_candidate", False))

    @property
    def agency(self) -> str:
        """Who caused a change in this field: manager, market, index, flows."""
        return self.spec.get("agency", "unknown")

    @property
    def narrative_class(self) -> str:
        return self.spec.get("narrative_class", "market")

    @property
    def ordered(self) -> list[str] | None:
        return self.spec.get("ordered")

    @property
    def applies_to(self) -> list[str] | None:
        return self.spec.get("applies_to")

    @property
    def supersedes(self) -> str | None:
        return self.spec.get("supersedes")

    @property
    def group_by(self) -> bool:
        return bool(self.spec.get("group_by", False))

    def applicable(self, asset_class: str) -> bool:
        """Is this field meaningful for this instrument type?"""
        aps = self.applies_to
        return True if not aps else asset_class in aps

    # --- the one question the diff engine asks ---------------------------
    def is_material(self, v0: Any, v1: Any, cob: str | None = None) -> tuple[bool, str]:
        """Return (material, reason). Reason is empty when not material."""
        m = self.compare
        if m == "none":
            return False, ""

        if m == "identity":
            if v0 == v1 or (v0 is None and v1 is None):
                return False, ""
            return True, self._identity_reason(v0, v1)

        if m == "staleness":
            if cob is None or v1 is None:
                return False, ""
            lag = (_as_date(cob) - _as_date(v1)).days
            if lag > self.max_lag_days:
                return True, f"model date lags COB by {lag} days (limit {self.max_lag_days})"
            return False, ""

        # numeric modes
        if v0 is None or v1 is None:
            return False, ""
        d = float(v1) - float(v0)
        a_ok = self.abs_floor is not None and abs(d) >= self.abs_floor
        r_ok = False
        if self.rel_floor is not None and abs(float(v0)) > 0:
            r_ok = abs(d) / abs(float(v0)) >= self.rel_floor

        hit = {
            "abs": a_ok,
            "rel": r_ok,
            "both": a_ok and r_ok,
            "either": a_ok or r_ok,
        }[m]
        return (True, f"moved by {d:+.6g}") if hit else (False, "")

    def _identity_reason(self, v0: Any, v1: Any) -> str:
        order = self.ordered
        if order and v0 in order and v1 in order:
            labels = self.spec.get("direction_labels", {})
            # earlier in the list == better quality, so a higher index is a downgrade
            word = labels.get("down" if order.index(v1) > order.index(v0) else "up", "change")
            return f"{word} {v0} to {v1}"
        return f"changed from {v0} to {v1}"


@dataclass(frozen=True)
class Metric:
    name: str
    spec: dict[str, Any] = field(default_factory=dict)

    @property
    def label(self) -> str:
        return self.spec.get("label", self.name)

    @property
    def unit(self) -> str:
        return self.spec.get("unit", "")

    @property
    def precision(self) -> int:
        return int(self.spec.get("precision", 2))

    @property
    def gate_rel(self) -> float:
        return float(self.spec.get("gate_rel", 0.10))

    @property
    def abs_floor(self) -> float:
        return float(self.spec.get("abs_floor", 0.0))

    @property
    def euler(self) -> bool:
        return bool(self.spec.get("euler", False))

    @property
    def linear(self) -> bool:
        return bool(self.spec.get("linear", False))

    @property
    def contribution_field(self) -> str | None:
        return self.spec.get("contribution_field")

    @property
    def weight_field(self) -> str | None:
        return self.spec.get("weight_field")

    @property
    def vol_field(self) -> str | None:
        return self.spec.get("vol_field")

    @property
    def analytic_field(self) -> str | None:
        return self.spec.get("analytic_field")

    @property
    def benchmark_split(self) -> bool:
        return bool(self.spec.get("benchmark_split", False))

    @property
    def benchmark_weight_field(self) -> str | None:
        return self.spec.get("benchmark_weight_field")

    @property
    def scales_with_nav(self) -> bool:
        return bool(self.spec.get("scales_with_nav", False))

    @property
    def derived_from(self) -> str | None:
        return self.spec.get("derived_from")

    @property
    def requires(self) -> str | None:
        return self.spec.get("requires")

    def fmt(self, v: float) -> str:
        return f"{v:.{self.precision}f}"


class Catalogue:
    """The loaded, validated catalogue plus the run profile."""

    def __init__(self, fields_doc: dict, profiles_doc: dict, version_hash: str):
        self.raw = fields_doc
        self.profiles = profiles_doc
        self.version_hash = version_hash
        self.schema_version = fields_doc.get("schema_version", "unknown")

        self.fields: dict[str, Field] = {}
        for name, spec in fields_doc["fields"].items():
            self.fields[name] = Field(
                name=name,
                dtype=spec.get("dtype", "float"),
                role=spec.get("role", "descriptive"),
                compare=spec.get("compare", "none"),
                spec=spec,
            )

        self.metrics: dict[str, Metric] = {
            name: Metric(name=name, spec=spec) for name, spec in fields_doc["metrics"].items()
        }
        self.curves = fields_doc.get("curves", {})
        self.keys = fields_doc.get("keys", {})

    # --- lookups ---------------------------------------------------------
    def field(self, name: str) -> Field:
        try:
            return self.fields[name]
        except KeyError:
            raise CatalogueError(
                f"field {name!r} is not in the catalogue. Add it to config/fields.json "
                f"rather than referencing it from code."
            ) from None

    def metric(self, name: str) -> Metric:
        try:
            return self.metrics[name]
        except KeyError:
            raise CatalogueError(f"metric {name!r} is not in the catalogue") from None

    def diffable(self) -> list[Field]:
        """Every field the diff engine should compare, in catalogue order."""
        return [f for f in self.fields.values() if f.compare != "none"]

    def drivers(self) -> list[Field]:
        return [f for f in self.diffable() if f.driver_candidate]

    def decomposition_weight(self) -> str:
        for f in self.fields.values():
            if f.spec.get("decomposition_weight"):
                return f.name
        raise CatalogueError("no field is flagged decomposition_weight in config/fields.json")

    def components_of(self, metric_name: str) -> list[str]:
        """Fields declared to be exact Euler components of this metric.

        This is what lets the additivity check be generic: a new metric becomes
        supported by declaring a contribution field for it, not by editing code.
        """
        return [f.name for f in self.fields.values() if f.euler_component_of == metric_name]

    # --- profile accessors ----------------------------------------------
    @property
    def triage(self) -> dict:
        return self.profiles["triage"]

    @property
    def materiality(self) -> dict:
        return self.profiles["materiality"]

    @property
    def coverage(self) -> dict:
        return self.profiles["coverage"]

    @property
    def cross_section(self) -> dict:
        return self.profiles.get("cross_section", {"enabled": False})

    def fund_type_spec(self, fund_type: str) -> dict:
        try:
            return self.profiles["fund_types"][fund_type]
        except KeyError:
            raise CatalogueError(f"fund type {fund_type!r} has no metric pack") from None

    def fund_override(self, fund_id: str) -> dict:
        return self.profiles.get("funds", {}).get(fund_id, {})

    def provenance(self) -> dict:
        """Everything needed to reproduce a run's rules. Travels with the output."""
        return {
            "fields_schema_version": self.schema_version,
            "materiality_version": self.materiality.get("version"),
            "catalogue_hash": self.version_hash,
            "n_fields": len(self.fields),
            "n_metrics": len(self.metrics),
        }


def _as_date(v: Any) -> date:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return datetime.strptime(str(v)[:10], "%Y-%m-%d").date()


def _validate(fields_doc: dict, profiles_doc: dict) -> None:
    if "fields" not in fields_doc or "metrics" not in fields_doc:
        raise CatalogueError("fields.json must define both 'fields' and 'metrics'")

    for name, spec in fields_doc["fields"].items():
        mode = spec.get("compare", "none")
        if mode not in _MODES:
            raise CatalogueError(f"{name}: compare {mode!r} not one of {sorted(_MODES)}")
        if mode in {"abs", "both", "either"} and spec.get("abs_floor") is None:
            raise CatalogueError(f"{name}: compare={mode} requires abs_floor")
        if mode in {"rel", "both", "either"} and spec.get("rel_floor") is None:
            raise CatalogueError(f"{name}: compare={mode} requires rel_floor")
        if mode == "staleness" and spec.get("max_lag_days") is None:
            raise CatalogueError(f"{name}: compare=staleness requires max_lag_days")
        if spec.get("ordered") is not None and spec.get("dtype") != "categorical":
            raise CatalogueError(f"{name}: 'ordered' only applies to categorical fields")

    flagged = [n for n, s in fields_doc["fields"].items() if s.get("decomposition_weight")]
    if len(flagged) != 1:
        raise CatalogueError(
            f"exactly one field must carry decomposition_weight; found {flagged}"
        )

    # every metric that claims to be Euler must have something to sum
    for name, spec in fields_doc["metrics"].items():
        if not spec.get("euler"):
            continue
        if spec.get("derived_from"):
            continue
        cf = spec.get("contribution_field")
        if not cf:
            raise CatalogueError(f"metric {name}: euler=true requires contribution_field")
        if cf not in fields_doc["fields"]:
            raise CatalogueError(f"metric {name}: contribution_field {cf!r} is not a field")
        declared = fields_doc["fields"][cf].get("euler_component_of")
        if declared != name:
            raise CatalogueError(
                f"metric {name}: field {cf!r} declares euler_component_of={declared!r}. "
                f"The link must be stated on both sides."
            )
        if spec.get("benchmark_split") and not spec.get("benchmark_weight_field"):
            raise CatalogueError(f"metric {name}: benchmark_split requires benchmark_weight_field")

    for key in ("triage", "materiality", "coverage", "fund_types"):
        if key not in profiles_doc:
            raise CatalogueError(f"profiles.json is missing '{key}'")


def load(config_dir: str | None = None) -> Catalogue:
    """Load, validate and hash the catalogue. Raises CatalogueError if malformed."""
    d = config_dir or CONFIG_DIR
    fp = os.path.join(d, "fields.json")
    pp = os.path.join(d, "profiles.json")

    with open(fp, "rb") as fh:
        fields_raw = fh.read()
    with open(pp, "rb") as fh:
        profiles_raw = fh.read()

    fields_doc = json.loads(fields_raw)
    profiles_doc = json.loads(profiles_raw)
    _validate(fields_doc, profiles_doc)

    h = hashlib.blake2s(fields_raw + profiles_raw, digest_size=8).hexdigest()
    return Catalogue(fields_doc, profiles_doc, h)
