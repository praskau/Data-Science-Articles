"""Yield curves: what MOVED, and what was RE-POINTED.

Two entirely different findings live in this module and must never be merged.

  - The curve moved.  A market event. Decomposed into level, slope and
    curvature below.
  - Positions were moved onto a different curve.  A model-input event: nobody
    traded, no market moved, somebody changed a configuration. It shows up in
    diff.py as a categorical change on `yield_curve_id`; this module quantifies
    what the swap actually cost in basis points, so the commentary can state a
    number instead of an insinuation.

Conflating the two produces the worst kind of risk commentary: a market story
told about an operational change.

Level / slope / curvature: a curve move is not one number. "Rates rose 10bp" is
almost always wrong, and a fund that just extended duration at the long end
cares far more about the 20bp of steepening than the 10bp of level. Three
orthogonal shapes explain nearly every real curve move; the R-squared tells you
when they do not, which is your signal that something unusual happened and the
commentary should say so.

A curve move is not one number. "Rates rose 10bp" is almost always wrong, and a
fund that just extended duration at the long end cares far more about the 20bp
of steepening than the 10bp of level. Three orthogonal shapes explain nearly
every real curve move; the R-squared tells you when they do not, which is your
signal that something unusual happened and the commentary should say so.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .catalogue import Catalogue


def _basis(tenors: np.ndarray) -> tuple[np.ndarray, list[str]]:
    """Level / slope / curvature, orthogonalised so the loadings are unambiguous.

    Without orthogonalisation the three shapes overlap and the split between
    them depends on arbitrary scaling -- you can make a move look like level or
    like slope at will, which is exactly the kind of number nobody should be
    allowed to put in a commentary.
    """
    x = np.log1p(tenors)
    level = np.ones_like(tenors)
    slope = (x - x.mean()) / (x.std() or 1.0)
    curv = slope ** 2
    # Gram-Schmidt against level and slope
    for prior in (level, slope):
        curv = curv - (curv @ prior) / (prior @ prior) * prior
    curv = curv / (np.linalg.norm(curv) / np.sqrt(len(curv)) or 1.0)
    return np.column_stack([level, slope, curv]), ["level", "slope", "curvature"]


def decompose_curve(curves: pd.DataFrame, curve_id: str, t0: str, t1: str) -> dict:
    c0 = curves.query("curve_id == @curve_id and cob_date == @t0").sort_values("tenor_years")
    c1 = curves.query("curve_id == @curve_id and cob_date == @t1").sort_values("tenor_years")
    tenors = c0.tenor_years.to_numpy()
    dy = (c1.rate.to_numpy() - c0.rate.to_numpy()) * 100.0        # bp
    B, names = _basis(tenors)
    beta, *_ = np.linalg.lstsq(B, dy, rcond=None)
    fitted = B @ beta
    ss_tot = float(((dy - dy.mean()) ** 2).sum())
    r2 = 1.0 - float(((dy - fitted) ** 2).sum()) / ss_tot if ss_tot > 1e-12 else 1.0
    return dict(
        curve_id=curve_id,
        level_bp=round(float(beta[0]), 2),
        slope_bp=round(float(beta[1]), 2),
        curvature_bp=round(float(beta[2]), 2),
        r_squared=round(r2, 4),
        move_2y_bp=round(float(np.interp(2.0, tenors, dy)), 2),
        move_10y_bp=round(float(np.interp(10.0, tenors, dy)), 2),
        move_30y_bp=round(float(np.interp(30.0, tenors, dy)), 2),
        twos_thirties_bp=round(float(np.interp(30.0, tenors, dy) - np.interp(2.0, tenors, dy)), 2),
        shape=_label(beta, np.interp(30.0, tenors, dy) - np.interp(2.0, tenors, dy)),
    )


def _label(beta: np.ndarray, steepen_bp: float) -> str:
    direction = "bear" if beta[0] > 0 else "bull"
    if abs(steepen_bp) < 3.0:
        return f"{direction} parallel"
    return f"{direction} {'steepening' if steepen_bp > 0 else 'flattening'}"


def curve_impact(curve: dict, duration: float) -> dict:
    """Indicative price impact of the level move only, given fund duration.

    Explicitly *not* a P&L attribution -- without key-rate durations you cannot
    attribute the slope component, and pretending otherwise is how commentary
    ends up with numbers nobody can reconcile. Labelled indicative on purpose.
    """
    return dict(
        basis="level component only; slope and curvature not attributed without key-rate durations",
        indicative_price_impact_pct=round(-duration * curve["level_bp"] / 100.0, 3),
    )


# --------------------------------------------------------------------------
# Curve reassignment -- the model-input case
# --------------------------------------------------------------------------

def reassignment_impact(curves: pd.DataFrame, from_id: str, to_id: str,
                        date: str, tenors: list[float] | None = None) -> dict:
    """What did moving from one curve to another cost, in basis points?

    Measured at a single date, so the market move between dates cannot leak in.
    This is the number that lets commentary say "the switch to OIS took 8bp off
    the discount curve" rather than "a curve change contributed to the move".
    """
    a = curves.query("curve_id == @from_id and cob_date == @date").sort_values("tenor_years")
    b = curves.query("curve_id == @to_id and cob_date == @date").sort_values("tenor_years")
    if a.empty or b.empty:
        return {"from": from_id, "to": to_id, "date": date, "available": False}

    t = a.tenor_years.to_numpy()
    d = (np.interp(t, b.tenor_years.to_numpy(), b.rate.to_numpy()) - a.rate.to_numpy()) * 100.0
    picks = tenors or [2.0, 10.0, 30.0]
    return {
        "from": from_id, "to": to_id, "date": date, "available": True,
        "mean_bp": round(float(d.mean()), 2),
        "min_bp": round(float(d.min()), 2),
        "max_bp": round(float(d.max()), 2),
        "by_tenor_bp": {f"{p:g}y": round(float(np.interp(p, t, d)), 2) for p in picks},
        "parallel": bool(float(d.max() - d.min()) < 1.0),
        "narrative_class": "model_input",
        "note": ("valued on a single date, so this is the cost of the switch alone "
                 "and contains no market move"),
    }


def analyse(curves: pd.DataFrame, t0: str, t1: str, cat: Catalogue,
            curve_ids: list[str] | None = None,
            reassignments: list[tuple[str, str]] | None = None) -> dict:
    """Everything the ladder's model-input rung needs about curves.

    Returns market moves for every curve in use, plus the quantified cost of any
    reassignment, kept in separate keys so the narrator cannot merge them.
    """
    spec = cat.curves
    floor = float(spec.get("abs_floor_bp", 3.0))
    ids = curve_ids or sorted(curves.curve_id.unique())

    moves = []
    for cid in ids:
        if curves.query("curve_id == @cid and cob_date == @t0").empty:
            continue
        if curves.query("curve_id == @cid and cob_date == @t1").empty:
            continue
        m = decompose_curve(curves, cid, t0, t1)
        m["material"] = bool(abs(m["level_bp"]) >= floor or abs(m["twos_thirties_bp"]) >= floor)
        m["narrative_class"] = "market"
        moves.append(m)

    swaps = [reassignment_impact(curves, a, b, t0) for a, b in (reassignments or [])]
    return {
        "market_moves": moves,
        "reassignments": swaps,
        "basis_floor_bp": floor,
        "note": ("market_moves are things that happened to the curve; reassignments "
                 "are decisions about which curve to use. Never narrate one as the other."),
    }
