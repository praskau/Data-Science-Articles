"""Verification: does the prose actually match the arithmetic?

Two independent checks, both deterministic. No language model is used to judge
another language model's output here -- coverage is set arithmetic and numeric
grounding is a lookup against an allowlist built from the ledger. A judge would
be cheaper to write and impossible to trust.

The allowlist is deliberately generous about *representation* (0.51 may be
written "51%", 1.71 vol points may be written "171bp") and strict about
*existence* (a number with no origin in the ledger fails, however plausible).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .catalogue import Catalogue
from .findings import coverage_targets

NUM_RE = re.compile(r"[-+]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[-+]?\d+(?:\.\d+)?")

INCREASE = re.compile(r"\b(rose|increase[sd]?|higher|added|widen(?:ed)?|up|grew|lifted|"
                      r"extended|gained)\b", re.I)
DECREASE = re.compile(r"\b(fell|decrease[sd]?|lower|reduced|cut|narrow(?:ed)?|down|"
                      r"declined|shrank|trimmed)\b", re.I)

STABILITY_PHRASES = re.compile(
    r"\b(broadly unchanged|little changed|largely stable|broadly flat|essentially "
    r"unchanged|remained stable|barely moved|broadly similar|roughly unchanged)\b", re.I)

# Read from config at call time; this is only the fallback if none is supplied.
NETTING_ALERT = 3.0


@dataclass
class Defect:
    kind: str
    severity: str            # "error" blocks publication; "warning" is reported
    detail: str
    where: str = ""

    def line(self) -> str:
        return f"[{self.severity.upper()}] {self.kind} ({self.where}): {self.detail}"


@dataclass
class VerificationResult:
    defects: list[Defect] = field(default_factory=list)
    covered: set[str] = field(default_factory=set)
    required: set[str] = field(default_factory=set)

    @property
    def errors(self) -> list[Defect]:
        return [d for d in self.defects if d.severity == "error"]

    @property
    def ok(self) -> bool:
        return not self.errors

    @property
    def coverage(self) -> float:
        return len(self.covered & self.required) / len(self.required) if self.required else 1.0

    def report(self) -> str:
        head = (f"coverage {len(self.covered & self.required)}/{len(self.required)} "
                f"({self.coverage:.0%}), {len(self.errors)} errors, "
                f"{len(self.defects) - len(self.errors)} warnings")
        return "\n".join([head] + [d.line() for d in self.defects])


def _rounding_forms(v: float) -> set[float]:
    """Every legitimate way to write `v` in prose.

    The model is instructed to copy figures, so a grounded number is a *rounding*
    of a source value, not merely something nearby. Fuzzy-band matching against a
    dense ledger accepts essentially any invented number -- measured at ~100% on
    this book before this was tightened -- which is worse than no check at all,
    because it manufactures confidence.
    """
    out: set[float] = set()
    for base in (v, -v):
        for d in range(0, 5):
            out.add(round(round(base, d), 6))
            if abs(base) <= 20.0:   # percent / basis-point rendering of a small quantity
                out.add(round(round(base * 100.0, d), 6))
    return out


def allowed_numbers(context: dict) -> dict[float, str]:
    """Every number the commentary may contain, harvested from the context that
    was actually sent to the model.

    Deriving this from the context rather than from the full bundle is the point:
    a figure the model never saw cannot be a faithful copy, so it must not pass.
    """
    allow: dict[float, str] = {}

    def walk(node, path: str):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else str(k))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, bool):
            return
        elif isinstance(node, (int, float)):
            for form in _rounding_forms(float(node)):
                allow.setdefault(form, path)
        elif isinstance(node, str):
            # numbers embedded in warning text are legitimate to quote back
            for tok in NUM_RE.findall(node):
                try:
                    for form in _rounding_forms(float(tok.replace(",", ""))):
                        allow.setdefault(form, f"{path} (text)")
                except ValueError:
                    pass

    walk(context, "")
    return allow


def _match(x: float, allow: dict[float, str]) -> str | None:
    return allow.get(round(x, 6))


def _numbers(text: str) -> list[float]:
    out = []
    for tok in NUM_RE.findall(text):
        raw = tok.replace(",", "")
        try:
            v = float(raw)
        except ValueError:
            continue
        # calendar years are not claims about the portfolio
        if "." not in raw and 1900 <= abs(v) <= 2100 and len(raw.lstrip("+-")) == 4:
            continue
        out.append(v)
    return out


class Provenance:
    """Per-claim number allowlists.

    Checking a figure against the whole document's numbers is far too weak: on
    this book, 72% of invented two-decimal numbers below 1.0 still matched
    something, because there are only a hundred such numbers and hundreds of
    ledger rows. A claim, though, cites the specific ledger items it is about --
    so the figures it may quote are those items' values, its metric's headline
    values, and a small set of global scalars. That collapses the allowlist from
    thousands to tens and makes the check bite.
    """

    def __init__(self, context: dict):
        self.global_nums = allowed_numbers({
            k: context[k] for k in (
                "fund", "period", "curve_moves", "curve_reassignments",
                "position_changes", "model_input_changes", "cross_sectional",
                "triage", "warnings") if k in context})
        self.metric_nums: dict[str, dict[float, str]] = {}
        self.item_nums: dict[str, dict[float, str]] = {}
        for m in context.get("metrics", []):
            scalars = {k: v for k, v in m.items() if k != "drivers"}
            self.metric_nums[m["metric"]] = allowed_numbers(scalars)
            for d in m.get("drivers", []):
                self.item_nums[d["item_id"]] = allowed_numbers(d)

    def allow_for(self, metric: str, ledger_ids: list[str]) -> dict[float, str]:
        allow = dict(self.global_nums)
        allow.update(self.metric_nums.get(metric, {}))
        for cid in ledger_ids:
            allow.update(self.item_nums.get(cid, {}))
        return allow


def verify_long_form(doc, a, cat: Catalogue, context: dict) -> VerificationResult:
    """Check a long-form draft against the analysis it was built from.

    `a` is an engine.analyze.Analysis. Nothing here consults a language model:
    coverage is set arithmetic and numeric grounding is a lookup against an
    allowlist derived from the context that was actually sent.
    """
    prov = Provenance(context)
    targets = coverage_targets(cat, a.changes, a.profile.headline_metric)
    known_ids = {it.item_id for mc in a.changes.values() for it in mc.items}
    res = VerificationResult(covered=doc.covered_ids(), required=set(targets))

    alert = float(cat.materiality.get("netting_alert", NETTING_ALERT))
    netting = {m: mc.netting_ratio for m, mc in a.changes.items()}

    for missing in sorted(res.required - res.covered):
        it = targets[missing]
        res.defects.append(Defect(
            "uncovered_driver", "error",
            f"ledger item {missing} is material and unaddressed: "
            f"{it.metric} / {it.entity_label} / {it.effect.value} = {it.value:+.4f}",
            where="coverage"))

    for i, claim in enumerate(doc.all_claims()):
        where = f"claim[{i}] {claim.metric}"
        for cid in claim.ledger_ids:
            if cid not in known_ids:
                res.defects.append(Defect(
                    "unknown_ledger_id", "error",
                    f"claim cites '{cid}', which is not in the ledger", where))
        if not claim.text.strip():
            res.defects.append(Defect("empty_claim", "error", "claim has no text", where))
            continue

        allow = prov.allow_for(claim.metric, claim.ledger_ids)
        for x in _numbers(claim.text):
            if _match(x, allow) is None:
                sev = "error" if x != int(x) else "warning"
                res.defects.append(Defect(
                    "ungrounded_figure", sev,
                    f"the figure {x:g} is not a value of this claim's metric "
                    f"({claim.metric}) or of the ledger items it cites "
                    f"({', '.join(claim.ledger_ids) or 'none'}). Either quote a figure "
                    f"from those, or cite the ledger item the figure comes from.",
                    where))

        declared = set(round(f, 6) for f in claim.figures)
        written = set(round(f, 6) for f in _numbers(claim.text))
        undeclared = {w for w in written if not any(abs(w - d) < 1e-6 for d in declared)}
        if undeclared:
            res.defects.append(Defect(
                "undeclared_figure", "warning",
                f"figures {sorted(undeclared)} appear in the text but were not "
                f"declared in `figures`", where))

        if netting.get(claim.metric, 0.0) > alert:
            m = STABILITY_PHRASES.search(claim.text)
            if m:
                res.defects.append(Defect(
                    "false_stability", "error",
                    f"'{m.group(0)}' is used for {claim.metric}, whose gross activity is "
                    f"{netting[claim.metric]:.0f}x its net change. Large offsetting moves "
                    f"were netted; say so and name both sides.", where))

        # direction sanity, single-item claims only
        if len(claim.ledger_ids) == 1 and claim.ledger_ids[0] in known_ids:
            item = next(it for mc in a.changes.values() for it in mc.items
                        if it.item_id == claim.ledger_ids[0])
            up, down = bool(INCREASE.search(claim.text)), bool(DECREASE.search(claim.text))
            if up ^ down:
                said_up = up
                if said_up != (item.value > 0):
                    res.defects.append(Defect(
                        "direction_mismatch", "warning",
                        f"text reads as {'an increase' if said_up else 'a decrease'} but "
                        f"{item.entity_label}/{item.effect.value} is {item.value:+.4f}",
                        where))
    return res


def verify_short_form(doc, a, cat: Catalogue, long_form, context: dict) -> VerificationResult:
    prov = Provenance(context)
    allow = prov.allow_for(a.profile.headline_metric, doc.key_driver_ledger_ids)
    res = VerificationResult()

    limits = cat.coverage.get("short_form", {})
    max_body = int(limits.get("max_words_body", 70))
    max_head = int(limits.get("max_words_headline", 25))
    max_drivers = int(limits.get("drivers", 1))

    words = len(doc.body.split())
    if words > max_body:
        res.defects.append(Defect("word_limit", "error",
                                  f"body is {words} words; the limit is {max_body}", "short_form"))
    if len(doc.headline.split()) > max_head:
        res.defects.append(Defect("word_limit", "error",
                                  f"headline is {len(doc.headline.split())} words; "
                                  f"limit {max_head}", "short_form"))
    if len(doc.key_driver_ledger_ids) > max_drivers:
        res.defects.append(Defect(
            "too_many_drivers", "error",
            f"short form cites {len(doc.key_driver_ledger_ids)} drivers; the contract is "
            f"{max_drivers}. If a second driver matters that much it belongs in the long "
            f"form.", "short_form"))

    # The driver is computed by the engine, not chosen by the model. Naming a
    # different one is not a style disagreement, it is a wrong answer.
    mc = a.changes.get(a.profile.headline_metric)
    if mc is not None and doc.key_driver_ledger_ids:
        from .findings import key_driver
        kd = key_driver(mc)
        if kd is not None and kd.item_id not in doc.key_driver_ledger_ids:
            res.defects.append(Defect(
                "wrong_key_driver", "error",
                f"the largest driver of {mc.label} is {kd.entity_label} / "
                f"{kd.effect.value} ({kd.value:+.4f}, item {kd.item_id}); the short form "
                f"names {doc.key_driver_ledger_ids} instead", "short_form"))
    lf_numbers = {round(x, 4) for c in long_form.all_claims() for x in _numbers(c.text)}
    lf_numbers |= {round(x, 4) for x in _numbers(long_form.headline + " " + long_form.opening)}
    for x in _numbers(doc.headline + " " + doc.body):
        if _match(x, allow) is None:
            res.defects.append(Defect(
                "ungrounded_figure", "error",
                f"the figure {x:g} is not a value of the headline metric or of the "
                f"ledger items cited as the key driver", "short_form"))
        elif round(x, 4) not in lf_numbers:
            res.defects.append(Defect(
                "not_in_long_form", "warning",
                f"the figure {x:g} is grounded but does not appear in the long form; "
                f"the two documents should not diverge", "short_form"))
    if not doc.key_driver_ledger_ids:
        res.defects.append(Defect("no_driver", "error",
                                  "short form names no ledger item as the key driver",
                                  "short_form"))
    return res
