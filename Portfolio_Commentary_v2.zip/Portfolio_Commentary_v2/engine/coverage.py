"""Loop B control: has the commentary accounted for what the data found?

The request was "loop until it explains everything". That needs a computable
definition of "everything", or the loop either never ends or ends on the model's
own say-so -- which is the same as having no loop.

Definition used here:

    missing = required_ids - cited_ids

Set arithmetic over ids the engine assigned. No judgement, no LLM, no scoring.
The loop stops when `missing` is empty AND the verifier reports no errors, or
when the defect signature stops changing (the model is not making progress and
another iteration will not help).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import blake2s

from .catalogue import Catalogue
from .types import LedgerItem


@dataclass
class LoopState:
    """Everything needed to decide whether to iterate again."""

    iteration: int = 1
    signatures: list[str] = field(default_factory=list)
    max_iterations: int = 4

    def record(self, defects: list) -> str:
        sig = signature(defects)
        self.signatures.append(sig)
        return sig

    @property
    def stalled(self) -> bool:
        """Two identical defect sets in a row means another attempt is wasted."""
        return len(self.signatures) >= 2 and self.signatures[-1] == self.signatures[-2]

    @property
    def exhausted(self) -> bool:
        return self.iteration >= self.max_iterations

    def should_continue(self, defects: list) -> tuple[bool, str]:
        if not defects:
            return False, "accepted: no defects"
        if self.stalled:
            return False, "stopped: no progress between iterations"
        if self.exhausted:
            return False, f"stopped: iteration limit ({self.max_iterations}) reached"
        return True, f"revising: {len(defects)} defect(s) outstanding"


def signature(defects: list) -> str:
    """A stable fingerprint of a defect set, for the no-progress check."""
    parts = sorted(f"{getattr(d, 'kind', '')}|{getattr(d, 'where', '')}" for d in defects)
    return blake2s("\n".join(parts).encode(), digest_size=6).hexdigest()


def missing(required: dict[str, LedgerItem], cited: set[str]) -> list[LedgerItem]:
    return [it for k, it in required.items() if k not in cited]


def state_from(cat: Catalogue) -> LoopState:
    return LoopState(max_iterations=int(cat.coverage.get("max_revisions", 4)))


def report(required: dict[str, LedgerItem], cited: set[str]) -> dict:
    miss = missing(required, cited)
    n = len(required)
    return {
        "required": n,
        "cited": len(cited & set(required)),
        "coverage": round((n - len(miss)) / n, 4) if n else 1.0,
        "missing": [{"item_id": i.item_id, "entity": i.entity_label,
                     "effect": i.effect.value, "value": round(i.value, 6)} for i in miss],
    }
