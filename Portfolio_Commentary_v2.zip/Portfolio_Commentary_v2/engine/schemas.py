"""Structured output contracts.

Every claim carries the ledger ids it accounts for and the figures it asserts.
That is what makes coverage and numeric grounding checkable by code rather than
by another language model: the check becomes set arithmetic, not judgement.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class Claim(BaseModel):
    model_config = {"extra": "forbid"}

    ledger_ids: list[str] = Field(
        description="item_id values from the ledger that this claim accounts for. "
                    "Every id you list must appear in the supplied ledger.")
    metric: str = Field(description="The metric this claim is about, e.g. ex_ante_vol.")
    text: str = Field(description="One to three sentences of finished commentary. "
                                  "State the driver and the direction, with figures.")
    figures: list[float] = Field(
        default_factory=list,
        description="Every numeric value asserted in `text`, as written.")


class Section(BaseModel):
    model_config = {"extra": "forbid"}

    title: str
    claims: list[Claim]


class LongFormCommentary(BaseModel):
    model_config = {"extra": "forbid"}

    headline: str = Field(description="One sentence a reader could act on. No hedging.")
    opening: str = Field(description="Two to four sentences: what changed overall and why "
                                     "it matters. Written for an investment committee.")
    sections: list[Section] = Field(description="One section per metric that moved materially.")
    not_the_driver: list[str] = Field(
        default_factory=list,
        description="Plausible explanations the data rules out. Each must name the "
                    "figure that rules it out.")
    caveats: list[str] = Field(
        default_factory=list,
        description="Data or model limitations a reader must know. Restate supplied "
                    "warnings in plain language.")

    def all_claims(self) -> list[Claim]:
        return [c for s in self.sections for c in s.claims]

    def covered_ids(self) -> set[str]:
        return {i for c in self.all_claims() for i in c.ledger_ids}


class ShortFormCommentary(BaseModel):
    model_config = {"extra": "forbid"}

    headline: str = Field(description="One sentence, max 25 words.")
    body: str = Field(description="One paragraph, maximum 70 words. The single key "
                                  "driver only. No secondary drivers, no caveats.")
    key_driver_ledger_ids: list[str]
    figures: list[float] = Field(default_factory=list)
