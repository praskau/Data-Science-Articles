"""Exact attribution of risk-metric changes between two COB dates.

The whole engine rests on one identity. For any risk measure homogeneous of
degree one in the exposure vector -- volatility, VaR and tracking error all are
-- Euler's theorem gives

    sigma_p  =  sum_i  w_i * MCTR_i        where MCTR_i = d(sigma_p)/d(w_i)

so per-position contributions sum *exactly* to portfolio risk, with no
residual. Risk systems publish those contributions. We therefore never need the
covariance matrix: MCTR_i = CTV_i / w_i is recoverable from the risk report,
and since MCTR_i = rho_i * sigma_i, so is the implied correlation:

    rho_i  =  CTV_i / (w_i * sigma_i)

That single line is what lets you say "credit did not get bigger, it got more
correlated" from a standard risk extract.

Changes decompose without residual:

    d(CTV_i) = dw * m0            <- we changed the weight
             + w0 * dm            <- its risk character changed
             + dw * dm            <- interaction

and the middle term splits again, using m = rho * sigma:

    w0 * dm  = w0 * rho0 * d(sigma)   <- the asset itself got more volatile
             + w0 * sigma0 * d(rho)   <- it started moving with the book
             + w0 * d(sigma) * d(rho) <- (folded into interaction)

v2 changes two things about how the terms are LABELLED -- never their values,
so additivity is untouched:

  1. The weight term is ENTRY or EXIT when the position was actually opened or
     closed, rather than being pooled with routine resizing. v1 decided this by
     testing whether the weight column was zero, which is wrong for tracking
     error: a benchmark constituent we do not hold has a large negative ACTIVE
     weight while not being a position at all.
  2. The correlation term is CROSS_IMPACT when the position was untouched and
     its own volatility did not move -- the case where a holding's risk changed
     purely because everything around it changed.

Which column feeds which metric comes from the catalogue, not from this file.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .catalogue import Catalogue, Metric as MetricSpec
from .positions import PositionSets
from .types import Effect, LedgerItem, Level

EPS = 1e-9


def _align(d0: pd.DataFrame, d1: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Outer-join two dates on instrument. Numeric columns zero-fill, because an
    absent position genuinely has zero weight and zero contribution."""
    meta = [c for c in ("name", "sleeve", "asset_class", "sector", "rating")
            if c in d0.columns and c in d1.columns]
    keep = ["instrument_id"] + meta + [c for c in cols if c in d0.columns]
    a = d0[keep].set_index("instrument_id").add_suffix("_0")
    b = d1[keep].set_index("instrument_id").add_suffix("_1")
    j = a.join(b, how="outer")
    for c in cols:
        if f"{c}_0" in j.columns:
            j[f"{c}_0"] = j[f"{c}_0"].fillna(0.0)
            j[f"{c}_1"] = j[f"{c}_1"].fillna(0.0)
    for c in meta:
        j[c] = np.where(j[f"{c}_1"].notna(), j[f"{c}_1"], j[f"{c}_0"])
    return j.reset_index()


def _mctr(ctv: float, w: float) -> float | None:
    return ctv / w if abs(w) > EPS else None


def decompose_risk(d0: pd.DataFrame, d1: pd.DataFrame, spec: MetricSpec,
                   cat: Catalogue, sets: PositionSets) -> list[LedgerItem]:
    """Decompose a homogeneous risk metric into per-position, per-effect terms.

    Every column name is read from the catalogue's metric spec.
    """
    wcol = spec.weight_field
    ccol = spec.contribution_field
    vcol = spec.vol_field
    bcol = spec.benchmark_weight_field if spec.benchmark_split else None
    if not (wcol and ccol):
        raise ValueError(f"metric {spec.name} is not decomposable: needs weight + contribution field")

    cols = [c for c in (wcol, ccol, vcol, bcol) if c]
    j = _align(d0, d1, cols)

    xi = cat.materiality.get("cross_impact", {})
    w_flat = float(xi.get("weight_unchanged_abs", 0.0005))
    v_flat = float(xi.get("vol_unchanged_rel", 0.02))

    items: list[LedgerItem] = []
    for r in j.itertuples():
        iid = r.instrument_id
        w0, w1 = getattr(r, f"{wcol}_0"), getattr(r, f"{wcol}_1")
        c0, c1 = getattr(r, f"{ccol}_0"), getattr(r, f"{ccol}_1")
        s0 = getattr(r, f"{vcol}_0", 0.0) if vcol else 0.0
        s1 = getattr(r, f"{vcol}_1", 0.0) if vcol else 0.0
        if abs(w0) < EPS and abs(w1) < EPS:
            continue

        m0, m1 = _mctr(c0, w0), _mctr(c1, w1)
        if m0 is None and m1 is None:
            continue
        # A position absent on one date has no marginal contribution there.
        # Carrying the other date's value across makes the whole change a weight
        # decision, which is the correct economic reading.
        if m0 is None:
            m0 = m1
        if m1 is None:
            m1 = m0

        dw, dm = w1 - w0, m1 - m0
        state = sets.classify(iid)

        ev = dict(w0=w0, w1=w1, ctv0=c0, ctv1=c1, mctr0=m0, mctr1=m1,
                  vol0=s0, vol1=s1, position_state=state)

        def add(effect: Effect, value: float, rung: str = "", **extra):
            if abs(value) < 1e-12:
                return
            items.append(LedgerItem(
                metric=spec.name, level=Level.POSITION, entity=iid,
                entity_label=f"{r.name} [{r.sleeve}]", effect=effect, value=value,
                evidence={**ev, **extra, "sleeve": r.sleeve, "asset_class": r.asset_class},
                rung=rung,
            ))

        # --- the weight term, labelled by what actually happened -----------
        weight_effect = {"entry": Effect.ENTRY, "exit": Effect.EXIT}.get(state, Effect.ALLOCATION)
        weight_rung = {"entry": "R2", "exit": "R2"}.get(state, "R3")

        if bcol:
            b0, b1 = getattr(r, f"{bcol}_0"), getattr(r, f"{bcol}_1")
            # w here is the ACTIVE weight, so dw = d(portfolio) - d(benchmark).
            # Active weight moved for two independent reasons and the manager is
            # accountable for only one of them.
            db = b1 - b0
            add(weight_effect, (dw + db) * m0, weight_rung, b0=b0, b1=b1, dbmk=db)
            add(Effect.BENCHMARK, -db * m0, "R7", b0=b0, b1=b1, dbmk=db)
        else:
            add(weight_effect, dw * m0, weight_rung)

        # --- the risk-character term ---------------------------------------
        inter = dw * dm
        if abs(s0) > EPS and abs(s1) > EPS:
            rho0, rho1 = m0 / s0, m1 / s1
            add(Effect.STANDALONE_VOL, w0 * rho0 * (s1 - s0), "R4", rho0=rho0, rho1=rho1)

            corr_value = w0 * s0 * (rho1 - rho0)
            # Untouched and unchanged, yet its contribution moved: the move came
            # entirely from how the rest of the book now behaves around it. This
            # is the case a human reading a risk report will never find.
            untouched = abs(dw) < w_flat and state == "held"
            vol_flat = abs(s1 - s0) <= v_flat * abs(s0)
            if untouched and vol_flat:
                add(Effect.CROSS_IMPACT, corr_value, "R5", rho0=rho0, rho1=rho1,
                    cross_impact=True, dw=dw, dvol=s1 - s0,
                    note="weight and standalone vol both unchanged; the entire "
                         "move is a change in how this position co-moves with the book")
            else:
                add(Effect.CORRELATION, corr_value, "R4", rho0=rho0, rho1=rho1)
            inter += w0 * (s1 - s0) * (rho1 - rho0)
        else:
            add(Effect.STANDALONE_VOL, w0 * dm, "R4")

        # "Interaction" is arithmetic, not English. Record what it means so the
        # narrator never has to guess: same-sign means the manager added to a
        # position that was simultaneously becoming riskier.
        reading = ("reinforcing: weight and risk moved the same way" if dw * dm > 0
                   else "offsetting: weight and risk moved in opposite directions")
        add(Effect.INTERACTION, inter, "R4", interaction_reading=reading, dw=dw, dm=dm)

    return items


def decompose_derived(base_items: list[LedgerItem], spec: MetricSpec, cat: Catalogue,
                      base0: float, base1: float, nav0: float, nav1: float) -> list[LedgerItem]:
    """Rescale a percentage-risk decomposition into money, adding the NAV terms.

    VaR_ccy = k * vol * NAV, so the change carries a fund-size term that pure
    percentage reporting hides. A fund whose volatility rises 30% while it pays
    a 10% redemption has *less* money at risk, not more -- and that is the
    number the board reacts to.
    """
    z = _z(spec.spec.get("confidence", 0.99))
    days = float(spec.spec.get("trading_days", 252))
    k = z / np.sqrt(days) / 100.0 / 1e6          # -> millions of base ccy
    dnav = nav1 - nav0

    out = [LedgerItem(metric=spec.name, level=it.level, entity=it.entity,
                      entity_label=it.entity_label, effect=it.effect,
                      value=it.value * k * nav0, rung=it.rung,
                      evidence={**it.evidence, "scaled_from": spec.derived_from,
                                "nav0": nav0, "k": k})
           for it in base_items]
    out.append(LedgerItem(
        metric=spec.name, level=Level.FUND, entity="FUND", entity_label="Fund size",
        effect=Effect.MARKET_VALUE, value=k * base0 * dnav, rung="R7",
        evidence=dict(nav0=nav0, nav1=nav1, dnav=dnav, base0=base0,
                      note="NAV moved; the same percentage risk is a different amount of money")))
    out.append(LedgerItem(
        metric=spec.name, level=Level.FUND, entity="FUND", entity_label="Fund size x risk",
        effect=Effect.INTERACTION, value=k * (base1 - base0) * dnav, rung="R7",
        evidence=dict(dnav=dnav, dbase=base1 - base0)))
    return out


def decompose_linear(d0: pd.DataFrame, d1: pd.DataFrame, spec: MetricSpec,
                     cat: Catalogue, sets: PositionSets) -> list[LedgerItem]:
    """Attribution for a plain weighted-average analytic: duration, spread duration.

        D = sum_i w_i * a_i   =>   dD = dw*a0 + w0*da + dw*da

    The middle term is what the instrument did on its own -- rolldown, a curve
    move repricing an option, a floater resetting. Separating it from trading is
    what stops "we extended duration" being written when nobody traded.
    """
    wcol, acol = spec.weight_field, spec.analytic_field
    j = _align(d0, d1, [wcol, acol])
    items: list[LedgerItem] = []
    for r in j.itertuples():
        iid = r.instrument_id
        w0, w1 = getattr(r, f"{wcol}_0"), getattr(r, f"{wcol}_1")
        a0, a1 = getattr(r, f"{acol}_0"), getattr(r, f"{acol}_1")
        if abs(w0) < EPS and abs(w1) < EPS:
            continue
        if abs(w0) < EPS:
            a0 = a1
        if abs(w1) < EPS:
            a1 = a0
        dw, da = w1 - w0, a1 - a0
        state = sets.classify(iid)
        weight_effect = {"entry": Effect.ENTRY, "exit": Effect.EXIT}.get(state, Effect.ALLOCATION)
        ev = dict(w0=w0, w1=w1, a0=a0, a1=a1, sleeve=r.sleeve,
                  asset_class=r.asset_class, position_state=state)
        for eff, val, rung in ((weight_effect, dw * a0, "R2" if state != "held" else "R3"),
                               (Effect.INSTRUMENT, w0 * da, "R4"),
                               (Effect.INTERACTION, dw * da, "R4")):
            if abs(val) > 1e-12:
                items.append(LedgerItem(
                    metric=spec.name, level=Level.POSITION, entity=iid,
                    entity_label=f"{r.name} [{r.sleeve}]", effect=eff,
                    value=val, evidence=ev, rung=rung))
    return items


def aggregate_to_sleeves(items: list[LedgerItem]) -> list[LedgerItem]:
    """Roll position items up to sleeve x effect. A derived view of the same
    money -- never mixed back into the additive set."""
    buckets: dict[tuple, list[LedgerItem]] = {}
    for it in items:
        if it.level is not Level.POSITION:
            continue
        buckets.setdefault(
            (it.metric, it.evidence.get("sleeve", "Unclassified"), it.effect), []
        ).append(it)
    out = []
    for (metric, sleeve, effect), group in buckets.items():
        out.append(LedgerItem(
            metric=metric, level=Level.SLEEVE, entity=f"SLEEVE::{sleeve}",
            entity_label=sleeve, effect=effect,
            value=sum(g.value for g in group), rung="R1",
            evidence=dict(n_positions=len(group),
                          top=sorted((dict(id=g.entity, label=g.entity_label,
                                           value=round(g.value, 6)) for g in group),
                                     key=lambda d: -abs(d["value"]))[:5])))
    return out


def _z(confidence: float) -> float:
    """One-tailed normal quantile, without pulling in scipy."""
    from statistics import NormalDist
    return NormalDist().inv_cdf(confidence)
