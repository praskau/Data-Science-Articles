"""Command line for the engine. Every command prints JSON to stdout so the
orchestrating prompt can read it directly; nothing here writes prose."""

from __future__ import annotations

import argparse
import json
import os
import sys

from . import analyze, catalogue, context as ctxmod, crosssection, findings, redact, render, triage
from .coverage import LoopState, report as coverage_report
from .types import Level


def _out(obj) -> None:
    print(json.dumps(obj, indent=1, default=str))


def _load(args):
    cat = catalogue.load(args.config)
    book = analyze.load_book(args.data)
    dates = book.dates
    t0 = args.t0 or dates[0]
    t1 = args.t1 or dates[-1]
    return cat, book, t0, t1


# --------------------------------------------------------------------------

def cmd_gen(args):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from data import synth
    out = synth.generate(args.data)
    _out({"generated": {k: list(v.shape) for k, v in out.items()}, "dir": args.data})


def cmd_triage(args):
    """Rung R0. Run before anything else -- it decides what is worth analysing."""
    cat, book, t0, t1 = _load(args)
    res = analyze.analyse_all(book, cat, t0, t1, args.fund)
    tr = triage.triage_all(cat, {f: a.changes for f, a in res.items()})
    tr["period"] = {"t0": t0, "t1": t1}
    tr["provenance"] = cat.provenance()
    _out(tr)


def cmd_analyse(args):
    """The full ledger for one fund. Loop A has already run to completion here."""
    cat, book, t0, t1 = _load(args)
    fid = args.fund[0] if args.fund else book.fund_ids[0]
    a = analyze.analyse(book, cat, fid, t0, t1)
    _out({
        "fund": a.profile.__dict__,
        "period": {"t0": t0, "t1": t1},
        "gate": a.gate.to_dict(),
        "rungs": a.rungs,
        "reconciliation": analyze.reconciliation(a, cat),
        "position_sets": a.sets.summary() | {"opened": a.sets.entered, "closed": a.sets.exited},
        "effects": {m: findings.effect_summary(mc) for m, mc in a.changes.items()},
        "warnings": a.warnings,
        "model_input_changes": [c.to_dict() for c in a.field_changes
                                if c.narrative_class == "model_input"],
        "curves": a.curves,
        "provenance": cat.provenance(),
    })


def cmd_context(args):
    """Write the exact JSON the narrator is given. Verification runs against this
    file, not a fresh build -- a figure the model never saw cannot be grounded."""
    cat, book, t0, t1 = _load(args)
    fid = args.fund[0] if args.fund else book.fund_ids[0]
    a = analyze.analyse(book, cat, fid, t0, t1)
    allr = analyze.analyse_all(book, cat, t0, t1) if args.cross else {fid: a}
    ctx = ctxmod.build(a, cat, crosssection.analyse(cat, allr))

    d = os.path.join(args.out, fid)
    os.makedirs(d, exist_ok=True)
    leaks: list[str] = []
    if args.redact:
        m = redact.build_map(a, book, fid)
        ctx = redact.redact_context(ctx, m)
        with open(os.path.join(d, "_redaction_map.json"), "w") as fh:
            json.dump(m, fh, indent=1)
        leaks = redact.audit(ctx, m)

    path = os.path.join(d, "context.json")
    with open(path, "w") as fh:
        fh.write(ctxmod.as_json(ctx))
    _out({"context": path, "must_cover": len(ctx["must_cover_ids"]),
          "approx_tokens": len(ctxmod.as_json(ctx)) // 4,
          "redacted": bool(args.redact), "leaks": leaks,
          "headline_metric": a.profile.headline_metric})


def cmd_drill(args):
    """Show one rung of the ladder in isolation. Used when the residual after the
    previous rung is still material."""
    cat, book, t0, t1 = _load(args)
    fid = args.fund[0] if args.fund else book.fund_ids[0]
    a = analyze.analyse(book, cat, fid, t0, t1)
    metric = args.metric or a.profile.headline_metric
    mc = a.changes[metric]
    rung = args.rung.upper()

    if rung == "R1":
        rows = [i for i in mc.items if i.level is Level.SLEEVE]
    elif rung == "R2":
        rows = [i for i in mc.items if i.rung == "R2"]
    else:
        rows = [i for i in mc.items if i.rung == rung]

    rows = sorted(rows, key=lambda i: -abs(i.value))[:args.limit]
    _out({
        "fund": fid, "metric": metric, "rung": rung,
        "metric_change": round(mc.change, 6),
        "explained_at_this_rung": round(sum(i.value for i in rows), 6),
        "items": [dict(item_id=i.item_id, entity=i.entity_label, effect=i.effect.value,
                       agency=i.agency, value=round(i.value, 6), material=i.material,
                       evidence={k: v for k, v in i.evidence.items() if k != "top"})
                  for i in rows],
    })


def cmd_verify(args):
    """Loop B's decision function. Exits 1 when the draft must be revised."""
    from .schemas import LongFormCommentary, ShortFormCommentary
    from . import verify as V

    cat, book, t0, t1 = _load(args)
    fid = args.fund[0] if args.fund else book.fund_ids[0]
    a = analyze.analyse(book, cat, fid, t0, t1)

    d = os.path.join(args.out, fid)
    with open(args.context or os.path.join(d, "context.json")) as fh:
        ctx = json.load(fh)
    with open(args.draft) as fh:
        payload = json.load(fh)

    if args.kind == "short":
        with open(args.long_form or os.path.join(d, "long_form.json")) as fh:
            lf = LongFormCommentary.model_validate(json.load(fh))
        doc = ShortFormCommentary.model_validate(payload)
        res = V.verify_short_form(doc, a, cat, lf, ctx)
        cov = None
    else:
        doc = LongFormCommentary.model_validate(payload)
        res = V.verify_long_form(doc, a, cat, ctx)
        targets = findings.coverage_targets(cat, a.changes, a.profile.headline_metric)
        cov = coverage_report(targets, doc.covered_ids())

    state = LoopState(iteration=args.iteration, max_iterations=int(cat.coverage["max_revisions"]))
    state.signatures = list(args.signature or [])
    state.record(res.defects)
    go, why = state.should_continue(res.defects)

    _out({
        "fund": fid, "kind": args.kind, "iteration": args.iteration,
        "accepted": res.ok, "coverage": cov,
        "defects": [dict(kind=x.kind, severity=x.severity, where=x.where, detail=x.detail)
                    for x in res.defects],
        "errors": len(res.errors), "warnings": len(res.defects) - len(res.errors),
        "defect_signature": state.signatures[-1],
        "continue_loop": go, "decision": why,
    })
    sys.exit(0 if res.ok else 1)


def cmd_render(args):
    from .schemas import LongFormCommentary, ShortFormCommentary
    cat, book, t0, t1 = _load(args)
    fid = args.fund[0] if args.fund else book.fund_ids[0]
    a = analyze.analyse(book, cat, fid, t0, t1)
    d = os.path.join(args.out, fid)

    mpath = os.path.join(d, "_redaction_map.json")
    mapping = json.load(open(mpath)) if os.path.exists(mpath) else None

    written = []
    lp = os.path.join(d, "long_form.json")
    if os.path.exists(lp):
        doc = LongFormCommentary.model_validate(json.load(open(lp)))
        p = os.path.join(d, "long.md")
        open(p, "w").write(render.long_form(doc, a, cat, mapping))
        written.append(p)
    sp = os.path.join(d, "short_form.json")
    if os.path.exists(sp):
        doc = ShortFormCommentary.model_validate(json.load(open(sp)))
        p = os.path.join(d, "short.md")
        open(p, "w").write(render.short_form(doc, a, cat, mapping))
        written.append(p)
    _out({"written": written, "names_restored": bool(mapping)})


def cmd_selftest(args):
    """Everything the engine can check about itself, without a language model."""
    cat, book, t0, t1 = _load(args)
    res = analyze.analyse_all(book, cat, t0, t1)
    recs, bad = [], 0
    for f, a in res.items():
        for r in analyze.reconciliation(a, cat):
            r["fund"] = f
            recs.append(r)
            bad += 0 if r["reconciles"] else 1
    tr = triage.triage_all(cat, {f: a.changes for f, a in res.items()})
    _out({"reconciliation": recs, "failures": bad,
          "triage": {k: tr[k] for k in ("in_scope", "out_of_scope",
                                        "caught_only_by_gross_gate")},
          "provenance": cat.provenance()})
    sys.exit(1 if bad else 0)


# --------------------------------------------------------------------------

def main(argv=None):
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    p = argparse.ArgumentParser(prog="portfolio-commentary",
                                description="Exact risk attribution across two COB dates.")

    # Shared options live on a parent parser attached to every subcommand, so
    # they are written AFTER the verb -- `context --fund FI001`, which is the
    # order the orchestration prompt documents and the order people type.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--data", default=os.path.join(root, "data"))
    common.add_argument("--config", default=os.path.join(root, "config"))
    common.add_argument("--out", default=os.path.join(root, "out"))
    common.add_argument("--fund", action="append")
    common.add_argument("--t0")
    common.add_argument("--t1")

    sub = p.add_subparsers(dest="cmd", required=True)
    add = lambda name, help: sub.add_parser(name, parents=[common], help=help)

    add("gen", "regenerate the synthetic book").set_defaults(fn=cmd_gen)
    add("triage", "R0: which funds are in scope").set_defaults(fn=cmd_triage)
    add("analyse", "full ledger for one fund").set_defaults(fn=cmd_analyse)
    add("selftest", "reconciliation + gates").set_defaults(fn=cmd_selftest)

    c = add("context", "write the JSON the narrator is given")
    c.add_argument("--redact", action="store_true", help="pseudonymise names before writing")
    c.add_argument("--cross", action="store_true", default=True,
                   help="include cross-sectional findings (needs all funds)")
    c.set_defaults(fn=cmd_context)

    d = add("drill", "one rung of the ladder")
    d.add_argument("--rung", required=True, help="R1..R9")
    d.add_argument("--metric")
    d.add_argument("--limit", type=int, default=15)
    d.set_defaults(fn=cmd_drill)

    v = add("verify", "check a draft against the ledger")
    v.add_argument("--draft", required=True)
    v.add_argument("--kind", choices=["long", "short"], default="long")
    v.add_argument("--context")
    v.add_argument("--long-form", dest="long_form")
    v.add_argument("--iteration", type=int, default=1)
    v.add_argument("--signature", action="append")
    v.set_defaults(fn=cmd_verify)

    add("render", "markdown from verified drafts").set_defaults(fn=cmd_render)

    args = p.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
