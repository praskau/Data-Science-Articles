"""Catalogue-driven field comparison between two COB dates.

Every rule this module applies comes out of config/fields.json. It knows how to
execute five comparison modes; it knows nothing about what a rating or a curve
or a spread duration is. That is the point: a new field becomes visible here by
being declared, not by being coded.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

import pandas as pd

from .catalogue import Catalogue
from . import positions as pos


@dataclass
class FieldChange:
    """One field, on one entity, moved between the two dates."""

    level: str                 # position | fund
    entity: str                # instrument_id, or fund_id at fund level
    entity_label: str
    field: str
    v0: Any
    v1: Any
    delta: float | None
    rel_delta: float | None
    material: bool
    reason: str
    agency: str                # manager | market | index | flows | unknown
    narrative_class: str       # market | model_input
    change_type: str           # numeric | categorical | staleness
    position_state: str = "held"   # held | entry | exit

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("v0", "v1"):
            v = d[k]
            if hasattr(v, "item"):
                d[k] = v.item()
        return d


def _num(v: Any) -> float | None:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if pd.isna(f) else f


def compare_positions(
    d0: pd.DataFrame,
    d1: pd.DataFrame,
    cat: Catalogue,
    fund_id: str,
    cob: str,
    sets: pos.PositionSets | None = None,
) -> list[FieldChange]:
    """Compare every catalogue-diffable field, position by position."""
    t0, t1 = str(d0.cob_date.iloc[0]), str(d1.cob_date.iloc[0])
    sets = sets or pos.split(d0, d1, fund_id, t0, t1)
    names = pos.labels(d0, d1)

    fields = [
        f for f in cat.diffable()
        if f.name in d0.columns and f.name in d1.columns
        # NAV is a fund attribute that happens to be denormalised onto every
        # position row. Diffing it per position would report one redemption
        # sixty times.
        and f.spec.get("level") != "fund"
    ]
    m = pos.align(d0, d1, [f.name for f in fields], cat)
    ac = _asset_class_map(d0, d1)

    out: list[FieldChange] = []
    for iid, row in m.iterrows():
        state = sets.classify(str(iid))
        for f in fields:
            # A field only means something where the instrument type has it.
            if not f.applicable(ac.get(iid, "")):
                continue
            v0, v1 = row.get(f"{f.name}_t0"), row.get(f"{f.name}_t1")

            # On an entry or an exit the position itself is the story. Reporting
            # "duration went from 0 to 7.2" for a bond we just bought is noise
            # dressed as analysis.
            if state in ("entry", "exit") and f.compare != "identity":
                continue
            if state in ("entry", "exit") and f.compare == "identity":
                continue

            material, reason = f.is_material(v0, v1, cob=cob)
            if not material:
                continue

            a, b = _num(v0), _num(v1)
            delta = (b - a) if (a is not None and b is not None) else None
            rel = (delta / abs(a)) if (delta is not None and a not in (None, 0)) else None

            out.append(FieldChange(
                level="position", entity=str(iid),
                entity_label=names.get(str(iid), str(iid)),
                field=f.name, v0=v0, v1=v1, delta=delta, rel_delta=rel,
                material=True, reason=reason,
                agency=f.agency, narrative_class=f.narrative_class,
                change_type=_kind(f.compare), position_state=state,
            ))
    return out


def compare_fund(snap0: dict, snap1: dict, cat: Catalogue, fund_id: str,
                 cob: str, fund_label: str = "") -> list[FieldChange]:
    """Compare fund-level fields (NAV, model date) declared in the catalogue."""
    out: list[FieldChange] = []
    for f in cat.diffable():
        if f.spec.get("level") != "fund" and f.name not in ("model_date",):
            continue
        if f.name not in snap0 or f.name not in snap1:
            continue
        material, reason = f.is_material(snap0[f.name], snap1[f.name], cob=cob)
        if not material:
            continue
        a, b = _num(snap0[f.name]), _num(snap1[f.name])
        delta = (b - a) if (a is not None and b is not None) else None
        rel = (delta / abs(a)) if (delta is not None and a not in (None, 0)) else None
        out.append(FieldChange(
            level="fund", entity=fund_id, entity_label=fund_label or fund_id,
            field=f.name, v0=snap0[f.name], v1=snap1[f.name],
            delta=delta, rel_delta=rel, material=True, reason=reason,
            agency=f.agency, narrative_class=f.narrative_class,
            change_type=_kind(f.compare),
        ))
    return out


def entries_and_exits(d0: pd.DataFrame, d1: pd.DataFrame, cat: Catalogue,
                      sets: pos.PositionSets) -> list[FieldChange]:
    """One record per position opened or closed, carrying the weight involved."""
    wcol = pos.risk_weight_column(cat, d0)
    names = pos.labels(d0, d1)
    a = d0.set_index("instrument_id")
    b = d1.set_index("instrument_id")

    out: list[FieldChange] = []
    for iid in sets.entered:
        w = float(b.loc[iid, wcol])
        out.append(FieldChange(
            level="position", entity=iid, entity_label=names.get(iid, iid),
            field=wcol, v0=0.0, v1=w, delta=w, rel_delta=None, material=True,
            reason=f"new position opened at {w:+.4%} risk weight",
            agency="manager", narrative_class="market",
            change_type="entry", position_state="entry",
        ))
    for iid in sets.exited:
        w = float(a.loc[iid, wcol])
        out.append(FieldChange(
            level="position", entity=iid, entity_label=names.get(iid, iid),
            field=wcol, v0=w, v1=0.0, delta=-w, rel_delta=-1.0, material=True,
            reason=f"position fully closed from {w:+.4%} risk weight",
            agency="manager", narrative_class="market",
            change_type="exit", position_state="exit",
        ))
    return out


def collapse(changes: list[FieldChange], cat: Catalogue,
             weights: dict[str, float] | None = None) -> list[FieldChange]:
    """Fold a categorical change that hit many positions identically into one finding.

    Forty-five positions moving from the swap curve to the OIS curve is one
    decision by one person, not forty-five findings. Which fields may be
    collapsed is declared in the catalogue (`collapse: true`); a rating
    migration is deliberately NOT collapsible, because each one is its own
    credit story even when two happen at once.
    """
    min_group = int(cat.materiality.get("collapse_min_group", 3))
    weights = weights or {}

    groups: dict[tuple, list[FieldChange]] = {}
    passthrough: list[FieldChange] = []
    for c in changes:
        f = cat.fields.get(c.field)
        if c.change_type != "categorical" or not f or not f.spec.get("collapse"):
            passthrough.append(c)
            continue
        groups.setdefault((c.field, str(c.v0), str(c.v1)), []).append(c)

    out = list(passthrough)
    for (fname, v0, v1), members in groups.items():
        if len(members) < min_group:
            out.extend(members)
            continue
        w = sum(abs(weights.get(m.entity, 0.0)) for m in members)
        head = members[0]
        out.append(FieldChange(
            level="group", entity=f"{fname}:{v0}->{v1}",
            entity_label=f"{len(members)} positions",
            field=fname, v0=v0, v1=v1, delta=None, rel_delta=None, material=True,
            reason=(f"{head.reason} across {len(members)} positions"
                    + (f" carrying {w:.2%} risk weight" if w else "")),
            agency=head.agency, narrative_class=head.narrative_class,
            change_type="categorical_group", position_state="held",
        ))
    return out


def summarise(changes: list[FieldChange]) -> dict:
    """Counts by field and by agency -- the shape of the period, before drill-down."""
    by_field: dict[str, int] = {}
    by_agency: dict[str, int] = {}
    by_class: dict[str, int] = {}
    for c in changes:
        by_field[c.field] = by_field.get(c.field, 0) + 1
        by_agency[c.agency] = by_agency.get(c.agency, 0) + 1
        by_class[c.narrative_class] = by_class.get(c.narrative_class, 0) + 1
    return {
        "total": len(changes),
        "by_field": dict(sorted(by_field.items(), key=lambda kv: -kv[1])),
        "by_agency": by_agency,
        "by_narrative_class": by_class,
    }


def model_input_changes(changes: list[FieldChange]) -> list[FieldChange]:
    """Changes that are model configuration, not market events.

    These must never be narrated as "the market moved". A curve reassignment or
    a stale model date is somebody's decision, and it is the one class of change
    a reader most needs separated from the rest.
    """
    return [c for c in changes if c.narrative_class == "model_input"]


def _kind(mode: str) -> str:
    return {"identity": "categorical", "staleness": "staleness"}.get(mode, "numeric")


def _asset_class_map(d0: pd.DataFrame, d1: pd.DataFrame) -> dict[str, str]:
    out: dict[str, str] = {}
    for df in (d1, d0):
        if "asset_class" not in df.columns:
            continue
        for r in df.itertuples():
            out.setdefault(r.instrument_id, str(r.asset_class))
    return out
