"""Rung R0: which funds are worth looking at.

Two gates, and the second one is the whole argument.

Gate 1 is the obvious rule: flag a fund whose headline risk moved more than
10%. It is the rule every risk team writes first, and on its own it is wrong in
a specific, dangerous way -- it is blind to the fund that was completely rebuilt
between the two dates and happened to land back where it started. Gross activity
of 3.6 vol points netting to 0.017 passes gate 1 as "no change".

Gate 2 catches that: high netting with material gross activity. A quiet headline
over a busy portfolio is not a non-event, it is the event most likely to be
missed, because nothing in the summary invites anyone to look.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .catalogue import Catalogue
from .types import MetricChange


@dataclass
class GateResult:
    fund_id: str
    in_scope: bool
    gate_1_net: bool
    gate_2_gross: bool
    reasons: list[str] = field(default_factory=list)
    detail: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(fund_id=self.fund_id, in_scope=self.in_scope,
                    gate_1_net=self.gate_1_net, gate_2_gross=self.gate_2_gross,
                    reasons=self.reasons, detail=self.detail)


def gate(cat: Catalogue, fund_id: str, changes: dict[str, MetricChange]) -> GateResult:
    """Evaluate both gates. A fund is in scope if either fires."""
    cfg = cat.triage
    g1cfg, g2cfg = cfg["gate_1_net"], cfg["gate_2_gross"]
    watched = set(g1cfg.get("metrics", []))

    res = GateResult(fund_id=fund_id, in_scope=False, gate_1_net=False, gate_2_gross=False)

    for metric, mc in changes.items():
        spec = cat.metric(metric)
        rel = mc.rel_change
        gate_rel = float(spec.gate_rel if spec.gate_rel else g1cfg["gate_rel_default"])
        p = mc.precision

        d = dict(metric=metric, value_t0=round(mc.value_t0, 6), value_t1=round(mc.value_t1, 6),
                 change=round(mc.change, 6),
                 rel_change=round(rel, 6) if rel not in (float("inf"), float("-inf")) else None,
                 gross_activity=round(mc.gross_activity, 6),
                 netting_ratio=round(mc.netting_ratio, 2)
                 if mc.netting_ratio != float("inf") else None,
                 gate_1=False, gate_2=False)

        # --- gate 1: the net move is large -------------------------------
        passed_1 = False
        if g1cfg.get("enabled", True) and metric in watched:
            big_rel = abs(rel) >= gate_rel
            big_abs = (not g1cfg.get("also_require_abs_floor", True)
                       or abs(mc.change) >= spec.abs_floor)
            if big_rel and big_abs:
                passed_1 = d["gate_1"] = True
                res.gate_1_net = True
                res.reasons.append(
                    f"{mc.label} moved {mc.change:+.{p}f} {mc.unit} ({rel:+.1%}), "
                    f"above the {gate_rel:.0%} threshold")

        # --- gate 2: the net move is small BECAUSE things cancelled -------
        # Only ever applied to a metric that gate 1 did NOT flag. Gate 2 exists
        # to catch the fund that looks like a non-event; saying a metric "looks
        # quiet" when it just moved 27% would be nonsense, and position-level
        # decompositions always carry high gross activity because positions
        # routinely offset one another. The signal is high gross with a SMALL
        # net, not high gross on its own.
        if g2cfg.get("enabled", True) and metric in watched and not passed_1:
            nr = mc.netting_ratio
            gross_floor = float(g2cfg["gross_floor_rel"]) * abs(mc.value_t0)
            if nr >= float(g2cfg["netting_alert"]) and mc.gross_activity >= gross_floor:
                d["gate_2"] = True
                res.gate_2_gross = True
                nrs = "infinite" if nr == float("inf") else f"{nr:.0f}x"
                res.reasons.append(
                    f"{mc.label} looks quiet ({mc.change:+.{p}f} {mc.unit}) but "
                    f"{mc.gross_activity:.{p}f} of gross activity netted to it ({nrs}); "
                    f"the portfolio was rebuilt underneath a flat headline")

        res.detail.append(d)

    res.in_scope = res.gate_1_net or res.gate_2_gross
    if not res.in_scope:
        res.reasons.append("no metric passed either gate; fund is out of scope this period")
    return res


def triage_all(cat: Catalogue, per_fund: dict[str, dict[str, MetricChange]]) -> dict:
    """Run the gates across the book. This is what runs before any drill-down."""
    results = {fid: gate(cat, fid, ch) for fid, ch in per_fund.items()}
    return {
        "in_scope": [f for f, r in results.items() if r.in_scope],
        "out_of_scope": [f for f, r in results.items() if not r.in_scope],
        "caught_only_by_gross_gate": [
            f for f, r in results.items() if r.gate_2_gross and not r.gate_1_net],
        "results": {f: r.to_dict() for f, r in results.items()},
    }
