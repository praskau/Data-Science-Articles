"""Build the model's view of the analysis.

Deliberately not a dump. A model handed 400 ledger rows will write about
whichever ones appear early, so the context is pre-ranked, pre-labelled and
budgeted. What is omitted here can never appear in the commentary -- which is
the point: the context *is* the fact base, and the verifier holds the
commentary to exactly this and nothing else.
"""

from __future__ import annotations

import json

from .catalogue import Catalogue
from .findings import coverage_targets, effect_summary, key_driver
from .types import Effect, Level

EFFECT_GLOSS = {
    "entry": "a position we did not previously hold was opened",
    "exit": "a position was closed entirely",
    "allocation": "we resized something we already held",
    "trade": "units were bought or sold",
    "standalone_vol": "the holding itself became more or less volatile",
    "correlation": "the holding's co-movement with the rest of the book changed; "
                   "nothing was traded to cause this",
    "cross_impact": "the position was untouched and its own volatility did not move, "
                    "yet its risk contribution changed -- entirely because the rest "
                    "of the book changed around it",
    "benchmark": "the index reweighted; the manager did not cause this",
    "interaction": "weight and risk character moved together in the same period",
    "instrument": "the instrument's own analytic moved (rolldown, reset, reprice)",
    "market_value": "the size of the fund changed, so the same percentage risk is a "
                    "different amount of money",
    "price": "the market moved the position's value",
    "rating_migration": "the issuer was re-rated; nothing was traded",
    "curve_reassignment": "positions were moved onto a different curve -- a model "
                          "input change, NOT a market event",
    "unexplained": "this amount does not reconcile and is not attributable; it must "
                   "be stated as unexplained and never assigned to a named driver",
}


def build(a, cat: Catalogue, cross: dict | None = None,
          max_positions_per_item: int = 3) -> dict:
    p = a.profile
    targets = coverage_targets(cat, a.changes, p.headline_metric)
    netting_alert = float(cat.materiality["netting_alert"])

    metrics = []
    for metric, mc in a.changes.items():
        pct = (mc.change / mc.value_t0 * 100.0) if abs(mc.value_t0) > 1e-9 else None
        items = []
        for it in sorted(mc.items, key=lambda i: -abs(i.value)):
            if it.level not in (Level.SLEEVE, Level.FUND):
                continue
            if not it.material and it.item_id not in targets:
                continue
            row = dict(
                item_id=it.item_id, entity=it.entity_label, effect=it.effect.value,
                effect_means=EFFECT_GLOSS.get(it.effect.value, ""),
                agency=it.agency, narrative_class=it.narrative_class,
                value=round(it.value, 4), rung=it.rung,
                must_cover=it.item_id in targets,
            )
            # Only offer share-of-change where it is a meaningful number. Above
            # the netting alert it is not, and offering it invites its use.
            if mc.netting_ratio <= netting_alert and abs(mc.change) > 1e-9:
                row["share_of_change"] = round(it.share_of_change, 3)
            elif mc.gross_activity:
                row["share_of_gross_activity"] = round(abs(it.value) / mc.gross_activity, 3)
            if it.evidence.get("top"):
                row["largest_positions"] = it.evidence["top"][:max_positions_per_item]
            if "interaction_reading" in it.evidence:
                row["reading"] = it.evidence["interaction_reading"]
            if it.evidence.get("note"):
                row["note"] = it.evidence["note"]
            items.append(row)

        kd = key_driver(mc)
        metrics.append(dict(
            metric=metric, label=mc.label, unit=mc.unit,
            is_headline=metric == p.headline_metric,
            value_t0=round(mc.value_t0, 4), value_t1=round(mc.value_t1, 4),
            change=round(mc.change, 4),
            pct_change=round(pct, 2) if pct is not None else None,
            gross_activity=round(mc.gross_activity, 4),
            netting_ratio=round(mc.netting_ratio, 1) if mc.netting_ratio != float("inf") else None,
            residual=float(f"{mc.residual():.2e}"),
            computed_key_driver=(dict(item_id=kd.item_id, entity=kd.entity_label,
                                      effect=kd.effect.value, value=round(kd.value, 4))
                                 if kd else None),
            effect_summary=effect_summary(mc)[:8],
            drivers=items,
        ))
    metrics.sort(key=lambda m: (not m["is_headline"], -abs(m["change"])))

    return dict(
        fund=dict(fund_id=p.fund_id, name=p.fund_name, type=p.fund_type,
                  benchmark=p.benchmark_name, headline_metric=p.headline_metric,
                  derivative_notional_share=round(p.derivative_share, 4),
                  classification_notes=p.rationale),
        period=dict(t0=a.t0, t1=a.t1,
                    nav_t0_musd=round(float(a.snapshot_t0["nav"]) / 1e6, 1),
                    nav_t1_musd=round(float(a.snapshot_t1["nav"]) / 1e6, 1),
                    risk_model_date_t1=str(a.snapshot_t1.get("model_date"))),
        triage=a.gate.to_dict() if a.gate else None,
        position_changes=_position_block(a),
        metrics=metrics,
        model_input_changes=_model_inputs(a),
        curve_moves=[c for c in a.curves.get("market_moves", []) if c.get("material")],
        curve_reassignments=a.curves.get("reassignments", []),
        cross_sectional=(cross or {}).get("findings", []),
        warnings=a.warnings,
        must_cover_ids=sorted(targets),
        must_cover_detail={k: dict(entity=v.entity_label, effect=v.effect.value,
                                   metric=v.metric, value=round(v.value, 4),
                                   agency=v.agency)
                           for k, v in targets.items()},
        provenance=cat.provenance(),
    )


def _position_block(a) -> dict:
    """Rung R2 in the context: what came in and what went out."""
    s = a.sets
    if s is None:
        return {}
    by_id = {c.entity: c for c in a.field_changes if c.change_type in ("entry", "exit")}
    fmt = lambda iid: dict(
        instrument_id=iid,
        name=by_id[iid].entity_label if iid in by_id else iid,
        risk_weight=round(by_id[iid].v1 if iid in by_id else 0.0, 6)
        if iid in s.entered else round(by_id[iid].v0 if iid in by_id else 0.0, 6),
    )
    return dict(
        opened=[fmt(i) for i in s.entered],
        closed=[fmt(i) for i in s.exited],
        held=len(s.held),
        note="opened and closed positions are decisions, and are reported as ENTRY "
             "and EXIT effects rather than pooled with routine resizing",
    )


def _model_inputs(a) -> list[dict]:
    """Changes that are configuration, not market. Kept in their own block so the
    narrator cannot accidentally fold them into a market story."""
    out = []
    for c in a.field_changes:
        if c.narrative_class != "model_input":
            continue
        out.append(dict(field=c.field, entity=c.entity_label, from_value=c.v0,
                        to_value=c.v1, detail=c.reason, agency=c.agency,
                        narrative_class="model_input",
                        instruction="describe this as a change of model input made by a "
                                    "person. Do NOT write it as a market move."))
    return out


def as_json(ctx: dict) -> str:
    return json.dumps(ctx, indent=1, default=str)
