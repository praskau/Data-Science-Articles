"""Pseudonymisation for the one step that leaves your machine.

The architecture already does most of the work here. Every number is computed
locally; the only thing that reaches a language model is the context, and the
only sensitive things in the context are *names* -- the fund, the benchmark, and
which issuers you hold. The arithmetic that the commentary is actually about
does not need any of them.

So: replace names with stable pseudonyms before the paste, keep the mapping on
disk, and substitute the real names back in when the report is rendered. The
model writes about `CorpBond-07`; your desk reads the issuer. The mapping file
never leaves the machine and is the only artefact that needs protecting.

This does not make the context public-safe by itself -- weights, durations and
risk contributions are still proprietary, and a determined reader with a holdings
file could re-identify large positions. It is the difference between "obviously
cannot paste this" and "a control your data-protection team can actually assess."
Get that assessment before you paste anything real.
"""

from __future__ import annotations

import json
import re

PREFIX = {
    "govt_bond": "Govt", "corp_bond": "CorpBond", "equity": "Equity",
    "future": "Future", "option": "Option", "irs": "Swap",
    "fx_forward": "FXFwd", "cash": "Cash",
}


def build_map(a, book, fund_id: str) -> dict[str, str]:
    """pseudonym -> real. Deterministic, so re-running gives the same labels."""
    p = book.positions
    pos = p[(p.fund_id == fund_id) & (p.cob_date == a.t1)]
    older = p[(p.fund_id == fund_id) & (p.cob_date == a.t0)]
    seen: dict[str, tuple[str, str]] = {}
    for df in (pos, older):
        for r in df.itertuples():
            seen.setdefault(str(r.instrument_id), (str(r.asset_class), str(r.name)))

    mapping: dict[str, str] = {}
    counters: dict[str, int] = {}
    for iid in sorted(seen):
        ac, name = seen[iid]
        p = PREFIX.get(ac, "Instr")
        counters[p] = counters.get(p, 0) + 1
        pseudo = f"{p}-{counters[p]:02d}"
        mapping[pseudo] = name
        mapping[f"{pseudo}#id"] = iid

    fr = book.funds[book.funds.fund_id == fund_id]
    if len(fr):
        row = fr.iloc[0]
        mapping["Fund-1"] = str(row.fund_name)
        mapping["FUND1"] = str(row.fund_id)
        if str(row.benchmark_name) not in ("nan", "None", ""):
            mapping["Benchmark-1"] = str(row.benchmark_name)
    return mapping


def _replacements(mapping: dict[str, str]) -> list[tuple[str, str]]:
    """Longest real string first, so 'GOVE002 4.795% 2047' is replaced before
    any substring of it can be."""
    return sorted(((real, pseudo) for pseudo, real in mapping.items()),
                  key=lambda kv: -len(kv[0]))


def redact_context(ctx: dict, mapping: dict[str, str]) -> dict:
    """Apply the mapping to every string in the context, wherever it appears --
    including inside warning text, which is where identifiers most often leak."""
    blob = json.dumps(ctx)
    for real, pseudo in _replacements(mapping):
        if real:
            blob = blob.replace(json.dumps(real)[1:-1], pseudo)
    return json.loads(blob)


def restore(text: str, mapping: dict[str, str]) -> str:
    """Substitute real names back into finished commentary, locally."""
    for pseudo in sorted(mapping, key=len, reverse=True):
        if pseudo.endswith("#id"):
            continue
        text = re.sub(rf"\b{re.escape(pseudo)}\b", mapping[pseudo], text)
    return text


def restore_doc(doc, mapping: dict[str, str]):
    """Walk a Pydantic commentary object and restore every free-text field."""
    data = json.loads(doc.model_dump_json())

    def walk(node):
        if isinstance(node, dict):
            return {k: (walk(v) if k != "ledger_ids" else v) for k, v in node.items()}
        if isinstance(node, list):
            return [walk(v) for v in node]
        if isinstance(node, str):
            return restore(node, mapping)
        return node

    return type(doc).model_validate(walk(data))


def audit(ctx: dict, mapping: dict[str, str]) -> list[str]:
    """Report any real name still present after redaction. Run this before pasting."""
    blob = json.dumps(ctx)
    return [real for real in mapping.values()
            if real and json.dumps(real)[1:-1] in blob]
