"""Identify the fund from its holdings, then look up what to measure.

Rules live in config/profiles.json. A fund is not told to us; it is inferred and
the inference is stated, because "why is tracking error the headline for this
fund" is a question that should have a printed answer.
"""

from __future__ import annotations

import pandas as pd

from .catalogue import Catalogue
from .types import FundProfile


def profile(cat: Catalogue, positions: pd.DataFrame, fund_id: str,
            fund_name: str = "") -> FundProfile:
    c = cat.profiles["classification"]
    deriv = set(c["derivative_classes"])
    df = positions[positions.fund_id == fund_id]

    mv = df.market_value.abs().sum()
    share = (lambda classes: float(df[df.asset_class.isin(classes)].market_value.abs().sum() / mv)
             if mv else 0.0)

    bond_share = share(["govt_bond", "corp_bond"])
    eq_share = share(["equity"])
    dshare = float(df[df.asset_class.isin(deriv)][c["derivative_share_field"]].abs().sum())

    rationale = [
        f"bonds are {bond_share:.0%} of market value",
        f"equities are {eq_share:.0%} of market value",
        f"derivatives carry {dshare:.1%} of notional weight",
    ]
    if bond_share >= 0.80:
        ftype = "fixed_income"
    elif eq_share >= 0.80:
        ftype = "equity"
    else:
        ftype = "multi_asset"
    rationale.append(f"classified {ftype}")

    spec = cat.fund_type_spec(ftype)
    over = cat.fund_override(fund_id)
    has_bmk = bool(over.get("has_benchmark", False))

    metrics = [m for m in spec["metrics"]
               if not (cat.metric(m).requires == "has_benchmark" and not has_bmk)]
    headline = spec["headline_metric"]
    if cat.metric(headline).requires == "has_benchmark" and not has_bmk:
        headline = metrics[0]
        rationale.append("no benchmark, so the headline falls back to a total-risk metric")

    if dshare > 0.10:
        rationale.append(
            f"derivative notional is material, so exposure is measured on "
            f"{cat.decomposition_weight()}, not market weight")

    return FundProfile(
        fund_id=fund_id, fund_name=fund_name or fund_id, fund_type=ftype,
        has_benchmark=has_bmk, benchmark_name=over.get("benchmark_name"),
        headline_metric=headline, metrics=metrics,
        derivative_share=dshare, rationale=rationale,
    )
