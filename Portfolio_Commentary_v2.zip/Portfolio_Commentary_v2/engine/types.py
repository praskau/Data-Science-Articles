"""Core records. Metrics are strings, not an enum, because they come from the
catalogue -- adding a metric must not require editing this file."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Level(str, Enum):
    FUND = "fund"
    SLEEVE = "sleeve"
    POSITION = "position"
    GROUP = "group"


class Effect(str, Enum):
    """The complete set of reasons a risk metric can move.

    Complete is meant literally: the decomposition is exact, so if a change is
    not one of these it does not exist. The narrator is forbidden from asserting
    any cause not on this list, which is what stops "risk-off sentiment"
    appearing in a document that is supposed to be arithmetic.
    """

    # --- the manager did something -------------------------------------
    ENTRY = "entry"                      # opened a position we did not hold
    EXIT = "exit"                        # closed a position entirely
    ALLOCATION = "allocation"            # resized something we already held
    TRADE = "trade"                      # units changed (market-value identity)

    # --- something happened to the portfolio ---------------------------
    STANDALONE_VOL = "standalone_vol"    # the asset got riskier by itself
    CORRELATION = "correlation"          # its co-movement with the book changed
    CROSS_IMPACT = "cross_impact"        # untouched, unchanged -- yet its risk moved
    PRICE = "price"                      # market value moved on price
    INSTRUMENT = "instrument"            # the analytic itself moved (rolldown, reset)

    # --- somebody else did something -----------------------------------
    BENCHMARK = "benchmark"              # the index reweighted
    MARKET_VALUE = "market_value"        # NAV moved (flows), rescaling money risk
    RATING_MIGRATION = "rating_migration"  # the issuer was re-rated

    # --- model inputs, not market events -------------------------------
    CURVE_REASSIGNMENT = "curve_reassignment"
    CURVE_LEVEL = "curve_level"
    CURVE_SLOPE = "curve_slope"
    CURVE_CURVATURE = "curve_curvature"

    # --- arithmetic -----------------------------------------------------
    INTERACTION = "interaction"
    UNEXPLAINED = "unexplained"          # rung R9: stated, never absorbed


# Who is accountable for each effect. The narrator uses this to avoid writing
# "we increased risk" about something nobody traded.
AGENCY: dict[Effect, str] = {
    Effect.ENTRY: "manager", Effect.EXIT: "manager",
    Effect.ALLOCATION: "manager", Effect.TRADE: "manager",
    Effect.STANDALONE_VOL: "market", Effect.CORRELATION: "market",
    Effect.CROSS_IMPACT: "market", Effect.PRICE: "market",
    Effect.INSTRUMENT: "market",
    Effect.CURVE_LEVEL: "market", Effect.CURVE_SLOPE: "market",
    Effect.CURVE_CURVATURE: "market",
    Effect.BENCHMARK: "index", Effect.MARKET_VALUE: "flows",
    Effect.RATING_MIGRATION: "issuer",
    Effect.CURVE_REASSIGNMENT: "model_owner",
    Effect.INTERACTION: "mixed", Effect.UNEXPLAINED: "none",
}

# Effects that are model configuration rather than market events. These must be
# narrated as decisions, never as things the market did.
MODEL_INPUT_EFFECTS = {Effect.CURVE_REASSIGNMENT}


@dataclass
class LedgerItem:
    """One signed, additive term of a metric's change."""

    metric: str
    level: Level
    entity: str
    entity_label: str
    effect: Effect
    value: float
    evidence: dict = field(default_factory=dict)
    item_id: str = ""
    share_of_change: float = 0.0
    material: bool = False
    rank: int = 0
    rung: str = ""                       # which ladder rung surfaced this

    def key(self) -> str:
        return f"{self.metric}|{self.level.value}|{self.entity}|{self.effect.value}"

    @property
    def agency(self) -> str:
        return AGENCY.get(self.effect, "unknown")

    @property
    def narrative_class(self) -> str:
        return "model_input" if self.effect in MODEL_INPUT_EFFECTS else "market"


@dataclass
class MetricChange:
    metric: str
    label: str
    unit: str
    precision: int
    t0: str
    t1: str
    value_t0: float
    value_t1: float
    items: list[LedgerItem] = field(default_factory=list)

    @property
    def change(self) -> float:
        return self.value_t1 - self.value_t0

    @property
    def rel_change(self) -> float:
        return self.change / abs(self.value_t0) if abs(self.value_t0) > 1e-12 else float("inf")

    def additive_items(self) -> list[LedgerItem]:
        """Only the levels that sum to the change. Sleeve rows are a derived
        view of the same money and would double-count."""
        return [i for i in self.items if i.level in (Level.POSITION, Level.FUND)]

    @property
    def gross_activity(self) -> float:
        return sum(abs(i.value) for i in self.additive_items())

    @property
    def netting_ratio(self) -> float:
        net = abs(self.change)
        return self.gross_activity / net if net > 1e-12 else float("inf")

    def residual(self) -> float:
        """The part of the change the decomposition does not account for.

        Deliberately excludes the UNEXPLAINED item. That item exists to RECORD a
        residual; if it were counted here, appending it would drive this to zero
        and the reconciliation check would pass by construction -- a check that
        cannot fail is not a check.
        """
        return self.change - sum(i.value for i in self.additive_items()
                                 if i.effect is not Effect.UNEXPLAINED)

    def material_items(self) -> list[LedgerItem]:
        return [i for i in self.items if i.material]

    def by_effect(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for i in self.additive_items():
            out[i.effect.value] = out.get(i.effect.value, 0.0) + i.value
        return dict(sorted(out.items(), key=lambda kv: -abs(kv[1])))

    def fmt(self, v: float) -> str:
        return f"{v:.{self.precision}f}"


@dataclass
class FundProfile:
    fund_id: str
    fund_name: str
    fund_type: str
    has_benchmark: bool
    benchmark_name: str | None
    headline_metric: str
    metrics: list[str]
    derivative_share: float
    rationale: list[str] = field(default_factory=list)
