"""Render verified commentary to markdown. Presentation only -- no analysis,
no numbers computed here. If a figure is not already in the document it does
not appear in the output."""

from __future__ import annotations

from .types import Effect


def long_form(doc, a, cat, mapping: dict[str, str] | None = None) -> str:
    from .redact import restore_doc
    if mapping:
        doc = restore_doc(doc, mapping)
    p = a.profile
    L: list[str] = [
        f"# {p.fund_name} — risk commentary",
        f"*{a.t0} to {a.t1} · {p.fund_type.replace('_', ' ')} · "
        f"headline metric: {cat.metric(p.headline_metric).label}*",
        "",
        f"**{doc.headline}**",
        "",
        doc.opening,
        "",
    ]
    for s in doc.sections:
        L += [f"## {s.title}", ""]
        for c in s.claims:
            L += [c.text, ""]
    if doc.not_the_driver:
        L += ["## What did not drive this", ""]
        L += [f"- {x}" for x in doc.not_the_driver] + [""]
    if doc.caveats:
        L += ["## Caveats", ""]
        L += [f"- {x}" for x in doc.caveats] + [""]
    L += ["---", "", _provenance(a, cat)]
    return "\n".join(L)


def short_form(doc, a, cat, mapping: dict[str, str] | None = None) -> str:
    from .redact import restore_doc
    if mapping:
        doc = restore_doc(doc, mapping)
    return "\n".join([f"**{doc.headline}**", "", doc.body, ""])


def _provenance(a, cat) -> str:
    pv = cat.provenance()
    rec = [f"{m}: residual {mc.residual():.1e}" for m, mc in a.changes.items()]
    return (
        f"<sub>Generated from an exact Euler decomposition. "
        f"Catalogue {pv['fields_schema_version']} (hash `{pv['catalogue_hash']}`), "
        f"materiality {pv['materiality_version']}. "
        f"Reconciliation — {'; '.join(rec)}. "
        f"Every figure above is traceable to a ledger item; the commentary was "
        f"machine-verified for coverage and numeric grounding before publication.</sub>"
    )


def ledger_table(mc, limit: int = 20) -> str:
    """A plain markdown view of a metric's ledger, for review."""
    L = [f"### {mc.label}: {mc.fmt(mc.value_t0)} → {mc.fmt(mc.value_t1)} "
         f"({mc.change:+.4f} {mc.unit})", "",
         "| id | entity | effect | agency | value | material |",
         "|---|---|---|---|---:|:---:|"]
    rows = sorted(mc.items, key=lambda i: -abs(i.value))[:limit]
    for it in rows:
        L.append(f"| `{it.item_id}` | {it.entity_label} | {it.effect.value} | "
                 f"{it.agency} | {it.value:+.4f} | {'yes' if it.material else ''} |")
    return "\n".join(L)
