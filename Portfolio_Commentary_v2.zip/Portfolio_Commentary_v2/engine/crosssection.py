"""Was it us, or was it everyone?

If the same effect moves the same way on the same sleeve in two or more funds,
it is a market event, and narrating it as a manager decision is simply wrong.
This is the cheapest large improvement available to portfolio commentary and
almost no automated system does it, because it requires looking outside the fund
you were asked about.
"""

from __future__ import annotations

from .catalogue import Catalogue
from .types import Effect, Level

# Effects nobody trades. Seeing these move together across funds is confirmation
# of a market regime; seeing ALLOCATION move together is a house view.
_MARKET_EFFECTS = {Effect.STANDALONE_VOL, Effect.CORRELATION, Effect.CROSS_IMPACT,
                   Effect.INSTRUMENT, Effect.PRICE}


def analyse(cat: Catalogue, analyses: dict) -> dict:
    """Find effects that moved the same way, on the same bucket, in >=N funds.

    Deliberately NOT keyed on sleeve. Sleeves are a per-fund reporting choice --
    FI001 buckets by credit rating, EQ001 by sector, MA001 by asset class -- so
    they never match across funds and a sleeve-keyed comparison silently finds
    nothing, which is worse than not doing it. The comparison axis has to be an
    attribute of the instrument, not of the report.
    """
    cfg = cat.cross_section
    if not cfg.get("enabled", True):
        return {"enabled": False, "findings": []}

    min_funds = int(cfg.get("min_funds", 2))
    same_sign = bool(cfg.get("same_sign_required", True))
    axes = cfg.get("axes") or ["asset_class", "sector"]

    # (axis, bucket, effect) -> {fund_id: summed value}
    buckets: dict[tuple[str, str, str], dict[str, float]] = {}
    for fid, a in analyses.items():
        for it in a.headline.items:
            if it.level is not Level.POSITION:
                continue
            for axis in axes:
                b = it.evidence.get(axis)
                if not b:
                    continue
                k = (axis, str(b), it.effect.value)
                buckets[k] = buckets.get(k, {})
                buckets[k][fid] = buckets[k].get(fid, 0.0) + it.value

    # Only compare buckets that are actually material somewhere, or every
    # rounding-error term in the book becomes a "market-wide finding".
    floors = {fid: max(a.headline.precision and 0.0,
                       float(cat.metric(a.headline.metric).abs_floor))
              for fid, a in analyses.items()}

    out = []
    for (axis, bucket, effect), per_fund in sorted(buckets.items()):
        live = {f: v for f, v in per_fund.items() if abs(v) >= floors.get(f, 0.0)}
        if len(live) < min_funds:
            continue
        vals = list(live.values())
        if same_sign and not (all(v > 0 for v in vals) or all(v < 0 for v in vals)):
            continue
        e = Effect(effect)
        out.append(dict(
            axis=axis, bucket=bucket, effect=effect, funds=sorted(live),
            n_funds=len(live),
            values={k: round(v, 6) for k, v in sorted(live.items())},
            direction="increase" if vals[0] > 0 else "decrease",
            classification="market_wide" if e in _MARKET_EFFECTS else "house_view",
            note=("this moved the same way in every fund listed, so it is a market "
                  "event and must not be narrated as a fund-specific decision"
                  if e in _MARKET_EFFECTS else
                  "the same decision was taken across funds -- a house view, not a "
                  "market event"),
        ))
    out.sort(key=lambda d: (-d["n_funds"], -abs(sum(d["values"].values()))))
    return {"enabled": True, "min_funds": min_funds, "axes": axes, "findings": out}
