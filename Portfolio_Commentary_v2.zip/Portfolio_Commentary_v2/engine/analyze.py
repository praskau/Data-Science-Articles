"""Assemble the full analysis for one fund across two COB dates.

This is the module that walks the ladder in config/logic.md. It computes
everything; it decides nothing about wording. Loop A -- the drill-down -- lives
here and is pure arithmetic, so it terminates by construction: nine rungs, each
either producing findings or not.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import pandas as pd

from . import classify, curve, decompose, diff, findings, positions as posmod, triage
from .catalogue import Catalogue
from .types import Effect, FundProfile, LedgerItem, Level, MetricChange


@dataclass
class Book:
    positions: pd.DataFrame
    snapshots: pd.DataFrame
    curves: pd.DataFrame
    instruments: pd.DataFrame
    funds: pd.DataFrame

    @property
    def dates(self) -> list[str]:
        return sorted(self.positions.cob_date.astype(str).unique())

    @property
    def fund_ids(self) -> list[str]:
        return sorted(self.positions.fund_id.unique())

    def name(self, fund_id: str) -> str:
        r = self.funds[self.funds.fund_id == fund_id]
        return str(r.fund_name.iloc[0]) if len(r) else fund_id


def load_book(datadir: str = "data") -> Book:
    rd = lambda f: pd.read_csv(os.path.join(datadir, f))
    b = Book(rd("positions.csv"), rd("risk_snapshots.csv"), rd("curves.csv"),
             rd("instruments.csv"), rd("funds.csv"))
    b.positions["cob_date"] = b.positions.cob_date.astype(str)
    b.snapshots["cob_date"] = b.snapshots.cob_date.astype(str)
    b.curves["cob_date"] = b.curves.cob_date.astype(str)
    return b


@dataclass
class Analysis:
    profile: FundProfile
    t0: str
    t1: str
    snapshot_t0: dict
    snapshot_t1: dict
    changes: dict[str, MetricChange] = field(default_factory=dict)
    sets: posmod.PositionSets | None = None
    field_changes: list[diff.FieldChange] = field(default_factory=list)
    curves: dict = field(default_factory=dict)
    gate: triage.GateResult | None = None
    warnings: list[str] = field(default_factory=list)
    rungs: dict[str, int] = field(default_factory=dict)

    @property
    def headline(self) -> MetricChange:
        return self.changes[self.profile.headline_metric]


def _snap(book: Book, fund_id: str, date: str) -> dict:
    r = book.snapshots[(book.snapshots.fund_id == fund_id) & (book.snapshots.cob_date == date)]
    if not len(r):
        raise KeyError(f"no risk snapshot for {fund_id} at {date}")
    return {k: (v.item() if hasattr(v, "item") else v) for k, v in r.iloc[0].to_dict().items()}


def analyse(book: Book, cat: Catalogue, fund_id: str, t0: str, t1: str) -> Analysis:
    """Walk the ladder. Every rung is arithmetic; none of it is a judgement call."""
    p = book.positions
    d0 = p[(p.fund_id == fund_id) & (p.cob_date == t0)]
    d1 = p[(p.fund_id == fund_id) & (p.cob_date == t1)]
    if d0.empty or d1.empty:
        raise KeyError(f"{fund_id} has no positions at {t0 if d0.empty else t1}")

    prof = classify.profile(cat, p[p.cob_date == t1], fund_id, book.name(fund_id))
    s0, s1 = _snap(book, fund_id, t0), _snap(book, fund_id, t1)
    a = Analysis(profile=prof, t0=t0, t1=t1, snapshot_t0=s0, snapshot_t1=s1)

    # --- R2: the position set itself ------------------------------------
    a.sets = posmod.split(d0, d1, fund_id, t0, t1)
    a.rungs["R2"] = a.sets.turnover_count

    # --- risk decomposition, per metric declared for this fund type ------
    base_items: dict[str, list[LedgerItem]] = {}
    for metric in prof.metrics:
        spec = cat.metric(metric)
        v0, v1 = float(s0[metric]), float(s1[metric])

        if spec.derived_from:
            src = spec.derived_from
            items = decompose.decompose_derived(
                base_items[src], spec, cat, float(s0[src]), float(s1[src]),
                float(s0["nav"]), float(s1["nav"]))
        elif spec.euler:
            items = decompose.decompose_risk(d0, d1, spec, cat, a.sets)
            base_items[metric] = items
        elif spec.linear:
            items = decompose.decompose_linear(d0, d1, spec, cat, a.sets)
        else:
            continue

        sleeves = decompose.aggregate_to_sleeves(items)
        fund_lvl = [i for i in items if i.level is Level.FUND]
        pos_lvl = [i for i in items if i.level is Level.POSITION]
        mc = findings.build_change(cat, metric, t0, t1, v0, v1, pos_lvl, sleeves, fund_lvl)
        findings.add_unexplained(mc, cat)
        a.changes[metric] = mc
        a.warnings += findings.diagnose(cat, mc, s0, s1)

    # rung counts, read off the ledger rather than tracked by hand
    for mc in a.changes.values():
        for it in mc.additive_items():
            if it.rung:
                a.rungs[it.rung] = a.rungs.get(it.rung, 0) + (1 if it.material else 0)

    # --- R0: the gates ---------------------------------------------------
    a.gate = triage.gate(cat, fund_id, a.changes)

    # --- R4 / R6: field-level and model-input changes --------------------
    fc = diff.compare_positions(d0, d1, cat, fund_id, t1, a.sets)
    fc += diff.entries_and_exits(d0, d1, cat, a.sets)
    fc += diff.compare_fund(s0, s1, cat, fund_id, t1, prof.fund_name)
    wcol = posmod.risk_weight_column(cat, d1)
    a.field_changes = diff.collapse(fc, cat, dict(zip(d1.instrument_id, d1[wcol])))
    a.rungs["R6"] = len(diff.model_input_changes(a.field_changes))

    # --- R6: curves, market move and reassignment kept apart -------------
    used = sorted(set(d0.yield_curve_id.dropna()) | set(d1.yield_curve_id.dropna())) \
        if "yield_curve_id" in d0.columns else []
    swaps = sorted({(str(c.v0), str(c.v1)) for c in a.field_changes
                    if c.field == "yield_curve_id"})
    a.curves = curve.analyse(book.curves, t0, t1, cat, used, swaps)

    return a


def analyse_all(book: Book, cat: Catalogue, t0: str, t1: str,
                fund_ids: list[str] | None = None) -> dict[str, Analysis]:
    return {f: analyse(book, cat, f, t0, t1) for f in (fund_ids or book.fund_ids)}


def reconciliation(a: Analysis, cat: Catalogue) -> list[dict]:
    """The additivity check, per metric. Runs on every analysis, always."""
    tol = float(cat.materiality.get("residual_tolerance", 1e-9))
    out = []
    for metric, mc in a.changes.items():
        r = mc.residual()
        out.append(dict(metric=metric, change=round(mc.change, 10),
                        sum_of_terms=round(sum(i.value for i in mc.additive_items()
                                               if i.effect is not Effect.UNEXPLAINED), 10),
                        residual=float(f"{r:.3e}"), tolerance=tol, reconciles=abs(r) <= tol,
                        n_terms=len(mc.additive_items())))
    return out
