"""The ledger: turn raw decomposition terms into ranked, material findings.

Two jobs. First, decide what is worth saying -- a decomposition of a 60-position
fund produces hundreds of signed terms and all of them are true. Materiality is
the difference between commentary and a data dump. Second, diagnose the shape of
the change, so the narrator is told when the headline is misleading before it
writes a sentence claiming otherwise.

Every threshold comes from config/profiles.json. Nothing is tuned here.
"""

from __future__ import annotations

from hashlib import blake2s

from .catalogue import Catalogue
from .types import Effect, LedgerItem, Level, MetricChange


def _item_id(it: LedgerItem) -> str:
    return blake2s(it.key().encode(), digest_size=4).hexdigest()


def build_change(cat: Catalogue, metric: str, t0: str, t1: str, v0: float, v1: float,
                 position_items: list[LedgerItem],
                 sleeve_items: list[LedgerItem] | None = None,
                 fund_items: list[LedgerItem] | None = None) -> MetricChange:
    """Assemble a MetricChange, assign ids, rank, share and materiality."""
    spec = cat.metric(metric)
    mat = cat.materiality
    rel_floor = float(mat["rel_floor"])
    max_items = mat["max_items"]

    mc = MetricChange(
        metric=metric, label=spec.label, unit=spec.unit, precision=spec.precision,
        t0=t0, t1=t1, value_t0=v0, value_t1=v1,
        items=list(position_items) + list(sleeve_items or []) + list(fund_items or []),
    )

    change = mc.change
    abs_floor = spec.abs_floor

    for it in mc.items:
        it.item_id = _item_id(it)
        it.share_of_change = it.value / change if abs(change) > 1e-12 else 0.0

    # Rank within each level, then apply both floors and a per-level cap.
    for level in (Level.POSITION, Level.SLEEVE, Level.FUND):
        group = sorted((i for i in mc.items if i.level is level),
                       key=lambda i: -abs(i.value))
        cap = int(max_items.get(level.value, 10))
        for n, it in enumerate(group, start=1):
            it.rank = n
            floor = max(abs_floor, rel_floor * abs(change))
            it.material = abs(it.value) >= floor and n <= cap

    return mc


def add_unexplained(mc: MetricChange, cat: Catalogue) -> LedgerItem | None:
    """Rung R9. If the terms do not reconcile, say so with a number.

    A framework that cannot admit an unexplained residual will invent a driver
    to cover it, and that is a worse failure than the gap.
    """
    tol = float(cat.materiality.get("residual_tolerance", 1e-9))
    r = mc.residual()
    if abs(r) <= tol:
        return None
    it = LedgerItem(
        metric=mc.metric, level=Level.FUND, entity="UNEXPLAINED",
        entity_label="Unexplained residual", effect=Effect.UNEXPLAINED,
        value=r, rung="R9", material=True,
        evidence=dict(tolerance=tol,
                      note="the decomposition does not reconcile to the headline change; "
                           "this amount is not attributable and must be stated as such"),
    )
    it.item_id = _item_id(it)
    it.share_of_change = r / mc.change if abs(mc.change) > 1e-12 else 0.0
    mc.items.append(it)
    return it


def diagnose(cat: Catalogue, mc: MetricChange, snap0: dict, snap1: dict) -> list[str]:
    """Warnings the narrator must restate. Each one exists because it names a
    specific way an honest-looking sentence would be wrong."""
    mat = cat.materiality
    out: list[str] = []
    change, gross = mc.change, mc.gross_activity
    p = mc.precision

    r = mc.residual()
    if abs(r) > float(mat.get("residual_tolerance", 1e-9)):
        out.append(
            f"ENGINE: {mc.label} does not reconcile -- {r:+.{p}f} {mc.unit} of the "
            f"{change:+.{p}f} move is unattributed. Report it as unexplained; do not "
            f"assign it to a named driver.")

    nr = mc.netting_ratio
    alert = float(mat["netting_alert"])
    spec = cat.metric(mc.metric)
    # A position-level decomposition always has high gross activity, because
    # positions routinely offset each other. What makes netting a WARNING rather
    # than a curiosity is a small net move: that is when a reader is invited to
    # conclude nothing happened. So the prohibition only binds on a quiet headline.
    quiet = abs(mc.rel_change) < spec.gate_rel
    if nr >= alert and gross > 0:
        if quiet:
            out.append(
                f"NETTING: gross activity of {gross:.{p}f} {mc.unit} netted to "
                f"{change:+.{p}f} ({nr:.0f}x). The portfolio was rebuilt underneath a quiet "
                f"headline. Do not describe {mc.label} as stable or broadly unchanged; name "
                f"both sides of the offset.")
        else:
            out.append(
                f"CONTEXT: {mc.label} moved {change:+.{p}f} {mc.unit} on {gross:.{p}f} of "
                f"gross activity ({nr:.0f}x). The net move understates how much was traded; "
                f"lead with the drivers, not the headline.")

    top = sorted(mc.additive_items(), key=lambda i: -abs(i.value))
    if top:
        t = top[0]
        conc = float(mat["concentration_alert"])
        if nr >= alert:
            # Expressing a driver as a share of a near-zero net move produces
            # numbers like "1,900% of the change", which is not a fact worth printing.
            share = abs(t.value) / gross if gross else 0.0
            if share >= conc:
                out.append(
                    f"CONCENTRATION: {t.entity_label} is {share:.0%} of gross activity. "
                    f"Express it as a share of gross, never of the net change.")
        elif abs(change) > 1e-12 and abs(t.value / change) >= conc:
            out.append(
                f"CONCENTRATION: {t.entity_label} alone is {t.value / change:.0%} of the "
                f"{mc.label} move.")

    # When gross activity dwarfs the net move, a share OF THE NET is arithmetically
    # true and rhetorically worthless -- "correlation was -102% of the change" is
    # not a sentence anyone should publish. Above the netting alert we quote
    # shares of gross instead, and say which basis we used.
    def _share(v: float) -> tuple[float, str]:
        if nr >= alert and gross > 0:
            return abs(v) / gross, "of gross activity"
        return (v / change if abs(change) > 1e-12 else 0.0), "of the move"

    eff = mc.by_effect()
    inter = eff.get(Effect.INTERACTION.value, 0.0)
    ishare, ibasis = _share(inter)
    if abs(ishare) >= float(mat["interaction_alert"]):
        out.append(
            f"INTERACTION: cross terms are {ishare:.0%} {ibasis}. Weight and risk moved "
            f"together; use the interaction_reading field rather than attributing the "
            f"whole move to either one.")

    for e, label in ((Effect.CORRELATION.value, "correlation"),
                     (Effect.CROSS_IMPACT.value, "cross-impact"),
                     (Effect.BENCHMARK.value, "benchmark reweighting")):
        v = eff.get(e, 0.0)
        share, basis = _share(v)
        if abs(share) >= 0.35:
            out.append(
                f"AGENCY: {label} accounts for {share:.0%} {basis}. Nothing was traded "
                f"for this. Do not write it as a manager decision.")

    md0, md1 = snap0.get("model_date"), snap1.get("model_date")
    if md1 and str(md1) != str(snap1.get("cob_date", md1)):
        out.append(f"DATA: the risk model date at T1 is {md1}, not the COB date "
                   f"{snap1.get('cob_date')}. Every risk figure below is that vintage.")
    if md0 and md1 and str(md0) == str(md1):
        out.append(f"DATA: the risk model date did not move between the two COB dates "
                   f"({md0}). The 'change' may be a portfolio change measured on a stale model.")
    return out


def effect_summary(mc: MetricChange) -> list[dict]:
    """Fund-level roll-up by effect, largest first."""
    from .types import AGENCY
    out = []
    for eff, val in mc.by_effect().items():
        e = Effect(eff)
        out.append(dict(
            effect=eff, value=round(val, 8), agency=AGENCY.get(e, "unknown"),
            share_of_change=round(val / mc.change, 4) if abs(mc.change) > 1e-12 else None,
            share_of_gross=round(abs(val) / mc.gross_activity, 4) if mc.gross_activity else None,
        ))
    return out


def coverage_targets(cat: Catalogue, changes: dict[str, MetricChange],
                     headline: str) -> dict[str, LedgerItem]:
    """The exact set of item ids the long form must account for.

    Budgeted on purpose. An earlier version required every material item and
    produced 51 targets on one fund, which yields a list, not commentary.
    """
    budget = cat.coverage["budget"]
    out: dict[str, LedgerItem] = {}
    for metric, mc in changes.items():
        n = int(budget["headline" if metric == headline else "other"])
        pool = [i for i in mc.items
                if i.material and i.level in (Level.SLEEVE, Level.FUND)]
        # An unexplained residual is never optional, budget or not.
        forced = [i for i in mc.items if i.effect is Effect.UNEXPLAINED]
        for it in sorted(pool, key=lambda i: -abs(i.value))[:n] + forced:
            out[it.item_id] = it
    return out


def key_driver(mc: MetricChange) -> LedgerItem | None:
    """The single driver the short form names. Computed, never chosen by the model.

    Selected from the SAME pool the coverage targets are drawn from -- sleeve and
    fund level -- so the short form can never name something the long form was
    not required to discuss. Picking the largest position-level term instead
    looks more precise and is worse: it routinely surfaces a single instrument
    that no sleeve-level section mentions, and the two documents then disagree,
    which is the failure that destroys trust faster than any factual error.

    Ranked on absolute size, so it is stable, reproducible and defensible --
    three properties a model's judgement does not have.
    """
    pool = [i for i in mc.items
            if i.level in (Level.SLEEVE, Level.FUND)
            and i.effect is not Effect.UNEXPLAINED]
    if not pool:      # a fund with no sleeve structure at all
        pool = [i for i in mc.additive_items() if i.effect is not Effect.UNEXPLAINED]
    return max(pool, key=lambda i: abs(i.value)) if pool else None
