#!/usr/bin/env python3
"""
Generate a realistic dummy output of the extract, for building and testing the
commentary prompt without touching production data.

Three funds: one equity only, one fixed income, one multi asset.

The column list is read out of risk_contribution_pairwise.sql itself, so the dummy
file has exactly the columns the real query produces, in the same order. Every
derived column is computed with the same rules the SQL uses, so the file
reconciles: SUM(Chg_ContriB_PfVol) == Chg_PortfolioVol per fund.

    python3 make_dummy_data.py
"""

import csv
import pathlib
import re
from datetime import date

HERE = pathlib.Path(__file__).resolve().parent
SQL = HERE.parent / "risk_drilldown.sql"
SQL_SUMMARY = HERE.parent / "01_portfolio_summary.sql"

COB_C, COB_P = date(2026, 8, 24), date(2026, 8, 12)
SC, SP = "Curr", "Prev"   # dated column suffixes; the dates live in ValuationDate_Curr/_Prev
FC, FP = COB_C.strftime("%d%m%Y"), COB_P.strftime("%d%m%Y")   # used in filenames only

# The load each COB came from. The queries keep only MAX(JobExecutionID) per date x
# portfolio, so exactly one job id appears per date in a clean extract.
JOB_C, JOB_P = 481207, 479833


# ---------------------------------------------------------------- column order
def split_top_level(block: str) -> list[str]:
    """Split a SELECT list on commas that are not inside parens or quotes."""
    items, depth, quoted, buf = [], 0, False, []
    for ch in block:
        if ch == "'":
            quoted = not quoted
        if not quoted:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "," and depth == 0:
                items.append("".join(buf))
                buf = []
                continue
        buf.append(ch)
    if "".join(buf).strip():
        items.append("".join(buf))
    return items


def output_columns(path=SQL) -> list[str]:
    # The queries are plain SQL now -- no template to unwrap. Aliases end in _Curr / _Prev.
    tpl = path.read_text()
    start = list(re.finditer(r"(?m)^SELECT$", tpl))[-1].end()
    block = tpl[start:]
    block = block[: re.search(r"(?m)^FROM ", block).start()]
    block = re.sub(r"--[^\n]*", "", block)          # strip comments
    cols = []
    for item in split_top_level(block):
        item = " ".join(item.split())
        if not item:
            continue
        m = re.search(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)$", item)
        cols.append(m.group(1) if m else item.split(".")[-1])
    return cols


# ---------------------------------------------------------------- fund content
# Columns per security:
#   name, isin, seccode, line, asset_class, sector, country, ccy,
#   mw_p, mw_c, bm_p, bm_c, pv_p, pv_c, te_p, te_c, ed_p, ed_c, flags
# A weight or contribution of None means the position did not exist on that date.
# flags: set of {'yc','vm','md','mt','dp','rating'} that changed between the dates.

EQUITY = [
    ("NVIDIA CORP",              "US67066G1040", "10110649", "Ordinary", "Equity",           "Information Technology", "US", "USD", 4.80, 6.10, 3.90, 4.35, 1.850, 2.950, 0.620, 1.150, None, None, set()),
    ("TAIWAN SEMICONDUCTOR MFG", "US8740391003", "10110651", "Ordinary", "Equity",           "Information Technology", "TW", "USD", 3.60, 4.20, 3.10, 3.25, 1.020, 1.350, 0.350, 0.480, None, None, {"mt", "dp"}),
    ("NOVO NORDISK A/S",         "DK0062498333", "10110657", "Ordinary", "Equity",           "Health Care",            "DK", "DKK", 2.80, 1.60, 1.95, 1.90, 0.880, 0.440, 0.290, 0.150, None, None, set()),
    ("BROADCOM INC",             "US11135F1012", "10110671", "Ordinary", "Equity",           "Information Technology", "US", "USD", 2.20, None, 1.80, 1.85, 0.740, None,  0.260, None,  None, None, set()),
    ("SPDR S&P 500 ETF TRUST",   "US78462F1030", "10110703", "Fund",     "Equity Fund",      "Diversified",            "US", "USD", None, 2.50, None, None, None,  0.550, None,  0.200, None, None, set()),
    ("ISHARES CORE MSCI EM ETF", "IE00B4L5YC18", "10110711", "Fund",     "Equity Fund",      "Diversified",            "IE", "USD", 3.00, 2.20, None, None, 0.720, 0.520, 0.240, 0.170, None, None, set()),
    ("MICROSOFT CORP",           "US5949181045", "10126484", "Ordinary", "Equity",           "Information Technology", "US", "USD", 5.40, 5.35, 5.10, 5.05, 1.100, 1.080, 0.180, 0.170, None, None, set()),
    ("TENCENT HOLDINGS LTD",     "KYG875721634", "10126634", "Ordinary", "Equity",           "Communication Services", "CN", "HKD", 3.20, 3.10, 2.60, 2.55, 0.950, 0.880, 0.310, 0.280, None, None, set()),
    ("ASML HOLDING NV",          "NL0010273215", "10127016", "Ordinary", "Equity",           "Information Technology", "NL", "EUR", 2.90, 2.85, 2.20, 2.20, 0.780, 0.920, 0.220, 0.300, None, None, set()),
    ("S&P 500 FUTURE SEP26",     "",             "10127074", "Future",   "Equity Derivative","Diversified",            "US", "USD", 0.15, 0.14, None, None, 0.280, 0.260, 0.060, 0.060, None, None, set()),
    ("SAMSUNG ELECTRONICS CO",   "KR7005930003", "10127082", "Ordinary", "Equity",           "Information Technology", "KR", "KRW", 2.10, 1.95, 1.70, 1.72, 0.660, 0.600, 0.210, 0.190, None, None, set()),
    ("JPMORGAN CHASE & CO",      "US46625H1005", "10127090", "Ordinary", "Equity",           "Financials",             "US", "USD", 2.60, 2.55, 2.45, 2.44, 0.520, 0.500, 0.110, 0.100, None, None, set()),
    ("NESTLE SA",                "CH0038863350", "10127104", "Ordinary", "Equity",           "Consumer Staples",       "CH", "CHF", 2.40, 2.35, 2.10, 2.08, 0.310, 0.300, 0.090, 0.090, None, None, set()),
    ("LVMH MOET HENNESSY",       "FR0000121014", "10127118", "Ordinary", "Equity",           "Consumer Discretionary", "FR", "EUR", 1.50, 1.45, 1.30, 1.28, 0.360, 0.340, 0.100, 0.090, None, None, set()),
    ("HSBC HOLDINGS PLC",        "GB0005405286", "10127122", "Ordinary", "Equity",           "Financials",             "GB", "GBP", 1.90, 1.88, 1.75, 1.74, 0.380, 0.370, 0.080, 0.080, None, None, set()),
    ("TOYOTA MOTOR CORP",        "JP3633400001", "10127136", "Ordinary", "Equity",           "Consumer Discretionary", "JP", "JPY", 1.70, 1.68, 1.60, 1.59, 0.340, 0.330, 0.070, 0.070, None, None, set()),
    ("SIEMENS AG",               "DE0007236101", "10127140", "Ordinary", "Equity",           "Industrials",            "DE", "EUR", 1.60, 1.58, 1.45, 1.44, 0.290, 0.280, 0.060, 0.060, None, None, set()),
    ("RELIANCE INDUSTRIES LTD",  "INE002A01018", "10127154", "Ordinary", "Equity",           "Energy",                 "IN", "INR", 1.40, 1.38, 1.20, 1.19, 0.300, 0.290, 0.080, 0.080, None, None, set()),
    ("UNILEVER PLC",             "GB00B10RZP78", "10127168", "Ordinary", "Equity",           "Consumer Staples",       "GB", "GBP", 1.30, 1.29, 1.22, 1.21, 0.210, 0.208, 0.040, 0.040, None, None, set()),
    ("SHELL PLC",                "GB00BP6MXD84", "10127172", "Ordinary", "Equity",           "Energy",                 "GB", "GBP", 1.25, 1.24, 1.18, 1.17, 0.230, 0.226, 0.050, 0.049, None, None, set()),
    ("SAP SE",                   "DE0007164600", "10127186", "Ordinary", "Equity",           "Information Technology", "DE", "EUR", 1.10, 1.09, 1.02, 1.01, 0.190, 0.187, 0.030, 0.030, None, None, set()),
    ("AIA GROUP LTD",            "HK0000069689", "10127190", "Ordinary", "Equity",           "Financials",             "HK", "HKD", 0.95, 0.94, 0.88, 0.87, 0.150, 0.148, 0.030, 0.029, None, None, set()),
]

FIXED_INCOME = [
    ("US TREASURY 4.25% 2034",   "US91282CJL63", "20110210", "Ordinary", "Government Bond",  "Sovereign",              "US", "USD", 12.40, 9.80,  11.50, 11.60, 1.420, 1.010, 0.310, 0.240,  7.85, 7.62, set()),
    ("ITALY BTP 3.85% 2035",     "IT0005560948", "20110224", "Ordinary", "Government Bond",  "Sovereign",              "IT", "EUR",  4.20, 5.90,   3.80,  3.85, 0.760, 1.340, 0.290, 0.560,  8.10, 8.05, {"yc"}),
    ("VERIZON COMMS 4.5% 2033",  "US92343VGH85", "20110238", "Ordinary", "Corporate Bond",   "Communication Services", "US", "USD",  3.10, 3.05,   2.40,  2.40, 0.540, 0.680, 0.220, 0.310,  6.40, 6.32, {"yc", "rating"}),
    ("DEUTSCHE BANK 6.0% 2031",  "DE000DL19V52", "20110242", "Ordinary", "Corporate Bond",   "Financials",             "DE", "EUR",  2.20, 2.15,   1.10,  1.10, 0.610, 0.520, 0.340, 0.270,  5.20, 5.11, set()),
    ("UK GILT 4.0% 2038",        "GB00BQC4WK37", "20110256", "Ordinary", "Government Bond",  "Sovereign",              "GB", "GBP",  5.60, 5.55,   5.40,  5.38, 0.680, 0.665, 0.120, 0.118, 10.20, 10.05, set()),
    ("APPLE INC 3.85% 2032",     "US037833EK41", "20110260", "Ordinary", "Corporate Bond",   "Information Technology", "US", "USD",  2.80, None,   2.10,  2.12, 0.310, None,  0.090, None,   6.05, None, set()),
    ("PEMEX 6.75% 2032",         "US71654QDF67", "20110274", "Ordinary", "Corporate Bond",   "Energy",                 "MX", "USD",  None, 1.80,   None,  None, None,  0.720, None,  0.480,  None, 5.40, set()),
    ("US 10Y NOTE FUTURE SEP26", "",             "20110288", "Future",   "Rates Derivative", "Sovereign",              "US", "USD",  0.22, 0.35,   None,  None, 0.480, 0.760, 0.190, 0.320,  7.10, 7.05, set()),
    ("EUR IRS 5Y PAY FIXED",     "",             "20110292", "Swap",     "Rates Derivative", "Sovereign",              "DE", "EUR",  0.08, 0.07,   None,  None, 0.260, 0.240, 0.110, 0.100,  4.50, 4.42, {"vm"}),
    ("JAPAN JGB 1.4% 2034",      "JP1051341L38", "20110306", "Ordinary", "Government Bond",  "Sovereign",              "JP", "JPY",  4.10, 4.05,   4.00,  3.98, 0.220, 0.215, 0.040, 0.040,  8.90, 8.82, set()),
    ("BARCLAYS 7.125% 2031",     "XS2607103302", "20110310", "Ordinary", "Corporate Bond",   "Financials",             "GB", "GBP",  1.90, 1.88,   0.95,  0.95, 0.420, 0.405, 0.210, 0.200,  4.80, 4.71, set()),
    ("SPAIN SPGB 3.55% 2033",    "ES0000012M50", "20110324", "Ordinary", "Government Bond",  "Sovereign",              "ES", "EUR",  3.40, 3.36,   3.30,  3.28, 0.330, 0.322, 0.060, 0.059,  7.40, 7.31, set()),
    ("MICROSOFT 2.921% 2052",    "US594918BY97", "20110338", "Ordinary", "Corporate Bond",   "Information Technology", "US", "USD",  1.60, 1.58,   1.20,  1.19, 0.280, 0.272, 0.080, 0.078, 17.20, 17.05, set()),
    ("FRANCE OAT 3.0% 2034",     "FR001400ILK7", "20110342", "Ordinary", "Government Bond",  "Sovereign",              "FR", "EUR",  4.80, 4.75,   4.70,  4.68, 0.410, 0.402, 0.050, 0.049,  8.05, 7.96, set()),
    ("ENEL 4.5% 2032",           "XS2542163689", "20110356", "Ordinary", "Corporate Bond",   "Utilities",              "IT", "EUR",  1.40, 1.38,   0.90,  0.89, 0.240, 0.234, 0.090, 0.088,  6.20, 6.11, set()),
    ("CASH USD",                 "",             "20110360", "Cash",     "Cash",             "Cash",                   "US", "USD",  2.10, 3.20,   None,  None, 0.010, 0.012, 0.010, 0.014,  None, None, set()),
    ("KOREA KTB 3.25% 2033",     "KR103502GD37", "20110374", "Ordinary", "Government Bond",  "Sovereign",              "KR", "KRW",  1.20, 1.18,   1.10,  1.09, 0.180, 0.176, 0.040, 0.039,  7.60, 7.52, set()),
    ("AT&T INC 4.3% 2034",       "US00206RMG78", "20110388", "Ordinary", "Corporate Bond",   "Communication Services", "US", "USD",  1.30, 1.28,   0.85,  0.84, 0.260, 0.252, 0.100, 0.097,  7.10, 7.01, set()),
]

MA_DERIV_OVERRIDE = {"EUR IRS 5Y PAY FIXED": (0.09, 0.14, 1.40, 2.20, 1.40, 2.20, 1.40, 2.20)}

MULTI_ASSET = [
    ("NVIDIA CORP",              "US67066G1040", "30110649", "Ordinary", "Equity",           "Information Technology", "US", "USD", 2.40, 3.35, 1.95, 2.18, 0.920, 1.640, 0.310, 0.640, None, None, set()),
    ("US TREASURY 4.25% 2034",   "US91282CJL63", "30110210", "Ordinary", "Government Bond",  "Sovereign",              "US", "USD", 8.20, 6.10, 7.60, 7.65, 0.940, 0.630, 0.210, 0.160,  7.85, 7.62, set()),
    ("ISHARES CORE MSCI EM ETF", "IE00B4L5YC18", "30110711", "Fund",     "Equity Fund",      "Diversified",            "IE", "USD", 4.10, 5.80, None, None, 0.980, 1.510, 0.330, 0.560, None, None, {"dp"}),
    ("ITALY BTP 3.85% 2035",     "IT0005560948", "30110224", "Ordinary", "Government Bond",  "Sovereign",              "IT", "EUR", 2.60, 3.40, 2.30, 2.32, 0.470, 0.760, 0.180, 0.330,  8.10, 8.05, {"yc"}),
    ("GOLD ETC PHYSICAL",        "JE00B1VS3770", "30110800", "Fund",     "Commodity Fund",   "Diversified",            "JE", "USD", None, 2.90, None, None, None,  0.680, None,  0.450, None, None, set()),
    ("MSCI WORLD FUTURE SEP26",  "",             "30127074", "Future",   "Equity Derivative","Diversified",            "US", "USD", 0.31, 0.10, None, None, 0.740, 0.250, 0.250, 0.090, None, None, set()),
    ("BLACKROCK GLOBAL HY FUND", "LU0252968424", "30110900", "Fund",     "Credit Fund",      "Diversified",            "LU", "USD", 3.80, 3.75, None, None, 0.860, 0.840, 0.360, 0.350,  3.90, 3.84, set()),
    ("MICROSOFT CORP",           "US5949181045", "30126484", "Ordinary", "Equity",           "Information Technology", "US", "USD", 2.70, 2.66, 2.55, 2.52, 0.550, 0.540, 0.090, 0.088, None, None, set()),
    ("UK GILT 4.0% 2038",        "GB00BQC4WK37", "30110256", "Ordinary", "Government Bond",  "Sovereign",              "GB", "GBP", 3.10, 3.06, 2.98, 2.96, 0.380, 0.372, 0.070, 0.069, 10.20, 10.05, set()),
    ("VERIZON COMMS 4.5% 2033",  "US92343VGH85", "30110238", "Ordinary", "Corporate Bond",   "Communication Services", "US", "USD", 1.80, 1.77, 1.40, 1.39, 0.310, 0.390, 0.130, 0.180,  6.40, 6.32, {"yc"}),
    ("TENCENT HOLDINGS LTD",     "KYG875721634", "30126634", "Ordinary", "Equity",           "Communication Services", "CN", "HKD", 1.60, 1.57, 1.30, 1.29, 0.470, 0.440, 0.150, 0.140, None, None, set()),
    ("EUR IRS 5Y PAY FIXED",     "",             "30110292", "Swap",     "Rates Derivative", "Sovereign",              "DE", "EUR", 0.09, 0.14, None, None, 0.200, 0.340, 0.090, 0.150,  4.50, 4.42, set()),
    ("NESTLE SA",                "CH0038863350", "30127104", "Ordinary", "Equity",           "Consumer Staples",       "CH", "CHF", 1.50, 1.48, 1.32, 1.31, 0.190, 0.186, 0.050, 0.049, None, None, set()),
    ("APPLE INC 3.85% 2032",     "US037833EK41", "30110260", "Ordinary", "Corporate Bond",   "Information Technology", "US", "USD", 1.70, 1.67, 1.28, 1.27, 0.190, 0.185, 0.055, 0.054,  6.05, 5.97, set()),
    ("CASH USD",                 "",             "30110360", "Cash",     "Cash",             "Cash",                   "US", "USD", 1.90, 2.85, None, None, 0.008, 0.010, 0.008, 0.011,  None, None, set()),
    ("SHELL PLC",                "GB00BP6MXD84", "30127172", "Ordinary", "Equity",           "Energy",                 "GB", "GBP", 1.20, 1.18, 1.05, 1.04, 0.170, 0.166, 0.045, 0.044, None, None, set()),
    ("FRANCE OAT 3.0% 2034",     "FR001400ILK7", "30110342", "Ordinary", "Government Bond",  "Sovereign",              "FR", "EUR", 2.40, 2.37, 2.30, 2.29, 0.210, 0.205, 0.035, 0.034,  8.05, 7.96, set()),
    ("AIA GROUP LTD",            "HK0000069689", "30127190", "Ordinary", "Equity",           "Financials",             "HK", "HKD", 0.90, 0.89, 0.82, 0.81, 0.120, 0.117, 0.028, 0.027, None, None, set()),
]

# Fund NAV on the prior and current COB, in USD. Weights are normalised to 100 on each
# date, so NAV is what makes market values move - and a fund that grows shifts every
# weight without a single trade.
FUNDS = [
    ("EQ_GLOBAL", "Global Equity Fund",       "MSCI_ACWI",     "MSCI ACWI Index",             "GlobalEquityLocal(USD)",   EQUITY,       1_240_000_000, 1_304_800_000),
    ("FI_CORE",   "Core Fixed Income Fund",   "BBG_GLOBAL_AGG","Bloomberg Global Aggregate",  "GlobalBondsLocal(USD)",    FIXED_INCOME,   890_000_000,   852_600_000),
    ("MA_BAL",    "Balanced Multi Asset Fund","MA_60_40",      "60/40 Composite Benchmark",   "MultiAssetGlobal(USD)",    MULTI_ASSET,    610_000_000,   704_550_000),
]

CURVES = {"USD": "USD_SWAP", "EUR": "EUR_SWAP", "GBP": "GBP_SWAP", "JPY": "JPY_SWAP",
          "CHF": "CHF_SWAP", "HKD": "HKD_SWAP", "KRW": "KRW_SWAP", "INR": "INR_SWAP",
          "DKK": "DKK_SWAP", "MXN": "MXN_SWAP"}
DERIV = {'S&P 500 FUTURE SEP26': (0.15, 0.14, 1.2, 1.15, 1.2, 1.15, None, None), 'US 10Y NOTE FUTURE SEP26': (0.22, 0.35, 3.5, 9.6, 3.5, 9.6, None, None), 'EUR IRS 5Y PAY FIXED': (0.08, 0.07, 1.8, 1.75, 1.8, 1.75, 1.8, 1.75), 'MSCI WORLD FUTURE SEP26': (0.31, 0.1, 3.2, 1.1, 3.2, 1.1, None, None)}

RATINGS = {"Government Bond": ("Aa1", "AA+", "AA+"), "Corporate Bond": ("Baa2", "BBB", "BBB"),
           "Credit Fund": ("Ba1", "BB+", "BB+")}


SP_SCALE = {"AAA": 1, "AA+": 2, "AA": 3, "AA-": 4, "A+": 5, "A": 6, "A-": 7,
            "BBB+": 8, "BBB": 9, "BBB-": 10, "BB+": 11, "BB": 12, "BB-": 13,
            "B+": 14, "B": 15, "B-": 16, "CCC+": 17, "CCC": 18, "CCC-": 19,
            "CC": 20, "C": 21, "D": 22}
MDY_SCALE = {"Aaa": 1, "Aa1": 2, "Aa2": 3, "Aa3": 4, "A1": 5, "A2": 6, "A3": 7,
             "Baa1": 8, "Baa2": 9, "Baa3": 10, "Ba1": 11, "Ba2": 12, "Ba3": 13,
             "B1": 14, "B2": 15, "B3": 16, "Caa1": 17, "Caa2": 18, "Caa3": 19, "Ca": 20}


def notch(mdy, sp):
    vals = [v for v in (MDY_SCALE.get(mdy), SP_SCALE.get(sp)) if v]
    return max(vals) if vals else None


def z(v):
    return 0.0 if v is None else v


def flag(c, p, changed):
    if c is None or p is None:
        return "N/A"
    return "Y" if changed else "N"


def build_fund(code, name, bm_code, bm_name, model, secs, nav_p, nav_c):  # noqa: C901
    # Real portfolio weights sum to 100 on each date. Normalise both sides so the
    # weight-completeness gate stays clean on the dummy data. Notional weights are
    # exposure over NAV and are left alone.
    def _scale(idx):
        tot = sum(s[idx] for s in secs if s[idx] is not None)
        return 100.0 / tot if tot else 1.0

    smw_p, smw_c, sbm_p, sbm_c = _scale(8), _scale(9), _scale(10), _scale(11)
    secs = [
        s[:8] + (
            None if s[8] is None else round(s[8] * smw_p, 3),
            None if s[9] is None else round(s[9] * smw_c, 3),
            None if s[10] is None else round(s[10] * sbm_p, 3),
            None if s[11] is None else round(s[11] * sbm_c, 3),
        ) + s[12:]
        for s in secs
    ]
    rows = []
    pf_vol_c = sum(z(s[13]) for s in secs)
    pf_vol_p = sum(z(s[12]) for s in secs)
    pf_te_c = sum(z(s[15]) for s in secs)
    pf_te_p = sum(z(s[14]) for s in secs)
    n_c = sum(1 for s in secs if s[13] is not None)
    n_p = sum(1 for s in secs if s[12] is not None)
    n_new = sum(1 for s in secs if s[9] is not None and s[8] is None)
    n_exit = sum(1 for s in secs if s[9] is None and s[8] is not None)

    for (sname, isin, seccode, line, aclass, sector, ctry, ccy,
         mw_p, mw_c, bm_p, bm_c, pv_p, pv_c, te_p, te_c, ed_p, ed_c, flags) in secs:

        chg_pv = z(pv_c) - z(pv_p)
        chg_mw = z(mw_c) - z(mw_p)
        status = ("NEW" if mw_c is not None and mw_p is None else
                  "EXITED" if mw_c is None and mw_p is not None else "HELD")
        share_c = pv_c / pf_vol_c if pv_c is not None and pf_vol_c else None
        share_p = pv_p / pf_vol_p if pv_p is not None and pf_vol_p else None

        f_yc = flag(pv_c, pv_p, "yc" in flags)
        f_md = flag(pv_c, pv_p, "md" in flags)
        f_mt = flag(pv_c, pv_p, "mt" in flags)
        f_dp = flag(pv_c, pv_p, "dp" in flags)
        f_rating = flag(pv_c, pv_p, "rating" in flags)
        any_model = "Y" if "Y" in (f_yc, f_md, f_mt, f_dp) else "N"   # VolatilityModel excluded

        mdy, sp_, fit = RATINGS.get(aclass, (None, None, None))
        mdy_p, sp_p_, fit_p = (mdy, sp_, fit)
        if "rating" in flags:
            mdy_p, sp_p_, fit_p = "Baa1", "BBB+", "BBB+"
        base = CURVES.get(ccy, "USD_SWAP")
        if "rating" in flags and "yc" in flags:
            # the downgrade re-mapped the security onto a wider curve: one linked event
            curve, curve_p = f"{base[:3]}_CORP_{sp_}", f"{base[:3]}_CORP_{sp_p_}"
        elif "yc" in flags:
            curve, curve_p = base, base.replace("_SWAP", "_GOVT")
        else:
            curve = curve_p = base

        sys_c = None if pv_c is None else round(pv_c * 0.86, 6)
        sys_p = None if pv_p is None else round(pv_p * 0.86, 6)
        spec_c = None if pv_c is None else round(pv_c - sys_c, 6)
        spec_p = None if pv_p is None else round(pv_p - sys_p, 6)
        syste_c = None if te_c is None else round(te_c * 0.78, 6)
        syste_p = None if te_p is None else round(te_p * 0.78, 6)

        dc_c = None if (mw_c is None or ed_c is None) else round(mw_c * ed_c, 6)
        dc_p = None if (mw_p is None or ed_p is None) else round(mw_p * ed_p, 6)
        spd_c = None if ed_c is None or aclass == "Government Bond" else round(ed_c * 0.95, 4)
        spd_p = None if ed_p is None or aclass == "Government Bond" else round(ed_p * 0.95, 4)
        sdc_c = None if (mw_c is None or spd_c is None) else round(mw_c * spd_c, 6)
        sdc_p = None if (mw_p is None or spd_p is None) else round(mw_p * spd_p, 6)
        rn_c, rn_p = notch(mdy, sp_), notch(mdy_p, sp_p_)
        rdir = ("N/A" if rn_c is None or rn_p is None else
                "DOWNGRADE" if rn_c > rn_p else "UPGRADE" if rn_c < rn_p else "UNCHANGED")
        rating_curve_linked = "Y" if (f_rating == "Y" and f_yc == "Y") else "N"

        is_deriv = (line in ("Future", "Swap", "Forward", "Option", "FX Forward", "CDS")
                    or "Derivative" in aclass)
        if is_deriv:
            d = MA_DERIV_OVERRIDE.get(sname) if code == "MA_BAL" else None
            d = d or DERIV[sname]
            nw_p, nw_c, nwb_p, nwb_c, nws_p, nws_c = d[2], d[3], d[4], d[5], d[6], d[7]
        else:
            nw_p, nw_c = mw_p, mw_c
            nwb_p = nwb_c = nws_p = nws_c = None
        ew_p, ew_c = (nw_p, nw_c) if is_deriv else (mw_p, mw_c)
        chg_ew = z(ew_c) - z(ew_p)
        rel = "n/a" if not pv_p else f"{chg_pv / pv_p * 100:+.1f}%"
        note = (
            f"{sname} ({isin or seccode}), {line}, {aclass}: contribution to portfolio vol "
            f"{z(pv_p):.4f}% -> {z(pv_c):.4f}% ({chg_pv:+.4f} pp, {rel} relative). "
            f"Contribution to tracking error {z(te_p)*100:.1f} bps -> {z(te_c)*100:.1f} bps "
            f"({(z(te_c)-z(te_p))*100:+.1f} bps). Fund weight {z(mw_p):.3f}% -> {z(mw_c):.3f}% "
            f"({chg_mw:+.3f} pp). Share of portfolio vol {(share_p or 0)*100:.2f}% -> "
            f"{(share_c or 0)*100:.2f}%. Accounts for "
            f"{(chg_pv/(pf_vol_c-pf_vol_p) if pf_vol_c != pf_vol_p else 0)*100:.1f}% of the "
            f"portfolio vol change. Status {status}. Model inputs changed: {any_model}. "
            f"Rating changed: {f_rating}. Yield curve changed: {f_yc}."
        )

        rows.append({
            "PortfolioCode": code, "PortfolioName": name,
            "BenchmarkCode": bm_code, "BenchmarkName": bm_name,
            "ValuationDate_Curr": COB_C.isoformat(), "ValuationDate_Prev": COB_P.isoformat(),
            "SecurityCode": seccode, "SecurityName": sname,
            "HoldingStatus": status,
            "DriverTag": (
                "NEW_POSITION" if status == "NEW" else
                "EXITED_POSITION" if status == "EXITED" else
                "IMMATERIAL" if abs(chg_pv) < 0.0001 else
                "RATING_DRIVEN_CURVE_CHANGE" if rating_curve_linked == "Y" else
                "ESTIMATION_WINDOW_CHANGED" if (f_dp == "Y" and f_yc == "N"
                                                and f_md == "N" and f_mt == "N") else
                "RATING_MIGRATION" if f_rating == "Y" else
                "MODEL_INPUT_CHANGED" if any_model == "Y" else
                "VOL_UP_ON_WEIGHT_UP" if chg_pv > 0 and chg_ew > 1e-6 else
                "VOL_UP_ON_RISK_UP" if chg_pv > 0 else
                "VOL_DOWN_ON_WEIGHT_DOWN" if chg_pv < 0 and chg_ew < -1e-6 else
                "VOL_DOWN_ON_RISK_DOWN"),
            "Rank_AbsChg_ContriB_PfVol": None, "Rank_ContriB_PfVol_Curr": None,
            "Rank_AbsChg_ContriB_TE": None,
            f"ContriB_PfVol_Pct_{SC}": pv_c, f"ContriB_PfVol_Pct_{SP}": pv_p,
            "Chg_ContriB_PfVol_PctPts": round(chg_pv, 6),
            "AbsChg_ContriB_PfVol_PctPts": round(abs(chg_pv), 6),
            "AbsChg_ContriB_TE_bps": round(abs((z(te_c) - z(te_p)) * 100), 2),
            "RelChg_ContriB_PfVol_Pct": (None if not pv_p else round(chg_pv / pv_p * 100, 4)),
            f"PctShare_PfVol_Pct_{SC}": None if share_c is None else round(share_c * 100, 4),
            f"PctShare_PfVol_Pct_{SP}": None if share_p is None else round(share_p * 100, 4),
            "Chg_PctShare_PfVol_PctPts": round((z(share_c) - z(share_p)) * 100, 4),
            "PctOfPortfolioVolChg_Pct": (round(chg_pv / (pf_vol_c - pf_vol_p) * 100, 4)
                                         if pf_vol_c != pf_vol_p else None),
            f"ContriB_SysPfVol_Pct_{SC}": sys_c, f"ContriB_SysPfVol_Pct_{SP}": sys_p,
            "Chg_ContriB_SysPfVol_PctPts": round(z(sys_c) - z(sys_p), 6),
            f"ContriB_SpecPfVol_Pct_{SC}": spec_c, f"ContriB_SpecPfVol_Pct_{SP}": spec_p,
            "Chg_ContriB_SpecPfVol_PctPts": round(z(spec_c) - z(spec_p), 6),
            # Benchmark-side volatility contribution, from the IsPortfolio = FALSE rows.
            # Scaled off benchmark weight so the fund and benchmark totals differ, which
            # is what makes the benchmark comparison worth reporting at all.
            f"ContriB_BmVol_Pct_{SC}": None if bm_c in (None, 0) else bm_c,
            f"ContriB_BmVol_Pct_{SP}": None if bm_p in (None, 0) else bm_p,
            "Chg_ContriB_BmVol_PctPts": 0.0,
            f"ContriB_TE_bps_{SC}": None if te_c is None else round(te_c * 100, 2),
            f"ContriB_TE_bps_{SP}": None if te_p is None else round(te_p * 100, 2),
            "Chg_ContriB_TE_bps": round((z(te_c) - z(te_p)) * 100, 2),
            "RelChg_ContriB_TE_Pct": (None if not te_p else round((z(te_c) - te_p) / te_p * 100, 4)),
            f"ContriB_SysTE_bps_{SC}": None if syste_c is None else round(syste_c * 100, 2),
            f"ContriB_SysTE_bps_{SP}": None if syste_p is None else round(syste_p * 100, 2),
            "Chg_ContriB_SysTE_bps": round((z(syste_c) - z(syste_p)) * 100, 2),
            f"ContriB_SpecTE_bps_{SC}": None if te_c is None else round((te_c - syste_c) * 100, 2),
            f"ContriB_SpecTE_bps_{SP}": None if te_p is None else round((te_p - syste_p) * 100, 2),
            "Chg_ContriB_SpecTE_bps": round(((z(te_c) - z(syste_c)) - (z(te_p) - z(syste_p))) * 100, 2),
            f"PortfolioVol_Pct_{SC}": round(pf_vol_c, 6), f"PortfolioVol_Pct_{SP}": round(pf_vol_p, 6),
            "Chg_PortfolioVol_PctPts": round(pf_vol_c - pf_vol_p, 6),
            "RelChg_PortfolioVol_Pct": round((pf_vol_c - pf_vol_p) / pf_vol_p * 100, 4),
            f"PortfolioTE_bps_{SC}": round(pf_te_c * 100, 2),
            f"PortfolioTE_bps_{SP}": round(pf_te_p * 100, 2),
            "Chg_PortfolioTE_bps": round((pf_te_c - pf_te_p) * 100, 2),
            "RelChg_PortfolioTE_Pct": round((pf_te_c - pf_te_p) / pf_te_p * 100, 4),
            f"SecurityCount_{SC}": n_c, f"SecurityCount_{SP}": n_p,
            "NewPositions_Portfolio": n_new, "ExitedPositions_Portfolio": n_exit,
            f"MarketWeight_Pf_Pct_{SC}": mw_c, f"MarketWeight_Pf_Pct_{SP}": mw_p,
            "Chg_MarketWeight_Pf_PctPts": round(chg_mw, 6),
            "RelChg_MarketWeight_Pf_Pct": (None if not mw_p else round(chg_mw / mw_p * 100, 4)),
            f"MarketWeight_Bm_Pct_{SC}": bm_c, f"MarketWeight_Bm_Pct_{SP}": bm_p,
            "Chg_MarketWeight_Bm_PctPts": round(z(bm_c) - z(bm_p), 6),
            f"ActiveWeight_Pct_{SC}": round(z(mw_c) - z(bm_c), 6),
            f"ActiveWeight_Pct_{SP}": round(z(mw_p) - z(bm_p), 6),
            "Chg_ActiveWeight_PctPts": round((z(mw_c) - z(bm_c)) - (z(mw_p) - z(bm_p)), 6),
            f"MarketValue_Pf_{SC}": None if mw_c is None else round(mw_c / 100 * nav_c, 2),
            f"MarketValue_Pf_{SP}": None if mw_p is None else round(mw_p / 100 * nav_p, 2),
            "Chg_MarketValue_Pf": round(z(mw_c) / 100 * nav_c - z(mw_p) / 100 * nav_p, 2),
            f"UserMarketValue_Pf_{SC}": None if mw_c is None else round(mw_c / 100 * nav_c, 2),
            f"UserMarketValue_Pf_{SP}": None if mw_p is None else round(mw_p / 100 * nav_p, 2),
            f"NotionalWeight_Pf_Pct_{SC}": nw_c, f"NotionalWeight_Pf_Pct_{SP}": nw_p,
            "Chg_NotionalWeight_Pf_PctPts": round(z(nw_c) - z(nw_p), 6),
            f"NotionalWeightBuy_Pct_{SC}": nwb_c, f"NotionalWeightBuy_Pct_{SP}": nwb_p,
            f"NotionalWeightSell_Pct_{SC}": nws_c, f"NotionalWeightSell_Pct_{SP}": nws_p,
            "ExposureBasis": "Notional" if is_deriv else "Market",
            "IsDerivative": "Y" if is_deriv else "N",
            f"ExposureWeight_Pct_{SC}": ew_c, f"ExposureWeight_Pct_{SP}": ew_p,
            "Chg_ExposureWeight_PctPts": round(chg_ew, 6),
            "RelChg_ExposureWeight_Pct": (None if not ew_p else round(chg_ew / ew_p * 100, 4)),
            f"EffectiveDuration_{SC}": ed_c, f"EffectiveDuration_{SP}": ed_p,
            "Chg_EffectiveDuration": (None if ed_c is None or ed_p is None
                                      else round(ed_c - ed_p, 6)),
            f"ModifiedDuration_{SC}": None if ed_c is None else round(ed_c * 0.98, 4),
            f"ModifiedDuration_{SP}": None if ed_p is None else round(ed_p * 0.98, 4),
            "Chg_ModifiedDuration": (None if ed_c is None or ed_p is None
                                     else round((ed_c - ed_p) * 0.98, 6)),
            f"EffectiveSpreadDuration_{SC}": (None if ed_c is None or aclass == "Government Bond"
                                              else round(ed_c * 0.95, 4)),
            f"EffectiveSpreadDuration_{SP}": (None if ed_p is None or aclass == "Government Bond"
                                              else round(ed_p * 0.95, 4)),
            "Chg_EffectiveSpreadDuration": (None if ed_c is None or ed_p is None
                                            or aclass == "Government Bond"
                                            else round((ed_c - ed_p) * 0.95, 6)),
            f"DurationContrib_{SC}": dc_c, f"DurationContrib_{SP}": dc_p,
            "Chg_DurationContrib": round(z(dc_c) - z(dc_p), 6),
            f"SpreadDurationContrib_{SC}": sdc_c, f"SpreadDurationContrib_{SP}": sdc_p,
            "Chg_SpreadDurationContrib": round(z(sdc_c) - z(sdc_p), 6),
            f"YieldCurve_{SC}": None if pv_c is None else curve,
            f"YieldCurve_{SP}": None if pv_p is None else curve_p,
            "YieldCurveChanged": f_yc,
            f"VolatilityModel_RefOnly_{SC}": None if pv_c is None else "EWMA_250",
            f"VolatilityModel_RefOnly_{SP}": None if pv_p is None else (
                "EWMA_500" if "vm" in flags else "EWMA_250"),
            f"ModelName_{SC}": None if pv_c is None else model,
            f"ModelName_{SP}": None if pv_p is None else model,
            "ModelNameChanged": flag(pv_c, pv_p, False),
            f"ModelDate_{SC}": None if pv_c is None else "2026-08-12",
            f"ModelDate_{SP}": None if pv_p is None else ("2026-07-31" if "md" in flags else "2026-08-12"),
            # One load per COB. Blank where the security is absent on that side.
            f"JobExecutionID_Pf_{SC}": None if pv_c is None else JOB_C,
            f"JobExecutionID_Pf_{SP}": None if pv_p is None else JOB_P,
            f"JobExecutionID_Bm_{SC}": None if bm_c in (None, 0) else JOB_C,
            f"JobExecutionID_Bm_{SP}": None if bm_p in (None, 0) else JOB_P,
            "ModelDateChanged": f_md,
            f"ModelLagDays_{SC}": None if pv_c is None else 12,
            f"ModelLagDays_{SP}": None if pv_p is None else (12 if "md" in flags else 0),
            "Chg_ModelLagDays": None if pv_c is None or pv_p is None else (0 if "md" in flags else 12),
            f"ModellyingTypeCode_{SC}": None if pv_c is None else ("Fund" if line == "Fund" else "Ordinary"),
            f"ModellyingTypeCode_{SP}": None if pv_p is None else (
                "Proxy" if "mt" in flags else ("Fund" if line == "Fund" else "Ordinary")),
            "ModellyingTypeCodeChanged": f_mt,
            f"UsedData_{SC}": None if pv_c is None else "Daily",
            f"UsedData_{SP}": None if pv_p is None else "Daily",
            "UsedDataChanged": flag(pv_c, pv_p, False),
            f"DataPoints_{SC}": None if pv_c is None else ("120" if "dp" in flags else "250"),
            f"DataPoints_{SP}": None if pv_p is None else "250",
            "DataPointsChanged": f_dp,
            "Chg_DataPoints": (None if pv_c is None or pv_p is None
                               else (120.0 if "dp" in flags else 250.0) - 250.0),
            "RelChg_DataPoints_Pct": (None if pv_c is None or pv_p is None
                                      else round(((120.0 if "dp" in flags else 250.0) / 250.0 - 1) * 100, 4)),
            f"IdType_{SC}": None if pv_c is None else ("ISIN" if isin else "INTERNAL"),
            f"IdType_{SP}": None if pv_p is None else ("ISIN" if isin else "INTERNAL"),
            "IdTypeChanged": flag(pv_c, pv_p, False),
            f"IdUsedInAnalytics_{SC}": None if pv_c is None else (isin or seccode),
            f"IdUsedInAnalytics_{SP}": None if pv_p is None else (isin or seccode),
            f"MissingAssetPercent_Pct_{SC}": None if pv_c is None else 0.0,
            f"MissingAssetPercent_Pct_{SP}": None if pv_p is None else 0.0,
            "Chg_MissingAssetPercent_PctPts": None if pv_c is None or pv_p is None else 0.0,
            "AnyModelInputChanged": any_model,
            "RatingDirection": rdir,
            "RatingNotchesDowngraded": (None if rn_c is None or rn_p is None else rn_c - rn_p),
            f"RatingNotch_{SC}": rn_c, f"RatingNotch_{SP}": rn_p,
            "RatingDrivenCurveChange": rating_curve_linked,
            f"MOODYS_{SC}": mdy, f"MOODYS_{SP}": mdy_p,
            f"SP_{SC}": sp_, f"SP_{SP}": sp_p_,
            f"FITCH_{SC}": fit, f"FITCH_{SP}": fit_p,
            "RatingChanged": f_rating,
            "SecurityType": aclass, "AssetClassification": aclass,
            "BorrowerClassificationName": sector if "Bond" in aclass else None,
            "SecuritySectorName": sector, "SecuritySectorChanged": flag(pv_c, pv_p, False),
            "Country_of_Risk": ctry, "CountryOfRiskChanged": flag(pv_c, pv_p, False),
            "APTIssuer": sname.split()[0], "APTCurrency": ccy, "Line": line,
            "BuyCurrency": ccy, "SellCurrency": None,
            "CompositionCode_Pf": code, "CompositionName_Pf": name,
            "CompositionCode_Bm": bm_code,
            "CommentaryNote": note,
        })

    # Benchmark volatility, scaled to sit just below the fund's own. Contributions were
    # seeded as raw benchmark weights above; this turns them into a total that reconciles.
    for suf, tgt in ((SC, pf_vol_c * 0.938), (SP, pf_vol_p * 0.961)):
        raw = sum(z(r[f"ContriB_BmVol_Pct_{suf}"]) for r in rows)
        k = tgt / raw if raw else 0
        for r in rows:
            v = r[f"ContriB_BmVol_Pct_{suf}"]
            r[f"ContriB_BmVol_Pct_{suf}"] = None if v is None else round(v * k, 6)
    for r in rows:
        r["Chg_ContriB_BmVol_PctPts"] = round(z(r[f"ContriB_BmVol_Pct_{SC}"])
                                              - z(r[f"ContriB_BmVol_Pct_{SP}"]), 6)

    rows.sort(key=lambda r: (-r["AbsChg_ContriB_PfVol_PctPts"], r["SecurityCode"]))
    by_curr = sorted(rows, key=lambda r: -z(r[f"ContriB_PfVol_Pct_{SC}"]))
    for i, r in enumerate(rows, 1):
        r["Rank_AbsChg_ContriB_PfVol"] = i
    for i, r in enumerate(sorted(rows, key=lambda r: (-r["AbsChg_ContriB_TE_bps"], r["SecurityCode"])), 1):
        r["Rank_AbsChg_ContriB_TE"] = i
    for i, r in enumerate(by_curr, 1):
        r["Rank_ContriB_PfVol_Curr"] = i
    for i, r in enumerate(sorted(rows, key=lambda r: -z(r[f"ContriB_PfVol_Pct_{SP}"])), 1):
        r["Rank_ContriB_PfVol_Prev"] = i
    return rows


def _wavg(rows, contrib_col, wt_col, level_col):
    num = sum(z(r[contrib_col]) for r in rows)
    den = sum(z(r[wt_col]) for r in rows if r[level_col] is not None)
    return round(num / den, 4) if den else None


def summary_row(code, rows):
    r0 = rows[0]
    vol_c, vol_p = r0[f"PortfolioVol_Pct_{SC}"], r0[f"PortfolioVol_Pct_{SP}"]
    te_c, te_p = r0[f"PortfolioTE_bps_{SC}"], r0[f"PortfolioTE_bps_{SP}"]
    # Benchmark volatility is the sum of ContriB_BmVol over the benchmark-side rows.
    bmvol_c = sum(z(r[f"ContriB_BmVol_Pct_{SC}"]) for r in rows)
    bmvol_p = sum(z(r[f"ContriB_BmVol_Pct_{SP}"]) for r in rows)
    sum_chg = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in rows), 6)
    held = [r for r in rows if r["HoldingStatus"] == "HELD"]
    new_ = [r for r in rows if r["HoldingStatus"] == "NEW"]
    ext = [r for r in rows if r["HoldingStatus"] == "EXITED"]
    mdl = [r for r in rows if r["AnyModelInputChanged"] == "Y"]
    top = sorted(rows, key=lambda r: -z(r[f"ContriB_PfVol_Pct_{SC}"]))[:3]
    up = [r for r in sorted(rows, key=lambda r: -r["Chg_ContriB_PfVol_PctPts"])
          if r["Chg_ContriB_PfVol_PctPts"] > 0][:3]
    dn = [r for r in sorted(rows, key=lambda r: r["Chg_ContriB_PfVol_PctPts"])
          if r["Chg_ContriB_PfVol_PctPts"] < 0][:3]
    chg_mdl = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in mdl), 6)
    chg_held = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in held), 6)
    chg_new = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in new_), 6)
    chg_ext = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in ext), 6)
    dur_c = sum(z(r[f"DurationContrib_{SC}"]) for r in rows)
    dur_p = sum(z(r[f"DurationContrib_{SP}"]) for r in rows)
    wdur_c = dur_c / sum(z(r[f"MarketWeight_Pf_Pct_{SC}"]) for r in rows
                         if r[f"EffectiveDuration_{SC}"] is not None) if dur_c else None
    wdur_p = dur_p / sum(z(r[f"MarketWeight_Pf_Pct_{SP}"]) for r in rows
                         if r[f"EffectiveDuration_{SP}"] is not None) if dur_p else None
    rel_vol = (vol_c - vol_p) / vol_p * 100
    rel_te = (te_c - te_p) / te_p * 100
    return {
        "PortfolioCode": code, "PortfolioName": r0["PortfolioName"],
        "BenchmarkCode": r0["BenchmarkCode"],
        "ValuationDate_Curr": COB_C.isoformat(), "ValuationDate_Prev": COB_P.isoformat(),
        f"PortfolioVol_Pct_{SC}": vol_c, f"PortfolioVol_Pct_{SP}": vol_p,
        "Chg_PortfolioVol_PctPts": round(vol_c - vol_p, 6),
        "RelChg_PortfolioVol_Pct": round(rel_vol, 4),
        f"SystematicVol_Pct_{SC}": round(sum(z(r[f"ContriB_SysPfVol_Pct_{SC}"]) for r in rows), 6),
        f"SystematicVol_Pct_{SP}": round(sum(z(r[f"ContriB_SysPfVol_Pct_{SP}"]) for r in rows), 6),
        "Chg_SystematicVol_PctPts": round(sum(r["Chg_ContriB_SysPfVol_PctPts"] for r in rows), 6),
        f"SpecificVol_Pct_{SC}": round(sum(z(r[f"ContriB_SpecPfVol_Pct_{SC}"]) for r in rows), 6),
        f"SpecificVol_Pct_{SP}": round(sum(z(r[f"ContriB_SpecPfVol_Pct_{SP}"]) for r in rows), 6),
        "Chg_SpecificVol_PctPts": round(sum(r["Chg_ContriB_SpecPfVol_PctPts"] for r in rows), 6),
        f"PortfolioTE_bps_{SC}": te_c, f"PortfolioTE_bps_{SP}": te_p,
        "Chg_PortfolioTE_bps": round(te_c - te_p, 2),
        "RelChg_PortfolioTE_Pct": round(rel_te, 4),

        # ---------- benchmark side (IsPortfolio = FALSE rows) ----------
        f"BenchmarkVol_Pct_{SC}": round(bmvol_c, 6),
        f"BenchmarkVol_Pct_{SP}": round(bmvol_p, 6),
        "Chg_BenchmarkVol_PctPts": round(bmvol_c - bmvol_p, 6),
        "RelChg_BenchmarkVol_Pct": round((bmvol_c - bmvol_p) / bmvol_p * 100, 4) if bmvol_p else None,
        f"SumBenchmarkWeight_Pct_{SC}": round(sum(z(r[f"MarketWeight_Bm_Pct_{SC}"]) for r in rows), 3),
        f"SumBenchmarkWeight_Pct_{SP}": round(sum(z(r[f"MarketWeight_Bm_Pct_{SP}"]) for r in rows), 3),
        f"BenchmarkSecurityCount_{SC}": sum(1 for r in rows if z(r[f"MarketWeight_Bm_Pct_{SC}"])),
        "Recon_SumOfSecurityChanges_PctPts": sum_chg,
        "Recon_Diff_PctPts": round((vol_c - vol_p) - sum_chg, 9),
        "Recon_Verdict": "PASS" if abs((vol_c - vol_p) - sum_chg) < 1e-6 else "FAIL",
        "VolChg_From_HeldPositions_PctPts": chg_held,
        "VolChg_From_NewPositions_PctPts": chg_new,
        "VolChg_From_ExitedPositions_PctPts": chg_ext,
        "VolChg_From_ModelInputChanges_PctPts": chg_mdl,
        "PctOfVolChg_From_ModelInputChanges_Pct": round(chg_mdl / (vol_c - vol_p) * 100, 4),
        f"FundMarketValue_{SC}": round(sum(z(r[f"MarketValue_Pf_{SC}"]) for r in rows), 2),
        f"FundMarketValue_{SP}": round(sum(z(r[f"MarketValue_Pf_{SP}"]) for r in rows), 2),
        "RelChg_FundMarketValue_Pct": round(
            (sum(z(r[f"MarketValue_Pf_{SC}"]) for r in rows)
             / sum(z(r[f"MarketValue_Pf_{SP}"]) for r in rows) - 1) * 100, 4),
        f"BenchmarkCode_{SC}": r0["BenchmarkCode"], f"BenchmarkCode_{SP}": r0["BenchmarkCode"],
        "BenchmarkChanged": "N",
        f"Top5ShareOfVol_Pct_{SC}": round(
            sum(z(r[f"ContriB_PfVol_Pct_{SC}"]) for r in
                sorted(rows, key=lambda r: -z(r[f"ContriB_PfVol_Pct_{SC}"]))[:5]) / vol_c * 100, 4),
        f"Top5ShareOfVol_Pct_{SP}": round(
            sum(z(r[f"ContriB_PfVol_Pct_{SP}"]) for r in
                sorted(rows, key=lambda r: -z(r[f"ContriB_PfVol_Pct_{SP}"]))[:5]) / vol_p * 100, 4),
        "Chg_Top5ShareOfVol_PctPts": None,   # filled below
        "Turnover_ExposureWeight_PctPts": round(
            sum(abs(r["Chg_ExposureWeight_PctPts"]) for r in rows) / 2, 4),
        "ShortOrNegativePositions": sum(
            1 for r in rows if z(r[f"ExposureWeight_Pct_{SC}"]) < 0
            or z(r[f"ExposureWeight_Pct_{SP}"]) < 0),
        f"SumNotionalWeight_Pct_{SC}": round(sum(z(r[f"NotionalWeight_Pf_Pct_{SC}"]) for r in rows), 4),
        f"SumNotionalWeight_Pct_{SP}": round(sum(z(r[f"NotionalWeight_Pf_Pct_{SP}"]) for r in rows), 4),
        f"SumExposureWeight_Pct_{SC}": round(sum(z(r[f"ExposureWeight_Pct_{SC}"]) for r in rows), 4),
        f"SumExposureWeight_Pct_{SP}": round(sum(z(r[f"ExposureWeight_Pct_{SP}"]) for r in rows), 4),
        "Chg_SumExposureWeight_PctPts": round(
            sum(z(r[f"ExposureWeight_Pct_{SC}"]) - z(r[f"ExposureWeight_Pct_{SP}"]) for r in rows), 4),
        f"DerivativePositions_{SC}": sum(1 for r in rows if r["IsDerivative"] == "Y"),
        "VolChg_From_Derivatives_PctPts": round(
            sum(r["Chg_ContriB_PfVol_PctPts"] for r in rows if r["IsDerivative"] == "Y"), 6),
        f"MaxMissingAssetPercent_Pct_{SC}": 0.0, f"MaxMissingAssetPercent_Pct_{SP}": 0.0,
        "SecuritiesDowngraded": sum(1 for r in rows if r["RatingDirection"] == "DOWNGRADE"),
        "SecuritiesUpgraded": sum(1 for r in rows if r["RatingDirection"] == "UPGRADE"),
        "SecuritiesWithRatingDrivenCurveChange": sum(
            1 for r in rows if r["RatingDrivenCurveChange"] == "Y"),
        "VolChg_From_RatingDrivenCurveChange_PctPts": round(sum(
            r["Chg_ContriB_PfVol_PctPts"] for r in rows
            if r["RatingDrivenCurveChange"] == "Y"), 6),
        "SecuritiesWithEstimationWindowChange": sum(
            1 for r in rows if r["DataPointsChanged"] == "Y"),
        "VolChg_From_EstimationWindowChange_PctPts": round(sum(
            r["Chg_ContriB_PfVol_PctPts"] for r in rows if r["DataPointsChanged"] == "Y"), 6),
        f"WavgSpreadDuration_{SC}": _wavg(rows, f"SpreadDurationContrib_{SC}",
                                          f"ExposureWeight_Pct_{SC}", f"EffectiveSpreadDuration_{SC}"),
        f"WavgSpreadDuration_{SP}": _wavg(rows, f"SpreadDurationContrib_{SP}",
                                          f"ExposureWeight_Pct_{SP}", f"EffectiveSpreadDuration_{SP}"),
        "Chg_WavgSpreadDuration": None,   # filled below
        f"CurrencyCount_{SC}": len({r["APTCurrency"] for r in rows}),
        f"SecurityCount_{SC}": r0[f"SecurityCount_{SC}"],
        f"SecurityCount_{SP}": r0[f"SecurityCount_{SP}"],
        "HeldPositions": len(held), "NewPositions": len(new_), "ExitedPositions": len(ext),
        f"JobExecutionID_{SC}": JOB_C, f"JobExecutionID_{SP}": JOB_P,
        f"ModelDate_{SC}": "2026-08-12", f"ModelDate_{SP}": "2026-08-12",
        f"ModelLagDays_{SC}": 12, f"ModelLagDays_{SP}": 0,
        "SecuritiesWithModelInputChange": len(mdl),
        "SecuritiesWithYieldCurveChange": sum(1 for r in rows if r["YieldCurveChanged"] == "Y"),
        "SecuritiesWithModelDateChange": sum(1 for r in rows if r["ModelDateChanged"] == "Y"),
        f"SumMarketWeight_Pct_{SC}": round(sum(z(r[f"MarketWeight_Pf_Pct_{SC}"]) for r in rows), 4),
        f"SumMarketWeight_Pct_{SP}": round(sum(z(r[f"MarketWeight_Pf_Pct_{SP}"]) for r in rows), 4),
        f"WavgEffectiveDuration_{SC}": None if not wdur_c else round(wdur_c, 4),
        f"WavgEffectiveDuration_{SP}": None if not wdur_p else round(wdur_p, 4),
        "Chg_WavgEffectiveDuration": (None if not (wdur_c and wdur_p) else round(wdur_c - wdur_p, 4)),
        "Top3_VolContributors_Curr": "; ".join(
            f"{r['SecurityName']} ({z(r[f'ContriB_PfVol_Pct_{SC}']):.4f}%)" for r in top),
        "Top3_VolIncreases": "; ".join(
            f"{r['SecurityName']} ({r['Chg_ContriB_PfVol_PctPts']:+.4f} pp)" for r in up),
        "Top3_VolDecreases": "; ".join(
            f"{r['SecurityName']} ({r['Chg_ContriB_PfVol_PctPts']:+.4f} pp)" for r in dn),
        "PortfolioCommentaryBrief": (
            f"Portfolio {code}: volatility moved from {vol_p:.4f}% to {vol_c:.4f}% "
            f"({vol_c - vol_p:+.4f} pp, {rel_vol:+.1f}% relative) between the two COB dates. "
            f"Tracking error moved from {te_p:.1f} bps to {te_c:.1f} bps "
            f"({te_c - te_p:+.1f} bps, {rel_te:+.1f}% relative). Held positions account for "
            f"{chg_held:+.4f} pp, new positions {chg_new:+.4f} pp, exits {chg_ext:+.4f} pp. "
            f"{len(mdl)} of {r0[f'SecurityCount_{SC}']} securities had a risk model input "
            f"change, contributing {chg_mdl:+.4f} pp "
            f"({chg_mdl/(vol_c-vol_p)*100:.1f}% of the total move) - treat that portion as "
            f"methodology, not market."),
    }


def _finish_summary(d):
    d["Chg_Top5ShareOfVol_PctPts"] = round(
        d[f"Top5ShareOfVol_Pct_{SC}"] - d[f"Top5ShareOfVol_Pct_{SP}"], 4)
    a, b = d[f"WavgSpreadDuration_{SC}"], d[f"WavgSpreadDuration_{SP}"]
    d["Chg_WavgSpreadDuration"] = None if a is None or b is None else round(a - b, 4)
    return d


def write_csv(path, rows, cols):
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="raise")
        w.writeheader()
        for r in rows:
            w.writerow({c: ("" if r.get(c) is None else r.get(c)) for c in cols})


def portfolio_row(code, rows, cols):
    """The fund row, aggregated from the security rows exactly as risk_drilldown.sql does.

    Mirroring the SQL here is the point: if the two ever diverge the assertion in main()
    fires, and the fixture stops being a valid stand-in for the real extract.
    """
    def z(v):
        return 0 if v in (None, "") else v

    ADD_PREFIX = ("ContriB_", "Chg_ContriB_", "MarketWeight_", "Chg_MarketWeight_",
                  "ActiveWeight_", "Chg_ActiveWeight_", "MarketValue_", "Chg_MarketValue_",
                  "UserMarketValue_", "NotionalWeight_", "Chg_NotionalWeight_",
                  "NotionalWeightBuy_", "NotionalWeightSell_", "ExposureWeight_",
                  "Chg_ExposureWeight_", "DurationContrib_", "Chg_DurationContrib",
                  "SpreadDurationContrib_", "Chg_SpreadDurationContrib")
    CARRY = {"PortfolioCode", "PortfolioName", "BenchmarkCode", "BenchmarkName",
             "ValuationDate_Curr", "ValuationDate_Prev", "CompositionCode_Bm",
             "ModelDate_Curr", "ModelDate_Prev", "ModelLagDays_Curr", "ModelLagDays_Prev",
             "Chg_ModelLagDays", "ModelName_Curr", "ModelName_Prev", "ModelNameChanged",
             "ModelDateChanged", "JobExecutionID_Pf_Curr", "JobExecutionID_Pf_Prev",
             "JobExecutionID_Bm_Curr", "JobExecutionID_Bm_Prev",
             "MissingAssetPercent_Pct_Curr", "MissingAssetPercent_Pct_Prev"}
    FUNDWIDE = ("PortfolioVol_", "Chg_PortfolioVol", "RelChg_PortfolioVol", "PortfolioTE_",
                "Chg_PortfolioTE", "RelChg_PortfolioTE", "SecurityCount_",
                "NewPositions_Portfolio", "ExitedPositions_Portfolio")
    WAVG = {"EffectiveDuration_Curr": "ExposureWeight_Pct_Curr",
            "EffectiveDuration_Prev": "ExposureWeight_Pct_Prev",
            "ModifiedDuration_Curr": "ExposureWeight_Pct_Curr",
            "ModifiedDuration_Prev": "ExposureWeight_Pct_Prev",
            "EffectiveSpreadDuration_Curr": "ExposureWeight_Pct_Curr",
            "EffectiveSpreadDuration_Prev": "ExposureWeight_Pct_Prev"}

    out = {c: None for c in cols}
    out["RowType"] = "PORTFOLIO"
    out["SecurityName"] = "PORTFOLIO TOTAL"
    out["Line"] = "ALL"
    out["AssetClassification"] = "ALL"
    for c in cols:
        if c in ("RowType", "SecurityName", "Line", "AssetClassification"):
            continue
        if c in CARRY or c.startswith(FUNDWIDE):
            out[c] = rows[0].get(c)
        elif c in WAVG:
            w = WAVG[c]
            num = sum(z(r.get(c)) * z(r.get(w)) for r in rows)
            den = sum(z(r.get(w)) for r in rows if r.get(c) not in (None, ""))
            out[c] = round(num / den, 6) if den else None
        elif c.startswith(ADD_PREFIX):
            vals = [r.get(c) for r in rows if r.get(c) not in (None, "")]
            out[c] = round(sum(vals), 6) if vals else None

    st = [r["HoldingStatus"] for r in rows]
    chg = lambda pred: round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in rows if pred(r)), 6)
    out["HeldPositions"] = st.count("HELD")
    out["NewPositions"] = st.count("NEW")
    out["ExitedPositions"] = st.count("EXITED")
    out["BenchmarkOnlyPositions"] = st.count("BENCHMARK_ONLY")
    out["VolChg_From_HeldPositions_PctPts"] = chg(lambda r: r["HoldingStatus"] == "HELD")
    out["VolChg_From_NewPositions_PctPts"] = chg(lambda r: r["HoldingStatus"] == "NEW")
    out["VolChg_From_ExitedPositions_PctPts"] = chg(lambda r: r["HoldingStatus"] == "EXITED")
    out["SecuritiesWithModelInputChange"] = sum(1 for r in rows if r["AnyModelInputChanged"] == "Y")
    out["VolChg_From_ModelInputChanges_PctPts"] = chg(lambda r: r["AnyModelInputChanged"] == "Y")
    out["SecuritiesDowngraded"] = sum(1 for r in rows if r["RatingDirection"] == "DOWNGRADE")
    out["SecuritiesUpgraded"] = sum(1 for r in rows if r["RatingDirection"] == "UPGRADE")
    out["SecuritiesWithRatingDrivenCurveChange"] = sum(1 for r in rows if r["RatingDrivenCurveChange"] == "Y")
    out["VolChg_From_RatingDrivenCurveChange_PctPts"] = chg(lambda r: r["RatingDrivenCurveChange"] == "Y")
    out["SecuritiesWithEstimationWindowChange"] = sum(1 for r in rows if r["DataPointsChanged"] == "Y")
    out["VolChg_From_EstimationWindowChange_PctPts"] = chg(lambda r: r["DataPointsChanged"] == "Y")
    out["SecuritiesWithYieldCurveChange"] = sum(1 for r in rows if r["YieldCurveChanged"] == "Y")
    out["DerivativePositions_Curr"] = sum(1 for r in rows if r["IsDerivative"] == "Y"
                                          and r.get("ExposureWeight_Pct_Curr") not in (None, ""))
    out["VolChg_From_Derivatives_PctPts"] = chg(lambda r: r["IsDerivative"] == "Y")
    out["CurrencyCount_Curr"] = len({r["APTCurrency"] for r in rows
                                     if r.get("ExposureWeight_Pct_Curr") not in (None, "")})
    out["Turnover_ExposureWeight_PctPts"] = round(
        sum(abs(z(r.get("Chg_ExposureWeight_PctPts"))) for r in rows) / 2, 6)
    out["ShortOrNegativePositions_Curr"] = sum(1 for r in rows if z(r.get("ExposureWeight_Pct_Curr")) < 0)
    out["BenchmarkChanged"] = "N"

    # ---- fund-level context, mirroring the port CTE ----
    out["Chg_SystematicVol_PctPts"] = round(sum(z(r["Chg_ContriB_SysPfVol_PctPts"]) for r in rows), 6)
    out["Chg_SpecificVol_PctPts"] = round(sum(z(r["Chg_ContriB_SpecPfVol_PctPts"]) for r in rows), 6)
    bvc = sum(z(r[f"ContriB_BmVol_Pct_{SC}"]) for r in rows)
    bvp = sum(z(r[f"ContriB_BmVol_Pct_{SP}"]) for r in rows)
    out["BenchmarkVol_Pct_Curr"] = round(bvc, 6)
    out["BenchmarkVol_Pct_Prev"] = round(bvp, 6)
    out["Chg_BenchmarkVol_PctPts"] = round(bvc - bvp, 6)
    out["RelChg_BenchmarkVol_Pct"] = round((bvc - bvp) / bvp * 100, 4) if bvp else None
    mvc = sum(z(r[f"MarketValue_Pf_{SC}"]) for r in rows)
    mvp = sum(z(r[f"MarketValue_Pf_{SP}"]) for r in rows)
    out["FundMarketValue_Curr"] = round(mvc, 2)
    out["FundMarketValue_Prev"] = round(mvp, 2)
    out["RelChg_FundMarketValue_Pct"] = round((mvc - mvp) / mvp * 100, 4) if mvp else None
    for suf, rk in ((SC, "Rank_ContriB_PfVol_Curr"), (SP, "Rank_ContriB_PfVol_Prev")):
        tot = sum(z(r[f"ContriB_PfVol_Pct_{suf}"]) for r in rows)
        top = sum(z(r[f"ContriB_PfVol_Pct_{suf}"]) for r in rows if (r[rk] or 999) <= 5)
        out[f"Top5ShareOfVol_Pct_{'Curr' if suf == SC else 'Prev'}"] = round(top / tot * 100, 4) if tot else None
    out["Chg_Top5ShareOfVol_PctPts"] = round(
        (out["Top5ShareOfVol_Pct_Curr"] or 0) - (out["Top5ShareOfVol_Pct_Prev"] or 0), 4)
    miss = [r[f"MissingAssetPercent_Pct_{SC}"] for r in rows if r.get(f"MissingAssetPercent_Pct_{SC}") not in (None, "")]
    out["MaxMissingAssetPercent_Pct_Curr"] = max(miss) if miss else None

    ssc = round(sum(r["Chg_ContriB_PfVol_PctPts"] for r in rows), 9)
    out["Recon_SumOfSecurityChanges_PctPts"] = ssc
    out["Recon_Diff_PctPts"] = round(ssc - rows[0]["Chg_PortfolioVol_PctPts"], 9)
    out["Recon_Verdict"] = "PASS" if abs(out["Recon_Diff_PctPts"]) < 1e-4 else "FAIL"
    return out


def main():
    cols = output_columns()
    allrows = []
    for code, name, bmc, bmn, model, secs, nav_p, nav_c in FUNDS:
        rows = build_fund(code, name, bmc, bmn, model, secs, nav_p, nav_c)
        for r in rows:
            r["RowType"] = "SECURITY"
            for c in cols:
                r.setdefault(c, None)
        missing = set(cols) - set(rows[0])
        extra = set(rows[0]) - set(cols)
        assert not missing, f"{code}: columns in SQL but not generated: {sorted(missing)}"
        assert not extra, f"{code}: columns generated but not in SQL: {sorted(extra)}"
        allrows.append(portfolio_row(code, rows, cols))
        allrows += rows

    d = HERE / f"dummy_extract_{FC}_vs_{FP}.csv"
    write_csv(d, allrows, cols)

    try:
        from openpyxl import Workbook
        wb = Workbook(); ws = wb.active; ws.title = "risk_drilldown"
        ws.append(cols)
        for r in allrows:
            ws.append([r.get(c) for c in cols])
        ws.freeze_panes = "A2"
        xl = HERE / f"dummy_extract_{FC}_vs_{FP}.xlsx"
        wb.save(xl); print(f"wrote {xl.name}")
    except ImportError:
        print("openpyxl not available - CSV only")

    detail = [r for r in allrows if r["RowType"] == "SECURITY"]
    summary = [r for r in allrows if r["RowType"] == "PORTFOLIO"]
    print(f"wrote {d.name}  ({len(summary)} PORTFOLIO + {len(detail)} SECURITY rows, "
          f"{len(cols)} columns)")
    print()
    for r in summary:
        print(f"  {r['PortfolioCode']:10s} vol {r[f'PortfolioVol_Pct_{SP}']:7.4f}% -> "
              f"{r[f'PortfolioVol_Pct_{SC}']:7.4f}% ({r['Chg_PortfolioVol_PctPts']:+.4f}%, "
              f"{r['RelChg_PortfolioVol_Pct']:+6.1f}%)   "
              f"TE {r[f'PortfolioTE_bps_{SP}']:6.1f} -> {r[f'PortfolioTE_bps_{SC}']:6.1f} bps "
              f"({r['Chg_PortfolioTE_bps']:+6.1f} bps, {r['RelChg_PortfolioTE_Pct']:+6.1f}%)   "
              f"Recon {r['Recon_Verdict']}")


if __name__ == "__main__":
    main()
