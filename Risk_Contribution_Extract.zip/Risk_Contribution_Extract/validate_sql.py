#!/usr/bin/env python3
"""
Structural check on the three .sql files. No bq CLI on this machine, so nothing is dry-run
against the server -- this catches what plain reading misses: unbalanced parens, unterminated
string literals, duplicate output aliases, leftovers from the old templated version, and
dated aliases that do not come in matched _Curr / _Prev pairs.

    python3 validate_sql.py [--quiet]

Semantics -- column existence, types, row grain, and whether the IsPortfolio side split is
what the queries assume -- are confirmed by running 00_preflight_checks.sql in the console.
"""

import argparse
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
TARGETS = ["00_preflight_checks.sql", "risk_drilldown.sql"]
DECLARED = ("cob_curr", "cob_prev", "portfolio_codes")


def format_arity(sql: str) -> list[str]:
    """FORMAT() placeholder count must equal its argument count, and string literals must be
    joined with `||`.

    BigQuery does NOT concatenate adjacent string literals the way Python does -- writing a
    multi-line template as `'a\n' 'b\n'` is a syntax error, and an easy habit to slip into.
    Neither fault is visible until the query is pasted into the console.
    """
    problems = []
    stripped = re.sub(r"--[^\n]*", "", sql)          # commas in comments would fake arguments

    def split_args(txt: str) -> list[str]:
        out, depth, buf, q = [], 0, [], None
        for ch in txt:
            if q:
                buf.append(ch)
                if ch == q:
                    q = None
                continue
            if ch in "'\"":
                q = ch
            elif ch in "([":
                depth += 1
            elif ch in ")]":
                if depth == 0:
                    if "".join(buf).strip():
                        out.append("".join(buf))
                    return out
                depth -= 1
            elif ch == "," and depth == 0:
                out.append("".join(buf)); buf = []; continue
            buf.append(ch)
        return out

    for m in re.finditer(r"\bFORMAT\(", stripped):
        args = split_args(stripped[m.end():])
        if not args:
            continue
        lits = re.findall(r"'((?:[^'\\]|\\.)*)'", args[0])
        if not lits:
            continue
        template = "".join(lits)
        n_ph = len(re.findall(r"%[-+ #0-9.*]*[a-zA-Z]", template.replace("%%", "")))
        n_arg = len(args) - 1
        if n_ph != n_arg:
            line = stripped[: m.start()].count("\n") + 1
            problems.append(f"FORMAT near line {line}: {n_ph} placeholders vs {n_arg} arguments")

    lines = sql.split("\n")
    for i, line in enumerate(lines[:-1]):
        body = re.sub(r"\s+--.*$", "", line.rstrip())
        if body.strip().startswith("'") and body.endswith("'") and lines[i + 1].strip().startswith("'"):
            problems.append(f"line {i + 1}: adjacent string literals with no `||` between them")
    return problems


def union_halves_align(sql: str) -> str | None:
    """Both halves of a UNION ALL must expose the same columns in the same order.

    `ranked` is `detail` with nine columns swapped out via `* EXCEPT(...)` and re-emitted, so
    its effective column list is detail-minus-those-nine plus the nine in their new order.
    Two bugs got through before this existed: a generated half missing 17 columns the other
    half selected without an AS alias, and multi-line expressions collapsing into fragments.
    Both are silent until BigQuery rejects the whole query.
    """
    if "port AS (" not in sql or "detail AS (" not in sql:
        return None
    lines = sql.split("\n")

    def span(starts_with: str, end_is: str):
        try:
            a = next(i for i, l in enumerate(lines) if l.startswith(starts_with))
            s = next(i for i in range(a, len(lines)) if lines[i].strip() == "SELECT")
            e = next(i for i in range(s + 1, len(lines))
                     if lines[i].strip() == end_is or lines[i].startswith(end_is))
        except StopIteration:
            return None
        return lines[s + 1: e]

    def parse(block) -> list[str]:
        if block is None:
            return []
        text, out, depth, buf = re.sub(r"--[^\n]*", "", "\n".join(block)), [], 0, []
        for ch in text:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth -= 1
            elif ch == "," and depth == 0:
                out.append("".join(buf)); buf = []; continue
            buf.append(ch)
        if "".join(buf).strip():
            out.append("".join(buf))
        names = []
        for item in out:
            item = " ".join(item.split())
            if not item:
                continue
            if item.startswith("* EXCEPT") or item == "*":
                names.append("*"); continue
            m = re.search(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)$", item)
            names.append(m.group(1) if m else item.split(".")[-1])
        return names

    detail = parse(span("detail AS (", "FROM final2"))
    ranked = parse(span("ranked AS (", "FROM ("))
    port = parse(span("port AS (", "FROM ranked"))
    if not detail or not port:
        return None
    if ranked:
        swapped = [c for c in ranked if c != "*"]
        left = [c for c in detail if c not in swapped] + swapped
    else:
        left = detail
    if left == port:
        return None
    if len(left) != len(port):
        return f"UNION halves differ in width: {len(left)} vs port {len(port)}"
    for i, (x, y) in enumerate(zip(left, port)):
        if x != y:
            return f"UNION halves diverge at column {i}: `{x}` vs port `{y}`"
    return "UNION halves differ"


def output_aliases(sql: str) -> list[str]:
    """Aliases of the outermost SELECT: the last bare `SELECT` line up to its `FROM`."""
    starts = list(re.finditer(r"(?m)^SELECT$", sql))
    if not starts:
        return []
    block = sql[starts[-1].end():]
    end = re.search(r"(?m)^FROM ", block)
    block = block[: end.start()] if end else block
    return re.findall(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*(?:--.*)?$", block, re.MULTILINE)


def check(path: pathlib.Path, quiet: bool) -> int:
    name = path.name
    sql = path.read_text()
    problems, notes = [], []

    # The old version templated its own column names. Nothing should reference that now.
    for ghost in ("EXECUTE IMMEDIATE stmt", "SET tpl", "{{C}}", "{{P}}"):
        if ghost in sql:
            problems.append(f"leftover from the templated version: {ghost}")
    for param in re.findall(r"@\w+", sql):
        problems.append(f"bound parameter {param} survives; there is no EXECUTE IMMEDIATE to supply it")

    depth = 0
    for ch in sql:
        depth += (ch == "(") - (ch == ")")
        if depth < 0:
            problems.append("unbalanced parentheses: closed more than opened")
            break
    if depth > 0:
        problems.append(f"unbalanced parentheses: {depth} left open")

    # Apostrophes inside -- comments are legal, and so is a single quote inside a
    # double-quoted string (BigQuery accepts both quote styles). Strip both before counting.
    stripped = re.sub(r'"[^"\n]*"', '""', re.sub(r"--[^\n]*", "", sql))
    if stripped.count("'") % 2:
        problems.append("odd number of single quotes - an unterminated string literal")

    # `... * 100AS Foo` -- a generated alias that lost its leading space. Parses as garbage
    # in BigQuery and is easy to miss by eye in a 900-line file.
    # trailing comma is optional -- the last column of a SELECT has none, and that is
    # exactly where a generated alias is most likely to lose its space.
    glued = re.findall(r"[)0-9]AS [A-Za-z_][A-Za-z0-9_]*\s*,?", sql)
    if glued:
        problems.append(f"{len(glued)} alias(es) with no space before AS, e.g. {glued[0].strip()}")

    for var in DECLARED:
        if not re.search(rf"DECLARE\s+{var}\b", sql):
            problems.append(f"missing DECLARE for {var}")
        elif not re.search(rf"(?<!DECLARE ){var}\b", sql.split("-- ====", 2)[-1]):
            notes.append(f"{var} is declared but never referenced")

    problems.extend(format_arity(sql))

    misaligned = union_halves_align(sql)
    if misaligned:
        problems.append(misaligned)

    aliases = output_aliases(sql)
    dupes = sorted({a for a in aliases if aliases.count(a) > 1})
    if dupes:
        problems.append(f"duplicate output aliases: {dupes}")

    curr = {a[:-5] for a in aliases if a.endswith("_Curr")}
    prev = {a[:-5] for a in aliases if a.endswith("_Prev")}
    if curr - prev:
        notes.append(f"_Curr aliases with no _Prev twin: {sorted(curr - prev)}")
    if prev - curr:
        notes.append(f"_Prev aliases with no _Curr twin: {sorted(prev - curr)}")

    print(f"\n=== {name} ===")
    print(f"  lines of SQL: {sql.count(chr(10))}")
    if aliases:
        print(f"  aliased output columns: {len(aliases)}  ({len(curr) + len(prev)} dated, "
              f"{len(aliases) - len(curr) - len(prev)} static)")
        if not quiet:
            print("  dated:  " + ", ".join(a for a in aliases if a.endswith(("_Curr", "_Prev"))))
            print("  static: " + ", ".join(a for a in aliases if not a.endswith(("_Curr", "_Prev"))))
    for n in notes:
        print(f"  NOTE: {n}")
    for p in problems:
        print(f"  FAIL: {p}")
    if not problems:
        print("  PASS: structural checks clean.")
    return len(problems)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true", help="omit the column listings")
    args = ap.parse_args()

    failures = sum(check(HERE / t, args.quiet) for t in TARGETS)

    print()
    if failures:
        print(f"{failures} structural problem(s) found.")
        return 1
    print("All files pass structural checks.")
    print("Semantics -- column existence, types, row grain, and the IsPortfolio side split --")
    print("are verified by running 00_preflight_checks.sql, then risk_drilldown.sql")
    print("and checking Recon_Verdict.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
