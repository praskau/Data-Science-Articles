#!/usr/bin/env python3
"""
Structural check on the three .sql files. No bq CLI on this machine, so nothing is dry-run
against the server -- this catches what plain reading misses: unbalanced parens, unterminated
string literals, duplicate output aliases, leftovers from the old templated version, and
dated aliases that do not come in matched _Curr / _Prev pairs.

    python3 validate_sql.py [--quiet]

Semantics -- column existence, types, row grain, and whether the IsPortfolio side split is
what the queries assume -- are confirmed by running 00_preflight_checks.sql in the console.
"""

import argparse
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
TARGETS = ["00_preflight_checks.sql", "risk_drilldown.sql"]
DECLARED = ("cob_curr", "cob_prev", "portfolio_codes")


def format_arity(sql: str) -> list[str]:
    """FORMAT() placeholder count must equal its argument count, and string literals must be
    joined with `||`.

    BigQuery does NOT concatenate adjacent string literals the way Python does -- writing a
    multi-line template as `'a\n' 'b\n'` is a syntax error, and an easy habit to slip into.
    Neither fault is visible until the query is pasted into the console.
    """
    problems = []
    stripped = re.sub(r"--[^\n]*", "", sql)          # commas in comments would fake arguments

    def split_args(txt: str) -> list[str]:
        out, depth, buf, q = [], 0, [], None
        for ch in txt:
            if q:
                buf.append(ch)
                if ch == q:
                    q = None
                continue
            if ch in "'\"":
                q = ch
            elif ch in "([":
                depth += 1
            elif ch in ")]":
                if depth == 0:
                    if "".join(buf).strip():
                        out.append("".join(buf))
                    return out
                depth -= 1
            elif ch == "," and depth == 0:
                out.append("".join(buf)); buf = []; continue
            buf.append(ch)
        return out

    for m in re.finditer(r"\bFORMAT\(", stripped):
        args = split_args(stripped[m.end():])
        if not args:
            continue
        lits = re.findall(r"'((?:[^'\\]|\\.)*)'", args[0])
        if not lits:
            continue
        template = "".join(lits)
        n_ph = len(re.findall(r"%[-+ #0-9.*]*[a-zA-Z]", template.replace("%%", "")))
        n_arg = len(args) - 1
        if n_ph != n_arg:
            line = stripped[: m.start()].count("\n") + 1
            problems.append(f"FORMAT near line {line}: {n_ph} placeholders vs {n_arg} arguments")

    lines = sql.split("\n")
    for i, line in enumerate(lines[:-1]):
        body = re.sub(r"\s+--.*$", "", line.rstrip())
        if body.strip().startswith("'") and body.endswith("'") and lines[i + 1].strip().startswith("'"):
            problems.append(f"line {i + 1}: adjacent string literals with no `||` between them")
    return problems


def union_halves_align(sql: str) -> str | None:
    """Both halves of a UNION ALL must expose the same columns in the same order.

    `ranked` is `detail` with nine columns swapped out via `* EXCEPT(...)` and re-emitted, so
    its effective column list is detail-minus-those-nine plus the nine in their new order.
    Two bugs got through before this existed: a generated half missing 17 columns the other
    half selected without an AS alias, and multi-line expressions collapsing into fragments.
    Both are silent until BigQuery rejects the whole query.
    """
    if "port AS (" not in sql or "detail AS (" not in sql:
        return None
    lines = sql.split("\n")

    def span(starts_with: str, end_is: str):
        try:
            a = next(i for i, l in enumerate(lines) if l.startswith(starts_with))
            s = next(i for i in range(a, len(lines)) if lines[i].strip() == "SELECT")
            e = next(i for i in range(s + 1, len(lines))
                     if lines[i].strip() == end_is or lines[i].startswith(end_is))
        except StopIteration:
            return None
        return lines[s + 1: e]

    def parse(block) -> list[str]:
        if block is None:
            return []
        text, out, depth, buf = re.sub(r"--[^\n]*", "", "\n".join(block)), [], 0, []
        for ch in text:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth -= 1
            elif ch == "," and depth == 0:
                out.append("".join(buf)); buf = []; continue
            buf.append(ch)
        if "".join(buf).strip():
            out.append("".join(buf))
        names = []
        for item in out:
            item = " ".join(item.split())
            if not item:
                continue
            if item.startswith("* EXCEPT") or item == "*":
                names.append("*"); continue
            m = re.search(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)$", item)
            names.append(m.group(1) if m else item.split(".")[-1])
        return names

    detail = parse(span("detail AS (", "FROM final2"))
    ranked = parse(span("ranked AS (", "FROM ("))
    port = parse(span("port AS (", "FROM ranked"))
    if not detail or not port:
        return None
    if ranked:
        swapped = [c for c in ranked if c != "*"]
        left = [c for c in detail if c not in swapped] + swapped
    else:
        left = detail
    if left == port:
        return None
    if len(left) != len(port):
        return f"UNION halves differ in width: {len(left)} vs port {len(port)}"
    for i, (x, y) in enumerate(zip(left, port)):
        if x != y:
            return f"UNION halves diverge at column {i}: `{x}` vs port `{y}`"
    return "UNION halves differ"



def cte_separators(sql: str) -> list[str]:
    """Every CTE but the last must be followed by a comma.

    A missing comma between two CTEs is a plain syntax error that nothing else here catches:
    parens stay balanced, quotes stay balanced, and both UNION halves still line up. It is
    also the single easiest thing to drop when a CTE is inserted or reordered.
    """
    problems = []
    lines = sql.split("\n")
    starts = [i for i, l in enumerate(lines)
              if re.match(r"^[A-Za-z_][A-Za-z0-9_]* AS \($", l)]
    for a, b in zip(starts, starts[1:]):
        # walk back from the next CTE over blank lines and comments
        j = b - 1
        while j > a and (not lines[j].strip() or lines[j].lstrip().startswith("--")):
            j -= 1
        if lines[j].strip() != "),":
            problems.append(
                f"CTE `{lines[a].split()[0]}` ends at line {j + 1} with "
                f"`{lines[j].strip()[:40]}` -- expected `),` before `{lines[b].split()[0]}`")
    return problems


def case_collisions(sql: str) -> list[str]:
    """BigQuery resolves column names case-INSENSITIVELY.

    `breadth` and `Breadth` are the same identifier, so selecting both -- or naming both in
    one SELECT * EXCEPT(...) list -- is a duplicate-name error, and any reference to either
    is ambiguous. Easy to introduce when a lower-case working column is re-emitted under a
    CamelCase output alias.
    """
    problems = []
    for m in re.finditer(r"\* EXCEPT\(([^)]*)\)", sql, re.DOTALL):
        names = [n.strip() for n in m.group(1).split(",") if n.strip()]
        seen = {}
        for n in names:
            seen.setdefault(n.lower(), []).append(n)
        for low, group in seen.items():
            if len(group) > 1:
                line = sql[: m.start()].count("\n") + 1
                problems.append(
                    f"EXCEPT list near line {line} names {group} -- BigQuery treats these as "
                    f"one column, so this is a duplicate and every reference is ambiguous")
    return problems


def float_partition(sql: str) -> list[str]:
    """FLOAT64 is not a groupable type, so it cannot appear in PARTITION BY or GROUP BY.

    SIGN() returns FLOAT64 when its argument is FLOAT64, so a direction column reads like an
    integer and behaves like a float. BigQuery rejects it only at run time, which is the
    worst place to find out. Wrap it in CAST(... AS INT64).
    """
    problems, floaty = [], set()
    for m in re.finditer(r"\bSIGN\(", sql):
        depth, i = 0, m.end() - 1
        while i < len(sql):                       # walk to the matching close paren
            depth += (sql[i] == "(") - (sql[i] == ")")
            if depth == 0:
                break
            i += 1
        tail = re.match(r"\)\s*AS\s+(\w+)", sql[i:])
        if not tail:
            continue
        # CAST(SIGN(...) AS INT64) parses as the same shape -- the alias would be INT64
        if tail.group(1).upper() in ("INT64", "INTEGER", "NUMERIC", "FLOAT64"):
            continue
        floaty.add(tail.group(1))
    for name in sorted(floaty):
        for m in re.finditer(rf"PARTITION BY[^)]*\b{re.escape(name)}\b", sql):
            line = sql[: m.start()].count("\n") + 1
            problems.append(
                f"line {line}: PARTITION BY uses `{name}`, which SIGN() makes FLOAT64 -- "
                f"FLOAT64 is not groupable in BigQuery. Wrap it in CAST(... AS INT64)")
    return problems



def cte_column_flow(sql: str) -> list[str]:
    """Every column a CTE reads must be produced by the CTE it reads from.

    BigQuery reports this only at run time, one name at a time, so a query with several gaps
    takes several round trips to fix. `JobExecutionID` reached production this way: `pivot`
    aggregated it into job_pf_c and its siblings while `typed` never selected it.

    Deliberately narrow -- it walks `typed` -> `pivot` only, where the select list is explicit
    on both sides. CTEs further down use `f.*` passthrough, which this cannot follow and
    should not guess at.
    """
    KEYWORDS = {
        "SELECT","FROM","MAX","MIN","SUM","IF","IFNULL","AS","AND","OR","NOT","NULL","CASE",
        "WHEN","THEN","ELSE","END","COUNT","COUNTIF","SAFE_CAST","SAFE_DIVIDE","CAST","INT64",
        "FLOAT64","STRING","DATE","BOOL","TRUE","FALSE","ANY_VALUE","ARRAY_AGG","ORDER","BY",
        "LIMIT","OFFSET","GROUP","IS","DISTINCT","STRUCT","NUMERIC","BIGNUMERIC","TIMESTAMP",
        "LOWER","UPPER","TRIM","CONCAT","COALESCE","SAFE_OFFSET","LOGICAL_OR","LOGICAL_AND",
        "ABS","ROUND","GREATEST","LEAST","DESC","ASC","NULLS","IGNORE","RESPECT","OVER",
        "PARTITION","NULLIF","DATE_DIFF","SIGN","ROW_NUMBER","RANK","FORMAT","REPLACE",
        "STRING_AGG","ARRAY_TO_STRING","ARRAY_LENGTH","UNBOUNDED","PRECEDING","CURRENT","ROW",
        "BETWEEN","EXCEPT",
    }
    lines = sql.split("\n")

    def body(name: str, ends_with: str):
        try:
            a = next(i for i, l in enumerate(lines) if l.startswith(f"{name} AS ("))
            b = next(i for i in range(a, len(lines)) if lines[i].strip().startswith(ends_with))
        except StopIteration:
            return None
        return re.sub(r"--.*", "", "\n".join(lines[a:b]))

    up, down = body("typed", "FROM dedup"), body("pivot", "FROM typed")
    if up is None or down is None:
        return []
    provided = set(re.findall(r"\bAS\s+([A-Za-z_]\w*)", up))
    for item in re.split(r",|\n", up):                 # bare passthrough columns
        if re.fullmatch(r"[A-Za-z_]\w*", item.strip()):
            provided.add(item.strip())
    used = {t for t in re.findall(r"\b([A-Za-z_]\w*)\b", down) if t.upper() not in KEYWORDS}
    known = provided | set(re.findall(r"\bAS\s+([A-Za-z_]\w*)", down)) \
            | set(re.findall(r"DECLARE\s+(\w+)", sql)) | {"typed", "pivot"}
    return [f"`pivot` reads {m}, which `typed` does not select" for m in sorted(used - known)]



def num_places(sql: str) -> list[str]:
    """Every decimal place asked of num() must have its own CASE arm.

    num() falls back to CAST(x AS STRING) for any place it does not handle, which silently
    drops the fixed decimals the whole document depends on -- 6.00 renders as 6, and the
    commentary is told to quote digits exactly as written. The fallback is not an error, so
    nothing else notices.
    """
    supported = {int(m) for m in re.findall(r"WHEN (\d+) THEN FORMAT", sql)}
    if not supported:
        return []
    body = re.sub(r"'(?:[^'\\]|\\.)*'", "''", re.sub(r"--.*", "", sql))
    used = {int(m) for m in re.findall(r"\bj?num\([^()]*?,\s*(\d+)\)", body)}
    gap = sorted(used - supported)
    return [f"num() is called with {n} decimal places but has no `WHEN {n}` arm -- "
            f"it will fall back to CAST and lose the fixed decimals" for n in gap]


def output_aliases(sql: str) -> list[str]:
    """Aliases of the outermost SELECT: the last bare `SELECT` line up to its `FROM`."""
    starts = list(re.finditer(r"(?m)^SELECT$", sql))
    if not starts:
        return []
    block = sql[starts[-1].end():]
    end = re.search(r"(?m)^FROM ", block)
    block = block[: end.start()] if end else block
    return re.findall(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*(?:--.*)?$", block, re.MULTILINE)


def check(path: pathlib.Path, quiet: bool) -> int:
    name = path.name
    sql = path.read_text()
    problems, notes = [], []

    # The old version templated its own column names. Nothing should reference that now.
    for ghost in ("EXECUTE IMMEDIATE stmt", "SET tpl", "{{C}}", "{{P}}"):
        if ghost in sql:
            problems.append(f"leftover from the templated version: {ghost}")
    for param in re.findall(r"@\w+", sql):
        problems.append(f"bound parameter {param} survives; there is no EXECUTE IMMEDIATE to supply it")

    depth = 0
    for ch in sql:
        depth += (ch == "(") - (ch == ")")
        if depth < 0:
            problems.append("unbalanced parentheses: closed more than opened")
            break
    if depth > 0:
        problems.append(f"unbalanced parentheses: {depth} left open")

    # Apostrophes inside -- comments are legal, and so is a single quote inside a
    # double-quoted string (BigQuery accepts both quote styles). Strip both before counting.
    stripped = re.sub(r'"[^"\n]*"', '""', re.sub(r"--[^\n]*", "", sql))
    if stripped.count("'") % 2:
        problems.append("odd number of single quotes - an unterminated string literal")

    # `... * 100AS Foo` -- a generated alias that lost its leading space. Parses as garbage
    # in BigQuery and is easy to miss by eye in a 900-line file.
    # trailing comma is optional -- the last column of a SELECT has none, and that is
    # exactly where a generated alias is most likely to lose its space.
    glued = re.findall(r"[)0-9]AS [A-Za-z_][A-Za-z0-9_]*\s*,?", sql)
    if glued:
        problems.append(f"{len(glued)} alias(es) with no space before AS, e.g. {glued[0].strip()}")

    for var in DECLARED:
        if not re.search(rf"DECLARE\s+{var}\b", sql):
            problems.append(f"missing DECLARE for {var}")
        elif not re.search(rf"(?<!DECLARE ){var}\b", sql.split("-- ====", 2)[-1]):
            notes.append(f"{var} is declared but never referenced")

    problems.extend(format_arity(sql))
    problems.extend(cte_separators(sql))
    problems.extend(case_collisions(sql))
    problems.extend(float_partition(sql))
    problems.extend(cte_column_flow(sql))
    problems.extend(num_places(sql))

    misaligned = union_halves_align(sql)
    if misaligned:
        problems.append(misaligned)

    aliases = output_aliases(sql)
    dupes = sorted({a for a in aliases if aliases.count(a) > 1})
    if dupes:
        problems.append(f"duplicate output aliases: {dupes}")

    curr = {a[:-5] for a in aliases if a.endswith("_Curr")}
    prev = {a[:-5] for a in aliases if a.endswith("_Prev")}
    if curr - prev:
        notes.append(f"_Curr aliases with no _Prev twin: {sorted(curr - prev)}")
    if prev - curr:
        notes.append(f"_Prev aliases with no _Curr twin: {sorted(prev - curr)}")

    print(f"\n=== {name} ===")
    print(f"  lines of SQL: {sql.count(chr(10))}")
    if aliases:
        print(f"  aliased output columns: {len(aliases)}  ({len(curr) + len(prev)} dated, "
              f"{len(aliases) - len(curr) - len(prev)} static)")
        if not quiet:
            print("  dated:  " + ", ".join(a for a in aliases if a.endswith(("_Curr", "_Prev"))))
            print("  static: " + ", ".join(a for a in aliases if not a.endswith(("_Curr", "_Prev"))))
    for n in notes:
        print(f"  NOTE: {n}")
    for p in problems:
        print(f"  FAIL: {p}")
    if not problems:
        print("  PASS: structural checks clean.")
    return len(problems)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true", help="omit the column listings")
    args = ap.parse_args()

    failures = sum(check(HERE / t, args.quiet) for t in TARGETS)

    print()
    if failures:
        print(f"{failures} structural problem(s) found.")
        return 1
    print("All files pass structural checks.")
    print("Semantics -- column existence, types, row grain, and the IsPortfolio side split --")
    print("are verified by running 00_preflight_checks.sql, then risk_drilldown.sql")
    print("and checking Recon_Verdict.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
