#!/usr/bin/env python3
"""
Materialise the templated .sql files the way BigQuery will, then check them structurally.

There is no bq CLI on this machine, so the EXECUTE IMMEDIATE bodies cannot be dry-run
against the server. This does the next best thing: it performs the same {{C}} / {{P}}
substitution each script performs at run time, writes the result out as plain readable
SQL, and runs the checks that templated SQL actually fails on -- stray placeholders,
unbalanced parens, unterminated literals, duplicate output aliases, and parameters
referenced but never supplied.

    python3 validate_sql.py [--curr 2026-08-24] [--prev 2026-08-12] [--quiet]

Structure only. Column existence and types are confirmed by running
00_preflight_checks.sql in the BigQuery console.
"""

import argparse
import pathlib
import re
import sys
from datetime import datetime

HERE = pathlib.Path(__file__).resolve().parent
TARGETS = ["risk_contribution_pairwise.sql", "01_portfolio_summary.sql"]


def extract_template(text: str, name: str) -> str:
    m = re.search(r'SET tpl = r"""(.*?)"""\s*;', text, re.DOTALL)
    if not m:
        sys.exit(f'FAIL [{name}]: could not locate the r"""..."""" template block.')
    return m.group(1)


def supplied_params(text: str) -> set[str]:
    m = re.search(r"EXECUTE IMMEDIATE stmt\s*(.*?);", text, re.DOTALL)
    return set(re.findall(r"\bAS\s+([a-z_]+)", m.group(1))) if m else set()


def output_aliases(sql: str, name: str) -> list[str]:
    """Aliases of the outermost SELECT: the last bare `SELECT` line up to its `FROM`."""
    starts = list(re.finditer(r"(?m)^SELECT$", sql))
    if not starts:
        sys.exit(f"FAIL [{name}]: could not locate the final SELECT block.")
    block = sql[starts[-1].end():]
    end = re.search(r"(?m)^FROM ", block)
    block = block[: end.start()] if end else block
    return re.findall(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*(?:--.*)?$", block, re.MULTILINE)


def check(path: pathlib.Path, s_curr: str, s_prev: str, quiet: bool) -> int:
    name = path.name
    src = path.read_text()
    sql = extract_template(src, name).replace("{{C}}", s_curr).replace("{{P}}", s_prev)
    out = HERE / f"_materialised_{path.stem}.sql"
    out.write_text(sql)

    problems, notes = [], []

    leftover = re.findall(r"\{\{[^}]*\}\}", sql)
    if leftover:
        problems.append(f"unsubstituted placeholders: {sorted(set(leftover))}")

    depth = 0
    for ch in sql:
        depth += (ch == "(") - (ch == ")")
        if depth < 0:
            problems.append("unbalanced parentheses: closed more than opened")
            break
    if depth > 0:
        problems.append(f"unbalanced parentheses: {depth} left open")

    # apostrophes inside -- comments are legal; strip comments before counting quotes
    if re.sub(r"--[^\n]*", "", sql).count("'") % 2:
        problems.append("odd number of single quotes - an unterminated string literal")

    aliases = output_aliases(sql, name)
    dupes = {a for a in aliases if aliases.count(a) > 1}
    if dupes:
        problems.append(f"duplicate output aliases: {sorted(dupes)}")

    used, supplied = set(re.findall(r"@([a-z_]+)", sql)), supplied_params(src)
    if used - supplied:
        problems.append(f"parameters used but not supplied: {sorted(used - supplied)}")
    if supplied - used:
        notes.append(f"parameters supplied but unused: {sorted(supplied - used)}")

    dated = [a for a in aliases if a.endswith(("_" + s_curr, "_" + s_prev))]
    static = [a for a in aliases if a not in dated]

    print(f"\n=== {name} ===")
    print(f"  materialised -> {out.name}")
    print(f"  aliased output columns: {len(aliases)}  ({len(dated)} dated, {len(static)} static)")
    print(f"  lines of SQL: {sql.count(chr(10))}")
    if not quiet:
        print("  dated:  " + ", ".join(dated))
        print("  static: " + ", ".join(static))
    for n in notes:
        print(f"  NOTE: {n}")
    for p in problems:
        print(f"  FAIL: {p}")
    if not problems:
        print("  PASS: structural checks clean.")
    return len(problems)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--curr", default="2026-08-24")
    ap.add_argument("--prev", default="2026-08-12")
    ap.add_argument("--quiet", action="store_true", help="omit the column listings")
    args = ap.parse_args()

    s_curr = datetime.strptime(args.curr, "%Y-%m-%d").strftime("%d%m%Y")
    s_prev = datetime.strptime(args.prev, "%Y-%m-%d").strftime("%d%m%Y")
    if s_curr == s_prev:
        sys.exit("FAIL: the two COB dates are identical; every dated alias would collide.")

    print(f"COB suffixes -> current {s_curr}   prior {s_prev}")
    failures = sum(check(HERE / t, s_curr, s_prev, args.quiet) for t in TARGETS)

    print()
    if failures:
        print(f"{failures} structural problem(s) found.")
        return 1
    print("All files pass structural checks.")
    print("Semantics (column existence, types, row grain) are verified by running")
    print("00_preflight_checks.sql, then 01_portfolio_summary.sql -> check Recon_Verdict.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
