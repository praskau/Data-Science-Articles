#!/usr/bin/env python3
"""
Structural check on the three .sql files. No bq CLI on this machine, so nothing is dry-run
against the server -- this catches what plain reading misses: unbalanced parens, unterminated
string literals, duplicate output aliases, leftovers from the old templated version, and
dated aliases that do not come in matched _Curr / _Prev pairs.

    python3 validate_sql.py [--quiet]

Semantics -- column existence, types, row grain, and whether the IsPortfolio side split is
what the queries assume -- are confirmed by running 00_preflight_checks.sql in the console.
"""

import argparse
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
TARGETS = ["00_preflight_checks.sql", "risk_contribution_pairwise.sql", "01_portfolio_summary.sql"]
DECLARED = ("cob_curr", "cob_prev", "portfolio_codes")


def output_aliases(sql: str) -> list[str]:
    """Aliases of the outermost SELECT: the last bare `SELECT` line up to its `FROM`."""
    starts = list(re.finditer(r"(?m)^SELECT$", sql))
    if not starts:
        return []
    block = sql[starts[-1].end():]
    end = re.search(r"(?m)^FROM ", block)
    block = block[: end.start()] if end else block
    return re.findall(r"\bAS ([A-Za-z_][A-Za-z0-9_]*)\s*,?\s*(?:--.*)?$", block, re.MULTILINE)


def check(path: pathlib.Path, quiet: bool) -> int:
    name = path.name
    sql = path.read_text()
    problems, notes = [], []

    # The old version templated its own column names. Nothing should reference that now.
    for ghost in ("EXECUTE IMMEDIATE stmt", "SET tpl", "{{C}}", "{{P}}"):
        if ghost in sql:
            problems.append(f"leftover from the templated version: {ghost}")
    for param in re.findall(r"@\w+", sql):
        problems.append(f"bound parameter {param} survives; there is no EXECUTE IMMEDIATE to supply it")

    depth = 0
    for ch in sql:
        depth += (ch == "(") - (ch == ")")
        if depth < 0:
            problems.append("unbalanced parentheses: closed more than opened")
            break
    if depth > 0:
        problems.append(f"unbalanced parentheses: {depth} left open")

    # apostrophes inside -- comments are legal; strip comments before counting quotes
    if re.sub(r"--[^\n]*", "", sql).count("'") % 2:
        problems.append("odd number of single quotes - an unterminated string literal")

    for var in DECLARED:
        if not re.search(rf"DECLARE\s+{var}\b", sql):
            problems.append(f"missing DECLARE for {var}")
        elif not re.search(rf"(?<!DECLARE ){var}\b", sql.split("-- ====", 2)[-1]):
            notes.append(f"{var} is declared but never referenced")

    aliases = output_aliases(sql)
    dupes = sorted({a for a in aliases if aliases.count(a) > 1})
    if dupes:
        problems.append(f"duplicate output aliases: {dupes}")

    curr = {a[:-5] for a in aliases if a.endswith("_Curr")}
    prev = {a[:-5] for a in aliases if a.endswith("_Prev")}
    if curr - prev:
        notes.append(f"_Curr aliases with no _Prev twin: {sorted(curr - prev)}")
    if prev - curr:
        notes.append(f"_Prev aliases with no _Curr twin: {sorted(prev - curr)}")

    print(f"\n=== {name} ===")
    print(f"  lines of SQL: {sql.count(chr(10))}")
    if aliases:
        print(f"  aliased output columns: {len(aliases)}  ({len(curr) + len(prev)} dated, "
              f"{len(aliases) - len(curr) - len(prev)} static)")
        if not quiet:
            print("  dated:  " + ", ".join(a for a in aliases if a.endswith(("_Curr", "_Prev"))))
            print("  static: " + ", ".join(a for a in aliases if not a.endswith(("_Curr", "_Prev"))))
    for n in notes:
        print(f"  NOTE: {n}")
    for p in problems:
        print(f"  FAIL: {p}")
    if not problems:
        print("  PASS: structural checks clean.")
    return len(problems)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true", help="omit the column listings")
    args = ap.parse_args()

    failures = sum(check(HERE / t, args.quiet) for t in TARGETS)

    print()
    if failures:
        print(f"{failures} structural problem(s) found.")
        return 1
    print("All files pass structural checks.")
    print("Semantics -- column existence, types, row grain, and the IsPortfolio side split --")
    print("are verified by running 00_preflight_checks.sql, then 01_portfolio_summary.sql")
    print("and checking Recon_Verdict.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
