-- =====================================================================================
-- 01_portfolio_summary.sql
--
-- One row per portfolio. Two jobs:
--
--   1. RECONCILIATION. Recon_Diff must be ~0. It proves that the per-security
--      Chg_ContriB_PfVol column in risk_contribution_pairwise.sql sums back to the
--      portfolio-level volatility change. If it does not, the detail CSV is not
--      additive and no attribution built on it can be trusted.
--
--   2. TOP-LEVEL CONTEXT for the AI commentary. The detail CSV says what each name did;
--      this says what the portfolio did, and crucially how much of the move came from
--      names whose MODEL INPUTS changed rather than from the market.
--
-- PLAIN SQL. No EXECUTE IMMEDIATE, no string templating. Dated columns end in _Curr or
-- _Prev; the dates themselves are carried in ValuationDate_Curr / ValuationDate_Prev.
--
-- IsPortfolio SEMANTICS
--   TRUE  -> the row describes the PORTFOLIO.  FALSE -> it describes the BENCHMARK.
--   Exception: ContriB_TE is COMMON to both sides and is summed across all rows.
--
-- Run with the same two dates and the same portfolio codes as the main query.
-- =====================================================================================

-- ================== EDIT THESE THREE LINES ==================
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
-- ============================================================

IF cob_curr = cob_prev THEN
  RAISE USING MESSAGE = 'cob_curr and cob_prev must differ.';
END IF;

WITH base AS (
  SELECT *
  FROM `hsbc-237274-amgrisk-prod.elmo.risk_contribution`
  WHERE ValuationDate IN (cob_curr, cob_prev)
    AND PortfolioCode IN UNNEST(portfolio_codes)
),
-- A COB can be loaded more than once. Take the LATEST LOAD AS A WHOLE -- not the latest
-- version of each row. Pick MAX(JobExecutionID) per ValuationDate x PortfolioCode and keep
-- only rows carrying that job id.
--
-- Row-level dedup is wrong here. If a re-run loads 48 of the 50 positions, picking the
-- latest row per security keeps the 48 corrected rows and silently carries the 2 stale rows
-- from the previous job. The result is a portfolio blended across two model vintages that
-- still sums to a plausible total and still reconciles -- the worst kind of wrong.
-- 00_preflight_checks.sql reports when the latest job is smaller than the one before it.
latest_job AS (
  SELECT ValuationDate, PortfolioCode, MAX(JobExecutionID) AS max_job
  FROM base
  GROUP BY ValuationDate, PortfolioCode
),
dedup AS (
  SELECT * EXCEPT(rn)
  FROM (
    SELECT
      b.*,
      -- Second net: the same job re-inserting an identical natural key.
      ROW_NUMBER() OVER (
        PARTITION BY b.ValuationDate, b.PortfolioCode, b.CompositionCode,
                     b.IsPortfolio, b.SecurityCode
        ORDER BY b.ImportDateTime DESC
      ) AS rn
    FROM base b
    JOIN latest_job l
      ON  b.ValuationDate  = l.ValuationDate
      AND b.PortfolioCode  = l.PortfolioCode
      AND b.JobExecutionID = l.max_job
  )
  WHERE rn = 1
),
typed AS (
  SELECT
    PortfolioCode, SecurityCode, SecurityName, PortfolioName, BenchmarkCode,
    (ValuationDate = cob_curr)     AS is_curr,
    IFNULL(IsPortfolio, TRUE) AS is_pf,
    JobExecutionID,
    ModelName, ModelDate, CurrentYieldCurve, UsedData, DataPoints, ModellyingTypeCode,
    MOODYS_L, SP_L, FITCH_L,
    SAFE_CAST(EffectiveSpreadDuration AS FLOAT64) AS spr_dur,
    NULLIF(GREATEST(
      IFNULL(CASE UPPER(TRIM(IFNULL(MOODYS_L, '')))
        WHEN 'AAA' THEN 1 WHEN 'AA1' THEN 2 WHEN 'AA2' THEN 3 WHEN 'AA3' THEN 4
        WHEN 'A1' THEN 5 WHEN 'A2' THEN 6 WHEN 'A3' THEN 7
        WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
        WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
        WHEN 'B1' THEN 14 WHEN 'B2' THEN 15 WHEN 'B3' THEN 16
        WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19 WHEN 'CA' THEN 20
        ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(SP_L, '')))
        WHEN 'AAA' THEN 1 WHEN 'AA+' THEN 2 WHEN 'AA' THEN 3 WHEN 'AA-' THEN 4
        WHEN 'A+' THEN 5 WHEN 'A' THEN 6 WHEN 'A-' THEN 7
        WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9 WHEN 'BBB-' THEN 10
        WHEN 'BB+' THEN 11 WHEN 'BB' THEN 12 WHEN 'BB-' THEN 13
        WHEN 'B+' THEN 14 WHEN 'B' THEN 15 WHEN 'B-' THEN 16
        WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
        WHEN 'CC' THEN 20 WHEN 'C' THEN 21 WHEN 'D' THEN 22 ELSE NULL END, 0)
    ), 0)                                         AS rating_notch,
    DATE_DIFF(ValuationDate, ModelDate, DAY)      AS model_lag_days,
    Line, AssetClassification,
    (UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                 'CDS', 'SWAPTION')
     OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%')  AS is_deriv,
    APTCurrency,
    SAFE_CAST(MarketValue       AS FLOAT64)       AS mkt_val,
    SAFE_CAST(MissingAssetPercent AS FLOAT64)     AS miss_pct,
    -- WEIGHT SCALE. MarketWeight and the notional weights are stored as FRACTIONS:
    -- a real run showed the portfolio side summing to 0.9295, i.e. 92.95%. The ContriB_*
    -- family is NOT on that scale -- those are already percentage points (0.27 means
    -- 0.27%). So weights are scaled by 100 here and contributions are left alone.
    -- 00_preflight_checks.sql reports the raw sums so this can be re-confirmed per fund.
    SAFE_CAST(MarketWeight      AS FLOAT64) * 100  AS mkt_wt,
    SAFE_CAST(NotionalWeight    AS FLOAT64) * 100  AS notl_wt,
    SAFE_CAST(EffectiveDuration AS FLOAT64)       AS eff_dur,
    SAFE_CAST(ContriB_PfVol     AS FLOAT64)       AS c_pfvol,
    SAFE_CAST(ContriB_BmVol     AS FLOAT64)       AS c_bmvol,
    SAFE_CAST(ContriB_SysPfVol  AS FLOAT64)       AS c_sys,
    SAFE_CAST(ContriB_SpecPfVol AS FLOAT64)       AS c_spec,
    SAFE_CAST(ContriB_TE        AS FLOAT64)       AS c_te
  FROM dedup
),

-- per security, so entries/exits and per-name model changes can be counted
sec AS (
  SELECT
    PortfolioCode,
    SecurityCode,
    COALESCE(MAX(IF(is_curr, SecurityName, NULL)), MAX(SecurityName))  AS SecurityName,
    MAX(IF(is_curr     AND is_pf, c_pfvol, NULL))                      AS pfvol_c,
    MAX(IF(NOT is_curr AND is_pf, c_pfvol, NULL))                      AS pfvol_p,
    MAX(IF(is_curr     AND is_pf, mkt_wt,  NULL))                      AS mw_c,
    MAX(IF(NOT is_curr AND is_pf, mkt_wt,  NULL))                      AS mw_p,
    MAX(IF(is_curr     AND is_pf, IF(is_deriv, notl_wt, mkt_wt), NULL)) AS ew_c,
    MAX(IF(NOT is_curr AND is_pf, IF(is_deriv, notl_wt, mkt_wt), NULL)) AS ew_p,
    MAX(IF(is_curr     AND is_pf, eff_dur, NULL))                      AS ed_c,
    MAX(IF(NOT is_curr AND is_pf, eff_dur, NULL))                      AS ed_p,
    MAX(IF(is_curr     AND is_pf, CurrentYieldCurve,  NULL))           AS yc_c,
    MAX(IF(NOT is_curr AND is_pf, CurrentYieldCurve,  NULL))           AS yc_p,
    MAX(IF(is_curr     AND is_pf, rating_notch,       NULL))           AS rn_c,
    MAX(IF(NOT is_curr AND is_pf, rating_notch,       NULL))           AS rn_p,
    MAX(IF(is_curr     AND is_pf, spr_dur,            NULL))           AS sd_c,
    MAX(IF(NOT is_curr AND is_pf, spr_dur,            NULL))           AS sd_p,
    MAX(IF(is_curr     AND is_pf, ModelName,          NULL))           AS mn_c,
    MAX(IF(NOT is_curr AND is_pf, ModelName,          NULL))           AS mn_p,
    MAX(IF(is_curr     AND is_pf, ModelDate,          NULL))           AS md_c,
    MAX(IF(NOT is_curr AND is_pf, ModelDate,          NULL))           AS md_p,
    MAX(IF(is_curr     AND is_pf, UsedData,           NULL))           AS ud_c,
    MAX(IF(NOT is_curr AND is_pf, UsedData,           NULL))           AS ud_p,
    MAX(IF(is_curr     AND is_pf, DataPoints,         NULL))           AS dp_c,
    MAX(IF(NOT is_curr AND is_pf, DataPoints,         NULL))           AS dp_p,
    MAX(IF(is_curr     AND is_pf, ModellyingTypeCode, NULL))           AS mt_c,
    MAX(IF(NOT is_curr AND is_pf, ModellyingTypeCode, NULL))           AS mt_p
  FROM typed
  GROUP BY PortfolioCode, SecurityCode
),
sec2 AS (
  SELECT
    *,
    IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0)                   AS chg,
    CASE WHEN mw_c IS NOT NULL AND mw_p IS NULL THEN 'NEW'
         WHEN mw_c IS NULL AND mw_p IS NOT NULL THEN 'EXITED'
         WHEN mw_c IS NULL AND mw_p IS NULL     THEN 'BENCHMARK_ONLY'
         ELSE 'HELD' END                                    AS status,
    (  (yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)
    OR (mn_c IS NOT NULL AND mn_p IS NOT NULL AND mn_c != mn_p)
    OR (md_c IS NOT NULL AND md_p IS NOT NULL AND md_c != md_p)
    OR (ud_c IS NOT NULL AND ud_p IS NOT NULL AND ud_c != ud_p)
    OR (dp_c IS NOT NULL AND dp_p IS NOT NULL AND dp_c != dp_p)
    OR (mt_c IS NOT NULL AND mt_p IS NOT NULL AND mt_c != mt_p) )  AS model_changed,
    (yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)       AS yc_changed,
    (md_c IS NOT NULL AND md_p IS NOT NULL AND md_c != md_p)       AS md_changed,
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c > rn_p)        AS downgraded,
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c < rn_p)        AS upgraded,
    -- a downgrade that also re-mapped the yield curve: one event, rating is the cause
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c != rn_p
     AND yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)   AS rating_curve_linked,
    (dp_c IS NOT NULL AND dp_p IS NOT NULL AND dp_c != dp_p)       AS dp_changed
  FROM sec
),

-- portfolio-side totals straight from the source rows: the independent side of the
-- reconciliation, computed without going through the per-security pivot
-- TRACKING ERROR IS COMMON TO BOTH SIDES, so unlike `tot` below this is NOT filtered on
-- is_pf. It sums ContriB_TE across the portfolio and benchmark rows exactly as they stand.
-- te_pfside_* is the same figure from the portfolio side only: if the source duplicates
-- ContriB_TE onto both rows rather than splitting it, te_* is double te_pfside_* and the
-- reported tracking error is overstated 2x. Compare the two on the first run.
te_tot AS (
  SELECT
    PortfolioCode,
    SUM(IF(is_curr,     c_te, NULL))                                 AS te_c,
    SUM(IF(NOT is_curr, c_te, NULL))                                 AS te_p,
    SUM(IF(is_curr     AND is_pf, c_te, NULL))                       AS te_pfside_c,
    SUM(IF(NOT is_curr AND is_pf, c_te, NULL))                       AS te_pfside_p
  FROM typed
  GROUP BY PortfolioCode
),

-- BENCHMARK volatility. IsPortfolio = FALSE rows describe the benchmark, so this is the
-- mirror of `tot`: benchmark side only.
bm_tot AS (
  SELECT
    PortfolioCode,
    SUM(IF(is_curr,     c_bmvol, NULL))                              AS bmvol_c,
    SUM(IF(NOT is_curr, c_bmvol, NULL))                              AS bmvol_p,
    SUM(IF(is_curr,     mkt_wt,  NULL))                              AS bmwt_c,
    SUM(IF(NOT is_curr, mkt_wt,  NULL))                              AS bmwt_p,
    COUNTIF(is_curr)                                                 AS n_bm_sec_c
  FROM typed
  WHERE NOT is_pf
  GROUP BY PortfolioCode
),

tot AS (
  SELECT
    PortfolioCode,
    SUM(IF(is_curr,     c_pfvol, NULL))                              AS vol_c,
    SUM(IF(NOT is_curr, c_pfvol, NULL))                              AS vol_p,
    SUM(IF(is_curr,     c_sys,   NULL))                              AS sys_c,
    SUM(IF(NOT is_curr, c_sys,   NULL))                              AS sys_p,
    SUM(IF(is_curr,     c_spec,  NULL))                              AS spec_c,
    SUM(IF(NOT is_curr, c_spec,  NULL))                              AS spec_p,
    SUM(IF(is_curr,     mkt_wt,  NULL))                              AS wt_c,
    SUM(IF(NOT is_curr, mkt_wt,  NULL))                              AS wt_p,
    SUM(IF(is_curr,     notl_wt, NULL))                              AS nwt_c,
    SUM(IF(NOT is_curr, notl_wt, NULL))                              AS nwt_p,
    -- exposure = notional for derivative lines, market weight otherwise
    SUM(IF(is_curr,     IF(is_deriv, notl_wt, mkt_wt), NULL))        AS ewt_c,
    SUM(IF(NOT is_curr, IF(is_deriv, notl_wt, mkt_wt), NULL))        AS ewt_p,
    COUNTIF(is_curr AND is_deriv)                                    AS n_deriv_c,
    SUM(IF(is_curr     AND is_deriv, c_pfvol, NULL))                 AS deriv_vol_c,
    SUM(IF(NOT is_curr AND is_deriv, c_pfvol, NULL))                 AS deriv_vol_p,
    SAFE_DIVIDE(SUM(IF(is_curr,     mkt_wt * eff_dur, NULL)),
                SUM(IF(is_curr     AND eff_dur IS NOT NULL, mkt_wt, NULL)))  AS wavg_dur_c,
    SAFE_DIVIDE(SUM(IF(NOT is_curr, mkt_wt * eff_dur, NULL)),
                SUM(IF(NOT is_curr AND eff_dur IS NOT NULL, mkt_wt, NULL)))  AS wavg_dur_p,
    MAX(IF(is_curr,     ModelDate, NULL))                            AS md_c,
    MAX(IF(NOT is_curr, ModelDate, NULL))                            AS md_p,
    MAX(IF(is_curr,     JobExecutionID, NULL))                       AS job_c,
    MAX(IF(NOT is_curr, JobExecutionID, NULL))                       AS job_p,
    MAX(IF(is_curr,     model_lag_days, NULL))                       AS lag_c,
    MAX(IF(NOT is_curr, model_lag_days, NULL))                       AS lag_p,
    SUM(IF(is_curr,     mkt_val, NULL))                              AS mv_c,
    SUM(IF(NOT is_curr, mkt_val, NULL))                              AS mv_p,
    MAX(IF(is_curr,     miss_pct, NULL))                             AS miss_c,
    MAX(IF(NOT is_curr, miss_pct, NULL))                             AS miss_p,
    MAX(IF(is_curr,     BenchmarkCode, NULL))                        AS bmc_c,
    MAX(IF(NOT is_curr, BenchmarkCode, NULL))                        AS bmc_p,
    COUNT(DISTINCT IF(is_curr, APTCurrency, NULL))                   AS n_ccy_c,
    ANY_VALUE(PortfolioName)                                         AS PortfolioName,
    ANY_VALUE(BenchmarkCode)                                         AS BenchmarkCode
  FROM typed
  WHERE is_pf
  GROUP BY PortfolioCode
),

agg AS (
  SELECT
    PortfolioCode,
    SUM(chg)                                                         AS sum_sec_chg,
    COUNTIF(status = 'HELD')                                         AS n_held,
    COUNTIF(status = 'NEW')                                          AS n_new,
    COUNTIF(status = 'EXITED')                                       AS n_exit,
    COUNTIF(pfvol_c IS NOT NULL)                                     AS n_sec_c,
    COUNTIF(pfvol_p IS NOT NULL)                                     AS n_sec_p,
    COUNTIF(model_changed)                                           AS n_model_changed,
    COUNTIF(yc_changed)                                              AS n_yc_changed,
    COUNTIF(md_changed)                                              AS n_md_changed,
    COUNTIF(downgraded)                                              AS n_downgraded,
    COUNTIF(upgraded)                                                AS n_upgraded,
    COUNTIF(rating_curve_linked)                                     AS n_rating_curve,
    COUNTIF(dp_changed)                                              AS n_dp_changed,
    SUM(IF(rating_curve_linked, chg, 0))                             AS chg_from_rating_curve,
    SUM(IF(dp_changed, chg, 0))                                      AS chg_from_dp,
    SAFE_DIVIDE(SUM(IFNULL(ew_c,0) * sd_c), SUM(IF(sd_c IS NOT NULL, ew_c, NULL)))
                                                                     AS wavg_sd_c,
    SAFE_DIVIDE(SUM(IFNULL(ew_p,0) * sd_p), SUM(IF(sd_p IS NOT NULL, ew_p, NULL)))
                                                                     AS wavg_sd_p,
    SUM(IF(model_changed, chg, 0))                                   AS chg_from_model_changes,
    SUM(IF(status = 'NEW',    chg, 0))                               AS chg_from_new,
    SUM(IF(status = 'EXITED', chg, 0))                               AS chg_from_exits,
    SUM(IF(status = 'HELD',   chg, 0))                               AS chg_from_held,
    SUM(IF(rk_top   <= 5, IFNULL(pfvol_c, 0), 0))                     AS top5_vol_c,
    SUM(IF(rk_top_p <= 5, IFNULL(pfvol_p, 0), 0))                     AS top5_vol_p,
    SUM(ABS(IFNULL(ew_c,0) - IFNULL(ew_p,0))) / 2                     AS turnover,
    COUNTIF(IFNULL(ew_c,0) < 0 OR IFNULL(ew_p,0) < 0)                 AS n_short,
    STRING_AGG(IF(rk_top   <= 3, FORMAT('%s (%.4f%%)', IFNULL(SecurityName, SecurityCode), IFNULL(pfvol_c,0)), NULL),
               '; ' ORDER BY rk_top)                                 AS top3_contributors,
    STRING_AGG(IF(rk_up    <= 3 AND chg > 0, FORMAT('%s (%+.4f pp)', IFNULL(SecurityName, SecurityCode), chg), NULL),
               '; ' ORDER BY rk_up)                                  AS top3_increases,
    STRING_AGG(IF(rk_down  <= 3 AND chg < 0, FORMAT('%s (%+.4f pp)', IFNULL(SecurityName, SecurityCode), chg), NULL),
               '; ' ORDER BY rk_down)                                AS top3_decreases
  FROM (
    SELECT s.*,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_c,0) DESC) AS rk_top,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_p,0) DESC) AS rk_top_p,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY chg DESC)               AS rk_up,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY chg ASC)                AS rk_down
    FROM sec2 s
  )
  GROUP BY PortfolioCode
)

SELECT
  -- UNITS. Source values are already in PERCENTAGE POINTS: a stored 0.27 means 0.27%.
  --   _Pct    = a level in percent;  _PctPts = an absolute change in percent
  --   _bps    = tracking error, in basis points (percent x 100)
  --   RelChg_..._Pct = a relative change in percent ((curr / prior) - 1) x 100
  t.PortfolioCode,
  t.PortfolioName,
  t.BenchmarkCode,
  cob_curr                                                AS ValuationDate_Curr,
  cob_prev                                                AS ValuationDate_Prev,

  -- ---------- headline volatility (percent) ----------
  t.vol_c                                            AS PortfolioVol_Pct_Curr,
  t.vol_p                                            AS PortfolioVol_Pct_Prev,
  t.vol_c - t.vol_p                                  AS Chg_PortfolioVol_PctPts,
  SAFE_DIVIDE(t.vol_c - t.vol_p, t.vol_p) * 100      AS RelChg_PortfolioVol_Pct,
  t.sys_c                                            AS SystematicVol_Pct_Curr,
  t.sys_p                                            AS SystematicVol_Pct_Prev,
  t.sys_c - t.sys_p                                  AS Chg_SystematicVol_PctPts,
  t.spec_c                                           AS SpecificVol_Pct_Curr,
  t.spec_p                                           AS SpecificVol_Pct_Prev,
  t.spec_c - t.spec_p                                AS Chg_SpecificVol_PctPts,

  -- ---------- tracking error (basis points) ----------
  x.te_c * 100                                       AS PortfolioTE_bps_Curr,
  x.te_p * 100                                       AS PortfolioTE_bps_Prev,
  (x.te_c - x.te_p) * 100                            AS Chg_PortfolioTE_bps,
  SAFE_DIVIDE(x.te_c - x.te_p, x.te_p) * 100         AS RelChg_PortfolioTE_Pct,
  -- Diagnostic. Should differ from the above only if ContriB_TE really is split across the
  -- two sides. If they are equal, the benchmark rows carry no TE. If te_c is exactly twice
  -- this, the source duplicates the figure and tracking error is overstated 2x.
  x.te_pfside_c * 100                                AS PortfolioTE_PfSideOnly_bps_Curr,
  x.te_pfside_p * 100                                AS PortfolioTE_PfSideOnly_bps_Prev,

  -- ---------- benchmark volatility (IsPortfolio = FALSE rows) ----------
  b.bmvol_c * 100                                    AS BenchmarkVol_Pct_Curr,
  b.bmvol_p * 100                                    AS BenchmarkVol_Pct_Prev,
  (b.bmvol_c - b.bmvol_p) * 100                      AS Chg_BenchmarkVol_PctPts,
  SAFE_DIVIDE(b.bmvol_c - b.bmvol_p, b.bmvol_p) * 100 AS RelChg_BenchmarkVol_Pct,
  b.bmwt_c                                           AS SumBenchmarkWeight_Pct_Curr,
  b.bmwt_p                                           AS SumBenchmarkWeight_Pct_Prev,
  b.n_bm_sec_c                                       AS BenchmarkSecurityCount_Curr,

  -- ---------- RECONCILIATION: Recon_Diff must be ~0 ----------
  a.sum_sec_chg                                      AS Recon_SumOfSecurityChanges_PctPts,
  (t.vol_c - t.vol_p) - a.sum_sec_chg                AS Recon_Diff_PctPts,
  IF(ABS((t.vol_c - t.vol_p) - a.sum_sec_chg) < 1e-6, 'PASS', 'FAIL')
                                                     AS Recon_Verdict,

  -- ---------- decomposition of the volatility change (percentage points) ----------
  a.chg_from_held                                    AS VolChg_From_HeldPositions_PctPts,
  a.chg_from_new                                     AS VolChg_From_NewPositions_PctPts,
  a.chg_from_exits                                   AS VolChg_From_ExitedPositions_PctPts,
  a.chg_from_model_changes                           AS VolChg_From_ModelInputChanges_PctPts,
  SAFE_DIVIDE(a.chg_from_model_changes, t.vol_c - t.vol_p) * 100
                                                     AS PctOfVolChg_From_ModelInputChanges_Pct,

  -- ---------- position counts ----------
  a.n_sec_c                                          AS SecurityCount_Curr,
  a.n_sec_p                                          AS SecurityCount_Prev,
  a.n_held                                           AS HeldPositions,
  a.n_new                                            AS NewPositions,
  a.n_exit                                           AS ExitedPositions,

  -- ---------- model / curve stability ----------
  t.job_c                                            AS JobExecutionID_Curr,
  t.job_p                                            AS JobExecutionID_Prev,
  t.md_c                                             AS ModelDate_Curr,
  t.md_p                                             AS ModelDate_Prev,
  t.lag_c                                            AS ModelLagDays_Curr,
  t.lag_p                                            AS ModelLagDays_Prev,
  a.n_model_changed                                  AS SecuritiesWithModelInputChange,
  a.n_downgraded                                     AS SecuritiesDowngraded,
  a.n_upgraded                                       AS SecuritiesUpgraded,
  a.n_rating_curve                                   AS SecuritiesWithRatingDrivenCurveChange,
  a.chg_from_rating_curve                            AS VolChg_From_RatingDrivenCurveChange_PctPts,
  a.n_dp_changed                                     AS SecuritiesWithEstimationWindowChange,
  a.chg_from_dp                                      AS VolChg_From_EstimationWindowChange_PctPts,
  a.n_yc_changed                                     AS SecuritiesWithYieldCurveChange,
  a.n_md_changed                                     AS SecuritiesWithModelDateChange,

  -- ---------- fund size: weights move when the fund grows, with no trading at all ----------
  t.mv_c                                             AS FundMarketValue_Curr,
  t.mv_p                                             AS FundMarketValue_Prev,
  SAFE_DIVIDE(t.mv_c - t.mv_p, t.mv_p) * 100         AS RelChg_FundMarketValue_Pct,

  -- ---------- benchmark identity: a change here invalidates the TE comparison ----------
  t.bmc_c                                            AS BenchmarkCode_Curr,
  t.bmc_p                                            AS BenchmarkCode_Prev,
  CASE WHEN t.bmc_c IS NULL OR t.bmc_p IS NULL THEN 'N/A'
       WHEN t.bmc_c = t.bmc_p THEN 'N' ELSE 'Y' END  AS BenchmarkChanged,

  -- ---------- concentration and turnover ----------
  SAFE_DIVIDE(a.top5_vol_c, t.vol_c) * 100           AS Top5ShareOfVol_Pct_Curr,
  SAFE_DIVIDE(a.top5_vol_p, t.vol_p) * 100           AS Top5ShareOfVol_Pct_Prev,
  SAFE_DIVIDE(a.top5_vol_c, t.vol_c) * 100
    - SAFE_DIVIDE(a.top5_vol_p, t.vol_p) * 100       AS Chg_Top5ShareOfVol_PctPts,
  a.turnover                                         AS Turnover_ExposureWeight_PctPts,
  a.n_short                                          AS ShortOrNegativePositions,

  -- ---------- exposure / data quality ----------
  t.wt_c                                             AS SumMarketWeight_Pct_Curr,
  t.wt_p                                             AS SumMarketWeight_Pct_Prev,
  t.nwt_c                                            AS SumNotionalWeight_Pct_Curr,
  t.nwt_p                                            AS SumNotionalWeight_Pct_Prev,
  t.ewt_c                                            AS SumExposureWeight_Pct_Curr,
  t.ewt_p                                            AS SumExposureWeight_Pct_Prev,
  IFNULL(t.ewt_c,0) - IFNULL(t.ewt_p,0)              AS Chg_SumExposureWeight_PctPts,
  t.n_deriv_c                                        AS DerivativePositions_Curr,
  IFNULL(t.deriv_vol_c,0) - IFNULL(t.deriv_vol_p,0)  AS VolChg_From_Derivatives_PctPts,
  t.miss_c                                           AS MaxMissingAssetPercent_Pct_Curr,
  t.miss_p                                           AS MaxMissingAssetPercent_Pct_Prev,
  t.n_ccy_c                                          AS CurrencyCount_Curr,
  t.wavg_dur_c                                       AS WavgEffectiveDuration_Curr,
  t.wavg_dur_p                                       AS WavgEffectiveDuration_Prev,
  t.wavg_dur_c - t.wavg_dur_p                        AS Chg_WavgEffectiveDuration,
  a.wavg_sd_c                                        AS WavgSpreadDuration_Curr,
  a.wavg_sd_p                                        AS WavgSpreadDuration_Prev,
  a.wavg_sd_c - a.wavg_sd_p                          AS Chg_WavgSpreadDuration,

  -- ---------- ready-made context for the commentary prompt ----------
  a.top3_contributors                                AS Top3_VolContributors_Curr,
  a.top3_increases                                   AS Top3_VolIncreases,
  a.top3_decreases                                   AS Top3_VolDecreases,

  FORMAT(
    'Portfolio %s: volatility moved from %.4f%% to %.4f%% (%+.4f pp, %s relative) between '
    || 'the two COB dates. Tracking error moved from %.1f bps to %.1f bps (%+.1f bps, %s '
    || 'relative). Held positions account for %+.4f pp, new positions %+.4f pp, exits '
    || '%+.4f pp. %d of %d securities had a risk model input change, contributing %+.4f pp '
    || '(%.1f%% of the total move) - treat that portion as methodology, not market. '
    || 'Largest current contributors: %s. Largest increases: %s. Largest decreases: %s.',
    IFNULL(t.PortfolioCode, '(unknown)'),
    IFNULL(t.vol_p, 0), IFNULL(t.vol_c, 0), IFNULL(t.vol_c - t.vol_p, 0),
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(t.vol_c - t.vol_p, t.vol_p) * 100), 'n/a'),
    IFNULL(x.te_p, 0) * 100, IFNULL(x.te_c, 0) * 100, IFNULL(x.te_c - x.te_p, 0) * 100,
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(x.te_c - x.te_p, x.te_p) * 100), 'n/a'),
    IFNULL(a.chg_from_held, 0), IFNULL(a.chg_from_new, 0), IFNULL(a.chg_from_exits, 0),
    a.n_model_changed, a.n_sec_c,
    IFNULL(a.chg_from_model_changes, 0),
    IFNULL(SAFE_DIVIDE(a.chg_from_model_changes, t.vol_c - t.vol_p), 0) * 100,
    IFNULL(a.top3_contributors, '(none)'),
    IFNULL(a.top3_increases,    '(none)'),
    IFNULL(a.top3_decreases,    '(none)')
  )                                                  AS PortfolioCommentaryBrief

FROM tot t
JOIN agg a         ON a.PortfolioCode  = t.PortfolioCode
LEFT JOIN te_tot x ON x.PortfolioCode  = t.PortfolioCode
LEFT JOIN bm_tot b ON b.PortfolioCode  = t.PortfolioCode
ORDER BY PortfolioCode;
