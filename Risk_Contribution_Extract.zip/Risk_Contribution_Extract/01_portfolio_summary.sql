-- =====================================================================================
-- 01_portfolio_summary.sql
--
-- One row per portfolio. Two jobs:
--
--   1. RECONCILIATION. Recon_Diff must be ~0. It proves that the per-security
--      Chg_ContriB_PfVol column in risk_contribution_pairwise.sql sums back to the
--      portfolio-level volatility change. If it does not, the detail CSV is not
--      additive and no attribution built on it can be trusted.
--
--   2. TOP-LEVEL CONTEXT for the AI commentary. The detail CSV says what each name did;
--      this says what the portfolio did, and crucially how much of the move came from
--      names whose MODEL INPUTS changed rather than from the market.
--
-- Run with the same two dates and three portfolio codes as the main query.
-- =====================================================================================

-- ================== EDIT THESE THREE LINES ==================
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
-- ============================================================

DECLARE s_curr STRING;
DECLARE s_prev STRING;
DECLARE tpl    STRING;
DECLARE stmt   STRING;

IF cob_curr = cob_prev THEN
  RAISE USING MESSAGE = 'cob_curr and cob_prev must differ - dated column aliases would collide.';
END IF;

SET s_curr = FORMAT_DATE('%d%m%Y', cob_curr);
SET s_prev = FORMAT_DATE('%d%m%Y', cob_prev);

SET tpl = r"""
WITH base AS (
  SELECT *
  FROM `hsbc-237274-amgrisk-prod.elmo.risk_contribution`
  WHERE ValuationDate IN (@cc, @cp)
    AND PortfolioCode IN UNNEST(@pcs)
),
dedup AS (
  SELECT * EXCEPT(rn) FROM (
    SELECT b.*, ROW_NUMBER() OVER (
      PARTITION BY ValuationDate, PortfolioCode, CompositionCode, IsPortfolio, SecurityCode
      ORDER BY JobExecutionID DESC, ImportDateTime DESC) AS rn
    FROM base b
  ) WHERE rn = 1
),
typed AS (
  SELECT
    PortfolioCode, SecurityCode, SecurityName, PortfolioName, BenchmarkCode,
    (ValuationDate = @cc)     AS is_curr,
    IFNULL(IsPortfolio, TRUE) AS is_pf,
    ModelName, ModelDate, CurrentYieldCurve, UsedData, DataPoints, ModellyingTypeCode,
    MOODYS_L, SP_L, FITCH_L,
    SAFE_CAST(EffectiveSpreadDuration AS FLOAT64) AS spr_dur,
    NULLIF(GREATEST(
      IFNULL(CASE UPPER(TRIM(IFNULL(MOODYS_L, '')))
        WHEN 'AAA' THEN 1 WHEN 'AA1' THEN 2 WHEN 'AA2' THEN 3 WHEN 'AA3' THEN 4
        WHEN 'A1' THEN 5 WHEN 'A2' THEN 6 WHEN 'A3' THEN 7
        WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
        WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
        WHEN 'B1' THEN 14 WHEN 'B2' THEN 15 WHEN 'B3' THEN 16
        WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19 WHEN 'CA' THEN 20
        ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(SP_L, '')))
        WHEN 'AAA' THEN 1 WHEN 'AA+' THEN 2 WHEN 'AA' THEN 3 WHEN 'AA-' THEN 4
        WHEN 'A+' THEN 5 WHEN 'A' THEN 6 WHEN 'A-' THEN 7
        WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9 WHEN 'BBB-' THEN 10
        WHEN 'BB+' THEN 11 WHEN 'BB' THEN 12 WHEN 'BB-' THEN 13
        WHEN 'B+' THEN 14 WHEN 'B' THEN 15 WHEN 'B-' THEN 16
        WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
        WHEN 'CC' THEN 20 WHEN 'C' THEN 21 WHEN 'D' THEN 22 ELSE NULL END, 0)
    ), 0)                                         AS rating_notch,
    DATE_DIFF(ValuationDate, ModelDate, DAY)      AS model_lag_days,
    Line, AssetClassification,
    (UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                 'CDS', 'SWAPTION')
     OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%')  AS is_deriv,
    APTCurrency,
    SAFE_CAST(MarketValue       AS FLOAT64)       AS mkt_val,
    SAFE_CAST(MissingAssetPercent AS FLOAT64)     AS miss_pct,
    SAFE_CAST(MarketWeight      AS FLOAT64)       AS mkt_wt,
    SAFE_CAST(NotionalWeight    AS FLOAT64)       AS notl_wt,
    SAFE_CAST(EffectiveDuration AS FLOAT64)       AS eff_dur,
    SAFE_CAST(ContriB_PfVol     AS FLOAT64)       AS c_pfvol,
    SAFE_CAST(ContriB_SysPfVol  AS FLOAT64)       AS c_sys,
    SAFE_CAST(ContriB_SpecPfVol AS FLOAT64)       AS c_spec,
    SAFE_CAST(ContriB_TE        AS FLOAT64)       AS c_te
  FROM dedup
),

-- per security, so entries/exits and per-name model changes can be counted
sec AS (
  SELECT
    PortfolioCode,
    SecurityCode,
    COALESCE(MAX(IF(is_curr, SecurityName, NULL)), MAX(SecurityName))  AS SecurityName,
    MAX(IF(is_curr     AND is_pf, c_pfvol, NULL))                      AS pfvol_c,
    MAX(IF(NOT is_curr AND is_pf, c_pfvol, NULL))                      AS pfvol_p,
    MAX(IF(is_curr     AND is_pf, mkt_wt,  NULL))                      AS mw_c,
    MAX(IF(NOT is_curr AND is_pf, mkt_wt,  NULL))                      AS mw_p,
    MAX(IF(is_curr     AND is_pf, IF(is_deriv, notl_wt, mkt_wt), NULL)) AS ew_c,
    MAX(IF(NOT is_curr AND is_pf, IF(is_deriv, notl_wt, mkt_wt), NULL)) AS ew_p,
    MAX(IF(is_curr     AND is_pf, eff_dur, NULL))                      AS ed_c,
    MAX(IF(NOT is_curr AND is_pf, eff_dur, NULL))                      AS ed_p,
    MAX(IF(is_curr     AND is_pf, CurrentYieldCurve,  NULL))           AS yc_c,
    MAX(IF(NOT is_curr AND is_pf, CurrentYieldCurve,  NULL))           AS yc_p,
    MAX(IF(is_curr     AND is_pf, rating_notch,       NULL))           AS rn_c,
    MAX(IF(NOT is_curr AND is_pf, rating_notch,       NULL))           AS rn_p,
    MAX(IF(is_curr     AND is_pf, spr_dur,            NULL))           AS sd_c,
    MAX(IF(NOT is_curr AND is_pf, spr_dur,            NULL))           AS sd_p,
    MAX(IF(is_curr     AND is_pf, ModelName,          NULL))           AS mn_c,
    MAX(IF(NOT is_curr AND is_pf, ModelName,          NULL))           AS mn_p,
    MAX(IF(is_curr     AND is_pf, ModelDate,          NULL))           AS md_c,
    MAX(IF(NOT is_curr AND is_pf, ModelDate,          NULL))           AS md_p,
    MAX(IF(is_curr     AND is_pf, UsedData,           NULL))           AS ud_c,
    MAX(IF(NOT is_curr AND is_pf, UsedData,           NULL))           AS ud_p,
    MAX(IF(is_curr     AND is_pf, DataPoints,         NULL))           AS dp_c,
    MAX(IF(NOT is_curr AND is_pf, DataPoints,         NULL))           AS dp_p,
    MAX(IF(is_curr     AND is_pf, ModellyingTypeCode, NULL))           AS mt_c,
    MAX(IF(NOT is_curr AND is_pf, ModellyingTypeCode, NULL))           AS mt_p
  FROM typed
  GROUP BY PortfolioCode, SecurityCode
),
sec2 AS (
  SELECT
    *,
    IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0)                   AS chg,
    CASE WHEN mw_c IS NOT NULL AND mw_p IS NULL THEN 'NEW'
         WHEN mw_c IS NULL AND mw_p IS NOT NULL THEN 'EXITED'
         WHEN mw_c IS NULL AND mw_p IS NULL     THEN 'BENCHMARK_ONLY'
         ELSE 'HELD' END                                    AS status,
    (  (yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)
    OR (mn_c IS NOT NULL AND mn_p IS NOT NULL AND mn_c != mn_p)
    OR (md_c IS NOT NULL AND md_p IS NOT NULL AND md_c != md_p)
    OR (ud_c IS NOT NULL AND ud_p IS NOT NULL AND ud_c != ud_p)
    OR (dp_c IS NOT NULL AND dp_p IS NOT NULL AND dp_c != dp_p)
    OR (mt_c IS NOT NULL AND mt_p IS NOT NULL AND mt_c != mt_p) )  AS model_changed,
    (yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)       AS yc_changed,
    (md_c IS NOT NULL AND md_p IS NOT NULL AND md_c != md_p)       AS md_changed,
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c > rn_p)        AS downgraded,
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c < rn_p)        AS upgraded,
    -- a downgrade that also re-mapped the yield curve: one event, rating is the cause
    (rn_c IS NOT NULL AND rn_p IS NOT NULL AND rn_c != rn_p
     AND yc_c IS NOT NULL AND yc_p IS NOT NULL AND yc_c != yc_p)   AS rating_curve_linked,
    (dp_c IS NOT NULL AND dp_p IS NOT NULL AND dp_c != dp_p)       AS dp_changed
  FROM sec
),

-- portfolio-side totals straight from the source rows: the independent side of the
-- reconciliation, computed without going through the per-security pivot
tot AS (
  SELECT
    PortfolioCode,
    SUM(IF(is_curr,     c_pfvol, NULL))                              AS vol_c,
    SUM(IF(NOT is_curr, c_pfvol, NULL))                              AS vol_p,
    SUM(IF(is_curr,     c_sys,   NULL))                              AS sys_c,
    SUM(IF(NOT is_curr, c_sys,   NULL))                              AS sys_p,
    SUM(IF(is_curr,     c_spec,  NULL))                              AS spec_c,
    SUM(IF(NOT is_curr, c_spec,  NULL))                              AS spec_p,
    SUM(IF(is_curr,     c_te,    NULL))                              AS te_c,
    SUM(IF(NOT is_curr, c_te,    NULL))                              AS te_p,
    SUM(IF(is_curr,     mkt_wt,  NULL))                              AS wt_c,
    SUM(IF(NOT is_curr, mkt_wt,  NULL))                              AS wt_p,
    SUM(IF(is_curr,     notl_wt, NULL))                              AS nwt_c,
    SUM(IF(NOT is_curr, notl_wt, NULL))                              AS nwt_p,
    -- exposure = notional for derivative lines, market weight otherwise
    SUM(IF(is_curr,     IF(is_deriv, notl_wt, mkt_wt), NULL))        AS ewt_c,
    SUM(IF(NOT is_curr, IF(is_deriv, notl_wt, mkt_wt), NULL))        AS ewt_p,
    COUNTIF(is_curr AND is_deriv)                                    AS n_deriv_c,
    SUM(IF(is_curr     AND is_deriv, c_pfvol, NULL))                 AS deriv_vol_c,
    SUM(IF(NOT is_curr AND is_deriv, c_pfvol, NULL))                 AS deriv_vol_p,
    SAFE_DIVIDE(SUM(IF(is_curr,     mkt_wt * eff_dur, NULL)),
                SUM(IF(is_curr     AND eff_dur IS NOT NULL, mkt_wt, NULL)))  AS wavg_dur_c,
    SAFE_DIVIDE(SUM(IF(NOT is_curr, mkt_wt * eff_dur, NULL)),
                SUM(IF(NOT is_curr AND eff_dur IS NOT NULL, mkt_wt, NULL)))  AS wavg_dur_p,
    MAX(IF(is_curr,     ModelDate, NULL))                            AS md_c,
    MAX(IF(NOT is_curr, ModelDate, NULL))                            AS md_p,
    MAX(IF(is_curr,     model_lag_days, NULL))                       AS lag_c,
    MAX(IF(NOT is_curr, model_lag_days, NULL))                       AS lag_p,
    SUM(IF(is_curr,     mkt_val, NULL))                              AS mv_c,
    SUM(IF(NOT is_curr, mkt_val, NULL))                              AS mv_p,
    MAX(IF(is_curr,     miss_pct, NULL))                             AS miss_c,
    MAX(IF(NOT is_curr, miss_pct, NULL))                             AS miss_p,
    MAX(IF(is_curr,     BenchmarkCode, NULL))                        AS bmc_c,
    MAX(IF(NOT is_curr, BenchmarkCode, NULL))                        AS bmc_p,
    COUNT(DISTINCT IF(is_curr, APTCurrency, NULL))                   AS n_ccy_c,
    ANY_VALUE(PortfolioName)                                         AS PortfolioName,
    ANY_VALUE(BenchmarkCode)                                         AS BenchmarkCode
  FROM typed
  WHERE is_pf
  GROUP BY PortfolioCode
),

agg AS (
  SELECT
    PortfolioCode,
    SUM(chg)                                                         AS sum_sec_chg,
    COUNTIF(status = 'HELD')                                         AS n_held,
    COUNTIF(status = 'NEW')                                          AS n_new,
    COUNTIF(status = 'EXITED')                                       AS n_exit,
    COUNTIF(pfvol_c IS NOT NULL)                                     AS n_sec_c,
    COUNTIF(pfvol_p IS NOT NULL)                                     AS n_sec_p,
    COUNTIF(model_changed)                                           AS n_model_changed,
    COUNTIF(yc_changed)                                              AS n_yc_changed,
    COUNTIF(md_changed)                                              AS n_md_changed,
    COUNTIF(downgraded)                                              AS n_downgraded,
    COUNTIF(upgraded)                                                AS n_upgraded,
    COUNTIF(rating_curve_linked)                                     AS n_rating_curve,
    COUNTIF(dp_changed)                                              AS n_dp_changed,
    SUM(IF(rating_curve_linked, chg, 0))                             AS chg_from_rating_curve,
    SUM(IF(dp_changed, chg, 0))                                      AS chg_from_dp,
    SAFE_DIVIDE(SUM(IFNULL(ew_c,0) * sd_c), SUM(IF(sd_c IS NOT NULL, ew_c, NULL)))
                                                                     AS wavg_sd_c,
    SAFE_DIVIDE(SUM(IFNULL(ew_p,0) * sd_p), SUM(IF(sd_p IS NOT NULL, ew_p, NULL)))
                                                                     AS wavg_sd_p,
    SUM(IF(model_changed, chg, 0))                                   AS chg_from_model_changes,
    SUM(IF(status = 'NEW',    chg, 0))                               AS chg_from_new,
    SUM(IF(status = 'EXITED', chg, 0))                               AS chg_from_exits,
    SUM(IF(status = 'HELD',   chg, 0))                               AS chg_from_held,
    SUM(IF(rk_top   <= 5, IFNULL(pfvol_c, 0), 0))                     AS top5_vol_c,
    SUM(IF(rk_top_p <= 5, IFNULL(pfvol_p, 0), 0))                     AS top5_vol_p,
    SUM(ABS(IFNULL(ew_c,0) - IFNULL(ew_p,0))) / 2                     AS turnover,
    COUNTIF(IFNULL(ew_c,0) < 0 OR IFNULL(ew_p,0) < 0)                 AS n_short,
    STRING_AGG(IF(rk_top   <= 3, FORMAT('%s (%.4f%%)', IFNULL(SecurityName, SecurityCode), IFNULL(pfvol_c,0)), NULL),
               '; ' ORDER BY rk_top)                                 AS top3_contributors,
    STRING_AGG(IF(rk_up    <= 3 AND chg > 0, FORMAT('%s (%+.4f pp)', IFNULL(SecurityName, SecurityCode), chg), NULL),
               '; ' ORDER BY rk_up)                                  AS top3_increases,
    STRING_AGG(IF(rk_down  <= 3 AND chg < 0, FORMAT('%s (%+.4f pp)', IFNULL(SecurityName, SecurityCode), chg), NULL),
               '; ' ORDER BY rk_down)                                AS top3_decreases
  FROM (
    SELECT s.*,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_c,0) DESC) AS rk_top,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_p,0) DESC) AS rk_top_p,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY chg DESC)               AS rk_up,
      ROW_NUMBER() OVER (PARTITION BY PortfolioCode ORDER BY chg ASC)                AS rk_down
    FROM sec2 s
  )
  GROUP BY PortfolioCode
)

SELECT
  -- UNITS. Source values are already in PERCENTAGE POINTS: a stored 0.27 means 0.27%.
  --   _Pct    = a level in percent;  _PctPts = an absolute change in percent
  --   _bps    = tracking error, in basis points (percent x 100)
  --   RelChg_..._Pct = a relative change in percent ((curr / prior) - 1) x 100
  t.PortfolioCode,
  t.PortfolioName,
  t.BenchmarkCode,
  @cc                                                AS ValuationDate_Curr,
  @cp                                                AS ValuationDate_Prev,

  -- ---------- headline volatility (percent) ----------
  t.vol_c                                            AS PortfolioVol_Pct_{{C}},
  t.vol_p                                            AS PortfolioVol_Pct_{{P}},
  t.vol_c - t.vol_p                                  AS Chg_PortfolioVol_PctPts,
  SAFE_DIVIDE(t.vol_c - t.vol_p, t.vol_p) * 100      AS RelChg_PortfolioVol_Pct,
  t.sys_c                                            AS SystematicVol_Pct_{{C}},
  t.sys_p                                            AS SystematicVol_Pct_{{P}},
  t.sys_c - t.sys_p                                  AS Chg_SystematicVol_PctPts,
  t.spec_c                                           AS SpecificVol_Pct_{{C}},
  t.spec_p                                           AS SpecificVol_Pct_{{P}},
  t.spec_c - t.spec_p                                AS Chg_SpecificVol_PctPts,

  -- ---------- tracking error (basis points) ----------
  t.te_c * 100                                       AS PortfolioTE_bps_{{C}},
  t.te_p * 100                                       AS PortfolioTE_bps_{{P}},
  (t.te_c - t.te_p) * 100                            AS Chg_PortfolioTE_bps,
  SAFE_DIVIDE(t.te_c - t.te_p, t.te_p) * 100         AS RelChg_PortfolioTE_Pct,

  -- ---------- RECONCILIATION: Recon_Diff must be ~0 ----------
  a.sum_sec_chg                                      AS Recon_SumOfSecurityChanges_PctPts,
  (t.vol_c - t.vol_p) - a.sum_sec_chg                AS Recon_Diff_PctPts,
  IF(ABS((t.vol_c - t.vol_p) - a.sum_sec_chg) < 1e-6, 'PASS', 'FAIL')
                                                     AS Recon_Verdict,

  -- ---------- decomposition of the volatility change (percentage points) ----------
  a.chg_from_held                                    AS VolChg_From_HeldPositions_PctPts,
  a.chg_from_new                                     AS VolChg_From_NewPositions_PctPts,
  a.chg_from_exits                                   AS VolChg_From_ExitedPositions_PctPts,
  a.chg_from_model_changes                           AS VolChg_From_ModelInputChanges_PctPts,
  SAFE_DIVIDE(a.chg_from_model_changes, t.vol_c - t.vol_p) * 100
                                                     AS PctOfVolChg_From_ModelInputChanges_Pct,

  -- ---------- position counts ----------
  a.n_sec_c                                          AS SecurityCount_{{C}},
  a.n_sec_p                                          AS SecurityCount_{{P}},
  a.n_held                                           AS HeldPositions,
  a.n_new                                            AS NewPositions,
  a.n_exit                                           AS ExitedPositions,

  -- ---------- model / curve stability ----------
  t.md_c                                             AS ModelDate_{{C}},
  t.md_p                                             AS ModelDate_{{P}},
  t.lag_c                                            AS ModelLagDays_{{C}},
  t.lag_p                                            AS ModelLagDays_{{P}},
  a.n_model_changed                                  AS SecuritiesWithModelInputChange,
  a.n_downgraded                                     AS SecuritiesDowngraded,
  a.n_upgraded                                       AS SecuritiesUpgraded,
  a.n_rating_curve                                   AS SecuritiesWithRatingDrivenCurveChange,
  a.chg_from_rating_curve                            AS VolChg_From_RatingDrivenCurveChange_PctPts,
  a.n_dp_changed                                     AS SecuritiesWithEstimationWindowChange,
  a.chg_from_dp                                      AS VolChg_From_EstimationWindowChange_PctPts,
  a.n_yc_changed                                     AS SecuritiesWithYieldCurveChange,
  a.n_md_changed                                     AS SecuritiesWithModelDateChange,

  -- ---------- fund size: weights move when the fund grows, with no trading at all ----------
  t.mv_c                                             AS FundMarketValue_{{C}},
  t.mv_p                                             AS FundMarketValue_{{P}},
  SAFE_DIVIDE(t.mv_c - t.mv_p, t.mv_p) * 100         AS RelChg_FundMarketValue_Pct,

  -- ---------- benchmark identity: a change here invalidates the TE comparison ----------
  t.bmc_c                                            AS BenchmarkCode_{{C}},
  t.bmc_p                                            AS BenchmarkCode_{{P}},
  CASE WHEN t.bmc_c IS NULL OR t.bmc_p IS NULL THEN 'N/A'
       WHEN t.bmc_c = t.bmc_p THEN 'N' ELSE 'Y' END  AS BenchmarkChanged,

  -- ---------- concentration and turnover ----------
  SAFE_DIVIDE(a.top5_vol_c, t.vol_c) * 100           AS Top5ShareOfVol_Pct_{{C}},
  SAFE_DIVIDE(a.top5_vol_p, t.vol_p) * 100           AS Top5ShareOfVol_Pct_{{P}},
  SAFE_DIVIDE(a.top5_vol_c, t.vol_c) * 100
    - SAFE_DIVIDE(a.top5_vol_p, t.vol_p) * 100       AS Chg_Top5ShareOfVol_PctPts,
  a.turnover                                         AS Turnover_ExposureWeight_PctPts,
  a.n_short                                          AS ShortOrNegativePositions,

  -- ---------- exposure / data quality ----------
  t.wt_c                                             AS SumMarketWeight_Pct_{{C}},
  t.wt_p                                             AS SumMarketWeight_Pct_{{P}},
  t.nwt_c                                            AS SumNotionalWeight_Pct_{{C}},
  t.nwt_p                                            AS SumNotionalWeight_Pct_{{P}},
  t.ewt_c                                            AS SumExposureWeight_Pct_{{C}},
  t.ewt_p                                            AS SumExposureWeight_Pct_{{P}},
  IFNULL(t.ewt_c,0) - IFNULL(t.ewt_p,0)              AS Chg_SumExposureWeight_PctPts,
  t.n_deriv_c                                        AS DerivativePositions_{{C}},
  IFNULL(t.deriv_vol_c,0) - IFNULL(t.deriv_vol_p,0)  AS VolChg_From_Derivatives_PctPts,
  t.miss_c                                           AS MaxMissingAssetPercent_Pct_{{C}},
  t.miss_p                                           AS MaxMissingAssetPercent_Pct_{{P}},
  t.n_ccy_c                                          AS CurrencyCount_{{C}},
  t.wavg_dur_c                                       AS WavgEffectiveDuration_{{C}},
  t.wavg_dur_p                                       AS WavgEffectiveDuration_{{P}},
  t.wavg_dur_c - t.wavg_dur_p                        AS Chg_WavgEffectiveDuration,
  a.wavg_sd_c                                        AS WavgSpreadDuration_{{C}},
  a.wavg_sd_p                                        AS WavgSpreadDuration_{{P}},
  a.wavg_sd_c - a.wavg_sd_p                          AS Chg_WavgSpreadDuration,

  -- ---------- ready-made context for the commentary prompt ----------
  a.top3_contributors                                AS Top3_VolContributors_Curr,
  a.top3_increases                                   AS Top3_VolIncreases,
  a.top3_decreases                                   AS Top3_VolDecreases,

  FORMAT(
    'Portfolio %s: volatility moved from %.4f%% to %.4f%% (%+.4f pp, %s relative) between '
    || 'the two COB dates. Tracking error moved from %.1f bps to %.1f bps (%+.1f bps, %s '
    || 'relative). Held positions account for %+.4f pp, new positions %+.4f pp, exits '
    || '%+.4f pp. %d of %d securities had a risk model input change, contributing %+.4f pp '
    || '(%.1f%% of the total move) - treat that portion as methodology, not market. '
    || 'Largest current contributors: %s. Largest increases: %s. Largest decreases: %s.',
    IFNULL(t.PortfolioCode, '(unknown)'),
    IFNULL(t.vol_p, 0), IFNULL(t.vol_c, 0), IFNULL(t.vol_c - t.vol_p, 0),
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(t.vol_c - t.vol_p, t.vol_p) * 100), 'n/a'),
    IFNULL(t.te_p, 0) * 100, IFNULL(t.te_c, 0) * 100, IFNULL(t.te_c - t.te_p, 0) * 100,
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(t.te_c - t.te_p, t.te_p) * 100), 'n/a'),
    IFNULL(a.chg_from_held, 0), IFNULL(a.chg_from_new, 0), IFNULL(a.chg_from_exits, 0),
    a.n_model_changed, a.n_sec_c,
    IFNULL(a.chg_from_model_changes, 0),
    IFNULL(SAFE_DIVIDE(a.chg_from_model_changes, t.vol_c - t.vol_p), 0) * 100,
    IFNULL(a.top3_contributors, '(none)'),
    IFNULL(a.top3_increases,    '(none)'),
    IFNULL(a.top3_decreases,    '(none)')
  )                                                  AS PortfolioCommentaryBrief

FROM tot t
JOIN agg a ON a.PortfolioCode = t.PortfolioCode
ORDER BY PortfolioCode
""";

SET stmt = REPLACE(REPLACE(tpl, '{{C}}', s_curr), '{{P}}', s_prev);

EXECUTE IMMEDIATE stmt
  USING cob_curr AS cc, cob_prev AS cp, portfolio_codes AS pcs;
