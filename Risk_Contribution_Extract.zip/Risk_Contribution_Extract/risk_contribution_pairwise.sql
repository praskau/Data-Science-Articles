-- =====================================================================================
-- risk_contribution_pairwise.sql
--
-- Two-COB portfolio risk drill-down over
--     hsbc-237274-amgrisk-prod.elmo.risk_contribution
--
-- Produces ONE row per PortfolioCode x SecurityCode, with every metric carried for both
-- COB dates side by side and the period-over-period calculations embedded.
--
-- COLUMN NAMING
--   Dated columns carry the real COB date in ddmmyyyy   -> ContriB_PfVol_24082026
--   Computed / delta columns keep STATIC names          -> Chg_ContriB_PfVol
--   BigQuery cannot parameterise identifiers, so the query templates its own aliases
--   and runs itself with EXECUTE IMMEDIATE.
--
-- HOW TO RUN
--   1. Run 00_preflight_checks.sql first.
--   2. Edit the three DECLARE lines below.
--   3. Run.  Then: Save results -> CSV.
--
-- READ THE CAVEATS IN README.md BEFORE TRUSTING THE DERIVED PERCENTAGES.
-- =====================================================================================

-- ================== EDIT THESE THREE LINES ==================
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';   -- current COB
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';   -- prior COB
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
-- ============================================================

-- Materiality floor for DriverTag classification, in the same units as ContriB_PfVol.
DECLARE vol_tolerance    FLOAT64 DEFAULT 0.0001;
DECLARE weight_tolerance FLOAT64 DEFAULT 0.000001;

-- Derived: the ddmmyyyy suffixes stamped onto every dated column alias.
DECLARE s_curr STRING;
DECLARE s_prev STRING;
DECLARE tpl    STRING;
DECLARE stmt   STRING;

-- Guard: identical dates would make every dated alias collide.
IF cob_curr = cob_prev THEN
  RAISE USING MESSAGE = 'cob_curr and cob_prev must differ - dated column aliases would collide.';
END IF;

SET s_curr = FORMAT_DATE('%d%m%Y', cob_curr);
SET s_prev = FORMAT_DATE('%d%m%Y', cob_prev);

SET tpl = r"""
WITH base AS (
  SELECT *
  FROM `hsbc-237274-amgrisk-prod.elmo.risk_contribution`
  WHERE ValuationDate IN (@cc, @cp)                 -- partition pruning: keep this first
    AND PortfolioCode IN UNNEST(@pcs)
),

-- A COB can be loaded more than once. Take the LATEST LOAD AS A WHOLE -- not the latest
-- version of each row. Pick MAX(JobExecutionID) per ValuationDate x PortfolioCode and keep
-- only rows carrying that job id.
--
-- Row-level dedup is wrong here. If a re-run loads 48 of the 50 positions, picking the
-- latest row per security keeps the 48 corrected rows and silently carries the 2 stale rows
-- from the previous job. The result is a portfolio blended across two model vintages that
-- still sums to a plausible total and still reconciles -- the worst kind of wrong.
-- 00_preflight_checks.sql reports when the latest job is smaller than the one before it.
latest_job AS (
  SELECT ValuationDate, PortfolioCode, MAX(JobExecutionID) AS max_job
  FROM base
  GROUP BY ValuationDate, PortfolioCode
),
dedup AS (
  SELECT * EXCEPT(rn)
  FROM (
    SELECT
      b.*,
      -- Second net: the same job re-inserting an identical natural key.
      ROW_NUMBER() OVER (
        PARTITION BY b.ValuationDate, b.PortfolioCode, b.CompositionCode,
                     b.IsPortfolio, b.SecurityCode
        ORDER BY b.ImportDateTime DESC
      ) AS rn
    FROM base b
    JOIN latest_job l
      ON  b.ValuationDate  = l.ValuationDate
      AND b.PortfolioCode  = l.PortfolioCode
      AND b.JobExecutionID = l.max_job
  )
  WHERE rn = 1
),

-- Normalise types once. Four fields are numerics stored as STRING, and the ContriB_Sys*
-- fields are FLOAT while their siblings are BIGNUMERIC - BigQuery will not mix the two
-- in arithmetic, so everything becomes FLOAT64 here.
typed AS (
  SELECT
    PortfolioCode,
    SecurityCode,
    (ValuationDate = @cc)       AS is_curr,
    IFNULL(IsPortfolio, TRUE)   AS is_pf,
    PortfolioName, BenchmarkCode, BenchmarkName,
    CompositionCode, CompositionName,
    ModelName, ModelDate, CurrentYieldCurve, VolatilityModel, UsedData, DataPoints,
    IdType, IdUsedInAnalytics, ModellyingTypeCode,
    SecurityName, SecurityType, AssetClassification, BorrowerClassificationName,
    SecuritySectorName, Country_of_Risk, APTIssuer, APTCurrency, Line,
    BuyCurrency, SellCurrency, MOODYS_L, SP_L, FITCH_L,
    DATE_DIFF(ValuationDate, ModelDate, DAY)            AS model_lag_days,
    SAFE_CAST(MarketWeight            AS FLOAT64)       AS mkt_wt,
    SAFE_CAST(MarketValue             AS FLOAT64)       AS mkt_val,
    SAFE_CAST(UserMarketValue         AS FLOAT64)       AS usr_mkt_val,
    SAFE_CAST(NotionalWeight          AS FLOAT64)       AS notl_wt,
    SAFE_CAST(NotionalWeightBuy       AS FLOAT64)       AS notl_buy,
    SAFE_CAST(NotionalWeightSell      AS FLOAT64)       AS notl_sell,
    SAFE_CAST(MissingAssetPercent     AS FLOAT64)       AS miss_pct,
    SAFE_CAST(EffectiveDuration       AS FLOAT64)       AS eff_dur,
    SAFE_CAST(ModifiedDuration        AS FLOAT64)       AS mod_dur,
    SAFE_CAST(EffectiveSpreadDuration AS FLOAT64)       AS spr_dur,
    -- Rating on a single 1-22 notch scale (1 = AAA, 22 = D). Moodys and SP/Fitch codes
    -- share the scale. Worst of the three available agencies, the conservative convention.
    NULLIF(GREATEST(
      IFNULL(CASE UPPER(TRIM(IFNULL(MOODYS_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(SP_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(FITCH_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0)
    ), 0)                                               AS rating_notch,
    SAFE_CAST(DataPoints              AS FLOAT64)       AS dp_num,
    SAFE_CAST(ContriB_PfVol           AS FLOAT64)       AS c_pfvol,
    SAFE_CAST(ContriB_SysPfVol        AS FLOAT64)       AS c_syspfvol,
    SAFE_CAST(ContriB_SpecPfVol       AS FLOAT64)       AS c_specpfvol,
    SAFE_CAST(ContriB_BmVol           AS FLOAT64)       AS c_bmvol,
    SAFE_CAST(ContriB_TE              AS FLOAT64)       AS c_te,
    SAFE_CAST(ContriB_SysTE           AS FLOAT64)       AS c_syste,
    SAFE_CAST(ContriB_SpecTE          AS FLOAT64)       AS c_specte
  FROM dedup
),

-- Conditional aggregation into four slices: portfolio/benchmark side x current/prior.
-- A holding present on only one date simply yields NULL on the other side, which is how
-- entries and exits fall out without a FULL OUTER JOIN.
pivot AS (
  SELECT
    PortfolioCode,
    SecurityCode,

    -- descriptors: prefer current COB, fall back to prior so exited names stay labelled
    COALESCE(MAX(IF(is_curr, SecurityName,                NULL)), MAX(SecurityName))                AS SecurityName,
    COALESCE(MAX(IF(is_curr, PortfolioName,               NULL)), MAX(PortfolioName))               AS PortfolioName,
    COALESCE(MAX(IF(is_curr, BenchmarkCode,               NULL)), MAX(BenchmarkCode))               AS BenchmarkCode,
    COALESCE(MAX(IF(is_curr, BenchmarkName,               NULL)), MAX(BenchmarkName))               AS BenchmarkName,
    COALESCE(MAX(IF(is_curr, SecurityType,                NULL)), MAX(SecurityType))                AS SecurityType,
    COALESCE(MAX(IF(is_curr, AssetClassification,         NULL)), MAX(AssetClassification))         AS AssetClassification,
    COALESCE(MAX(IF(is_curr, BorrowerClassificationName,  NULL)), MAX(BorrowerClassificationName))  AS BorrowerClassificationName,
    COALESCE(MAX(IF(is_curr, APTIssuer,                   NULL)), MAX(APTIssuer))                   AS APTIssuer,
    COALESCE(MAX(IF(is_curr, APTCurrency,                 NULL)), MAX(APTCurrency))                 AS APTCurrency,
    COALESCE(MAX(IF(is_curr, Line,                        NULL)), MAX(Line))                        AS Line,
    COALESCE(MAX(IF(is_curr, BuyCurrency,                 NULL)), MAX(BuyCurrency))                 AS BuyCurrency,
    COALESCE(MAX(IF(is_curr, SellCurrency,                NULL)), MAX(SellCurrency))                AS SellCurrency,
    MAX(IF(is_pf,      CompositionCode, NULL))                                                      AS CompositionCode_Pf,
    MAX(IF(NOT is_pf,  CompositionCode, NULL))                                                      AS CompositionCode_Bm,
    MAX(IF(is_pf,      CompositionName, NULL))                                                      AS CompositionName_Pf,

    -- security-level analytics attributes, per COB (portfolio side preferred)
    COALESCE(MAX(IF(is_curr     AND is_pf, CurrentYieldCurve,  NULL)), MAX(IF(is_curr,     CurrentYieldCurve,  NULL))) AS yc_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, CurrentYieldCurve,  NULL)), MAX(IF(NOT is_curr, CurrentYieldCurve,  NULL))) AS yc_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, VolatilityModel,    NULL)), MAX(IF(is_curr,     VolatilityModel,    NULL))) AS vm_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, VolatilityModel,    NULL)), MAX(IF(NOT is_curr, VolatilityModel,    NULL))) AS vm_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, ModelName,          NULL)), MAX(IF(is_curr,     ModelName,          NULL))) AS mn_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, ModelName,          NULL)), MAX(IF(NOT is_curr, ModelName,          NULL))) AS mn_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, ModelDate,          NULL)), MAX(IF(is_curr,     ModelDate,          NULL))) AS md_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, ModelDate,          NULL)), MAX(IF(NOT is_curr, ModelDate,          NULL))) AS md_p,
    -- Which load each side of the pair came from. Carried through so a detail row can be
    -- traced back to its job, and so the two exports can be checked against each other.
    MAX(IF(is_curr     AND is_pf, JobExecutionID, NULL))                                            AS job_pf_c,
    MAX(IF(NOT is_curr AND is_pf, JobExecutionID, NULL))                                            AS job_pf_p,
    MAX(IF(is_curr     AND NOT is_pf, JobExecutionID, NULL))                                        AS job_bm_c,
    MAX(IF(NOT is_curr AND NOT is_pf, JobExecutionID, NULL))                                        AS job_bm_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, model_lag_days,     NULL)), MAX(IF(is_curr,     model_lag_days,     NULL))) AS lag_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, model_lag_days,     NULL)), MAX(IF(NOT is_curr, model_lag_days,     NULL))) AS lag_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, ModellyingTypeCode, NULL)), MAX(IF(is_curr,     ModellyingTypeCode, NULL))) AS mt_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, ModellyingTypeCode, NULL)), MAX(IF(NOT is_curr, ModellyingTypeCode, NULL))) AS mt_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, UsedData,           NULL)), MAX(IF(is_curr,     UsedData,           NULL))) AS ud_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, UsedData,           NULL)), MAX(IF(NOT is_curr, UsedData,           NULL))) AS ud_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, DataPoints,         NULL)), MAX(IF(is_curr,     DataPoints,         NULL))) AS dp_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, DataPoints,         NULL)), MAX(IF(NOT is_curr, DataPoints,         NULL))) AS dp_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, IdType,             NULL)), MAX(IF(is_curr,     IdType,             NULL))) AS it_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, IdType,             NULL)), MAX(IF(NOT is_curr, IdType,             NULL))) AS it_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, IdUsedInAnalytics,  NULL)), MAX(IF(is_curr,     IdUsedInAnalytics,  NULL))) AS ia_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, IdUsedInAnalytics,  NULL)), MAX(IF(NOT is_curr, IdUsedInAnalytics,  NULL))) AS ia_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, SecuritySectorName, NULL)), MAX(IF(is_curr,     SecuritySectorName, NULL))) AS ss_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, SecuritySectorName, NULL)), MAX(IF(NOT is_curr, SecuritySectorName, NULL))) AS ss_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, Country_of_Risk,    NULL)), MAX(IF(is_curr,     Country_of_Risk,    NULL))) AS cr_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, Country_of_Risk,    NULL)), MAX(IF(NOT is_curr, Country_of_Risk,    NULL))) AS cr_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, MOODYS_L,           NULL)), MAX(IF(is_curr,     MOODYS_L,           NULL))) AS mdy_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, MOODYS_L,           NULL)), MAX(IF(NOT is_curr, MOODYS_L,           NULL))) AS mdy_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, SP_L,               NULL)), MAX(IF(is_curr,     SP_L,               NULL))) AS sp_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, SP_L,               NULL)), MAX(IF(NOT is_curr, SP_L,               NULL))) AS sp_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, FITCH_L,            NULL)), MAX(IF(is_curr,     FITCH_L,            NULL))) AS fit_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, FITCH_L,            NULL)), MAX(IF(NOT is_curr, FITCH_L,            NULL))) AS fit_p,

    -- portfolio side, current / prior
    MAX(IF(is_curr     AND is_pf, mkt_wt,      NULL)) AS mw_pf_c,
    MAX(IF(NOT is_curr AND is_pf, mkt_wt,      NULL)) AS mw_pf_p,
    MAX(IF(is_curr     AND is_pf, mkt_val,     NULL)) AS mv_pf_c,
    MAX(IF(NOT is_curr AND is_pf, mkt_val,     NULL)) AS mv_pf_p,
    MAX(IF(is_curr     AND is_pf, usr_mkt_val, NULL)) AS umv_pf_c,
    MAX(IF(NOT is_curr AND is_pf, usr_mkt_val, NULL)) AS umv_pf_p,
    MAX(IF(is_curr     AND is_pf, notl_wt,     NULL)) AS nw_pf_c,
    MAX(IF(NOT is_curr AND is_pf, notl_wt,     NULL)) AS nw_pf_p,
    MAX(IF(is_curr     AND is_pf, notl_buy,    NULL)) AS nwb_pf_c,
    MAX(IF(NOT is_curr AND is_pf, notl_buy,    NULL)) AS nwb_pf_p,
    MAX(IF(is_curr     AND is_pf, notl_sell,   NULL)) AS nws_pf_c,
    MAX(IF(NOT is_curr AND is_pf, notl_sell,   NULL)) AS nws_pf_p,
    MAX(IF(is_curr     AND is_pf, miss_pct,    NULL)) AS miss_c,
    MAX(IF(NOT is_curr AND is_pf, miss_pct,    NULL)) AS miss_p,
    MAX(IF(is_curr     AND is_pf, eff_dur,     NULL)) AS ed_c,
    MAX(IF(NOT is_curr AND is_pf, eff_dur,     NULL)) AS ed_p,
    MAX(IF(is_curr     AND is_pf, mod_dur,     NULL)) AS mdur_c,
    MAX(IF(NOT is_curr AND is_pf, mod_dur,     NULL)) AS mdur_p,
    MAX(IF(is_curr     AND is_pf, spr_dur,     NULL)) AS sd_c,
    MAX(IF(NOT is_curr AND is_pf, spr_dur,     NULL)) AS sd_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, rating_notch, NULL)),
             MAX(IF(is_curr,     rating_notch, NULL))) AS rn_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, rating_notch, NULL)),
             MAX(IF(NOT is_curr, rating_notch, NULL))) AS rn_p,
    COALESCE(MAX(IF(is_curr     AND is_pf, dp_num, NULL)),
             MAX(IF(is_curr,     dp_num, NULL)))       AS dpn_c,
    COALESCE(MAX(IF(NOT is_curr AND is_pf, dp_num, NULL)),
             MAX(IF(NOT is_curr, dp_num, NULL)))       AS dpn_p,

    -- benchmark side, current / prior
    MAX(IF(is_curr     AND NOT is_pf, mkt_wt,  NULL)) AS mw_bm_c,
    MAX(IF(NOT is_curr AND NOT is_pf, mkt_wt,  NULL)) AS mw_bm_p,

    -- risk contributions
    MAX(IF(is_curr     AND is_pf,     c_pfvol,     NULL)) AS pfvol_c,
    MAX(IF(NOT is_curr AND is_pf,     c_pfvol,     NULL)) AS pfvol_p,
    MAX(IF(is_curr     AND is_pf,     c_syspfvol,  NULL)) AS syspfvol_c,
    MAX(IF(NOT is_curr AND is_pf,     c_syspfvol,  NULL)) AS syspfvol_p,
    MAX(IF(is_curr     AND is_pf,     c_specpfvol, NULL)) AS specpfvol_c,
    MAX(IF(NOT is_curr AND is_pf,     c_specpfvol, NULL)) AS specpfvol_p,
    MAX(IF(is_curr     AND NOT is_pf, c_bmvol,     NULL)) AS bmvol_c,
    MAX(IF(NOT is_curr AND NOT is_pf, c_bmvol,     NULL)) AS bmvol_p,
    MAX(IF(is_curr     AND is_pf,     c_te,        NULL)) AS te_c,
    MAX(IF(NOT is_curr AND is_pf,     c_te,        NULL)) AS te_p,
    MAX(IF(is_curr     AND is_pf,     c_syste,     NULL)) AS syste_c,
    MAX(IF(NOT is_curr AND is_pf,     c_syste,     NULL)) AS syste_p,
    MAX(IF(is_curr     AND is_pf,     c_specte,    NULL)) AS specte_c,
    MAX(IF(NOT is_curr AND is_pf,     c_specte,    NULL)) AS specte_p

  FROM typed
  GROUP BY PortfolioCode, SecurityCode
),

-- Portfolio-level totals, carried onto every row so the CSV needs no second query and
-- each line can be read on its own.
calc AS (
  SELECT
    p.*,
    SUM(pfvol_c)                      OVER w AS pf_vol_c,
    SUM(pfvol_p)                      OVER w AS pf_vol_p,
    SUM(te_c)                         OVER w AS pf_te_c,
    SUM(te_p)                         OVER w AS pf_te_p,
    COUNTIF(pfvol_c IS NOT NULL)      OVER w AS n_sec_c,
    COUNTIF(pfvol_p IS NOT NULL)      OVER w AS n_sec_p,
    COUNTIF(mw_pf_c IS NOT NULL AND mw_pf_p IS NULL) OVER w AS n_new,
    COUNTIF(mw_pf_c IS NULL AND mw_pf_p IS NOT NULL) OVER w AS n_exit
  FROM pivot p
  WINDOW w AS (PARTITION BY PortfolioCode)
),

flags AS (
  SELECT
    c.*,
    -- Y / N / N-A. N-A where one COB is missing the holding, so an entry or exit is not
    -- misreported as a methodology change.
    CASE WHEN yc_c  IS NULL OR yc_p  IS NULL THEN 'N/A' WHEN yc_c  = yc_p  THEN 'N' ELSE 'Y' END AS f_yc,
    CASE WHEN mn_c  IS NULL OR mn_p  IS NULL THEN 'N/A' WHEN mn_c  = mn_p  THEN 'N' ELSE 'Y' END AS f_mn,
    CASE WHEN md_c  IS NULL OR md_p  IS NULL THEN 'N/A' WHEN md_c  = md_p  THEN 'N' ELSE 'Y' END AS f_md,
    CASE WHEN mt_c  IS NULL OR mt_p  IS NULL THEN 'N/A' WHEN mt_c  = mt_p  THEN 'N' ELSE 'Y' END AS f_mt,
    CASE WHEN ud_c  IS NULL OR ud_p  IS NULL THEN 'N/A' WHEN ud_c  = ud_p  THEN 'N' ELSE 'Y' END AS f_ud,
    CASE WHEN dp_c  IS NULL OR dp_p  IS NULL THEN 'N/A' WHEN dp_c  = dp_p  THEN 'N' ELSE 'Y' END AS f_dp,
    CASE WHEN it_c  IS NULL OR it_p  IS NULL THEN 'N/A' WHEN it_c  = it_p  THEN 'N' ELSE 'Y' END AS f_it,
    CASE WHEN ss_c  IS NULL OR ss_p  IS NULL THEN 'N/A' WHEN ss_c  = ss_p  THEN 'N' ELSE 'Y' END AS f_ss,
    CASE WHEN cr_c  IS NULL OR cr_p  IS NULL THEN 'N/A' WHEN cr_c  = cr_p  THEN 'N' ELSE 'Y' END AS f_cr,
    CASE
      WHEN mdy_c IS NULL AND sp_c IS NULL AND fit_c IS NULL THEN 'N/A'
      WHEN mdy_p IS NULL AND sp_p IS NULL AND fit_p IS NULL THEN 'N/A'
      WHEN IFNULL(mdy_c,'~') != IFNULL(mdy_p,'~')
        OR IFNULL(sp_c, '~') != IFNULL(sp_p, '~')
        OR IFNULL(fit_c,'~') != IFNULL(fit_p,'~') THEN 'Y'
      ELSE 'N'
    END AS f_rating
  FROM calc c
),

final AS (
  SELECT
    f.*,
    -- Additive quantities: a missing side is a genuine zero (entry from nothing, exit
    -- to nothing), so IFNULL keeps SUM(Chg_*) reconciling to the portfolio-level change.
    IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0)                         AS chg_pfvol,
    ABS(IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0))                    AS abs_chg_pfvol,
    IFNULL(mw_pf_c,0) - IFNULL(mw_pf_p,0)                         AS chg_mw_pf,

    -- EXPOSURE WEIGHT. A future or swap carries almost no market value - only margin and
    -- unrealised P&L - so market weight understates what the fund is actually exposed to.
    -- For derivative lines the exposure is the NOTIONAL weight. ExposureBasis says which
    -- one was used on each row, so nothing has to be assumed downstream.
    UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                'CDS', 'SWAPTION')
      OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%'                AS is_deriv,
    IF(UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                   'CDS', 'SWAPTION')
       OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%',
       nw_pf_c, mw_pf_c)                                                           AS exp_wt_c,
    IF(UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                   'CDS', 'SWAPTION')
       OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%',
       nw_pf_p, mw_pf_p)                                                           AS exp_wt_p,
    SAFE_DIVIDE(pfvol_c, pf_vol_c)                                AS share_c,
    SAFE_DIVIDE(pfvol_p, pf_vol_p)                                AS share_p,
    pf_vol_c - pf_vol_p                                           AS chg_pf_vol,
    pf_te_c  - pf_te_p                                            AS chg_pf_te,
    CASE WHEN mw_pf_c IS NOT NULL AND mw_pf_p IS NULL THEN 'NEW'
         WHEN mw_pf_c IS NULL AND mw_pf_p IS NOT NULL THEN 'EXITED'
         WHEN mw_pf_c IS NULL AND mw_pf_p IS NULL     THEN 'BENCHMARK_ONLY'
         ELSE 'HELD' END                                          AS holding_status,
    -- VolatilityModel is deliberately EXCLUDED from this roll-up and from every flag and
    -- tag below. It is carried as a reference field only and must not drive analysis.
    IF(f_yc = 'Y' OR f_mn = 'Y' OR f_md = 'Y'
       OR f_mt = 'Y' OR f_ud = 'Y' OR f_dp = 'Y' OR f_it = 'Y', 'Y', 'N')
                                                                  AS any_model_changed,

    -- Notches moved on the 1-22 scale. Positive = DOWNGRADED by that many notches.
    rn_c - rn_p                                                   AS rating_notches_down,
    CASE WHEN rn_c IS NULL OR rn_p IS NULL THEN 'N/A'
         WHEN rn_c > rn_p THEN 'DOWNGRADE'
         WHEN rn_c < rn_p THEN 'UPGRADE'
         ELSE 'UNCHANGED' END                                     AS rating_direction,

    -- A downgrade often re-maps the security onto a different (wider) yield curve, which
    -- then moves its volatility. When both flags fire together the two are one event, not
    -- two independent ones, and the rating is the cause.
    IF(f_rating = 'Y' AND f_yc = 'Y', 'Y', 'N')                   AS rating_curve_linked,

    -- DataPoints is the number of observations the volatility estimate is built on. A
    -- change here moves the vol number for estimation reasons alone.
    dpn_c - dpn_p                                                 AS chg_datapoints
  FROM flags f
),

-- exp_wt_c / exp_wt_p are defined in `final`, so the change is computed one level up
final2 AS (
  SELECT
    f.*,
    IFNULL(exp_wt_c, 0) - IFNULL(exp_wt_p, 0)                     AS chg_exp_wt
  FROM final f
)

SELECT
  -- ---------- identity ----------
  -- UNITS. Source values are already in PERCENTAGE POINTS: a stored 0.27 means 0.27%.
  --   _Pct     = a level in percent            (12.7290 reads 12.7290%)
  --   _PctPts  = an absolute change in percent (+1.1000 reads +1.1000 percentage points)
  --   _bps     = a level or change in basis points (percent x 100)
  --   RelChg_..._Pct = a RELATIVE change in percent ((curr / prior) - 1) x 100
  -- Tracking error is carried in bps throughout. Volatility and weights are carried in
  -- percent. Relative change is NULL where the prior value is zero or absent.
  PortfolioCode,
  PortfolioName,
  BenchmarkCode,
  BenchmarkName,
  @cc                                                             AS ValuationDate_Curr,
  @cp                                                             AS ValuationDate_Prev,
  SecurityCode,
  SecurityName,
  holding_status                                                  AS HoldingStatus,

  -- ---------- driver classification (the AI hook) ----------
  CASE
    WHEN holding_status = 'NEW'            THEN 'NEW_POSITION'
    WHEN holding_status = 'EXITED'         THEN 'EXITED_POSITION'
    WHEN holding_status = 'BENCHMARK_ONLY' THEN 'BENCHMARK_ONLY'
    WHEN IFNULL(abs_chg_pfvol, 0) < @vtol  THEN 'IMMATERIAL'
    -- most specific cause first: a generic MODEL_INPUT_CHANGED tag would otherwise hide
    -- both the rating that caused a curve re-map and a changed estimation window
    WHEN rating_curve_linked = 'Y'         THEN 'RATING_DRIVEN_CURVE_CHANGE'
    WHEN f_dp = 'Y' AND f_yc = 'N' AND f_mn = 'N'
         AND f_md = 'N' AND f_mt = 'N'     THEN 'ESTIMATION_WINDOW_CHANGED'
    WHEN f_rating = 'Y'                    THEN 'RATING_MIGRATION'
    WHEN any_model_changed = 'Y'           THEN 'MODEL_INPUT_CHANGED'
    -- classified on EXPOSURE weight: notional for derivatives, market weight otherwise
    WHEN chg_pfvol > 0 AND IFNULL(chg_exp_wt, 0) >  @wtol THEN 'VOL_UP_ON_WEIGHT_UP'
    WHEN chg_pfvol > 0                                    THEN 'VOL_UP_ON_RISK_UP'
    WHEN chg_pfvol < 0 AND IFNULL(chg_exp_wt, 0) < -@wtol THEN 'VOL_DOWN_ON_WEIGHT_DOWN'
    WHEN chg_pfvol < 0                                    THEN 'VOL_DOWN_ON_RISK_DOWN'
    ELSE 'IMMATERIAL'
  END                                                             AS DriverTag,

  RANK() OVER (PARTITION BY PortfolioCode ORDER BY abs_chg_pfvol DESC)      AS Rank_AbsChg_ContriB_PfVol,
  RANK() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_c,0) DESC)  AS Rank_ContriB_PfVol_Curr,

  -- ---------- contribution to portfolio volatility (percent) ----------
  pfvol_c                                                         AS ContriB_PfVol_Pct_{{C}},
  pfvol_p                                                         AS ContriB_PfVol_Pct_{{P}},
  chg_pfvol                                                       AS Chg_ContriB_PfVol_PctPts,
  abs_chg_pfvol                                                   AS AbsChg_ContriB_PfVol_PctPts,
  SAFE_DIVIDE(chg_pfvol, pfvol_p) * 100                           AS RelChg_ContriB_PfVol_Pct,
  share_c * 100                                                   AS PctShare_PfVol_Pct_{{C}},
  share_p * 100                                                   AS PctShare_PfVol_Pct_{{P}},
  (IFNULL(share_c,0) - IFNULL(share_p,0)) * 100                   AS Chg_PctShare_PfVol_PctPts,
  SAFE_DIVIDE(chg_pfvol, chg_pf_vol) * 100                        AS PctOfPortfolioVolChg_Pct,

  syspfvol_c                                                      AS ContriB_SysPfVol_Pct_{{C}},
  syspfvol_p                                                      AS ContriB_SysPfVol_Pct_{{P}},
  IFNULL(syspfvol_c,0) - IFNULL(syspfvol_p,0)                     AS Chg_ContriB_SysPfVol_PctPts,
  specpfvol_c                                                     AS ContriB_SpecPfVol_Pct_{{C}},
  specpfvol_p                                                     AS ContriB_SpecPfVol_Pct_{{P}},
  IFNULL(specpfvol_c,0) - IFNULL(specpfvol_p,0)                   AS Chg_ContriB_SpecPfVol_PctPts,

  -- ---------- benchmark volatility (percent) and tracking error (bps) ----------
  bmvol_c                                                         AS ContriB_BmVol_Pct_{{C}},
  bmvol_p                                                         AS ContriB_BmVol_Pct_{{P}},
  IFNULL(bmvol_c,0) - IFNULL(bmvol_p,0)                           AS Chg_ContriB_BmVol_PctPts,
  te_c    * 100                                                   AS ContriB_TE_bps_{{C}},
  te_p    * 100                                                   AS ContriB_TE_bps_{{P}},
  (IFNULL(te_c,0) - IFNULL(te_p,0)) * 100                         AS Chg_ContriB_TE_bps,
  SAFE_DIVIDE(IFNULL(te_c,0) - IFNULL(te_p,0), te_p) * 100        AS RelChg_ContriB_TE_Pct,
  syste_c  * 100                                                  AS ContriB_SysTE_bps_{{C}},
  syste_p  * 100                                                  AS ContriB_SysTE_bps_{{P}},
  (IFNULL(syste_c,0) - IFNULL(syste_p,0)) * 100                   AS Chg_ContriB_SysTE_bps,
  specte_c * 100                                                  AS ContriB_SpecTE_bps_{{C}},
  specte_p * 100                                                  AS ContriB_SpecTE_bps_{{P}},
  (IFNULL(specte_c,0) - IFNULL(specte_p,0)) * 100                 AS Chg_ContriB_SpecTE_bps,

  -- ---------- portfolio-level context (same on every row of a portfolio) ----------
  pf_vol_c                                                        AS PortfolioVol_Pct_{{C}},
  pf_vol_p                                                        AS PortfolioVol_Pct_{{P}},
  chg_pf_vol                                                      AS Chg_PortfolioVol_PctPts,
  SAFE_DIVIDE(chg_pf_vol, pf_vol_p) * 100                         AS RelChg_PortfolioVol_Pct,
  pf_te_c * 100                                                   AS PortfolioTE_bps_{{C}},
  pf_te_p * 100                                                   AS PortfolioTE_bps_{{P}},
  chg_pf_te * 100                                                 AS Chg_PortfolioTE_bps,
  SAFE_DIVIDE(chg_pf_te, pf_te_p) * 100                           AS RelChg_PortfolioTE_Pct,
  n_sec_c                                                         AS SecurityCount_{{C}},
  n_sec_p                                                         AS SecurityCount_{{P}},
  n_new                                                           AS NewPositions_Portfolio,
  n_exit                                                          AS ExitedPositions_Portfolio,

  -- ---------- weights and exposure (percent) ----------
  mw_pf_c                                                         AS MarketWeight_Pf_Pct_{{C}},
  mw_pf_p                                                         AS MarketWeight_Pf_Pct_{{P}},
  chg_mw_pf                                                       AS Chg_MarketWeight_Pf_PctPts,
  SAFE_DIVIDE(chg_mw_pf, mw_pf_p) * 100                           AS RelChg_MarketWeight_Pf_Pct,
  mw_bm_c                                                         AS MarketWeight_Bm_Pct_{{C}},
  mw_bm_p                                                         AS MarketWeight_Bm_Pct_{{P}},
  IFNULL(mw_bm_c,0) - IFNULL(mw_bm_p,0)                           AS Chg_MarketWeight_Bm_PctPts,
  IFNULL(mw_pf_c,0) - IFNULL(mw_bm_c,0)                           AS ActiveWeight_Pct_{{C}},
  IFNULL(mw_pf_p,0) - IFNULL(mw_bm_p,0)                           AS ActiveWeight_Pct_{{P}},
  (IFNULL(mw_pf_c,0) - IFNULL(mw_bm_c,0))
    - (IFNULL(mw_pf_p,0) - IFNULL(mw_bm_p,0))                     AS Chg_ActiveWeight_PctPts,
  mv_pf_c                                                         AS MarketValue_Pf_{{C}},
  mv_pf_p                                                         AS MarketValue_Pf_{{P}},
  IFNULL(mv_pf_c,0) - IFNULL(mv_pf_p,0)                           AS Chg_MarketValue_Pf,
  umv_pf_c                                                        AS UserMarketValue_Pf_{{C}},
  umv_pf_p                                                        AS UserMarketValue_Pf_{{P}},
  nw_pf_c                                                         AS NotionalWeight_Pf_Pct_{{C}},
  nw_pf_p                                                         AS NotionalWeight_Pf_Pct_{{P}},
  IFNULL(nw_pf_c,0) - IFNULL(nw_pf_p,0)                           AS Chg_NotionalWeight_Pf_PctPts,
  nwb_pf_c                                                        AS NotionalWeightBuy_Pct_{{C}},
  nwb_pf_p                                                        AS NotionalWeightBuy_Pct_{{P}},
  nws_pf_c                                                        AS NotionalWeightSell_Pct_{{C}},
  nws_pf_p                                                        AS NotionalWeightSell_Pct_{{P}},

  -- ---------- EXPOSURE WEIGHT: use this for the drill-down, not market weight ----------
  -- Notional for derivative lines, market weight for everything else. ExposureBasis names
  -- which was used, so commentary can state it rather than assume it.
  IF(is_deriv, 'Notional', 'Market')                              AS ExposureBasis,
  IF(is_deriv, 'Y', 'N')                                          AS IsDerivative,
  exp_wt_c                                                        AS ExposureWeight_Pct_{{C}},
  exp_wt_p                                                        AS ExposureWeight_Pct_{{P}},
  chg_exp_wt                                                      AS Chg_ExposureWeight_PctPts,
  SAFE_DIVIDE(chg_exp_wt, exp_wt_p) * 100                         AS RelChg_ExposureWeight_Pct,

  -- ---------- duration (years; DurationContrib is percent x years) ----------
  ed_c                                                            AS EffectiveDuration_{{C}},
  ed_p                                                            AS EffectiveDuration_{{P}},
  ed_c - ed_p                                                     AS Chg_EffectiveDuration,   -- level, NULL on entry/exit
  mdur_c                                                          AS ModifiedDuration_{{C}},
  mdur_p                                                          AS ModifiedDuration_{{P}},
  mdur_c - mdur_p                                                 AS Chg_ModifiedDuration,
  sd_c                                                            AS EffectiveSpreadDuration_{{C}},
  sd_p                                                            AS EffectiveSpreadDuration_{{P}},
  sd_c - sd_p                                                     AS Chg_EffectiveSpreadDuration,
  mw_pf_c * ed_c                                                  AS DurationContrib_{{C}},
  mw_pf_p * ed_p                                                  AS DurationContrib_{{P}},
  IFNULL(mw_pf_c * ed_c, 0) - IFNULL(mw_pf_p * ed_p, 0)           AS Chg_DurationContrib,
  -- spread duration contribution: the credit-risk equivalent of DurationContrib
  mw_pf_c * sd_c                                                  AS SpreadDurationContrib_{{C}},
  mw_pf_p * sd_p                                                  AS SpreadDurationContrib_{{P}},
  IFNULL(mw_pf_c * sd_c, 0) - IFNULL(mw_pf_p * sd_p, 0)           AS Chg_SpreadDurationContrib,

  -- ---------- model, curve and data-quality inputs ----------
  -- NOTE: YieldCurve holds the curve NAME. YieldCurveChanged = the curve assigned to this
  -- security changed. It does NOT mean rates moved.
  yc_c                                                            AS YieldCurve_{{C}},
  yc_p                                                            AS YieldCurve_{{P}},
  f_yc                                                            AS YieldCurveChanged,
  -- REFERENCE ONLY. VolatilityModel is not used in any flag, tag or roll-up, and
  -- commentary must not draw conclusions from it.
  vm_c                                                            AS VolatilityModel_RefOnly_{{C}},
  vm_p                                                            AS VolatilityModel_RefOnly_{{P}},
  mn_c                                                            AS ModelName_{{C}},
  mn_p                                                            AS ModelName_{{P}},
  f_mn                                                            AS ModelNameChanged,
  md_c                                                            AS ModelDate_{{C}},
  md_p                                                            AS ModelDate_{{P}},
  job_pf_c                                                        AS JobExecutionID_Pf_{{C}},
  job_pf_p                                                        AS JobExecutionID_Pf_{{P}},
  job_bm_c                                                        AS JobExecutionID_Bm_{{C}},
  job_bm_p                                                        AS JobExecutionID_Bm_{{P}},
  f_md                                                            AS ModelDateChanged,
  lag_c                                                           AS ModelLagDays_{{C}},
  lag_p                                                           AS ModelLagDays_{{P}},
  lag_c - lag_p                                                   AS Chg_ModelLagDays,
  mt_c                                                            AS ModellyingTypeCode_{{C}},
  mt_p                                                            AS ModellyingTypeCode_{{P}},
  f_mt                                                            AS ModellyingTypeCodeChanged,
  ud_c                                                            AS UsedData_{{C}},
  ud_p                                                            AS UsedData_{{P}},
  f_ud                                                            AS UsedDataChanged,
  dp_c                                                            AS DataPoints_{{C}},
  dp_p                                                            AS DataPoints_{{P}},
  f_dp                                                            AS DataPointsChanged,
  chg_datapoints                                                  AS Chg_DataPoints,
  SAFE_DIVIDE(chg_datapoints, dpn_p) * 100                        AS RelChg_DataPoints_Pct,
  it_c                                                            AS IdType_{{C}},
  it_p                                                            AS IdType_{{P}},
  f_it                                                            AS IdTypeChanged,
  -- IdUsedInAnalytics is THE identifier for commentary: it holds the ISIN where IdType
  -- says ISIN, and falls back to the internal code for futures, swaps and cash.
  ia_c                                                            AS IdUsedInAnalytics_{{C}},
  ia_p                                                            AS IdUsedInAnalytics_{{P}},
  miss_c                                                          AS MissingAssetPercent_Pct_{{C}},
  miss_p                                                          AS MissingAssetPercent_Pct_{{P}},
  miss_c - miss_p                                                 AS Chg_MissingAssetPercent_PctPts,
  any_model_changed                                               AS AnyModelInputChanged,

  -- ---------- ratings ----------
  mdy_c                                                           AS MOODYS_{{C}},
  mdy_p                                                           AS MOODYS_{{P}},
  sp_c                                                            AS SP_{{C}},
  sp_p                                                            AS SP_{{P}},
  fit_c                                                           AS FITCH_{{C}},
  fit_p                                                           AS FITCH_{{P}},
  f_rating                                                        AS RatingChanged,
  rating_direction                                                AS RatingDirection,
  rating_notches_down                                             AS RatingNotchesDowngraded,
  rn_c                                                            AS RatingNotch_{{C}},
  rn_p                                                            AS RatingNotch_{{P}},
  rating_curve_linked                                             AS RatingDrivenCurveChange,

  -- ---------- descriptors for slicing the drill-down ----------
  SecurityType,
  AssetClassification,
  BorrowerClassificationName,
  COALESCE(ss_c, ss_p)                                            AS SecuritySectorName,
  f_ss                                                            AS SecuritySectorChanged,
  COALESCE(cr_c, cr_p)                                            AS Country_of_Risk,
  f_cr                                                            AS CountryOfRiskChanged,
  APTIssuer,
  APTCurrency,
  Line,
  BuyCurrency,
  SellCurrency,
  CompositionCode_Pf,
  CompositionName_Pf,
  CompositionCode_Bm,

  -- ---------- pre-written factual sentence for the LLM to rewrite, not invent ----------
  FORMAT(
    '%s (%s), %s, %s: contribution to portfolio vol %.4f%% -> %.4f%% '
    || '(%+.4f pp, %s relative). Contribution to tracking error %.1f bps -> %.1f bps '
    || '(%+.1f bps). Fund %s weight %.3f%% -> %.3f%% (%+.3f pp). '
    || 'Share of portfolio vol %.2f%% -> %.2f%%. Accounts for %.1f%% of the portfolio vol '
    || 'change. Status %s. Model inputs changed: %s. Rating changed: %s. Yield curve changed: %s.',
    IFNULL(SecurityName, '(unnamed)'),
    IFNULL(COALESCE(ia_c, ia_p), IFNULL(SecurityCode, '(no id)')),
    IFNULL(Line, '(no line)'),
    IFNULL(AssetClassification, '(no asset class)'),
    IFNULL(pfvol_p, 0), IFNULL(pfvol_c, 0), IFNULL(chg_pfvol, 0),
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(chg_pfvol, pfvol_p) * 100), 'n/a'),
    IFNULL(te_p, 0) * 100, IFNULL(te_c, 0) * 100,
    (IFNULL(te_c,0) - IFNULL(te_p,0)) * 100,
    IF(is_deriv, 'notional', 'market'),
    IFNULL(exp_wt_p, 0), IFNULL(exp_wt_c, 0), IFNULL(chg_exp_wt, 0),
    IFNULL(share_p, 0) * 100, IFNULL(share_c, 0) * 100,
    IFNULL(SAFE_DIVIDE(chg_pfvol, chg_pf_vol), 0) * 100,
    holding_status,
    any_model_changed, f_rating, f_yc
  )                                                               AS CommentaryNote

FROM final2
ORDER BY PortfolioCode, abs_chg_pfvol DESC, SecurityCode
""";

-- Substitute the ddmmyyyy suffixes into the column aliases, then run.
SET stmt = REPLACE(REPLACE(tpl, '{{C}}', s_curr), '{{P}}', s_prev);

EXECUTE IMMEDIATE stmt
  USING cob_curr        AS cc,
        cob_prev        AS cp,
        portfolio_codes AS pcs,
        vol_tolerance   AS vtol,
        weight_tolerance AS wtol;
