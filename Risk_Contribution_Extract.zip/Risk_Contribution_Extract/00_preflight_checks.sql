-- =====================================================================================
-- 00_preflight_checks.sql
-- Run this BEFORE risk_contribution_pairwise.sql.
-- It validates the assumptions the main query relies on. Six result sets, unioned into
-- one output so a single Run tells you whether the pair-wise extract will be sound.
--
-- Table: hsbc-237274-amgrisk-prod.elmo.risk_contribution  (partitioned on ValuationDate)
-- =====================================================================================

-- ================== EDIT THESE THREE LINES ==================
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
-- ============================================================

WITH base AS (
  SELECT *
  FROM `hsbc-237274-amgrisk-prod.elmo.risk_contribution`
  WHERE ValuationDate IN (cob_curr, cob_prev)          -- partition pruning
    AND PortfolioCode IN UNNEST(portfolio_codes)
),

-- 1. Does each portfolio have rows on BOTH dates? A missing half silently produces a
--    CSV full of NULLs on one side, which reads as "everything was a new position".
chk_coverage AS (
  SELECT
    1                                                          AS Seq,
    'COVERAGE'                                                 AS Check_Name,
    PortfolioCode                                              AS Subject,
    FORMAT('curr_rows=%d  prev_rows=%d',
           COUNTIF(ValuationDate = cob_curr),
           COUNTIF(ValuationDate = cob_prev))                  AS Detail,
    IF(COUNTIF(ValuationDate = cob_curr) > 0
       AND COUNTIF(ValuationDate = cob_prev) > 0,
       'OK', 'FAIL - one COB has no rows')                     AS Verdict
  FROM base
  GROUP BY PortfolioCode
),

-- 2. Multiple load jobs for the same COB? The main queries keep ONLY the rows carrying
--    MAX(JobExecutionID) for that ValuationDate x PortfolioCode -- the latest load taken
--    as a whole set. Everything from an earlier job is dropped, not merged.
--
--    That is safe when a re-load is a full replacement. It is NOT safe if a re-load is
--    partial: the rows the re-run did not carry disappear from the analysis entirely.
--    Check 2b below is the one that tells you which case you are in.
chk_jobs AS (
  SELECT
    2,
    'DUPLICATE_LOADS',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('distinct_jobs=%d  max_job=%d  latest_import=%t',
           COUNT(DISTINCT JobExecutionID),
           MAX(JobExecutionID),
           MAX(ImportDateTime)),
    IF(COUNT(DISTINCT JobExecutionID) = 1,
       'OK', 'WARN - multiple loads; main query keeps the latest job only')
  FROM base
  GROUP BY PortfolioCode, ValuationDate
),

-- 2b. PARTIAL RE-LOAD. Only fires where a COB has more than one job. Compares the row
--     count of the latest job against the largest EARLIER job for the same COB and
--     portfolio. If the latest job is smaller, the extract silently loses the positions
--     the re-run did not carry -- and because the remaining contributions still sum to
--     their own total, Recon_Verdict in 01_portfolio_summary.sql will still say PASS.
--     This is the only check that catches that case.
job_rows AS (
  SELECT PortfolioCode, ValuationDate, JobExecutionID, COUNT(*) AS n_rows
  FROM base
  GROUP BY PortfolioCode, ValuationDate, JobExecutionID
),
job_ranked AS (
  SELECT jr.*, MAX(JobExecutionID) OVER w AS latest_job
  FROM job_rows jr
  WINDOW w AS (PARTITION BY PortfolioCode, ValuationDate)
),
job_pair AS (
  SELECT
    PortfolioCode,
    ValuationDate,
    ANY_VALUE(latest_job)                               AS latest_job,
    MAX(IF(JobExecutionID = latest_job, n_rows, NULL))  AS latest_rows,
    MAX(IF(JobExecutionID < latest_job, n_rows, NULL))  AS prior_max_rows
  FROM job_ranked
  GROUP BY PortfolioCode, ValuationDate
  HAVING COUNT(*) > 1
),
chk_partial AS (
  SELECT
    3,
    'PARTIAL_RELOAD',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('latest_job=%d rows=%d  |  largest_earlier_job rows=%d  |  delta=%d',
           latest_job, latest_rows, prior_max_rows, latest_rows - prior_max_rows),
    IF(latest_rows < prior_max_rows,
       'WARN - latest load is SMALLER than an earlier one; positions will be dropped. Confirm the re-run was a full replacement before using this extract.',
       'OK - latest load is not smaller than any earlier load')
  FROM job_pair
),

-- 3. THE CRITICAL ONE. The main query keys on (PortfolioCode, SecurityCode). If a single
--    security appears under more than one CompositionCode on the same side of the same
--    date, that key collides and the pivot will silently drop rows.
chk_key_uniqueness AS (
  SELECT
    4,
    'KEY_COLLISION',
    FORMAT('%s @ %t  IsPortfolio=%t', PortfolioCode, ValuationDate, IsPortfolio),
    FORMAT('colliding_securities=%d', COUNTIF(n_comp > 1)),
    IF(COUNTIF(n_comp > 1) = 0,
       'OK',
       'FAIL - add CompositionCode to the join key in the main query')
  FROM (
    SELECT PortfolioCode, ValuationDate, IsPortfolio, SecurityCode,
           COUNT(DISTINCT CompositionCode) AS n_comp
    FROM base
    GROUP BY 1,2,3,4
  )
  GROUP BY PortfolioCode, ValuationDate, IsPortfolio
),

-- 3b. WHICH SIDE IS WHICH. Both main queries split every metric on IsPortfolio: portfolio
--     weights, durations, ratings and ContriB_PfVol / ContriB_TE are read from the rows
--     where IsPortfolio is TRUE, and benchmark weights and ContriB_BmVol from the rows
--     where it is FALSE. Two things would silently break that:
--
--       - a NULL IsPortfolio. The queries default it to TRUE, so a NULL row is counted as a
--         fund holding and inflates every contribution. That is a defensible default only
--         because this check refuses to let it pass unnoticed.
--       - the contribution columns living on the opposite side to the one assumed. In the
--         sampled portfolio ContriB_TE and ContriB_BmVol were both NULL, so which row
--         carries them was never actually observed. If the system writes ContriB_BmVol on
--         the portfolio row, the _Bm_ columns come back empty and nothing else complains.
chk_sides AS (
  SELECT
    5,
    'ISPORTFOLIO_SIDES',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('pf_rows=%d bm_rows=%d null_flag=%d | PfVol pf/bm=%d/%d | TE pf/bm=%d/%d | BmVol pf/bm=%d/%d',
           COUNTIF(IsPortfolio),
           COUNTIF(NOT IsPortfolio),
           COUNTIF(IsPortfolio IS NULL),
           COUNTIF(IsPortfolio AND ContriB_PfVol IS NOT NULL),
           COUNTIF(NOT IsPortfolio AND ContriB_PfVol IS NOT NULL),
           COUNTIF(IsPortfolio AND ContriB_TE IS NOT NULL),
           COUNTIF(NOT IsPortfolio AND ContriB_TE IS NOT NULL),
           COUNTIF(IsPortfolio AND ContriB_BmVol IS NOT NULL),
           COUNTIF(NOT IsPortfolio AND ContriB_BmVol IS NOT NULL)),
    CASE
      WHEN COUNTIF(IsPortfolio IS NULL) > 0
        THEN 'FAIL - IsPortfolio is NULL on some rows; the queries treat NULL as the portfolio side, which would inflate contributions'
      WHEN COUNTIF(IsPortfolio) = 0
        THEN 'FAIL - no portfolio-side rows for this COB'
      -- TE is COMMON to both sides and is summed as-is, so a split across TRUE and FALSE
      -- rows is expected here and is not an error. This line only reports the split.
      WHEN COUNTIF(IsPortfolio AND ContriB_PfVol IS NOT NULL) = 0
        THEN 'FAIL - no ContriB_PfVol on the portfolio side; portfolio volatility cannot be summed'
      WHEN COUNTIF(NOT IsPortfolio) > 0
           AND COUNTIF(NOT IsPortfolio AND ContriB_BmVol IS NOT NULL) = 0
        THEN 'WARN - benchmark rows exist but carry no ContriB_BmVol; benchmark volatility will be empty'
      WHEN COUNTIF(NOT IsPortfolio) = 0
        THEN 'INFO - no benchmark rows; side split is moot, _Bm_ and TE columns will be empty'
      ELSE 'OK - sides are as the queries assume'
    END
  FROM base
  GROUP BY PortfolioCode, ValuationDate
),

-- 4. Model / curve / vol-model vintage per date. Tells you upfront whether the
--    ModelDateChanged and YieldCurveChanged flags will fire across the whole book
--    (a methodology change) rather than name by name (a genuine reclassification).
chk_model AS (
  SELECT
    6,
    'MODEL_VINTAGE',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    -- VolatilityModel is deliberately not reported: it is excluded from all analysis.
    FORMAT('models=[%s]  model_dates=[%s]  curves=%d  obs_windows=[%s]  max_model_lag_days=%d',
           IFNULL(STRING_AGG(DISTINCT ModelName        ORDER BY ModelName        LIMIT 5), '(none)'),
           IFNULL(STRING_AGG(DISTINCT FORMAT('%t', ModelDate) ORDER BY FORMAT('%t', ModelDate) LIMIT 5), '(none)'),
           COUNT(DISTINCT CurrentYieldCurve),
           IFNULL(STRING_AGG(DISTINCT DataPoints       ORDER BY DataPoints       LIMIT 5), '(none)'),
           IFNULL(MAX(DATE_DIFF(ValuationDate, ModelDate, DAY)), -1)),
    IF(IFNULL(MAX(DATE_DIFF(ValuationDate, ModelDate, DAY)), 0) > 30,
       'WARN - risk model is more than 30 days stale',
       'OK')
  FROM base
  GROUP BY PortfolioCode, ValuationDate
),

-- 5. Will the benchmark and tracking-error columns actually be populated? In the sampled
--    portfolio every ContriB_TE / ContriB_BmVol was NULL. Knowing this before you export
--    saves you reading a CSV of empty columns as a data error.
chk_benchmark AS (
  SELECT
    7,
    'BENCHMARK_TE',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('bm_side_rows=%d  nonnull_ContriB_BmVol=%d  nonnull_ContriB_TE=%d  benchmark=%s',
           COUNTIF(NOT IsPortfolio),
           COUNTIF(ContriB_BmVol IS NOT NULL),
           COUNTIF(ContriB_TE    IS NOT NULL),
           IFNULL(MAX(BenchmarkCode), '(none)')),
    CASE
      WHEN COUNTIF(NOT IsPortfolio) = 0
        THEN 'INFO - no benchmark rows; _Bm_ and TE columns will be empty'
      WHEN COUNTIF(ContriB_TE IS NOT NULL) = 0
        THEN 'INFO - benchmark rows present but TE contributions are all NULL'
      ELSE 'OK'
    END
  FROM base
  GROUP BY PortfolioCode, ValuationDate
),

-- 6. Do the vol contributions sum to something that looks like a portfolio volatility?
--    The main query treats SUM(ContriB_PfVol) as total portfolio vol. That is only valid
--    if these are true marginal contributions. Compare this number against the risk
--    system's reported portfolio vol before trusting any derived percentage.
-- 7. Did the BENCHMARK change between the two dates? If it did, the tracking error
--    comparison is meaningless - you would be comparing risk against two different things.
chk_benchmark_identity AS (
  SELECT
    9,
    'BENCHMARK_IDENTITY',
    PortfolioCode,
    FORMAT('prev=%s  curr=%s',
           IFNULL(MAX(IF(ValuationDate = cob_prev, BenchmarkCode, NULL)), '(none)'),
           IFNULL(MAX(IF(ValuationDate = cob_curr, BenchmarkCode, NULL)), '(none)')),
    IF(MAX(IF(ValuationDate = cob_prev, BenchmarkCode, NULL))
       = MAX(IF(ValuationDate = cob_curr, BenchmarkCode, NULL)),
       'OK',
       'FAIL - benchmark changed; do NOT compare tracking error across these dates')
  FROM base
  GROUP BY PortfolioCode
),

-- 8. Do the portfolio weights sum to roughly 100? If not, the fund is not fully
--    represented and every contribution figure is understated.
chk_weight_sum AS (
  SELECT
    10,
    'WEIGHT_COMPLETENESS',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('sum_MarketWeight=%.4f  max_MissingAssetPercent=%.4f',
           IFNULL(SUM(SAFE_CAST(MarketWeight AS FLOAT64)), 0),
           IFNULL(MAX(SAFE_CAST(MissingAssetPercent AS FLOAT64)), 0)),
    CASE
      WHEN ABS(IFNULL(SUM(SAFE_CAST(MarketWeight AS FLOAT64)), 0) - 100) > 5
        THEN 'WARN - weights are more than 5 points away from 100'
      WHEN IFNULL(MAX(SAFE_CAST(MissingAssetPercent AS FLOAT64)), 0) > 0
        THEN 'WARN - some assets are missing from the risk calculation'
      ELSE 'OK'
    END
  FROM base
  WHERE IsPortfolio
  GROUP BY PortfolioCode, ValuationDate
),

chk_vol_sum AS (
  SELECT
    8,
    'VOL_SUM_SANITY',
    FORMAT('%s @ %t', PortfolioCode, ValuationDate),
    FORMAT('sum_ContriB_PfVol=%.6f  sum_sys=%.6f  sum_spec=%.6f  n_sec=%d  sum_MarketWeight=%.6f',
           IFNULL(SUM(SAFE_CAST(ContriB_PfVol     AS FLOAT64)), 0),
           IFNULL(SUM(SAFE_CAST(ContriB_SysPfVol  AS FLOAT64)), 0),
           IFNULL(SUM(SAFE_CAST(ContriB_SpecPfVol AS FLOAT64)), 0),
           COUNT(DISTINCT SecurityCode),
           IFNULL(SUM(SAFE_CAST(MarketWeight      AS FLOAT64)), 0)),
    'INFO - verify sum_ContriB_PfVol against the risk system reported vol'
  FROM base
  WHERE IsPortfolio
  GROUP BY PortfolioCode, ValuationDate
)

SELECT * FROM chk_coverage
UNION ALL SELECT * FROM chk_jobs
UNION ALL SELECT * FROM chk_partial
UNION ALL SELECT * FROM chk_key_uniqueness
UNION ALL SELECT * FROM chk_sides
UNION ALL SELECT * FROM chk_model
UNION ALL SELECT * FROM chk_benchmark
UNION ALL SELECT * FROM chk_benchmark_identity
UNION ALL SELECT * FROM chk_weight_sum
UNION ALL SELECT * FROM chk_vol_sum
ORDER BY Seq, Subject;
