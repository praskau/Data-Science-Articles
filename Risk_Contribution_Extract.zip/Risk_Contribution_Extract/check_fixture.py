#!/usr/bin/env python3
"""Structural and semantic checks on the generated commentary JSON.

validate_sql.py checks the SQL text; this checks the document the SQL produces, using the
fixture as a stand-in. json.loads() is the parse check -- a malformed document raises here
rather than silently reaching the model. The reconciliation identity is the one the whole design rests on --
if named_up + named_down + all_other stops equalling the headline, the commentary stops
being able to close its own arithmetic.

    python3 check_fixture.py
"""
import json, pathlib, re, sys

MAT_ACTIVE_WEIGHT, MAT_BM_WEIGHT, MAT_WINDOW_REL, MAT_DURATION = 0.50, 0.25, 20.0, 0.25
HERE = pathlib.Path(__file__).resolve().parent
DOC = next((HERE / "dummy_data").glob("dummy_commentary_*.json"))

fails = []
def chk(name, ok, detail=""):
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail and not ok else ""))
    if not ok:
        fails.append(name)

raw = DOC.read_text()
doc = json.loads(raw)                      # raises on malformed JSON -- that IS the check
funds = doc["funds"]
drivers = [(f, d) for f in funds for d in f["drivers"]]

print("DOCUMENT")
chk("parses as JSON", True)
chk("no null values anywhere -- absence is by omission", ": null" not in raw)
chk("no empty strings", '""' not in raw.replace('": "', "X"))
chk("no whitespace-only lines", not re.search(r"(?m)^[ \t]+$", raw))
chk("an unescaped & survives (JSON does not escape it)",
    any("&" in d["name"] for _, d in drivers) and "&amp;" not in raw)
chk("fixed decimals survive -- 1.1000 not 1.1", re.search(r": \d+\.\d{4}[,}]", raw) is not None)
chk("under 25 KB", len(raw) < 25_000, f"{len(raw)/1024:.1f} KB")

print("\nRECONCILIATION -- the identity the design rests on")
for f in funds:
    r = f["reconciliation"]
    h, u, d, o = (r[k] for k in ("headline", "named_up", "named_down", "all_other"))
    n = len(f["drivers"])
    chk(f"{f['code']:10s} {u:+7.1f} {d:+7.1f} {o:+7.1f} = {h:+7.1f}"
        f"  [{r['breadth']:12s} {n} of {r['total_names']}]", abs(u + d + o - h) < 0.051)
    chk(f"{f['code']:10s} names_shown matches driver count", r["names_shown"] == n)
    chk(f"{f['code']:10s} recon verdict is PASS", f["checks"]["recon"] == "PASS")

print("\nDRIVERS")
chk("ranks strictly increasing within each fund",
    all([d["rank"] for d in f["drivers"]] == sorted(d["rank"] for d in f["drivers"])
        for f in funds))
chk("every driver has side, id, name and a change",
    all(d.get("side") in ("UP", "DOWN") and d.get("id") and d.get("name")
        and d.get("te_change_bps") is not None for _, d in drivers))
chk("every driver carries at least one contribution level",
    all("te_prev_bps" in d or "te_curr_bps" in d for _, d in drivers))
chk("side matches the sign of the change",
    all((d["te_change_bps"] >= 0) == (d["side"] == "UP") for _, d in drivers))
chk("a NEW position has no prior level",
    all("te_prev_bps" not in d for _, d in drivers if d.get("status") == "NEW"))
chk("an EXITED position has no current level",
    all("te_curr_bps" not in d for _, d in drivers if d.get("status") == "EXITED"))

print("\nMATERIALITY GATE -- absence must mean 'not material', never 'missing'")
chk(f"no active_weight_change below {MAT_ACTIVE_WEIGHT}%",
    all(abs(d["active_weight_change"]) >= MAT_ACTIVE_WEIGHT
        for _, d in drivers if "active_weight_change" in d))
chk(f"no benchmark_weight_change below {MAT_BM_WEIGHT}%",
    all(abs(d["benchmark_weight_change"]) >= MAT_BM_WEIGHT
        for _, d in drivers if "benchmark_weight_change" in d))
chk("no duration pair below the floor",
    all(abs(d["duration_curr"] - d["duration_prev"]) >= MAT_DURATION
        for _, d in drivers if "duration_prev" in d))
# This one runs FIRST: the differ-checks below index both halves, so a half-emitted pair
# would crash them with a KeyError instead of reporting a named failure.
PAIRS = ("curve", "rating", "observations")
chk("both halves of every pair are present, never one",
    all((f"{k}_prev" in d) == (f"{k}_curr" in d) for _, d in drivers for k in PAIRS))
for k in PAIRS:
    chk(f"a {k} pair is only ever emitted when the two values differ",
        all(d.get(f"{k}_prev") != d.get(f"{k}_curr")
            for _, d in drivers if f"{k}_prev" in d or f"{k}_curr" in d))

print("\nMUST-SHOW -- the causes a holdings report cannot show are never cut")
rated = [(f["code"], d["name"]) for f, d in drivers if "rating_direction" in d]
windo = [(f["code"], d["name"]) for f, d in drivers if "observations_prev" in d]
chk("every fund reporting a downgrade names the security",
    all(any(c == f["code"] for c, _ in rated)
        for f in funds if f.get("model_changes", {}).get("downgraded", 0) > 0),
    "model_changes says one was downgraded but no driver carries rating_direction")
print(f"    ratings shown: {rated}")
print(f"    windows shown: {windo}")

print("\n" + ("ALL CHECKS PASS" if not fails else f"{len(fails)} FAILURE(S)"))
sys.exit(1 if fails else 0)
