#!/usr/bin/env python3
"""Structural and semantic checks on the generated commentary XML.

validate_sql.py checks the SQL text; this checks the document the SQL produces, using the
fixture as a stand-in. The reconciliation identity is the one the whole design rests on --
if named_up + named_down + all_other stops equalling the headline, the commentary stops
being able to close its own arithmetic.

    python3 check_fixture.py
"""
import pathlib, re, sys, xml.etree.ElementTree as ET

MAT_ACTIVE_WEIGHT, MAT_BM_WEIGHT, MAT_WINDOW_REL, MAT_DURATION = 0.50, 0.25, 20.0, 0.25
HERE = pathlib.Path(__file__).resolve().parent
XML = next((HERE / "dummy_data").glob("dummy_commentary_*.xml"))

fails = []
def chk(name, ok, detail=""):
    print(f"  {'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail and not ok else ""))
    if not ok:
        fails.append(name)

raw = XML.read_text()
root = ET.fromstring(raw)
drivers = [(f, d) for f in root.findall("fund") for d in f.find("drivers").findall("driver")]

print("DOCUMENT")
chk("parses as XML", True)
chk("no empty attributes", '=""' not in raw)
chk("no whitespace-only lines", not re.search(r"(?m)^[ \t]+$", raw))
chk("ampersand round-trips", "&amp;" in raw and any("&" in (d.text or "") for _, d in drivers))
chk("under 25 KB", len(raw) < 25_000, f"{len(raw)/1024:.1f} KB")

print("\nRECONCILIATION -- the identity the design rests on")
for f in root.findall("fund"):
    r = f.find("reconciliation")
    h, u, d, o = (float(r.get(k)) for k in ("headline", "named_up", "named_down", "all_other"))
    n = len(f.find("drivers").findall("driver"))
    chk(f"{f.get('code'):10s} {u:+7.1f} {d:+7.1f} {o:+7.1f} = {h:+7.1f}"
        f"  [{r.get('breadth'):12s} {n} of {r.get('total_names')}]", abs(u + d + o - h) < 0.051)
    chk(f"{f.get('code'):10s} names_shown matches driver count", int(r.get("names_shown")) == n)
    chk(f"{f.get('code'):10s} recon verdict is PASS", f.find("checks").get("recon") == "PASS")

print("\nDRIVERS")
def fl(d, a):
    v = d.get(a)
    return None if v is None else float(v)

chk("ranks strictly increasing within each fund",
    all([int(d.get("rank")) for d in f.find("drivers").findall("driver")]
        == sorted(int(d.get("rank")) for d in f.find("drivers").findall("driver"))
        for f in root.findall("fund")))
chk("every driver has side, id and a change",
    all(d.get("side") in ("UP", "DOWN") and d.get("id") is not None
        and d.get("te_change_bps") is not None for _, d in drivers))
chk("every driver carries at least one contribution level",
    all(d.get("te_prev_bps") or d.get("te_curr_bps") for _, d in drivers))
chk("side matches the sign of the change",
    all((fl(d, "te_change_bps") >= 0) == (d.get("side") == "UP") for _, d in drivers))
chk("a NEW position has no prior level",
    all(d.get("te_prev_bps") is None for _, d in drivers if d.get("status") == "NEW"))
chk("an EXITED position has no current level",
    all(d.get("te_curr_bps") is None for _, d in drivers if d.get("status") == "EXITED"))

print("\nMATERIALITY GATE -- absence must mean 'not material', never 'missing'")
chk(f"no active_weight_change below {MAT_ACTIVE_WEIGHT}%",
    all(abs(fl(d, "active_weight_change")) >= MAT_ACTIVE_WEIGHT
        for _, d in drivers if d.get("active_weight_change")))
chk(f"no benchmark_weight_change below {MAT_BM_WEIGHT}%",
    all(abs(fl(d, "benchmark_weight_change")) >= MAT_BM_WEIGHT
        for _, d in drivers if d.get("benchmark_weight_change")))
chk("no duration pair below the floor",
    all(abs(fl(d, "duration_curr") - fl(d, "duration_prev")) >= MAT_DURATION
        for _, d in drivers if d.get("duration_prev")))
chk("a curve pair is only ever emitted when the two names differ",
    all(d.get("curve_prev") != d.get("curve_curr") for _, d in drivers if d.get("curve_prev")))
chk("a rating pair is only ever emitted when the two grades differ",
    all(d.get("rating_prev") != d.get("rating_curr") for _, d in drivers if d.get("rating_prev")))
chk("an observation pair is only ever emitted when the counts differ",
    all(d.get("observations_prev") != d.get("observations_curr")
        for _, d in drivers if d.get("observations_prev")))

print("\nMUST-SHOW -- the causes a holdings report cannot show are never cut")
rated = [(f.get("code"), d.text) for f, d in drivers if d.get("rating_direction")]
windo = [(f.get("code"), d.text) for f, d in drivers if d.get("observations_prev")]
chk("every fund reporting a downgrade names the security",
    all(any(c == f.get("code") for c, _ in rated)
        for f in root.findall("fund")
        if f.find("model_changes") is not None
        and int(f.find("model_changes").get("downgraded", 0)) > 0),
    "model_changes says one was downgraded but no driver carries rating_direction")
print(f"    ratings shown: {rated}")
print(f"    windows shown: {windo}")

print("\n" + ("ALL CHECKS PASS" if not fails else f"{len(fails)} FAILURE(S)"))
sys.exit(1 if fails else 0)
