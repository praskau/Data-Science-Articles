-- =====================================================================================
-- risk_drilldown.sql
--
-- Two-COB portfolio risk drill-down over
--     hsbc-237274-amgrisk-prod.elmo.risk_contribution
--
-- Produces ONE row per PortfolioCode x SecurityCode, with every metric carried for both
-- COB dates side by side and the period-over-period calculations embedded.
--
-- PLAIN SQL. No EXECUTE IMMEDIATE, no string templating. Paste it, edit the three DECLARE
-- lines, Run. Every CTE can be selected from on its own while debugging: comment out the
-- final SELECT and put `SELECT * FROM pivot LIMIT 50` in its place.
--
-- COLUMN NAMING
--   Dated columns end in _Curr or _Prev      -> ContriB_PfVol_Pct_Curr
--   The dates themselves are columns         -> ValuationDate_Curr, ValuationDate_Prev
--   Computed / delta columns keep static names -> Chg_ContriB_PfVol_PctPts
--
-- IsPortfolio SEMANTICS
--   TRUE  -> every column on the row describes the PORTFOLIO
--   FALSE -> every column on the row describes the BENCHMARK
--   Exception: the ContriB_TE family is COMMON to both sides and is summed across all
--   rows without filtering. Portfolio volatility sums ContriB_PfVol over TRUE rows only;
--   benchmark volatility sums ContriB_BmVol over FALSE rows only.
--
-- HOW TO RUN
--   1. Run 00_preflight_checks.sql first.
--   2. Edit the three DECLARE lines below.
--   3. Run.  Then: Save results -> CSV.
--
-- READ THE CAVEATS IN README.md BEFORE TRUSTING THE DERIVED PERCENTAGES.
-- =====================================================================================

-- ================== EDIT THESE THREE LINES ==================
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';   -- current COB
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';   -- prior COB
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
-- ============================================================

-- Materiality floor for DriverTag classification, in the same units as ContriB_PfVol.
-- DRIVER SELECTION.
-- The commentary names the few securities that carry the movement and reconciles them to
-- the fund's headline change; everything else collapses into a single residual line. So the
-- cut is directional -- risers and offsets are chosen separately -- rather than a single
-- ranked list. Raising max_named_per_side names more of each and shrinks the residual.
DECLARE max_named_per_side INT64   DEFAULT 4;      -- risers named, and offsets named
DECLARE side_target        FLOAT64 DEFAULT 0.85;   -- stop once this much of a side is named
DECLARE broad_max_names    INT64   DEFAULT 10;     -- table rows when no name carries the move

-- Breadth, from the share of gross movement carried by the top three names. A concentrated
-- move gets prose naming the securities; a broad one gets a table and a sentence saying the
-- impact is spread. Tune on real funds -- these are set from the three test funds, which
-- sit at 66%, 71% and 67%.
DECLARE concentrated_floor FLOAT64 DEFAULT 0.50;
DECLARE broad_ceiling      FLOAT64 DEFAULT 0.25;

-- Materiality floors for the cause attributes. Below these a change is not emitted at all,
-- so it cannot be reported. Without them every driver carries a weight move of 0.006% and
-- the commentary flags noise as if it were a decision.
DECLARE mat_active_weight  FLOAT64 DEFAULT 0.50;   -- percentage points
DECLARE mat_bm_weight      FLOAT64 DEFAULT 0.25;   -- percentage points
DECLARE mat_window_rel     FLOAT64 DEFAULT 20.0;   -- percent change in observation count
DECLARE mat_duration       FLOAT64 DEFAULT 0.25;   -- years

DECLARE vol_tolerance    FLOAT64 DEFAULT 0.0001;
DECLARE weight_tolerance FLOAT64 DEFAULT 0.000001;

IF cob_curr = cob_prev THEN
  RAISE USING MESSAGE = 'cob_curr and cob_prev must differ.';
END IF;

-- XML helpers. Escaping is not optional: a security called "SPDR S&P 500 ETF TRUST" emits a
-- bare & and a parser rejects the whole document. num() exists because a NULL inside FORMAT
-- renders as the literal text "NULL", which would read as a value.
CREATE TEMP FUNCTION json_escape(s STRING) AS (
  -- Backslash FIRST, or the escapes introduced after it get escaped a second time.
  -- Note JSON needs LESS escaping than XML did: & < > are ordinary characters here, so
  -- "SPDR S&P 500 ETF TRUST" passes through untouched.
  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
    IFNULL(s, ''), '\\', '\\\\'), '"', '\"'), '\n', '\\n'), '\r', '\\r'), '\t', '\\t')
);

-- Fixed decimals, not %g: the commentary quotes what it is given, so 348.0 must not
-- arrive as 348 and 1.1000 must not arrive as 1.1.
CREATE TEMP FUNCTION num(x FLOAT64, places INT64) AS (
  IF(x IS NULL, '',
     CASE places
       WHEN 0 THEN FORMAT('%.0f', x)
       WHEN 1 THEN FORMAT('%.1f', x)
       WHEN 2 THEN FORMAT('%.2f', x)
       WHEN 3 THEN FORMAT('%.3f', x)
       WHEN 4 THEN FORMAT('%.4f', x)
       ELSE CAST(x AS STRING)
     END)
);

-- JSON key builders. Each returns NULL when the value is absent, and ARRAY_TO_STRING skips
-- NULL elements -- so an absent field emits no key AND no dangling comma, with no counting of
-- placeholders against arguments anywhere. That removes the whole bug class the FORMAT
-- templates were prone to.
CREATE TEMP FUNCTION jnum(k STRING, x FLOAT64, places INT64) AS (
  IF(x IS NULL, NULL, FORMAT('"%s": %s', k, num(x, places)))
);
CREATE TEMP FUNCTION jstr(k STRING, v STRING) AS (
  IF(v IS NULL OR v = '', NULL, FORMAT('"%s": "%s"', k, json_escape(v)))
);
CREATE TEMP FUNCTION jobj(k STRING, parts ARRAY<STRING>) AS (
  IF(ARRAY_TO_STRING(parts, '') = '', NULL,
     FORMAT('"%s": {%s}', k, ARRAY_TO_STRING(parts, ', ')))
);

CREATE TEMP TABLE drilldown AS (
WITH base AS (
  SELECT *
  FROM `hsbc-237274-amgrisk-prod.elmo.risk_contribution`
  WHERE ValuationDate IN (cob_curr, cob_prev)                 -- partition pruning: keep this first
    AND PortfolioCode IN UNNEST(portfolio_codes)
),

-- A COB can be loaded more than once. Take the LATEST LOAD AS A WHOLE -- not the latest
-- version of each row. Pick MAX(JobExecutionID) per ValuationDate x PortfolioCode and keep
-- only rows carrying that job id.
--
-- Row-level dedup is wrong here. If a re-run loads 48 of the 50 positions, picking the
-- latest row per security keeps the 48 corrected rows and silently carries the 2 stale rows
-- from the previous job. The result is a portfolio blended across two model vintages that
-- still sums to a plausible total and still reconciles -- the worst kind of wrong.
-- 00_preflight_checks.sql reports when the latest job is smaller than the one before it.
latest_job AS (
  SELECT ValuationDate, PortfolioCode, MAX(JobExecutionID) AS max_job
  FROM base
  GROUP BY ValuationDate, PortfolioCode
),
dedup AS (
  SELECT * EXCEPT(rn)
  FROM (
    SELECT
      b.*,
      -- Second net: the same job re-inserting an identical natural key.
      ROW_NUMBER() OVER (
        PARTITION BY b.ValuationDate, b.PortfolioCode, b.CompositionCode,
                     b.IsPortfolio, b.SecurityCode
        ORDER BY b.ImportDateTime DESC
      ) AS rn
    FROM base b
    JOIN latest_job l
      ON  b.ValuationDate  = l.ValuationDate
      AND b.PortfolioCode  = l.PortfolioCode
      AND b.JobExecutionID = l.max_job
  )
  WHERE rn = 1
),

-- Normalise types once. Four fields are numerics stored as STRING, and the ContriB_Sys*
-- fields are FLOAT while their siblings are BIGNUMERIC - BigQuery will not mix the two
-- in arithmetic, so everything becomes FLOAT64 here.
typed AS (
  SELECT
    PortfolioCode,
    SecurityCode,
    -- carried through because `pivot` reports the winning load per side (job_pf_c and its
    -- three siblings), so the commentary can show which load each figure came from.
    JobExecutionID,
    (ValuationDate = cob_curr)       AS is_curr,
    IFNULL(IsPortfolio, TRUE)   AS is_pf,
    PortfolioName, BenchmarkCode, BenchmarkName,
    CompositionCode, CompositionName,
    ModelName, ModelDate, CurrentYieldCurve, VolatilityModel, UsedData, DataPoints,
    IdType, IdUsedInAnalytics, ModellyingTypeCode,
    SecurityName, SecurityType, AssetClassification, BorrowerClassificationName,
    SecuritySectorName, Country_of_Risk, APTIssuer, APTCurrency, Line,
    BuyCurrency, SellCurrency, MOODYS_L, SP_L, FITCH_L,
    DATE_DIFF(ValuationDate, ModelDate, DAY)            AS model_lag_days,
    -- WEIGHT SCALE. MarketWeight and the notional weights are stored as FRACTIONS:
    -- a real run showed the portfolio side summing to 0.9295, i.e. 92.95%. The ContriB_*
    -- family is NOT on that scale -- those are already percentage points (0.27 means
    -- 0.27%). So weights are scaled by 100 here and contributions are left alone.
    -- 00_preflight_checks.sql reports the raw sums so this can be re-confirmed per fund.
    SAFE_CAST(MarketWeight            AS FLOAT64) * 100  AS mkt_wt,
    SAFE_CAST(MarketValue             AS FLOAT64)       AS mkt_val,
    SAFE_CAST(UserMarketValue         AS FLOAT64)       AS usr_mkt_val,
    SAFE_CAST(NotionalWeight          AS FLOAT64) * 100  AS notl_wt,
    SAFE_CAST(NotionalWeightBuy       AS FLOAT64) * 100  AS notl_buy,
    SAFE_CAST(NotionalWeightSell      AS FLOAT64) * 100  AS notl_sell,
    SAFE_CAST(MissingAssetPercent     AS FLOAT64)       AS miss_pct,
    SAFE_CAST(EffectiveDuration       AS FLOAT64)       AS eff_dur,
    SAFE_CAST(ModifiedDuration        AS FLOAT64)       AS mod_dur,
    SAFE_CAST(EffectiveSpreadDuration AS FLOAT64)       AS spr_dur,
    -- Rating on a single 1-22 notch scale (1 = AAA, 22 = D). Moodys and SP/Fitch codes
    -- share the scale. Worst of the three available agencies, the conservative convention.
    NULLIF(GREATEST(
      IFNULL(CASE UPPER(TRIM(IFNULL(MOODYS_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(SP_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0),
      IFNULL(CASE UPPER(TRIM(IFNULL(FITCH_L, '')))
      WHEN 'AAA' THEN 1  WHEN 'AA+' THEN 2  WHEN 'AA'  THEN 3  WHEN 'AA-' THEN 4
      WHEN 'A+'  THEN 5  WHEN 'A'   THEN 6  WHEN 'A-'  THEN 7
      WHEN 'BBB+' THEN 8 WHEN 'BBB' THEN 9  WHEN 'BBB-' THEN 10
      WHEN 'BB+' THEN 11 WHEN 'BB'  THEN 12 WHEN 'BB-' THEN 13
      WHEN 'B+'  THEN 14 WHEN 'B'   THEN 15 WHEN 'B-'  THEN 16
      WHEN 'CCC+' THEN 17 WHEN 'CCC' THEN 18 WHEN 'CCC-' THEN 19
      WHEN 'CC'  THEN 20 WHEN 'C'   THEN 21 WHEN 'D' THEN 22
      WHEN 'AAA' THEN 1
      WHEN 'AA1' THEN 2  WHEN 'AA2' THEN 3  WHEN 'AA3' THEN 4
      WHEN 'A1'  THEN 5  WHEN 'A2'  THEN 6  WHEN 'A3'  THEN 7
      WHEN 'BAA1' THEN 8 WHEN 'BAA2' THEN 9 WHEN 'BAA3' THEN 10
      WHEN 'BA1' THEN 11 WHEN 'BA2' THEN 12 WHEN 'BA3' THEN 13
      WHEN 'B1'  THEN 14 WHEN 'B2'  THEN 15 WHEN 'B3'  THEN 16
      WHEN 'CAA1' THEN 17 WHEN 'CAA2' THEN 18 WHEN 'CAA3' THEN 19
      WHEN 'CA'  THEN 20
      ELSE NULL END, 0)
    ), 0)                                               AS rating_notch,
    SAFE_CAST(DataPoints              AS FLOAT64)       AS dp_num,
    SAFE_CAST(ContriB_PfVol           AS FLOAT64)       AS c_pfvol,
    SAFE_CAST(ContriB_SysPfVol        AS FLOAT64)       AS c_syspfvol,
    SAFE_CAST(ContriB_SpecPfVol       AS FLOAT64)       AS c_specpfvol,
    SAFE_CAST(ContriB_BmVol           AS FLOAT64)       AS c_bmvol,
    SAFE_CAST(ContriB_TE              AS FLOAT64)       AS c_te,
    SAFE_CAST(ContriB_SysTE           AS FLOAT64)       AS c_syste,
    SAFE_CAST(ContriB_SpecTE          AS FLOAT64)       AS c_specte
  FROM dedup
),

-- Conditional aggregation into four slices: portfolio/benchmark side x current/prior.
-- A holding present on only one date simply yields NULL on the other side, which is how
-- entries and exits fall out without a FULL OUTER JOIN.
pivot AS (
  SELECT
    PortfolioCode,
    SecurityCode,

    -- descriptors: prefer current COB, fall back to prior so exited names stay labelled
    ARRAY_AGG(SecurityName IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                AS SecurityName,
    ARRAY_AGG(PortfolioName IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]               AS PortfolioName,
    ARRAY_AGG(BenchmarkCode IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]               AS BenchmarkCode,
    ARRAY_AGG(BenchmarkName IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]               AS BenchmarkName,
    ARRAY_AGG(SecurityType IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                AS SecurityType,
    ARRAY_AGG(AssetClassification IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]         AS AssetClassification,
    ARRAY_AGG(BorrowerClassificationName IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]  AS BorrowerClassificationName,
    ARRAY_AGG(APTIssuer IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                   AS APTIssuer,
    ARRAY_AGG(APTCurrency IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                 AS APTCurrency,
    ARRAY_AGG(Line IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                        AS Line,
    ARRAY_AGG(BuyCurrency IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                 AS BuyCurrency,
    ARRAY_AGG(SellCurrency IGNORE NULLS ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]                AS SellCurrency,
    MAX(IF(is_pf,      CompositionCode, NULL))                                                      AS CompositionCode_Pf,
    MAX(IF(NOT is_pf,  CompositionCode, NULL))                                                      AS CompositionCode_Bm,
    MAX(IF(is_pf,      CompositionName, NULL))                                                      AS CompositionName_Pf,

    -- security-level analytics attributes, per COB (portfolio side preferred)
    ARRAY_AGG(IF(is_curr, CurrentYieldCurve, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS yc_c,
    ARRAY_AGG(IF(NOT is_curr, CurrentYieldCurve, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS yc_p,
    ARRAY_AGG(IF(is_curr, VolatilityModel, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS vm_c,
    ARRAY_AGG(IF(NOT is_curr, VolatilityModel, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS vm_p,
    ARRAY_AGG(IF(is_curr, ModelName, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mn_c,
    ARRAY_AGG(IF(NOT is_curr, ModelName, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mn_p,
    ARRAY_AGG(IF(is_curr, ModelDate, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS md_c,
    ARRAY_AGG(IF(NOT is_curr, ModelDate, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS md_p,
    -- Which load each side of the pair came from. Carried through so a detail row can be
    -- traced back to its job, and so the two exports can be checked against each other.
    MAX(IF(is_curr     AND is_pf, JobExecutionID, NULL))                                            AS job_pf_c,
    MAX(IF(NOT is_curr AND is_pf, JobExecutionID, NULL))                                            AS job_pf_p,
    MAX(IF(is_curr     AND NOT is_pf, JobExecutionID, NULL))                                        AS job_bm_c,
    MAX(IF(NOT is_curr AND NOT is_pf, JobExecutionID, NULL))                                        AS job_bm_p,
    ARRAY_AGG(IF(is_curr, model_lag_days, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS lag_c,
    ARRAY_AGG(IF(NOT is_curr, model_lag_days, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS lag_p,
    ARRAY_AGG(IF(is_curr, ModellyingTypeCode, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mt_c,
    ARRAY_AGG(IF(NOT is_curr, ModellyingTypeCode, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mt_p,
    ARRAY_AGG(IF(is_curr, UsedData, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ud_c,
    ARRAY_AGG(IF(NOT is_curr, UsedData, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ud_p,
    ARRAY_AGG(IF(is_curr, DataPoints, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS dp_c,
    ARRAY_AGG(IF(NOT is_curr, DataPoints, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS dp_p,
    ARRAY_AGG(IF(is_curr, IdType, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS it_c,
    ARRAY_AGG(IF(NOT is_curr, IdType, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS it_p,
    ARRAY_AGG(IF(is_curr, IdUsedInAnalytics, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ia_c,
    ARRAY_AGG(IF(NOT is_curr, IdUsedInAnalytics, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ia_p,
    ARRAY_AGG(IF(is_curr, SecuritySectorName, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ss_c,
    ARRAY_AGG(IF(NOT is_curr, SecuritySectorName, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS ss_p,
    ARRAY_AGG(IF(is_curr, Country_of_Risk, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS cr_c,
    ARRAY_AGG(IF(NOT is_curr, Country_of_Risk, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS cr_p,
    ARRAY_AGG(IF(is_curr, MOODYS_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mdy_c,
    ARRAY_AGG(IF(NOT is_curr, MOODYS_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS mdy_p,
    ARRAY_AGG(IF(is_curr, SP_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS sp_c,
    ARRAY_AGG(IF(NOT is_curr, SP_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS sp_p,
    ARRAY_AGG(IF(is_curr, FITCH_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS fit_c,
    ARRAY_AGG(IF(NOT is_curr, FITCH_L, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS fit_p,

    -- portfolio side, current / prior
    SUM(IF(is_curr     AND is_pf, mkt_wt,      NULL)) AS mw_pf_c,
    SUM(IF(NOT is_curr AND is_pf, mkt_wt,      NULL)) AS mw_pf_p,
    SUM(IF(is_curr     AND is_pf, mkt_val,     NULL)) AS mv_pf_c,
    SUM(IF(NOT is_curr AND is_pf, mkt_val,     NULL)) AS mv_pf_p,
    SUM(IF(is_curr     AND is_pf, usr_mkt_val, NULL)) AS umv_pf_c,
    SUM(IF(NOT is_curr AND is_pf, usr_mkt_val, NULL)) AS umv_pf_p,
    SUM(IF(is_curr     AND is_pf, notl_wt,     NULL)) AS nw_pf_c,
    SUM(IF(NOT is_curr AND is_pf, notl_wt,     NULL)) AS nw_pf_p,
    SUM(IF(is_curr     AND is_pf, notl_buy,    NULL)) AS nwb_pf_c,
    SUM(IF(NOT is_curr AND is_pf, notl_buy,    NULL)) AS nwb_pf_p,
    SUM(IF(is_curr     AND is_pf, notl_sell,   NULL)) AS nws_pf_c,
    SUM(IF(NOT is_curr AND is_pf, notl_sell,   NULL)) AS nws_pf_p,
    MAX(IF(is_curr     AND is_pf, miss_pct,    NULL)) AS miss_c,
    MAX(IF(NOT is_curr AND is_pf, miss_pct,    NULL)) AS miss_p,
    -- Durations across duplicate rows: EXPOSURE-WEIGHTED AVERAGE, not MAX. Two sleeves of
    -- the same bond normally carry the same duration, so this usually returns that value --
    -- but where they differ it is the only answer that keeps the identity
    -- SUM(weight_i * duration_i) = SUM(weight_i) * wavg_duration, which is what makes
    -- DurationContrib additive downstream.
    SAFE_DIVIDE(SUM(IF(is_curr     AND is_pf, eff_dur * mkt_wt, NULL)),
                SUM(IF(is_curr     AND is_pf AND eff_dur IS NOT NULL, mkt_wt, NULL))) AS ed_c,
    SAFE_DIVIDE(SUM(IF(NOT is_curr AND is_pf, eff_dur * mkt_wt, NULL)),
                SUM(IF(NOT is_curr AND is_pf AND eff_dur IS NOT NULL, mkt_wt, NULL))) AS ed_p,
    SAFE_DIVIDE(SUM(IF(is_curr     AND is_pf, mod_dur * mkt_wt, NULL)),
                SUM(IF(is_curr     AND is_pf AND mod_dur IS NOT NULL, mkt_wt, NULL))) AS mdur_c,
    SAFE_DIVIDE(SUM(IF(NOT is_curr AND is_pf, mod_dur * mkt_wt, NULL)),
                SUM(IF(NOT is_curr AND is_pf AND mod_dur IS NOT NULL, mkt_wt, NULL))) AS mdur_p,
    SAFE_DIVIDE(SUM(IF(is_curr     AND is_pf, spr_dur * mkt_wt, NULL)),
                SUM(IF(is_curr     AND is_pf AND spr_dur IS NOT NULL, mkt_wt, NULL))) AS sd_c,
    SAFE_DIVIDE(SUM(IF(NOT is_curr AND is_pf, spr_dur * mkt_wt, NULL)),
                SUM(IF(NOT is_curr AND is_pf AND spr_dur IS NOT NULL, mkt_wt, NULL))) AS sd_p,
    ARRAY_AGG(IF(is_curr, rating_notch, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS rn_c,
    ARRAY_AGG(IF(NOT is_curr, rating_notch, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)] AS rn_p,
    ARRAY_AGG(IF(is_curr, dp_num, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]       AS dpn_c,
    ARRAY_AGG(IF(NOT is_curr, dp_num, NULL) IGNORE NULLS ORDER BY is_pf DESC, mkt_wt DESC LIMIT 1)[SAFE_OFFSET(0)]       AS dpn_p,

    -- benchmark side, current / prior
    SUM(IF(is_curr     AND NOT is_pf, mkt_wt,  NULL)) AS mw_bm_c,
    SUM(IF(NOT is_curr AND NOT is_pf, mkt_wt,  NULL)) AS mw_bm_p,

    -- risk contributions
    SUM(IF(is_curr     AND is_pf, c_pfvol,     NULL)) AS pfvol_c,
    SUM(IF(NOT is_curr AND is_pf, c_pfvol,     NULL)) AS pfvol_p,
    SUM(IF(is_curr     AND is_pf, c_syspfvol,  NULL)) AS syspfvol_c,
    SUM(IF(NOT is_curr AND is_pf, c_syspfvol,  NULL)) AS syspfvol_p,
    SUM(IF(is_curr     AND is_pf, c_specpfvol, NULL)) AS specpfvol_c,
    SUM(IF(NOT is_curr AND is_pf, c_specpfvol, NULL)) AS specpfvol_p,
    SUM(IF(is_curr     AND NOT is_pf, c_bmvol,     NULL)) AS bmvol_c,
    SUM(IF(NOT is_curr AND NOT is_pf, c_bmvol,     NULL)) AS bmvol_p,
    -- TRACKING ERROR IS COMMON TO BOTH SIDES. Unlike every aggregate above, the ContriB_TE
    -- family is NOT filtered on is_pf -- it is summed across the portfolio and benchmark
    -- rows for the security on that date, exactly as it stands in the source.
    SUM(IF(is_curr,     c_te,     NULL))               AS te_c,
    SUM(IF(NOT is_curr, c_te,     NULL))               AS te_p,
    SUM(IF(is_curr,     c_syste,  NULL))               AS syste_c,
    SUM(IF(NOT is_curr, c_syste,  NULL))               AS syste_p,
    SUM(IF(is_curr,     c_specte, NULL))               AS specte_c,
    SUM(IF(NOT is_curr, c_specte, NULL))               AS specte_p

  FROM typed
  GROUP BY PortfolioCode, SecurityCode
),

-- Portfolio-level totals, carried onto every row so the CSV needs no second query and
-- each line can be read on its own.
calc AS (
  SELECT
    p.*,
    SUM(pfvol_c)                      OVER w AS pf_vol_c,
    SUM(pfvol_p)                      OVER w AS pf_vol_p,
    SUM(te_c)                         OVER w AS pf_te_c,
    SUM(te_p)                         OVER w AS pf_te_p,
    COUNTIF(pfvol_c IS NOT NULL)      OVER w AS n_sec_c,
    COUNTIF(pfvol_p IS NOT NULL)      OVER w AS n_sec_p,
    COUNTIF(mw_pf_c IS NOT NULL AND mw_pf_p IS NULL) OVER w AS n_new,
    COUNTIF(mw_pf_c IS NULL AND mw_pf_p IS NOT NULL) OVER w AS n_exit
  FROM pivot p
  WINDOW w AS (PARTITION BY PortfolioCode)
),

flags AS (
  SELECT
    c.*,
    -- Y / N / N-A. N-A where one COB is missing the holding, so an entry or exit is not
    -- misreported as a methodology change.
    CASE WHEN yc_c  IS NULL OR yc_p  IS NULL THEN 'N/A' WHEN yc_c  = yc_p  THEN 'N' ELSE 'Y' END AS f_yc,
    CASE WHEN mn_c  IS NULL OR mn_p  IS NULL THEN 'N/A' WHEN mn_c  = mn_p  THEN 'N' ELSE 'Y' END AS f_mn,
    CASE WHEN md_c  IS NULL OR md_p  IS NULL THEN 'N/A' WHEN md_c  = md_p  THEN 'N' ELSE 'Y' END AS f_md,
    CASE WHEN mt_c  IS NULL OR mt_p  IS NULL THEN 'N/A' WHEN mt_c  = mt_p  THEN 'N' ELSE 'Y' END AS f_mt,
    CASE WHEN ud_c  IS NULL OR ud_p  IS NULL THEN 'N/A' WHEN ud_c  = ud_p  THEN 'N' ELSE 'Y' END AS f_ud,
    CASE WHEN dp_c  IS NULL OR dp_p  IS NULL THEN 'N/A' WHEN dp_c  = dp_p  THEN 'N' ELSE 'Y' END AS f_dp,
    CASE WHEN it_c  IS NULL OR it_p  IS NULL THEN 'N/A' WHEN it_c  = it_p  THEN 'N' ELSE 'Y' END AS f_it,
    CASE WHEN ss_c  IS NULL OR ss_p  IS NULL THEN 'N/A' WHEN ss_c  = ss_p  THEN 'N' ELSE 'Y' END AS f_ss,
    CASE WHEN cr_c  IS NULL OR cr_p  IS NULL THEN 'N/A' WHEN cr_c  = cr_p  THEN 'N' ELSE 'Y' END AS f_cr,
    CASE
      WHEN mdy_c IS NULL AND sp_c IS NULL AND fit_c IS NULL THEN 'N/A'
      WHEN mdy_p IS NULL AND sp_p IS NULL AND fit_p IS NULL THEN 'N/A'
      WHEN IFNULL(mdy_c,'~') != IFNULL(mdy_p,'~')
        OR IFNULL(sp_c, '~') != IFNULL(sp_p, '~')
        OR IFNULL(fit_c,'~') != IFNULL(fit_p,'~') THEN 'Y'
      ELSE 'N'
    END AS f_rating
  FROM calc c
),

final AS (
  SELECT
    f.*,
    -- Additive quantities: a missing side is a genuine zero (entry from nothing, exit
    -- to nothing), so IFNULL keeps SUM(Chg_*) reconciling to the portfolio-level change.
    IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0)                         AS chg_pfvol,
    ABS(IFNULL(pfvol_c,0) - IFNULL(pfvol_p,0))                    AS abs_chg_pfvol,
    -- Ranking key when tracking error is the lead metric in the commentary.
    ABS(IFNULL(te_c,0) - IFNULL(te_p,0))                          AS abs_chg_te,
    IFNULL(mw_pf_c,0) - IFNULL(mw_pf_p,0)                         AS chg_mw_pf,

    -- EXPOSURE WEIGHT. A future or swap carries almost no market value - only margin and
    -- unrealised P&L - so market weight understates what the fund is actually exposed to.
    -- For derivative lines the exposure is the NOTIONAL weight. ExposureBasis says which
    -- one was used on each row, so nothing has to be assumed downstream.
    UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                'CDS', 'SWAPTION')
      OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%'                AS is_deriv,
    IF(UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                   'CDS', 'SWAPTION')
       OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%',
       nw_pf_c, mw_pf_c)                                                           AS exp_wt_c,
    IF(UPPER(IFNULL(Line, '')) IN ('FUTURE', 'SWAP', 'FORWARD', 'OPTION', 'FX FORWARD',
                                   'CDS', 'SWAPTION')
       OR UPPER(IFNULL(AssetClassification, '')) LIKE '%DERIVATIVE%',
       nw_pf_p, mw_pf_p)                                                           AS exp_wt_p,
    SAFE_DIVIDE(pfvol_c, pf_vol_c)                                AS share_c,
    SAFE_DIVIDE(pfvol_p, pf_vol_p)                                AS share_p,
    pf_vol_c - pf_vol_p                                           AS chg_pf_vol,
    pf_te_c  - pf_te_p                                            AS chg_pf_te,
    CASE WHEN mw_pf_c IS NOT NULL AND mw_pf_p IS NULL THEN 'NEW'
         WHEN mw_pf_c IS NULL AND mw_pf_p IS NOT NULL THEN 'EXITED'
         WHEN mw_pf_c IS NULL AND mw_pf_p IS NULL     THEN 'BENCHMARK_ONLY'
         ELSE 'HELD' END                                          AS holding_status,
    -- VolatilityModel is deliberately EXCLUDED from this roll-up and from every flag and
    -- tag below. It is carried as a reference field only and must not drive analysis.
    IF(f_yc = 'Y' OR f_mn = 'Y' OR f_md = 'Y'
       OR f_mt = 'Y' OR f_ud = 'Y' OR f_dp = 'Y' OR f_it = 'Y', 'Y', 'N')
                                                                  AS any_model_changed,

    -- Notches moved on the 1-22 scale. Positive = DOWNGRADED by that many notches.
    rn_c - rn_p                                                   AS rating_notches_down,
    CASE WHEN rn_c IS NULL OR rn_p IS NULL THEN 'N/A'
         WHEN rn_c > rn_p THEN 'DOWNGRADE'
         WHEN rn_c < rn_p THEN 'UPGRADE'
         ELSE 'UNCHANGED' END                                     AS rating_direction,

    -- A downgrade often re-maps the security onto a different (wider) yield curve, which
    -- then moves its volatility. When both flags fire together the two are one event, not
    -- two independent ones, and the rating is the cause.
    IF(f_rating = 'Y' AND f_yc = 'Y', 'Y', 'N')                   AS rating_curve_linked,

    -- DataPoints is the number of observations the volatility estimate is built on. A
    -- change here moves the vol number for estimation reasons alone.
    dpn_c - dpn_p                                                 AS chg_datapoints
  FROM flags f
),

-- exp_wt_c / exp_wt_p are defined in `final`, so the change is computed one level up
final2 AS (
  SELECT
    f.*,
    IFNULL(exp_wt_c, 0) - IFNULL(exp_wt_p, 0)                     AS chg_exp_wt
  FROM final f
),

-- =====================================================================================
-- ONE QUERY, TWO LEVELS.
--
-- `detail` is one row per security. `port` is one row per fund, built by AGGREGATING
-- `detail` -- not by re-aggregating the source table. That is the whole point: the fund
-- total is a SUM over exactly the rows it is meant to reconcile against, so the two can
-- never disagree. The previous split-file design summed the source once for the fund and
-- once per security; where a SecurityCode appeared under more than one CompositionCode
-- (fund-of-funds sleeves) the per-security side collapsed the duplicates with MAX while
-- the fund side summed them, and the reconciliation broke by exactly the dropped amount.
--
-- Tell the two apart with the RowType column: 'PORTFOLIO' or 'SECURITY'.
-- =====================================================================================
detail AS (
SELECT
  'SECURITY'                                                      AS RowType,
  -- ---------- identity ----------
  -- UNITS. Source values are already in PERCENTAGE POINTS: a stored 0.27 means 0.27%.
  --   _Pct     = a level in percent            (12.7290 reads 12.7290%)
  --   _PctPts  = an absolute change in percent (+1.1000 reads +1.1000 percentage points)
  --   _bps     = a level or change in basis points (percent x 100)
  --   RelChg_..._Pct = a RELATIVE change in percent ((curr / prior) - 1) x 100
  -- Tracking error is carried in bps throughout. Volatility and weights are carried in
  -- percent. Relative change is NULL where the prior value is zero or absent.
  PortfolioCode,
  PortfolioName,
  BenchmarkCode,
  BenchmarkName,
  cob_curr                                                             AS ValuationDate_Curr,
  cob_prev                                                             AS ValuationDate_Prev,
  SecurityCode,
  SecurityName,
  holding_status                                                  AS HoldingStatus,

  -- ---------- driver classification (the AI hook) ----------
  CASE
    WHEN holding_status = 'NEW'            THEN 'NEW_POSITION'
    WHEN holding_status = 'EXITED'         THEN 'EXITED_POSITION'
    WHEN holding_status = 'BENCHMARK_ONLY' THEN 'BENCHMARK_ONLY'
    WHEN IFNULL(abs_chg_pfvol, 0) < vol_tolerance  THEN 'IMMATERIAL'
    -- most specific cause first: a generic MODEL_INPUT_CHANGED tag would otherwise hide
    -- both the rating that caused a curve re-map and a changed estimation window
    WHEN rating_curve_linked = 'Y'         THEN 'RATING_DRIVEN_CURVE_CHANGE'
    WHEN f_dp = 'Y' AND f_yc = 'N' AND f_mn = 'N'
         AND f_md = 'N' AND f_mt = 'N'     THEN 'ESTIMATION_WINDOW_CHANGED'
    WHEN f_rating = 'Y'                    THEN 'RATING_MIGRATION'
    WHEN any_model_changed = 'Y'           THEN 'MODEL_INPUT_CHANGED'
    -- classified on EXPOSURE weight: notional for derivatives, market weight otherwise
    WHEN chg_pfvol > 0 AND IFNULL(chg_exp_wt, 0) >  weight_tolerance THEN 'VOL_UP_ON_WEIGHT_UP'
    WHEN chg_pfvol > 0                                    THEN 'VOL_UP_ON_RISK_UP'
    WHEN chg_pfvol < 0 AND IFNULL(chg_exp_wt, 0) < -weight_tolerance THEN 'VOL_DOWN_ON_WEIGHT_DOWN'
    WHEN chg_pfvol < 0                                    THEN 'VOL_DOWN_ON_RISK_DOWN'
    ELSE 'IMMATERIAL'
  END                                                             AS DriverTag,

  RANK() OVER (PARTITION BY PortfolioCode ORDER BY abs_chg_pfvol DESC)      AS Rank_AbsChg_ContriB_PfVol,
  RANK() OVER (PARTITION BY PortfolioCode ORDER BY abs_chg_te DESC)         AS Rank_AbsChg_ContriB_TE,
  RANK() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_c,0) DESC)  AS Rank_ContriB_PfVol_Curr,
  RANK() OVER (PARTITION BY PortfolioCode ORDER BY IFNULL(pfvol_p,0) DESC)  AS Rank_ContriB_PfVol_Prev,

  -- ---------- contribution to portfolio volatility (percent) ----------
  pfvol_c                                                         AS ContriB_PfVol_Pct_Curr,
  pfvol_p                                                         AS ContriB_PfVol_Pct_Prev,
  chg_pfvol                                                       AS Chg_ContriB_PfVol_PctPts,
  abs_chg_pfvol                                                   AS AbsChg_ContriB_PfVol_PctPts,
  abs_chg_te * 100                                                AS AbsChg_ContriB_TE_bps,
  SAFE_DIVIDE(chg_pfvol, pfvol_p) * 100                           AS RelChg_ContriB_PfVol_Pct,
  share_c * 100                                                   AS PctShare_PfVol_Pct_Curr,
  share_p * 100                                                   AS PctShare_PfVol_Pct_Prev,
  (IFNULL(share_c,0) - IFNULL(share_p,0)) * 100                   AS Chg_PctShare_PfVol_PctPts,
  SAFE_DIVIDE(chg_pfvol, chg_pf_vol) * 100                        AS PctOfPortfolioVolChg_Pct,

  syspfvol_c                                                      AS ContriB_SysPfVol_Pct_Curr,
  syspfvol_p                                                      AS ContriB_SysPfVol_Pct_Prev,
  IFNULL(syspfvol_c,0) - IFNULL(syspfvol_p,0)                     AS Chg_ContriB_SysPfVol_PctPts,
  specpfvol_c                                                     AS ContriB_SpecPfVol_Pct_Curr,
  specpfvol_p                                                     AS ContriB_SpecPfVol_Pct_Prev,
  IFNULL(specpfvol_c,0) - IFNULL(specpfvol_p,0)                   AS Chg_ContriB_SpecPfVol_PctPts,

  -- ---------- benchmark volatility (percent) and tracking error (bps) ----------
  bmvol_c                                                         AS ContriB_BmVol_Pct_Curr,
  bmvol_p                                                         AS ContriB_BmVol_Pct_Prev,
  IFNULL(bmvol_c,0) - IFNULL(bmvol_p,0)                           AS Chg_ContriB_BmVol_PctPts,
  te_c    * 100                                                   AS ContriB_TE_bps_Curr,
  te_p    * 100                                                   AS ContriB_TE_bps_Prev,
  (IFNULL(te_c,0) - IFNULL(te_p,0)) * 100                         AS Chg_ContriB_TE_bps,
  SAFE_DIVIDE(IFNULL(te_c,0) - IFNULL(te_p,0), te_p) * 100        AS RelChg_ContriB_TE_Pct,
  syste_c  * 100                                                  AS ContriB_SysTE_bps_Curr,
  syste_p  * 100                                                  AS ContriB_SysTE_bps_Prev,
  (IFNULL(syste_c,0) - IFNULL(syste_p,0)) * 100                   AS Chg_ContriB_SysTE_bps,
  specte_c * 100                                                  AS ContriB_SpecTE_bps_Curr,
  specte_p * 100                                                  AS ContriB_SpecTE_bps_Prev,
  (IFNULL(specte_c,0) - IFNULL(specte_p,0)) * 100                 AS Chg_ContriB_SpecTE_bps,

  -- ---------- portfolio-level context (same on every row of a portfolio) ----------
  pf_vol_c                                                        AS PortfolioVol_Pct_Curr,
  pf_vol_p                                                        AS PortfolioVol_Pct_Prev,
  chg_pf_vol                                                      AS Chg_PortfolioVol_PctPts,
  SAFE_DIVIDE(chg_pf_vol, pf_vol_p) * 100                         AS RelChg_PortfolioVol_Pct,
  pf_te_c * 100                                                   AS PortfolioTE_bps_Curr,
  pf_te_p * 100                                                   AS PortfolioTE_bps_Prev,
  chg_pf_te * 100                                                 AS Chg_PortfolioTE_bps,
  SAFE_DIVIDE(chg_pf_te, pf_te_p) * 100                           AS RelChg_PortfolioTE_Pct,
  n_sec_c                                                         AS SecurityCount_Curr,
  n_sec_p                                                         AS SecurityCount_Prev,
  n_new                                                           AS NewPositions_Portfolio,
  n_exit                                                          AS ExitedPositions_Portfolio,

  -- ---------- weights and exposure (percent) ----------
  mw_pf_c                                                         AS MarketWeight_Pf_Pct_Curr,
  mw_pf_p                                                         AS MarketWeight_Pf_Pct_Prev,
  chg_mw_pf                                                       AS Chg_MarketWeight_Pf_PctPts,
  SAFE_DIVIDE(chg_mw_pf, mw_pf_p) * 100                           AS RelChg_MarketWeight_Pf_Pct,
  mw_bm_c                                                         AS MarketWeight_Bm_Pct_Curr,
  mw_bm_p                                                         AS MarketWeight_Bm_Pct_Prev,
  IFNULL(mw_bm_c,0) - IFNULL(mw_bm_p,0)                           AS Chg_MarketWeight_Bm_PctPts,
  IFNULL(mw_pf_c,0) - IFNULL(mw_bm_c,0)                           AS ActiveWeight_Pct_Curr,
  IFNULL(mw_pf_p,0) - IFNULL(mw_bm_p,0)                           AS ActiveWeight_Pct_Prev,
  (IFNULL(mw_pf_c,0) - IFNULL(mw_bm_c,0))
    - (IFNULL(mw_pf_p,0) - IFNULL(mw_bm_p,0))                     AS Chg_ActiveWeight_PctPts,
  mv_pf_c                                                         AS MarketValue_Pf_Curr,
  mv_pf_p                                                         AS MarketValue_Pf_Prev,
  IFNULL(mv_pf_c,0) - IFNULL(mv_pf_p,0)                           AS Chg_MarketValue_Pf,
  umv_pf_c                                                        AS UserMarketValue_Pf_Curr,
  umv_pf_p                                                        AS UserMarketValue_Pf_Prev,
  nw_pf_c                                                         AS NotionalWeight_Pf_Pct_Curr,
  nw_pf_p                                                         AS NotionalWeight_Pf_Pct_Prev,
  IFNULL(nw_pf_c,0) - IFNULL(nw_pf_p,0)                           AS Chg_NotionalWeight_Pf_PctPts,
  nwb_pf_c                                                        AS NotionalWeightBuy_Pct_Curr,
  nwb_pf_p                                                        AS NotionalWeightBuy_Pct_Prev,
  nws_pf_c                                                        AS NotionalWeightSell_Pct_Curr,
  nws_pf_p                                                        AS NotionalWeightSell_Pct_Prev,

  -- ---------- EXPOSURE WEIGHT: use this for the drill-down, not market weight ----------
  -- Notional for derivative lines, market weight for everything else. ExposureBasis names
  -- which was used, so commentary can state it rather than assume it.
  IF(is_deriv, 'Notional', 'Market')                              AS ExposureBasis,
  IF(is_deriv, 'Y', 'N')                                          AS IsDerivative,
  exp_wt_c                                                        AS ExposureWeight_Pct_Curr,
  exp_wt_p                                                        AS ExposureWeight_Pct_Prev,
  chg_exp_wt                                                      AS Chg_ExposureWeight_PctPts,
  SAFE_DIVIDE(chg_exp_wt, exp_wt_p) * 100                         AS RelChg_ExposureWeight_Pct,

  -- ---------- duration (years; DurationContrib is percent x years) ----------
  ed_c                                                            AS EffectiveDuration_Curr,
  ed_p                                                            AS EffectiveDuration_Prev,
  ed_c - ed_p                                                     AS Chg_EffectiveDuration,   -- level, NULL on entry/exit
  mdur_c                                                          AS ModifiedDuration_Curr,
  mdur_p                                                          AS ModifiedDuration_Prev,
  mdur_c - mdur_p                                                 AS Chg_ModifiedDuration,
  sd_c                                                            AS EffectiveSpreadDuration_Curr,
  sd_p                                                            AS EffectiveSpreadDuration_Prev,
  sd_c - sd_p                                                     AS Chg_EffectiveSpreadDuration,
  mw_pf_c * ed_c                                                  AS DurationContrib_Curr,
  mw_pf_p * ed_p                                                  AS DurationContrib_Prev,
  IFNULL(mw_pf_c * ed_c, 0) - IFNULL(mw_pf_p * ed_p, 0)           AS Chg_DurationContrib,
  -- spread duration contribution: the credit-risk equivalent of DurationContrib
  mw_pf_c * sd_c                                                  AS SpreadDurationContrib_Curr,
  mw_pf_p * sd_p                                                  AS SpreadDurationContrib_Prev,
  IFNULL(mw_pf_c * sd_c, 0) - IFNULL(mw_pf_p * sd_p, 0)           AS Chg_SpreadDurationContrib,

  -- ---------- model, curve and data-quality inputs ----------
  -- NOTE: YieldCurve holds the curve NAME. YieldCurveChanged = the curve assigned to this
  -- security changed. It does NOT mean rates moved.
  yc_c                                                            AS YieldCurve_Curr,
  yc_p                                                            AS YieldCurve_Prev,
  f_yc                                                            AS YieldCurveChanged,
  -- REFERENCE ONLY. VolatilityModel is not used in any flag, tag or roll-up, and
  -- commentary must not draw conclusions from it.
  vm_c                                                            AS VolatilityModel_RefOnly_Curr,
  vm_p                                                            AS VolatilityModel_RefOnly_Prev,
  mn_c                                                            AS ModelName_Curr,
  mn_p                                                            AS ModelName_Prev,
  f_mn                                                            AS ModelNameChanged,
  md_c                                                            AS ModelDate_Curr,
  md_p                                                            AS ModelDate_Prev,
  job_pf_c                                                        AS JobExecutionID_Pf_Curr,
  job_pf_p                                                        AS JobExecutionID_Pf_Prev,
  job_bm_c                                                        AS JobExecutionID_Bm_Curr,
  job_bm_p                                                        AS JobExecutionID_Bm_Prev,
  f_md                                                            AS ModelDateChanged,
  lag_c                                                           AS ModelLagDays_Curr,
  lag_p                                                           AS ModelLagDays_Prev,
  lag_c - lag_p                                                   AS Chg_ModelLagDays,
  mt_c                                                            AS ModellyingTypeCode_Curr,
  mt_p                                                            AS ModellyingTypeCode_Prev,
  f_mt                                                            AS ModellyingTypeCodeChanged,
  ud_c                                                            AS UsedData_Curr,
  ud_p                                                            AS UsedData_Prev,
  f_ud                                                            AS UsedDataChanged,
  dp_c                                                            AS DataPoints_Curr,
  dp_p                                                            AS DataPoints_Prev,
  f_dp                                                            AS DataPointsChanged,
  chg_datapoints                                                  AS Chg_DataPoints,
  SAFE_DIVIDE(chg_datapoints, dpn_p) * 100                        AS RelChg_DataPoints_Pct,
  it_c                                                            AS IdType_Curr,
  it_p                                                            AS IdType_Prev,
  f_it                                                            AS IdTypeChanged,
  -- IdUsedInAnalytics is THE identifier for commentary: it holds the ISIN where IdType
  -- says ISIN, and falls back to the internal code for futures, swaps and cash.
  ia_c                                                            AS IdUsedInAnalytics_Curr,
  ia_p                                                            AS IdUsedInAnalytics_Prev,
  miss_c                                                          AS MissingAssetPercent_Pct_Curr,
  miss_p                                                          AS MissingAssetPercent_Pct_Prev,
  miss_c - miss_p                                                 AS Chg_MissingAssetPercent_PctPts,
  any_model_changed                                               AS AnyModelInputChanged,

  -- ---------- ratings ----------
  mdy_c                                                           AS MOODYS_Curr,
  mdy_p                                                           AS MOODYS_Prev,
  sp_c                                                            AS SP_Curr,
  sp_p                                                            AS SP_Prev,
  fit_c                                                           AS FITCH_Curr,
  fit_p                                                           AS FITCH_Prev,
  f_rating                                                        AS RatingChanged,
  rating_direction                                                AS RatingDirection,
  rating_notches_down                                             AS RatingNotchesDowngraded,
  rn_c                                                            AS RatingNotch_Curr,
  rn_p                                                            AS RatingNotch_Prev,
  rating_curve_linked                                             AS RatingDrivenCurveChange,

  -- ---------- descriptors for slicing the drill-down ----------
  SecurityType,
  AssetClassification,
  BorrowerClassificationName,
  COALESCE(ss_c, ss_p)                                            AS SecuritySectorName,
  f_ss                                                            AS SecuritySectorChanged,
  COALESCE(cr_c, cr_p)                                            AS Country_of_Risk,
  f_cr                                                            AS CountryOfRiskChanged,
  APTIssuer,
  APTCurrency,
  Line,
  BuyCurrency,
  SellCurrency,
  CompositionCode_Pf,
  CompositionName_Pf,
  CompositionCode_Bm,

  -- ---------- pre-written factual sentence for the LLM to rewrite, not invent ----------
  FORMAT(
    '%s (%s), %s, %s: contribution to portfolio vol %.4f%% -> %.4f%% '
    || '(%+.4f pp, %s relative). Contribution to tracking error %.1f bps -> %.1f bps '
    || '(%+.1f bps). Fund %s weight %.3f%% -> %.3f%% (%+.3f pp). '
    || 'Share of portfolio vol %.2f%% -> %.2f%%. Accounts for %.1f%% of the portfolio vol '
    || 'change. Status %s. Model inputs changed: %s. Rating changed: %s. Yield curve changed: %s.',
    IFNULL(SecurityName, '(unnamed)'),
    IFNULL(COALESCE(ia_c, ia_p), IFNULL(SecurityCode, '(no id)')),
    IFNULL(Line, '(no line)'),
    IFNULL(AssetClassification, '(no asset class)'),
    IFNULL(pfvol_p, 0), IFNULL(pfvol_c, 0), IFNULL(chg_pfvol, 0),
    IFNULL(FORMAT('%+.1f%%', SAFE_DIVIDE(chg_pfvol, pfvol_p) * 100), 'n/a'),
    IFNULL(te_p, 0) * 100, IFNULL(te_c, 0) * 100,
    (IFNULL(te_c,0) - IFNULL(te_p,0)) * 100,
    IF(is_deriv, 'notional', 'market'),
    IFNULL(exp_wt_p, 0), IFNULL(exp_wt_c, 0), IFNULL(chg_exp_wt, 0),
    IFNULL(share_p, 0) * 100, IFNULL(share_c, 0) * 100,
    IFNULL(SAFE_DIVIDE(chg_pfvol, chg_pf_vol), 0) * 100,
    holding_status,
    any_model_changed, f_rating, f_yc
  )                                                               AS CommentaryNote,

  -- ---------- fund-level columns: NULL on a security row ----------
  CAST(NULL AS INT64)                                             AS HeldPositions,
  CAST(NULL AS INT64)                                             AS NewPositions,
  CAST(NULL AS INT64)                                             AS ExitedPositions,
  CAST(NULL AS INT64)                                             AS BenchmarkOnlyPositions,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_HeldPositions_PctPts,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_NewPositions_PctPts,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_ExitedPositions_PctPts,
  CAST(NULL AS INT64)                                             AS SecuritiesWithModelInputChange,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_ModelInputChanges_PctPts,
  CAST(NULL AS INT64)                                             AS SecuritiesDowngraded,
  CAST(NULL AS INT64)                                             AS SecuritiesUpgraded,
  CAST(NULL AS INT64)                                             AS SecuritiesWithRatingDrivenCurveChange,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_RatingDrivenCurveChange_PctPts,
  CAST(NULL AS INT64)                                             AS SecuritiesWithEstimationWindowChange,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_EstimationWindowChange_PctPts,
  CAST(NULL AS INT64)                                             AS SecuritiesWithYieldCurveChange,
  CAST(NULL AS INT64)                                             AS DerivativePositions_Curr,
  CAST(NULL AS FLOAT64)                                           AS VolChg_From_Derivatives_PctPts,
  CAST(NULL AS INT64)                                             AS CurrencyCount_Curr,
  CAST(NULL AS FLOAT64)                                           AS Turnover_ExposureWeight_PctPts,
  CAST(NULL AS INT64)                                             AS ShortOrNegativePositions_Curr,
  CAST(NULL AS STRING)                                            AS BenchmarkChanged,

  -- ---------- reconciliation tripwire ----------
  CAST(NULL AS FLOAT64)                                           AS Recon_SumOfSecurityChanges_PctPts,
  CAST(NULL AS FLOAT64)                                           AS Recon_Diff_PctPts,
  CAST(NULL AS STRING)                                            AS Recon_Verdict,

  -- ---------- fund-level context ----------
  CAST(NULL AS FLOAT64)                                           AS Chg_SystematicVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS Chg_SpecificVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS BenchmarkVol_Pct_Curr,
  CAST(NULL AS FLOAT64)                                           AS BenchmarkVol_Pct_Prev,
  CAST(NULL AS FLOAT64)                                           AS Chg_BenchmarkVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS RelChg_BenchmarkVol_Pct,
  CAST(NULL AS FLOAT64)                                           AS FundMarketValue_Curr,
  CAST(NULL AS FLOAT64)                                           AS FundMarketValue_Prev,
  CAST(NULL AS FLOAT64)                                           AS RelChg_FundMarketValue_Pct,
  CAST(NULL AS FLOAT64)                                           AS Top5ShareOfVol_Pct_Curr,
  CAST(NULL AS FLOAT64)                                           AS Top5ShareOfVol_Pct_Prev,
  CAST(NULL AS FLOAT64)                                           AS Chg_Top5ShareOfVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS MaxMissingAssetPercent_Pct_Curr,
  CAST(NULL AS STRING)                                            AS LeadMetric,
  CAST(NULL AS FLOAT64)                                           AS LeadAbsChg,
  CAST(NULL AS INT64)                                             AS LeadRank,
  CAST(NULL AS FLOAT64)                                           AS CumCoverage_Pct,
  CAST(NULL AS STRING)                                            AS InCommentary,
  CAST(NULL AS INT64)                                             AS NamesShown,
  CAST(NULL AS INT64)                                             AS TotalNames,
  CAST(NULL AS FLOAT64)                                           AS CoverageAchieved_Pct,
  CAST(NULL AS FLOAT64)                                           AS GrossLeadAbsChg,
  -- placeholders for the reconciliation, filled by `ranked` and `port`. They are declared
  -- here so both UNION halves are the same width and the flat CSV export carries them too.
  CAST(NULL AS FLOAT64)                                           AS LeadSignedChg,
  CAST(NULL AS FLOAT64)                                           AS Named_Up,
  CAST(NULL AS FLOAT64)                                           AS Named_Down,
  CAST(NULL AS FLOAT64)                                           AS All_Other,
  CAST(NULL AS FLOAT64)                                           AS Top3ShareOfGross_Pct,
  CAST(NULL AS STRING)                                            AS Breadth,
  CAST(NULL AS FLOAT64)                                           AS ResidualShareOfHeadline_Pct

FROM final2
),


-- =====================================================================================
-- DRIVER SELECTION, done here rather than by whoever reads the export.
--
-- The commentary states the fund's headline change and then names the securities that
-- produced it, closing the arithmetic with a residual line. That needs the cut to be
-- DIRECTIONAL: the names that pushed the metric up are chosen separately from the names
-- that pulled it back, because a single ranked list of absolute movers can fill up with
-- risers and leave the reader unable to see why the fund moved less than they did.
--
-- Each side takes names in order of size until side_target of that side is named, capped
-- at max_named_per_side (the target usually binds first; the cap is a safety rail).
-- Everything not named -- both sides, and every security below the
-- cut -- lands in All_Other, which is computed by subtraction from the fund's own headline
-- figure so the three parts always sum to it exactly.
--
-- Where no name carries the move (Breadth = 'BROAD') the directional cut is abandoned and
-- the top broad_max_names by absolute size are emitted instead, for a table.
-- =====================================================================================
ranked AS (
  SELECT
    * EXCEPT(LeadMetric, LeadAbsChg, LeadRank, CumCoverage_Pct, InCommentary,
             NamesShown, TotalNames, CoverageAchieved_Pct, GrossLeadAbsChg,
             LeadSignedChg, Named_Up, Named_Down, All_Other,
             Top3ShareOfGross_Pct, Breadth, ResidualShareOfHeadline_Pct,
             lead_metric, lead_abs, lead_signed, lead_dir, lead_rank, cum_abs, gross_abs,
             dir_rank, dir_cum, dir_total, top3_abs, breadth_calc),
    -- re-emitted in the same order the port half uses, so the UNION lines up
    lead_metric                                                     AS LeadMetric,
    lead_abs                                                        AS LeadAbsChg,
    lead_rank                                                       AS LeadRank,
    SAFE_DIVIDE(cum_abs, gross_abs) * 100                           AS CumCoverage_Pct,
    CASE
      WHEN lead_abs <= 0                       THEN 'N'
      -- MUST SHOW. A rating move or a materially changed estimation window is named whatever
      -- its size. These are the causes a holdings report cannot show, and they are usually
      -- small: a one-notch downgrade worth 9.0 bps loses the directional cut every time, and
      -- <model_changes downgraded="1"/> says one happened without saying which security.
      WHEN IFNULL(RatingChanged, 'N') = 'Y'    THEN 'Y'
      WHEN IFNULL(DataPointsChanged, 'N') = 'Y'
       AND ABS(IFNULL(RelChg_DataPoints_Pct, 0)) >= mat_window_rel  THEN 'Y'
      WHEN breadth_calc = 'BROAD'              THEN IF(lead_rank <= broad_max_names, 'Y', 'N')
      WHEN dir_rank <= max_named_per_side
       AND SAFE_DIVIDE(dir_cum - lead_abs, dir_total) < side_target THEN 'Y'
      ELSE 'N'
    END                                                             AS InCommentary,
    CAST(NULL AS INT64)                                             AS NamesShown,
    CAST(NULL AS INT64)                                             AS TotalNames,
    CAST(NULL AS FLOAT64)                                           AS CoverageAchieved_Pct,
    CAST(NULL AS FLOAT64)                                           AS GrossLeadAbsChg,
    lead_signed                                                     AS LeadSignedChg,
    CAST(NULL AS FLOAT64)                                           AS Named_Up,
    CAST(NULL AS FLOAT64)                                           AS Named_Down,
    CAST(NULL AS FLOAT64)                                           AS All_Other,
    SAFE_DIVIDE(top3_abs, gross_abs) * 100                          AS Top3ShareOfGross_Pct,
    breadth_calc                                                    AS Breadth,
    CAST(NULL AS FLOAT64)                                           AS ResidualShareOfHeadline_Pct
  FROM (
    SELECT
      *,
      CASE
        WHEN SAFE_DIVIDE(top3_abs, gross_abs) >= concentrated_floor THEN 'CONCENTRATED'
        WHEN SAFE_DIVIDE(top3_abs, gross_abs) <  broad_ceiling      THEN 'BROAD'
        ELSE 'MIXED'
      END                                                           AS breadth_calc
    FROM (
      SELECT
        *,
        -- needs lead_rank, so it cannot live one level down
        SUM(IF(lead_rank <= 3, lead_abs, 0))
          OVER (PARTITION BY PortfolioCode)                         AS top3_abs
      FROM (
        SELECT
          *,
          ROW_NUMBER() OVER (PARTITION BY PortfolioCode
                             ORDER BY lead_abs DESC, SecurityCode)  AS lead_rank,
          SUM(lead_abs) OVER (PARTITION BY PortfolioCode
                              ORDER BY lead_abs DESC, SecurityCode
                              ROWS BETWEEN UNBOUNDED PRECEDING
                                       AND CURRENT ROW)             AS cum_abs,
          SUM(lead_abs) OVER (PARTITION BY PortfolioCode)           AS gross_abs,
          -- the same three, computed within a direction rather than across the fund
          ROW_NUMBER() OVER (PARTITION BY PortfolioCode, lead_dir
                             ORDER BY lead_abs DESC, SecurityCode)  AS dir_rank,
          SUM(lead_abs) OVER (PARTITION BY PortfolioCode, lead_dir
                              ORDER BY lead_abs DESC, SecurityCode
                              ROWS BETWEEN UNBOUNDED PRECEDING
                                       AND CURRENT ROW)             AS dir_cum,
          SUM(lead_abs) OVER (PARTITION BY PortfolioCode, lead_dir) AS dir_total
        FROM (
          SELECT
            *,
            -- Tracking error leads wherever it is present on both dates.
            IF(PortfolioTE_bps_Curr IS NOT NULL
               AND PortfolioTE_bps_Prev IS NOT NULL, 'TE', 'VOL')   AS lead_metric,
            IFNULL(IF(PortfolioTE_bps_Curr IS NOT NULL
                      AND PortfolioTE_bps_Prev IS NOT NULL,
                      AbsChg_ContriB_TE_bps,
                      AbsChg_ContriB_PfVol_PctPts), 0)              AS lead_abs,
            -- signed, because the reconciliation needs to know which way each name pushed
            IFNULL(IF(PortfolioTE_bps_Curr IS NOT NULL
                      AND PortfolioTE_bps_Prev IS NOT NULL,
                      Chg_ContriB_TE_bps,
                      Chg_ContriB_PfVol_PctPts), 0)                 AS lead_signed,
            -- CAST is required, not cosmetic: SIGN() on a FLOAT64 returns FLOAT64, and
            -- FLOAT64 is not a groupable type, so PARTITION BY on it is rejected.
            CAST(SIGN(IFNULL(IF(PortfolioTE_bps_Curr IS NOT NULL
                     AND PortfolioTE_bps_Prev IS NOT NULL,
                     Chg_ContriB_TE_bps,
                     Chg_ContriB_PfVol_PctPts), 0)) AS INT64)       AS lead_dir
          FROM detail
        )
      )
    )
  )
),

port AS (
  SELECT
  'PORTFOLIO'                                                     AS RowType,
  PortfolioCode                                                   AS PortfolioCode,
  MAX(PortfolioName)                                              AS PortfolioName,
  MAX(BenchmarkCode)                                              AS BenchmarkCode,
  MAX(BenchmarkName)                                              AS BenchmarkName,
  MAX(ValuationDate_Curr)                                         AS ValuationDate_Curr,
  MAX(ValuationDate_Prev)                                         AS ValuationDate_Prev,
  CAST(NULL AS STRING)                                            AS SecurityCode,
  'PORTFOLIO TOTAL'                                               AS SecurityName,
  CAST(NULL AS STRING)                                            AS HoldingStatus,
  CAST(NULL AS STRING)                                            AS DriverTag,
  CAST(NULL AS FLOAT64)                                           AS Rank_AbsChg_ContriB_PfVol,
  CAST(NULL AS FLOAT64)                                           AS Rank_AbsChg_ContriB_TE,
  CAST(NULL AS FLOAT64)                                           AS Rank_ContriB_PfVol_Curr,
  CAST(NULL AS FLOAT64)                                           AS Rank_ContriB_PfVol_Prev,
  SUM(ContriB_PfVol_Pct_Curr)                                     AS ContriB_PfVol_Pct_Curr,
  SUM(ContriB_PfVol_Pct_Prev)                                     AS ContriB_PfVol_Pct_Prev,
  SUM(Chg_ContriB_PfVol_PctPts)                                   AS Chg_ContriB_PfVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS AbsChg_ContriB_PfVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS AbsChg_ContriB_TE_bps,
  CAST(NULL AS FLOAT64)                                           AS RelChg_ContriB_PfVol_Pct,
  CAST(NULL AS FLOAT64)                                           AS PctShare_PfVol_Pct_Curr,
  CAST(NULL AS FLOAT64)                                           AS PctShare_PfVol_Pct_Prev,
  CAST(NULL AS FLOAT64)                                           AS Chg_PctShare_PfVol_PctPts,
  CAST(NULL AS FLOAT64)                                           AS PctOfPortfolioVolChg_Pct,
  SUM(ContriB_SysPfVol_Pct_Curr)                                  AS ContriB_SysPfVol_Pct_Curr,
  SUM(ContriB_SysPfVol_Pct_Prev)                                  AS ContriB_SysPfVol_Pct_Prev,
  SUM(Chg_ContriB_SysPfVol_PctPts)                                AS Chg_ContriB_SysPfVol_PctPts,
  SUM(ContriB_SpecPfVol_Pct_Curr)                                 AS ContriB_SpecPfVol_Pct_Curr,
  SUM(ContriB_SpecPfVol_Pct_Prev)                                 AS ContriB_SpecPfVol_Pct_Prev,
  SUM(Chg_ContriB_SpecPfVol_PctPts)                               AS Chg_ContriB_SpecPfVol_PctPts,
  SUM(ContriB_BmVol_Pct_Curr)                                     AS ContriB_BmVol_Pct_Curr,
  SUM(ContriB_BmVol_Pct_Prev)                                     AS ContriB_BmVol_Pct_Prev,
  SUM(Chg_ContriB_BmVol_PctPts)                                   AS Chg_ContriB_BmVol_PctPts,
  SUM(ContriB_TE_bps_Curr)                                        AS ContriB_TE_bps_Curr,
  SUM(ContriB_TE_bps_Prev)                                        AS ContriB_TE_bps_Prev,
  SUM(Chg_ContriB_TE_bps)                                         AS Chg_ContriB_TE_bps,
  CAST(NULL AS FLOAT64)                                           AS RelChg_ContriB_TE_Pct,
  SUM(ContriB_SysTE_bps_Curr)                                     AS ContriB_SysTE_bps_Curr,
  SUM(ContriB_SysTE_bps_Prev)                                     AS ContriB_SysTE_bps_Prev,
  SUM(Chg_ContriB_SysTE_bps)                                      AS Chg_ContriB_SysTE_bps,
  SUM(ContriB_SpecTE_bps_Curr)                                    AS ContriB_SpecTE_bps_Curr,
  SUM(ContriB_SpecTE_bps_Prev)                                    AS ContriB_SpecTE_bps_Prev,
  SUM(Chg_ContriB_SpecTE_bps)                                     AS Chg_ContriB_SpecTE_bps,
  MAX(PortfolioVol_Pct_Curr)                                      AS PortfolioVol_Pct_Curr,
  MAX(PortfolioVol_Pct_Prev)                                      AS PortfolioVol_Pct_Prev,
  MAX(Chg_PortfolioVol_PctPts)                                    AS Chg_PortfolioVol_PctPts,
  MAX(RelChg_PortfolioVol_Pct)                                    AS RelChg_PortfolioVol_Pct,
  MAX(PortfolioTE_bps_Curr)                                       AS PortfolioTE_bps_Curr,
  MAX(PortfolioTE_bps_Prev)                                       AS PortfolioTE_bps_Prev,
  MAX(Chg_PortfolioTE_bps)                                        AS Chg_PortfolioTE_bps,
  MAX(RelChg_PortfolioTE_Pct)                                     AS RelChg_PortfolioTE_Pct,
  MAX(SecurityCount_Curr)                                         AS SecurityCount_Curr,
  MAX(SecurityCount_Prev)                                         AS SecurityCount_Prev,
  MAX(NewPositions_Portfolio)                                     AS NewPositions_Portfolio,
  MAX(ExitedPositions_Portfolio)                                  AS ExitedPositions_Portfolio,
  SUM(MarketWeight_Pf_Pct_Curr)                                   AS MarketWeight_Pf_Pct_Curr,
  SUM(MarketWeight_Pf_Pct_Prev)                                   AS MarketWeight_Pf_Pct_Prev,
  SUM(Chg_MarketWeight_Pf_PctPts)                                 AS Chg_MarketWeight_Pf_PctPts,
  CAST(NULL AS FLOAT64)                                           AS RelChg_MarketWeight_Pf_Pct,
  SUM(MarketWeight_Bm_Pct_Curr)                                   AS MarketWeight_Bm_Pct_Curr,
  SUM(MarketWeight_Bm_Pct_Prev)                                   AS MarketWeight_Bm_Pct_Prev,
  SUM(Chg_MarketWeight_Bm_PctPts)                                 AS Chg_MarketWeight_Bm_PctPts,
  SUM(ActiveWeight_Pct_Curr)                                      AS ActiveWeight_Pct_Curr,
  SUM(ActiveWeight_Pct_Prev)                                      AS ActiveWeight_Pct_Prev,
  SUM(Chg_ActiveWeight_PctPts)                                    AS Chg_ActiveWeight_PctPts,
  SUM(MarketValue_Pf_Curr)                                        AS MarketValue_Pf_Curr,
  SUM(MarketValue_Pf_Prev)                                        AS MarketValue_Pf_Prev,
  SUM(Chg_MarketValue_Pf)                                         AS Chg_MarketValue_Pf,
  SUM(UserMarketValue_Pf_Curr)                                    AS UserMarketValue_Pf_Curr,
  SUM(UserMarketValue_Pf_Prev)                                    AS UserMarketValue_Pf_Prev,
  SUM(NotionalWeight_Pf_Pct_Curr)                                 AS NotionalWeight_Pf_Pct_Curr,
  SUM(NotionalWeight_Pf_Pct_Prev)                                 AS NotionalWeight_Pf_Pct_Prev,
  SUM(Chg_NotionalWeight_Pf_PctPts)                               AS Chg_NotionalWeight_Pf_PctPts,
  SUM(NotionalWeightBuy_Pct_Curr)                                 AS NotionalWeightBuy_Pct_Curr,
  SUM(NotionalWeightBuy_Pct_Prev)                                 AS NotionalWeightBuy_Pct_Prev,
  SUM(NotionalWeightSell_Pct_Curr)                                AS NotionalWeightSell_Pct_Curr,
  SUM(NotionalWeightSell_Pct_Prev)                                AS NotionalWeightSell_Pct_Prev,
  CAST(NULL AS STRING)                                            AS ExposureBasis,
  CAST(NULL AS STRING)                                            AS IsDerivative,
  SUM(ExposureWeight_Pct_Curr)                                    AS ExposureWeight_Pct_Curr,
  SUM(ExposureWeight_Pct_Prev)                                    AS ExposureWeight_Pct_Prev,
  SUM(Chg_ExposureWeight_PctPts)                                  AS Chg_ExposureWeight_PctPts,
  CAST(NULL AS FLOAT64)                                           AS RelChg_ExposureWeight_Pct,
  SAFE_DIVIDE(SUM(EffectiveDuration_Curr * ExposureWeight_Pct_Curr), SUM(IF(EffectiveDuration_Curr IS NOT NULL, ExposureWeight_Pct_Curr, NULL))) AS EffectiveDuration_Curr,
  SAFE_DIVIDE(SUM(EffectiveDuration_Prev * ExposureWeight_Pct_Prev), SUM(IF(EffectiveDuration_Prev IS NOT NULL, ExposureWeight_Pct_Prev, NULL))) AS EffectiveDuration_Prev,
  NULL                                                            AS Chg_EffectiveDuration,
  SAFE_DIVIDE(SUM(ModifiedDuration_Curr * ExposureWeight_Pct_Curr), SUM(IF(ModifiedDuration_Curr IS NOT NULL, ExposureWeight_Pct_Curr, NULL))) AS ModifiedDuration_Curr,
  SAFE_DIVIDE(SUM(ModifiedDuration_Prev * ExposureWeight_Pct_Prev), SUM(IF(ModifiedDuration_Prev IS NOT NULL, ExposureWeight_Pct_Prev, NULL))) AS ModifiedDuration_Prev,
  NULL                                                            AS Chg_ModifiedDuration,
  SAFE_DIVIDE(SUM(EffectiveSpreadDuration_Curr * ExposureWeight_Pct_Curr), SUM(IF(EffectiveSpreadDuration_Curr IS NOT NULL, ExposureWeight_Pct_Curr, NULL))) AS EffectiveSpreadDuration_Curr,
  SAFE_DIVIDE(SUM(EffectiveSpreadDuration_Prev * ExposureWeight_Pct_Prev), SUM(IF(EffectiveSpreadDuration_Prev IS NOT NULL, ExposureWeight_Pct_Prev, NULL))) AS EffectiveSpreadDuration_Prev,
  NULL                                                            AS Chg_EffectiveSpreadDuration,
  SUM(DurationContrib_Curr)                                       AS DurationContrib_Curr,
  SUM(DurationContrib_Prev)                                       AS DurationContrib_Prev,
  SUM(Chg_DurationContrib)                                        AS Chg_DurationContrib,
  SUM(SpreadDurationContrib_Curr)                                 AS SpreadDurationContrib_Curr,
  SUM(SpreadDurationContrib_Prev)                                 AS SpreadDurationContrib_Prev,
  SUM(Chg_SpreadDurationContrib)                                  AS Chg_SpreadDurationContrib,
  CAST(NULL AS STRING)                                            AS YieldCurve_Curr,
  CAST(NULL AS STRING)                                            AS YieldCurve_Prev,
  CAST(NULL AS STRING)                                            AS YieldCurveChanged,
  CAST(NULL AS STRING)                                            AS VolatilityModel_RefOnly_Curr,
  CAST(NULL AS STRING)                                            AS VolatilityModel_RefOnly_Prev,
  MAX(ModelName_Curr)                                             AS ModelName_Curr,
  MAX(ModelName_Prev)                                             AS ModelName_Prev,
  MAX(ModelNameChanged)                                           AS ModelNameChanged,
  MAX(ModelDate_Curr)                                             AS ModelDate_Curr,
  MAX(ModelDate_Prev)                                             AS ModelDate_Prev,
  MAX(JobExecutionID_Pf_Curr)                                     AS JobExecutionID_Pf_Curr,
  MAX(JobExecutionID_Pf_Prev)                                     AS JobExecutionID_Pf_Prev,
  MAX(JobExecutionID_Bm_Curr)                                     AS JobExecutionID_Bm_Curr,
  MAX(JobExecutionID_Bm_Prev)                                     AS JobExecutionID_Bm_Prev,
  MAX(ModelDateChanged)                                           AS ModelDateChanged,
  MAX(ModelLagDays_Curr)                                          AS ModelLagDays_Curr,
  MAX(ModelLagDays_Prev)                                          AS ModelLagDays_Prev,
  MAX(Chg_ModelLagDays)                                           AS Chg_ModelLagDays,
  CAST(NULL AS STRING)                                            AS ModellyingTypeCode_Curr,
  CAST(NULL AS STRING)                                            AS ModellyingTypeCode_Prev,
  CAST(NULL AS STRING)                                            AS ModellyingTypeCodeChanged,
  CAST(NULL AS STRING)                                            AS UsedData_Curr,
  CAST(NULL AS STRING)                                            AS UsedData_Prev,
  CAST(NULL AS STRING)                                            AS UsedDataChanged,
  CAST(NULL AS STRING)                                            AS DataPoints_Curr,
  CAST(NULL AS STRING)                                            AS DataPoints_Prev,
  CAST(NULL AS STRING)                                            AS DataPointsChanged,
  CAST(NULL AS FLOAT64)                                           AS Chg_DataPoints,
  CAST(NULL AS FLOAT64)                                           AS RelChg_DataPoints_Pct,
  CAST(NULL AS STRING)                                            AS IdType_Curr,
  CAST(NULL AS STRING)                                            AS IdType_Prev,
  CAST(NULL AS STRING)                                            AS IdTypeChanged,
  CAST(NULL AS STRING)                                            AS IdUsedInAnalytics_Curr,
  CAST(NULL AS STRING)                                            AS IdUsedInAnalytics_Prev,
  MAX(MissingAssetPercent_Pct_Curr)                               AS MissingAssetPercent_Pct_Curr,
  MAX(MissingAssetPercent_Pct_Prev)                               AS MissingAssetPercent_Pct_Prev,
  CAST(NULL AS FLOAT64)                                           AS Chg_MissingAssetPercent_PctPts,
  CAST(NULL AS STRING)                                            AS AnyModelInputChanged,
  CAST(NULL AS STRING)                                            AS MOODYS_Curr,
  CAST(NULL AS STRING)                                            AS MOODYS_Prev,
  CAST(NULL AS STRING)                                            AS SP_Curr,
  CAST(NULL AS STRING)                                            AS SP_Prev,
  CAST(NULL AS STRING)                                            AS FITCH_Curr,
  CAST(NULL AS STRING)                                            AS FITCH_Prev,
  CAST(NULL AS STRING)                                            AS RatingChanged,
  CAST(NULL AS STRING)                                            AS RatingDirection,
  CAST(NULL AS FLOAT64)                                           AS RatingNotchesDowngraded,
  CAST(NULL AS FLOAT64)                                           AS RatingNotch_Curr,
  CAST(NULL AS FLOAT64)                                           AS RatingNotch_Prev,
  CAST(NULL AS STRING)                                            AS RatingDrivenCurveChange,
  CAST(NULL AS STRING)                                            AS SecurityType,
  'ALL'                                                           AS AssetClassification,
  CAST(NULL AS STRING)                                            AS BorrowerClassificationName,
  CAST(NULL AS STRING)                                            AS SecuritySectorName,
  CAST(NULL AS STRING)                                            AS SecuritySectorChanged,
  CAST(NULL AS STRING)                                            AS Country_of_Risk,
  CAST(NULL AS STRING)                                            AS CountryOfRiskChanged,
  CAST(NULL AS STRING)                                            AS APTIssuer,
  CAST(NULL AS STRING)                                            AS APTCurrency,
  'ALL'                                                           AS Line,
  CAST(NULL AS STRING)                                            AS BuyCurrency,
  CAST(NULL AS STRING)                                            AS SellCurrency,
  CAST(NULL AS STRING)                                            AS CompositionCode_Pf,
  CAST(NULL AS STRING)                                            AS CompositionName_Pf,
  CAST(NULL AS STRING)                                            AS CompositionCode_Bm,
  CAST(NULL AS STRING)                                            AS CommentaryNote,
  COUNTIF(HoldingStatus = 'HELD')                                 AS HeldPositions,
  COUNTIF(HoldingStatus = 'NEW')                                  AS NewPositions,
  COUNTIF(HoldingStatus = 'EXITED')                               AS ExitedPositions,
  COUNTIF(HoldingStatus = 'BENCHMARK_ONLY')                       AS BenchmarkOnlyPositions,
  SUM(IF(HoldingStatus = 'HELD',   Chg_ContriB_PfVol_PctPts, 0))  AS VolChg_From_HeldPositions_PctPts,
  SUM(IF(HoldingStatus = 'NEW',    Chg_ContriB_PfVol_PctPts, 0))  AS VolChg_From_NewPositions_PctPts,
  SUM(IF(HoldingStatus = 'EXITED', Chg_ContriB_PfVol_PctPts, 0))  AS VolChg_From_ExitedPositions_PctPts,
  COUNTIF(AnyModelInputChanged = 'Y')                             AS SecuritiesWithModelInputChange,
  SUM(IF(AnyModelInputChanged = 'Y', Chg_ContriB_PfVol_PctPts, 0)) AS VolChg_From_ModelInputChanges_PctPts,
  COUNTIF(RatingDirection = 'DOWNGRADE')                          AS SecuritiesDowngraded,
  COUNTIF(RatingDirection = 'UPGRADE')                            AS SecuritiesUpgraded,
  COUNTIF(RatingDrivenCurveChange = 'Y')                          AS SecuritiesWithRatingDrivenCurveChange,
  SUM(IF(RatingDrivenCurveChange = 'Y', Chg_ContriB_PfVol_PctPts, 0)) AS VolChg_From_RatingDrivenCurveChange_PctPts,
  COUNTIF(DataPointsChanged = 'Y')                                AS SecuritiesWithEstimationWindowChange,
  SUM(IF(DataPointsChanged = 'Y', Chg_ContriB_PfVol_PctPts, 0))   AS VolChg_From_EstimationWindowChange_PctPts,
  COUNTIF(YieldCurveChanged = 'Y')                                AS SecuritiesWithYieldCurveChange,
  COUNTIF(IsDerivative = 'Y' AND ExposureWeight_Pct_Curr IS NOT NULL) AS DerivativePositions_Curr,
  SUM(IF(IsDerivative = 'Y', Chg_ContriB_PfVol_PctPts, 0))        AS VolChg_From_Derivatives_PctPts,
  COUNT(DISTINCT IF(ExposureWeight_Pct_Curr IS NOT NULL, APTCurrency, NULL)) AS CurrencyCount_Curr,
  SUM(ABS(IFNULL(Chg_ExposureWeight_PctPts, 0))) / 2              AS Turnover_ExposureWeight_PctPts,
  COUNTIF(ExposureWeight_Pct_Curr < 0)                            AS ShortOrNegativePositions_Curr,
  IF(MAX(BenchmarkCode) = MIN(BenchmarkCode), 'N', 'Y')           AS BenchmarkChanged,
  SUM(Chg_ContriB_PfVol_PctPts)                                   AS Recon_SumOfSecurityChanges_PctPts,
  SUM(Chg_ContriB_PfVol_PctPts) - MAX(Chg_PortfolioVol_PctPts)    AS Recon_Diff_PctPts,
  IF(ABS(SUM(Chg_ContriB_PfVol_PctPts) - MAX(Chg_PortfolioVol_PctPts)) < 0.0001, 'PASS', 'FAIL') AS Recon_Verdict,
  SUM(Chg_ContriB_SysPfVol_PctPts)                                AS Chg_SystematicVol_PctPts,
  SUM(Chg_ContriB_SpecPfVol_PctPts)                               AS Chg_SpecificVol_PctPts,
  SUM(ContriB_BmVol_Pct_Curr)                                     AS BenchmarkVol_Pct_Curr,
  SUM(ContriB_BmVol_Pct_Prev)                                     AS BenchmarkVol_Pct_Prev,
  SUM(Chg_ContriB_BmVol_PctPts)                                   AS Chg_BenchmarkVol_PctPts,
  SAFE_DIVIDE(SUM(Chg_ContriB_BmVol_PctPts), SUM(ContriB_BmVol_Pct_Prev)) * 100 AS RelChg_BenchmarkVol_Pct,
  SUM(MarketValue_Pf_Curr)                                        AS FundMarketValue_Curr,
  SUM(MarketValue_Pf_Prev)                                        AS FundMarketValue_Prev,
  SAFE_DIVIDE(SUM(MarketValue_Pf_Curr) - SUM(MarketValue_Pf_Prev), SUM(MarketValue_Pf_Prev)) * 100 AS RelChg_FundMarketValue_Pct,
  SAFE_DIVIDE(SUM(IF(Rank_ContriB_PfVol_Curr <= 5, ContriB_PfVol_Pct_Curr, 0)), SUM(ContriB_PfVol_Pct_Curr)) * 100 AS Top5ShareOfVol_Pct_Curr,
  SAFE_DIVIDE(SUM(IF(Rank_ContriB_PfVol_Prev <= 5, ContriB_PfVol_Pct_Prev, 0)), SUM(ContriB_PfVol_Pct_Prev)) * 100 AS Top5ShareOfVol_Pct_Prev,
  SAFE_DIVIDE(SUM(IF(Rank_ContriB_PfVol_Curr <= 5, ContriB_PfVol_Pct_Curr, 0)), SUM(ContriB_PfVol_Pct_Curr)) * 100 - SAFE_DIVIDE(SUM(IF(Rank_ContriB_PfVol_Prev <= 5, ContriB_PfVol_Pct_Prev, 0)), SUM(ContriB_PfVol_Pct_Prev)) * 100 AS Chg_Top5ShareOfVol_PctPts,
  MAX(MissingAssetPercent_Pct_Curr)                               AS MaxMissingAssetPercent_Pct_Curr,
  MAX(LeadMetric)                                                 AS LeadMetric,
  CAST(NULL AS FLOAT64)                                           AS LeadAbsChg,
  CAST(NULL AS INT64)                                             AS LeadRank,
  CAST(NULL AS FLOAT64)                                           AS CumCoverage_Pct,
  CAST(NULL AS STRING)                                            AS InCommentary,
  COUNTIF(InCommentary = 'Y')                                     AS NamesShown,
  COUNT(*)                                                        AS TotalNames,
  SAFE_DIVIDE(SUM(IF(InCommentary = 'Y', LeadAbsChg, 0)), SUM(LeadAbsChg)) * 100 AS CoverageAchieved_Pct,
  SUM(LeadAbsChg)                                                 AS GrossLeadAbsChg,
  CAST(NULL AS FLOAT64)                                           AS LeadSignedChg,
  -- THE RECONCILIATION. Named_Up + Named_Down + All_Other = the fund's headline change,
  -- exactly, because All_Other is the headline less the two named sides rather than a sum
  -- of its own. The commentary quotes these four numbers and does no arithmetic.
  SUM(IF(InCommentary = 'Y' AND LeadSignedChg > 0, LeadSignedChg, 0))  AS Named_Up,
  SUM(IF(InCommentary = 'Y' AND LeadSignedChg < 0, LeadSignedChg, 0))  AS Named_Down,
  IFNULL(IF(MAX(LeadMetric) = 'TE',
            MAX(Chg_PortfolioTE_bps), MAX(Chg_PortfolioVol_PctPts)), 0)
    - SUM(IF(InCommentary = 'Y', LeadSignedChg, 0))                AS All_Other,
  SAFE_DIVIDE(SUM(IF(LeadRank <= 3, LeadAbsChg, 0)), SUM(LeadAbsChg)) * 100 AS Top3ShareOfGross_Pct,
  MAX(Breadth)                                                    AS Breadth,
  -- how much of the headline the residual line carries. Large means the move is broader
  -- than the names shown, and the commentary should say so.
  SAFE_DIVIDE(
    ABS(IFNULL(IF(MAX(LeadMetric) = 'TE',
                  MAX(Chg_PortfolioTE_bps), MAX(Chg_PortfolioVol_PctPts)), 0)
        - SUM(IF(InCommentary = 'Y', LeadSignedChg, 0))),
    ABS(IF(MAX(LeadMetric) = 'TE',
           MAX(Chg_PortfolioTE_bps), MAX(Chg_PortfolioVol_PctPts)))) * 100
                                                                  AS ResidualShareOfHeadline_Pct
  FROM ranked
  GROUP BY PortfolioCode
)

  SELECT * FROM port
  UNION ALL
  SELECT * FROM ranked
);


-- =====================================================================================
-- COMMENTARY INPUT -- this is the statement that runs, and the one you copy.
--
-- Returns ONE ROW, ONE COLUMN: the whole document as JSON. Click the cell in the console to
-- expand it, copy, and paste it into the chat underneath the prompt. Do not save it to a
-- file and attach it -- a file goes through the host's document pipeline (schema inspection,
-- chunking, "Reading All Documents") and that is what has been losing the instructions.
-- Pasted text goes straight into the context window.
--
-- Fund figures appear ONCE. Drivers are nested inside the fund they belong to. An absent key
-- means the value does not apply -- nothing is ever emitted null or empty, which is the same
-- signal the commentary skill already works to.
--
-- LAYOUT is deliberate: pretty-printed at fund level so it can be read in the console cell,
-- but one line per driver so it stays compact. Fully pretty-printed it is 39% larger than
-- the XML it replaces; like this, 12%.
-- =====================================================================================
WITH drv AS (
  SELECT
    PortfolioCode,
    STRING_AGG(
      '        {' || ARRAY_TO_STRING([
        jnum('rank', LeadRank, 0),
        jstr('side', IF(LeadSignedChg >= 0, 'UP', 'DOWN')),
        jstr('id', COALESCE(IdUsedInAnalytics_Curr, IdUsedInAnalytics_Prev)),
        jstr('name', SecurityName),
        jstr('line', Line),
        jstr('asset_class', AssetClassification),
        -- LEVELS, not just the change. "rose from 62.0 to 115.0 bps" is the sentence the
        -- commentary exists for; a lone change figure cannot produce it. A level is omitted
        -- where it does not exist: a new position has no prior contribution, an exited one
        -- has no current.
        jnum('te_prev_bps', ContriB_TE_bps_Prev, 1),
        jnum('te_curr_bps', ContriB_TE_bps_Curr, 1),
        jnum('te_change_bps', Chg_ContriB_TE_bps, 1),
        jnum('te_rel_pct', RelChg_ContriB_TE_Pct, 1),
        jnum('vol_prev_pct', ContriB_PfVol_Pct_Prev, 4),
        jnum('vol_curr_pct', ContriB_PfVol_Pct_Curr, 4),
        jnum('vol_change_pct', Chg_ContriB_PfVol_PctPts, 4),
        -- Weights: absent means the position or the benchmark holding does not exist.
        jnum('exposure_weight_prev', ExposureWeight_Pct_Prev, 3),
        jnum('exposure_weight_curr', ExposureWeight_Pct_Curr, 3),
        jstr('exposure_basis', ExposureBasis),
        jnum('benchmark_weight_prev', MarketWeight_Bm_Pct_Prev, 3),
        jnum('benchmark_weight_curr', MarketWeight_Bm_Pct_Curr, 3),
        -- MATERIALITY GATE. Levels are always given; the CHANGE only when it clears the
        -- floor, so a benchmark that drifted 0.007% cannot be written up as a re-weighting.
        IF(ABS(IFNULL(Chg_MarketWeight_Bm_PctPts, 0)) < mat_bm_weight, NULL,
           jnum('benchmark_weight_change', Chg_MarketWeight_Bm_PctPts, 3)),
        -- Active weight is the axis the commentary reasons on: what the fund chose, net of
        -- the index. An absent active_weight_change is a FINDING -- the weight did not move.
        jnum('active_weight_prev', ActiveWeight_Pct_Prev, 3),
        jnum('active_weight_curr', ActiveWeight_Pct_Curr, 3),
        IF(ABS(IFNULL(Chg_ActiveWeight_PctPts, 0)) < mat_active_weight, NULL,
           jnum('active_weight_change', Chg_ActiveWeight_PctPts, 3)),
        jstr('status', HoldingStatus),
        jstr('driver_tag', DriverTag),
        -- CAUSE FIELDS, each behind its own floor. Absent means the change was not material,
        -- so the commentary has nothing to over-report.
        IF(RatingDirection IS NULL OR RatingDirection IN ('UNCHANGED', 'N/A'), NULL,
           jstr('rating_direction', RatingDirection)),
        IF(RatingDirection IS NULL OR RatingDirection IN ('UNCHANGED', 'N/A'), NULL,
           jnum('rating_notches', RatingNotchesDowngraded, 0)),
        IF(MOODYS_Prev IS NULL OR MOODYS_Curr IS NULL OR MOODYS_Prev = MOODYS_Curr, NULL,
           jstr('rating_prev', MOODYS_Prev)),
        IF(MOODYS_Prev IS NULL OR MOODYS_Curr IS NULL OR MOODYS_Prev = MOODYS_Curr, NULL,
           jstr('rating_curr', MOODYS_Curr)),
        IF(IFNULL(RatingDrivenCurveChange, 'N') != 'Y', NULL,
           jstr('rating_drove_curve_change', 'Y')),
        IF(IFNULL(YieldCurveChanged, 'N') != 'Y' OR YieldCurve_Prev IS NULL
           OR YieldCurve_Curr IS NULL OR YieldCurve_Prev = YieldCurve_Curr, NULL,
           jstr('curve_prev', YieldCurve_Prev)),
        IF(IFNULL(YieldCurveChanged, 'N') != 'Y' OR YieldCurve_Prev IS NULL
           OR YieldCurve_Curr IS NULL OR YieldCurve_Prev = YieldCurve_Curr, NULL,
           jstr('curve_curr', YieldCurve_Curr)),
        IF(IFNULL(DataPointsChanged, 'N') != 'Y'
           OR ABS(IFNULL(RelChg_DataPoints_Pct, 0)) < mat_window_rel, NULL,
           jstr('observations_prev', DataPoints_Prev)),
        IF(IFNULL(DataPointsChanged, 'N') != 'Y'
           OR ABS(IFNULL(RelChg_DataPoints_Pct, 0)) < mat_window_rel, NULL,
           jstr('observations_curr', DataPoints_Curr)),
        IF(ABS(IFNULL(Chg_EffectiveSpreadDuration, 0)) < mat_duration, NULL,
           jnum('spread_duration_prev', EffectiveSpreadDuration_Prev, 2)),
        IF(ABS(IFNULL(Chg_EffectiveSpreadDuration, 0)) < mat_duration, NULL,
           jnum('spread_duration_curr', EffectiveSpreadDuration_Curr, 2)),
        IF(ABS(IFNULL(Chg_EffectiveDuration, 0)) < mat_duration, NULL,
           jnum('duration_prev', EffectiveDuration_Prev, 2)),
        IF(ABS(IFNULL(Chg_EffectiveDuration, 0)) < mat_duration, NULL,
           jnum('duration_curr', EffectiveDuration_Curr, 2))
      ], ', ') || '}'
      , ',\n' ORDER BY LeadRank)                                   AS drivers_json
  FROM drilldown
  WHERE RowType = 'SECURITY' AND InCommentary = 'Y'
  GROUP BY PortfolioCode
),

funds AS (
  SELECT
    p.PortfolioCode,
    '    {\n      ' || ARRAY_TO_STRING([
      jstr('code', p.PortfolioCode),
      jstr('name', p.PortfolioName),
      jstr('benchmark', IFNULL(p.BenchmarkCode, 'none')),
      jstr('lead_metric', p.LeadMetric),
      -- omitted entirely when no benchmark is attached
      jobj('tracking_error', [
        jstr('unit', 'bps'),
        jnum('prev', p.PortfolioTE_bps_Prev, 1),
        jnum('curr', p.PortfolioTE_bps_Curr, 1),
        jnum('change', p.Chg_PortfolioTE_bps, 1),
        jnum('relative_pct', p.RelChg_PortfolioTE_Pct, 1)]),
      jobj('volatility', [
        jstr('unit', 'pct'),
        jnum('prev', p.PortfolioVol_Pct_Prev, 4),
        jnum('curr', p.PortfolioVol_Pct_Curr, 4),
        jnum('change', p.Chg_PortfolioVol_PctPts, 4),
        jnum('relative_pct', p.RelChg_PortfolioVol_Pct, 1)]),
      -- THE RECONCILIATION. named_up + named_down + all_other = headline, exactly, because
      -- all_other is the headline LESS the two named sides rather than a total of its own.
      -- The commentary quotes these four and never adds anything up itself.
      jobj('reconciliation', [
        jstr('metric', p.LeadMetric),
        jstr('unit', IF(p.LeadMetric = 'TE', 'bps', 'pct')),
        jnum('headline', IF(p.LeadMetric = 'TE', p.Chg_PortfolioTE_bps, p.Chg_PortfolioVol_PctPts),
             IF(p.LeadMetric = 'TE', 1, 4)),
        jnum('named_up',   p.Named_Up,   IF(p.LeadMetric = 'TE', 1, 4)),
        jnum('named_down', p.Named_Down, IF(p.LeadMetric = 'TE', 1, 4)),
        jnum('all_other',  p.All_Other,  IF(p.LeadMetric = 'TE', 1, 4)),
        jnum('residual_share_pct', p.ResidualShareOfHeadline_Pct, 1),
        jstr('breadth', p.Breadth),
        jnum('names_shown', p.NamesShown, 0),
        jnum('total_names', p.TotalNames, 0)]),
      jobj('checks', [
        jstr('recon', p.Recon_Verdict),
        jstr('benchmark_changed', p.BenchmarkChanged),
        jnum('modelled_weight_pct', p.MarketWeight_Pf_Pct_Curr, 1),
        jstr('model_date', CAST(p.ModelDate_Curr AS STRING)),
        jnum('model_lag_days', p.ModelLagDays_Curr, 0)]),
      jobj('vol_split', [
        jnum('systematic_change', p.Chg_SystematicVol_PctPts, 4),
        jnum('specific_change', p.Chg_SpecificVol_PctPts, 4)]),
      jobj('benchmark_volatility', [
        jstr('unit', 'pct'),
        jnum('prev', p.BenchmarkVol_Pct_Prev, 4),
        jnum('curr', p.BenchmarkVol_Pct_Curr, 4),
        jnum('relative_pct', p.RelChg_BenchmarkVol_Pct, 1)]),
      jobj('fund_context', [
        jnum('market_value_change_pct', p.RelChg_FundMarketValue_Pct, 1),
        jnum('turnover_pct', p.Turnover_ExposureWeight_PctPts, 3),
        jnum('top5_share_prev', p.Top5ShareOfVol_Pct_Prev, 4),
        jnum('top5_share_curr', p.Top5ShareOfVol_Pct_Curr, 4),
        jnum('top5_share_change', p.Chg_Top5ShareOfVol_PctPts, 4)]),
      jobj('positions', [
        jnum('held', p.HeldPositions, 0),
        jnum('new', p.NewPositions, 0),
        jnum('exited', p.ExitedPositions, 0)]),
      -- omitted entirely when no security had a model input change
      IF(IFNULL(p.SecuritiesWithModelInputChange, 0) = 0, NULL,
         jobj('model_changes', [
           jnum('securities', p.SecuritiesWithModelInputChange, 0),
           jnum('vol_impact_pct', p.VolChg_From_ModelInputChanges_PctPts, 4),
           jnum('downgraded', p.SecuritiesDowngraded, 0),
           jnum('upgraded', p.SecuritiesUpgraded, 0)]))
    ], ',\n      ')
    || ',\n      "drivers": [\n' || IFNULL(d.drivers_json, '') || '\n      ]\n    }'
                                                                  AS fund_json,
    p.ValuationDate_Prev,
    p.ValuationDate_Curr
  FROM drilldown p
  LEFT JOIN drv d ON d.PortfolioCode = p.PortfolioCode
  WHERE p.RowType = 'PORTFOLIO'
)

SELECT
  '{\n  "prev_cob": "' || CAST(MAX(ValuationDate_Prev) AS STRING) || '",\n'
  || '  "curr_cob": "' || CAST(MAX(ValuationDate_Curr) AS STRING) || '",\n'
  || '  "funds": [\n'
  || STRING_AGG(fund_json, ',\n' ORDER BY PortfolioCode)
  || '\n  ]\n}'                                                   AS commentary_json
FROM funds;


-- =====================================================================================
-- FALLBACK VIEWS -- uncomment one of these instead if you need a flat export. The narrow one runs by default.
--
-- The wide extract is 212 columns and carries every security. That is right for audit and
-- wrong for handing to an LLM: an agentic reader inspects the schema and ingests the file
-- before it does anything, and a 7 MB / 203-column CSV sends it into a loop of
-- re-inspecting and re-planning without ever producing commentary.
--
-- The narrow view below is the fund row plus only the securities flagged InCommentary --
-- roughly 60 KB instead of 7 MB.
-- =====================================================================================

-- FULL AUDIT EXTRACT -- swap the two statements below to export all 212 columns.
-- SELECT * FROM drilldown
-- ORDER BY PortfolioCode, RowType, LeadRank, SecurityCode;

-- COMMENTARY INPUT -- this is the one to attach.
-- SELECT
--   RowType,
--   PortfolioCode,
--   PortfolioName,
--   BenchmarkCode,
--   ValuationDate_Curr,
--   ValuationDate_Prev,
--   LeadMetric,
--   LeadRank,
--   NamesShown,
--   TotalNames,
--   CoverageAchieved_Pct,
--   PortfolioTE_bps_Curr,
--   PortfolioTE_bps_Prev,
--   Chg_PortfolioTE_bps,
--   RelChg_PortfolioTE_Pct,
--   PortfolioVol_Pct_Curr,
--   PortfolioVol_Pct_Prev,
--   Chg_PortfolioVol_PctPts,
--   RelChg_PortfolioVol_Pct,
--   Chg_SystematicVol_PctPts,
--   Chg_SpecificVol_PctPts,
--   BenchmarkVol_Pct_Curr,
--   BenchmarkVol_Pct_Prev,
--   RelChg_BenchmarkVol_Pct,
--   RelChg_FundMarketValue_Pct,
--   Top5ShareOfVol_Pct_Curr,
--   Top5ShareOfVol_Pct_Prev,
--   Chg_Top5ShareOfVol_PctPts,
--   Turnover_ExposureWeight_PctPts,
--   MarketWeight_Pf_Pct_Curr,
--   ModelLagDays_Curr,
--   ModelDate_Curr,
--   SecuritiesWithModelInputChange,
--   VolChg_From_ModelInputChanges_PctPts,
--   SecuritiesDowngraded,
--   SecuritiesUpgraded,
--   HeldPositions,
--   NewPositions,
--   ExitedPositions,
--   BenchmarkChanged,
--   Recon_Verdict,
--   SecurityName,
--   IdUsedInAnalytics_Curr,
--   IdUsedInAnalytics_Prev,
--   Line,
--   AssetClassification,
--   Chg_ContriB_TE_bps,
--   Chg_ContriB_PfVol_PctPts,
--   ExposureWeight_Pct_Curr,
--   ExposureWeight_Pct_Prev,
--   ExposureBasis,
--   MarketWeight_Bm_Pct_Curr,
--   MarketWeight_Bm_Pct_Prev,
--   HoldingStatus,
--   DriverTag,
--   AnyModelInputChanged,
--   RatingDirection,
--   RatingNotchesDowngraded,
--   RatingDrivenCurveChange,
--   DataPointsChanged,
--   DataPoints_Curr,
--   DataPoints_Prev,
--   PctOfPortfolioVolChg_Pct
-- FROM drilldown
-- WHERE RowType = 'PORTFOLIO' OR InCommentary = 'Y'
-- ORDER BY PortfolioCode, RowType, LeadRank, SecurityCode;

