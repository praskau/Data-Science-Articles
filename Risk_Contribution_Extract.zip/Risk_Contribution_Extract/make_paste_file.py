#!/usr/bin/env python3
"""
Write PROMPT_TO_PASTE.txt -- the instruction block on its own.

commentary_prompt.md carries a runbook above the prompt for the person running it. Pasting
that runbook into the chat alongside the prompt is a live failure mode: it talks *about* the
instructions in the second person, so the model reads deployment notes as part of its brief.

This strips it. Open PROMPT_TO_PASTE.txt, select all, paste. Nothing to trim.

    python3 make_paste_file.py
"""
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
src = HERE / "commentary_prompt.md"
dst = HERE / "PROMPT_TO_PASTE.txt"

lines = src.read_text().split("\n")
try:
    i0 = next(i for i, l in enumerate(lines) if l.strip() == "<<<SYSTEM")
    i1 = next(i for i, l in enumerate(lines) if l.strip() == "SYSTEM>>>")
except StopIteration:
    sys.exit("FAIL: could not find the <<<SYSTEM / SYSTEM>>> markers in commentary_prompt.md")
if i1 <= i0:
    sys.exit("FAIL: SYSTEM>>> appears before <<<SYSTEM")

block = "\n".join(lines[i0 + 1:i1]).strip() + "\n"

for marker in ("<<<SYSTEM", "SYSTEM>>>"):
    if marker in block:
        sys.exit(f"FAIL: {marker} survived into the extracted block")
for required in ("## Role", "## Input", "## Which securities to show", "## Output", "## Self-check"):
    if required not in block:
        sys.exit(f"FAIL: {required} missing from the extracted block")

dst.write_text(block)
print(f"wrote {dst.name}  ({len(block.split(chr(10)))} lines, ~{len(block)//4.35:.0f} tokens)")
print("Open it, select all, paste it into the chat, then paste the XML underneath it.")
