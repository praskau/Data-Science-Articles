# Risk Contribution Extract — 2-COB Portfolio Drill-Down

Parameterised BigQuery extract over
`hsbc-237274-amgrisk-prod.elmo.risk_contribution`.

Feed it **two COB dates** and **three portfolio codes**; it returns an analysis-ready CSV
with every metric carried for both dates side by side, the period-over-period calculations
embedded in the query, and a pre-classified driver for each position so an LLM can write
commentary over verified numbers rather than inferring them.

Nothing runs from this machine. You run the queries yourself, export the results, and hand
them to the model.

---

## Quick reference — what to run, what to upload

**Two queries. One upload.**

| # | Run this | Then | Upload? |
|---|---|---|---|
| 1 | `00_preflight_checks.sql` | Read the `Verdict` column on screen. `FAIL` on `COVERAGE`, `KEY_COLLISION` or `ISPORTFOLIO_SIDES` → stop. | **No** — a go / no-go check, not data. |
| 2 | `risk_drilldown.sql` | Returns **one row, one column** — the whole XML document in a single cell. Click the cell to expand it and copy. | **Nothing is attached.** |

Both take the same two dates and portfolio codes, in the three `DECLARE` lines at the top.

Then send **one message**: paste `PROMPT_TO_PASTE.txt`, the ask, and the XML underneath it.

**Attach nothing at all.** An attachment goes through the host's document pipeline — schema
inspection, chunking, "Reading All Documents" — and that is what was losing the instructions.
`schema_risk_contribution.csv` describes the raw source table, not this extract; `SKILL.md` is
pasted as text via `PROMPT_TO_PASTE.txt`; `dummy_data/` and `_retired/` are never uploaded.

---


## Three views, and why XML is the default

`risk_drilldown.sql` ends with three statements. **XML runs by default.** The narrow CSV and
the full 212-column audit extract sit below it, commented out.

| View | Shape | Size (3-fund fixture) |
|---|---|---|
| **XML** (default) | one row, one column — the whole document | **12 KB** |
| Narrow CSV | 26 rows x 63 columns | 10 KB |
| Full audit extract | 61 rows x 212 columns | 91 KB |

**Copy the XML cell and paste it into the chat under the prompt. Do not save it and attach
it.** An attachment goes through the host's document pipeline — schema inspection, chunking,
"Reading All Documents" — which is what has been losing the instructions. Pasted text lands
straight in the context window.

### Why not a spreadsheet

A run against the 7 MB, 203-column CSV never produced commentary: the host cycled
`Planning the analysis → Recalling exec_N → Inspecting schema → Reading All Documents →
Planning the analysis` for five minutes. Narrowing to 63 columns stopped the loop, but a CSV
is still routed through the same tabular path — and the flat shape was working against it:

| | |
|---|---|
| Blank cells in the narrow CSV | **38%** (618 of 1,638) |
| Columns populated on *both* row types | **27** — every security row repeated the fund's TE, volatility, dates, benchmark and model lag |
| Structure linking a security to its fund | none, beyond a shared `PortfolioCode` |

A chunk of security rows carried the fund's headline numbers twenty-five times over, with
nothing marking them as fund-level. Nesting fixes all three: fund figures appear once, drivers
sit inside the fund they belong to, and nothing is emitted empty.

### The document

```xml
<risk_extract prev_cob="2026-08-12" curr_cob="2026-08-24">
<fund code="EQ_GLOBAL" name="Global Equity Fund" benchmark="MSCI_ACWI" lead_metric="TE">
  <tracking_error unit="bps" prev="348.0" curr="386.8" change="38.8" relative_pct="11.1"/>
  <volatility unit="pct" prev="12.2600" curr="12.7290" change="0.4690" relative_pct="3.8"/>
  <reconciliation metric="TE" unit="bps" headline="38.8" named_up="86.0" named_down="-47.0"
                  all_other="-0.2" residual_share_pct="0.5" breadth="CONCENTRATED"
                  names_shown="6" total_names="22"/>
  <checks recon="PASS" benchmark_changed="N" modelled_weight_pct="100.0" .../>
  ...
  <drivers>
    <driver rank="1" side="UP" id="US67066G1040" line="Ordinary" asset_class="Equity"
            te_prev_bps="62.0" te_curr_bps="115.0" te_change_bps="53.0" te_rel_pct="85.5"
            vol_prev_pct="1.8500" vol_curr_pct="2.9500" vol_change_pct="1.1000"
            exposure_weight_prev="10.031" exposure_weight_curr="12.864" exposure_basis="Market"
            benchmark_weight_prev="10.130" benchmark_weight_curr="11.185" benchmark_weight_change="1.055"
            active_weight_prev="-0.099" active_weight_curr="1.679" active_weight_change="1.778"
            status="HELD" driver_tag="VOL_UP_ON_WEIGHT_UP">NVIDIA CORP</driver>
  </drivers>
</fund>
</risk_extract>
```

The levels are the point. `te_change_bps="53.0"` alone can only ever produce "added 53.0 bps";
`te_prev_bps` and `te_curr_bps` produce "rose from 62.0 to 115.0 bps", which is the sentence a
CRO can act on. Same for `active_weight_*` — it is the axis the fund actually chose, net of
the index, and without it a benchmark re-weighting is indistinguishable from a trade.

**Absence carries meaning; nothing is ever emitted empty.** No `benchmark_weight_*` means the
benchmark does not hold the security. No `te_curr_bps` means it was sold. No `<tracking_error>`
means no benchmark is attached. No `active_weight_change` means the active weight did not move
*materially* — which is a finding, not a gap, and the second rung of the cause ladder.

Two details that are easy to get wrong and are covered by `xml_escape()` and `num()`:

- **Escaping is not optional.** The fixture contains `SPDR S&P 500 ETF TRUST` — a bare `&`
  makes the document unparseable. Verified by round-tripping it through `xml.etree`.
- **Fixed decimals, not `%g`.** `348.0` must not arrive as `348`, and `1.1000` must not arrive
  as `1.1` — the commentary quotes what it is given.

### Output is prose, not tables

One text block per fund, headed by fund name and code: what changed, a short paragraph per
riser, the offsets opened by quoting the arithmetic, the residual line, the second metric, and
material flags. The earlier tabular format was introduced to cut runtime; the runtime problem
is now solved upstream by the SQL-side selection and the inline paste, so the tables were
dropped — except on a `BROAD` fund, where a table is the honest format.

---

## One query, two levels

`risk_drilldown.sql` returns both the fund totals and the security detail in one result set.
Tell them apart with **`RowType`**:

| `RowType` | Rows | Notes |
|---|---|---|
| `PORTFOLIO` | one per fund | `SecurityName` reads `PORTFOLIO TOTAL`, `SecurityCode` blank, `Line` and `AssetClassification` read `ALL` |
| `SECURITY` | one per holding | fund-level columns (`Turnover_…`, `SecuritiesDowngraded`, `Recon_…`) are blank |

### Why this replaced the two-file design

The split version ran two separate aggregations over the same table — one grouped by
`PortfolioCode` for the fund totals, one grouped by `(PortfolioCode, SecurityCode)` for the
detail. They disagreed on a real fund by `Recon_Diff_PctPts = 0.0136`, which tripped the
reconciliation gate and killed the entire commentary run.

The cause: a `SecurityCode` can appear more than once on the same side of the same COB —
fund-of-funds sleeves under different `CompositionCode`s. The fund-level aggregate **summed**
those rows. The per-security pivot collapsed them with `MAX(IF(...))`, keeping one and
dropping the rest. The gap was exactly the dropped contributions.

Two fixes, both structural:

1. **Additive quantities now `SUM` across duplicate rows** instead of `MAX` — contributions,
   weights, market values, notionals. A security row is the whole holding, all sleeves
   combined. `DUPLICATE_SECURITY` (Seq 11) in the preflight reports how much of the fund sits
   in duplicated codes, so you know when a row is a combination.
2. **The fund row is built by aggregating the security rows**, in the same query, rather than
   by re-reading the source. The total is a `SUM` over exactly the rows it is meant to
   reconcile against, so the two cannot disagree.

`Recon_Diff_PctPts` is still emitted on the `PORTFOLIO` row. It is now structurally zero, and
kept as a tripwire: a non-zero value means something between the pivot and the output dropped
or duplicated a row.

**Identifiers are never picked with `MAX`.** Where several source rows collapse into one
security row, descriptors are taken with
`ARRAY_AGG(x ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)` — the current COB,
portfolio side, largest holding. Deterministic and meaningful, rather than alphabetical.

---

## Weight scale — the source stores fractions

`MarketWeight` and the notional weights are **fractions** in the source table. A real run
summed the portfolio side to `0.9295`, i.e. 92.95%. The `ContriB_*` family is **not** on that
scale — those are already percentage points, where `0.27` means `0.27%`.

So the query multiplies weights by 100 and leaves contributions alone. The preflight prints
the raw sum alongside the scaled one, so the assumption can be re-confirmed per fund rather
than taken on trust.

**Weights are not expected to reach 100%.** Cash, unmodelled assets and look-through gaps
leave a shortfall. `WEIGHT_COMPLETENESS` treats **90% or above as `OK`**, below 90% as a
`WARN` the commentary must disclose, and above 105% as a `FAIL` — that would mean the scale
assumption or the load is wrong.

## Load selection — only the latest job is used

The same COB can be loaded more than once, so both queries filter to a single load before
anything else happens:

```sql
latest_job AS (
  SELECT ValuationDate, PortfolioCode, MAX(JobExecutionID) AS max_job
  FROM base
  GROUP BY ValuationDate, PortfolioCode
),
```

Rows are then kept only where `JobExecutionID = max_job`. Every earlier job is dropped
whole, not merged. `MAX(JobExecutionID)` is taken **per `ValuationDate` × `PortfolioCode`**,
not once across the extract — the 24 Aug load and the 12 Aug load are different jobs and each
date keeps its own latest.

A second `ROW_NUMBER()` over the natural key
(`ValuationDate`, `PortfolioCode`, `CompositionCode`, `IsPortfolio`, `SecurityCode`) ordered
by `ImportDateTime DESC` sits behind that, to catch the same job inserting an identical key
twice.

### Why the latest *load*, not the latest version of each row

An earlier version of this query de-duplicated row by row —
`ROW_NUMBER() OVER (PARTITION BY <natural key> ORDER BY JobExecutionID DESC)`. That reads as
the same thing and is not.

If job 100 loads 5 positions and a re-run as job 101 carries only 3, row-level picking keeps
the 3 corrected rows from job 101 **and the 2 stale rows from job 100**:

| | Positions | Jobs present | Total vol |
|---|---|---|---|
| Row-level dedup | 5 | 100 **and** 101 | 15.3 |
| Latest job only | 3 | 101 | 6.3 |

The row-level result is a portfolio blended across two model vintages. It looks complete, and
it still reconciles — the contributions sum to their own total regardless of which vintage
they came from — so `Recon_Verdict` says `PASS` and nothing flags it.

That is why the extract now takes the load whole, and why `PARTIAL_RELOAD` exists in the
preflight: it compares the row count of the latest job against the largest earlier job for
the same COB and portfolio, and warns when the latest is smaller. Selecting the latest load
is the right default, but if a re-run was genuinely partial you need to know before you use
the numbers — that is a judgement call, not something the query should make silently.

---


## Commentary shape

**The arithmetic closes.** Every fund carries a `<reconciliation>` element:

```xml
<reconciliation metric="TE" unit="bps" headline="38.8" named_up="86.0" named_down="-47.0"
                all_other="-0.2" residual_share_pct="0.5" breadth="CONCENTRATED"
                names_shown="6" total_names="22"/>
```

`named_up + named_down + all_other = headline`, **exactly**, because `all_other` is the
headline less the two named sides rather than a total of its own. The model quotes the four
numbers and does no arithmetic anywhere in the task. An earlier version showed drivers summing
to +44.0 against a fund change of +38.8 with nothing naming the −5.2 gap; that is now
impossible by construction, and `check_fixture.py` asserts the identity on every fund.

**Selection is directional.** Risers and offsets are chosen separately — each takes names in
size order until `side_target` (85%) of that side is named, capped at `max_named_per_side`
(4). A single ranked list of absolute movers fills with risers and leaves the reader unable to
see why the fund moved less than they did. On the four test funds this names six or seven of
eighteen to twenty-four, with residuals of 0.5%, 2.8%, 8.2% — and 52% on the broad fund, which
is the finding rather than a defect.

**Breadth switches the format.** `breadth` comes from the top-three share of gross movement:
`CONCENTRATED` at ≥50%, `BROAD` at <25%, `MIXED` between. A concentrated move gets prose
naming the securities; a broad one gets one sentence saying the impact is spread and a table.

**Some names are never cut.** A rating move, or an estimation window that changed by more than
`mat_window_rel`, is named whatever its size. These are the causes a holdings report cannot
show and they are usually small — a one-notch downgrade worth 9.0 bps loses the directional cut
every time, and `<model_changes downgraded="1"/>` says one happened without saying which.

**Materiality is enforced in SQL, not in the prompt.** Levels are always present; a *change*
attribute appears only when it clears its floor — active weight 0.50%, benchmark weight 0.25%,
window 20%, duration 0.25 years, any rating notch at all. An attribute absent from the document
cannot be over-reported, which is a stronger guarantee than an instruction not to mention it.

**Tracking error leads where it exists.** If `PortfolioTE_bps` is populated on both dates, the
lead metric is `TE`, drivers are ranked on `AbsChg_ContriB_TE_bps`, and the reconciliation is
in basis points. Where it is blank — no benchmark attached — volatility leads and the absence
is stated once.

**Nothing is written that did not move a risk number.** Each fund-level fact has a materiality
test in the skill and fails silently. There is no "concentration was broadly stable" sentence,
because a CRO reads absence as nothing to report. The only things written regardless are the
gate lines and the model staleness line, which are controls rather than narrative.

**No "pp".** Everything that is a percentage is written with a `%` sign, and the sentence
carries whether the move is absolute or relative:

- relative — *Volatility rose 3.8%, from 12.2600% to 12.7290%.*
- absolute — *NVIDIA CORP's contribution rose from 62.0 to 115.0 bps.*

Tracking error stays in basis points.

---


## How `IsPortfolio` is used

`IsPortfolio` says **whose numbers the row carries**. `TRUE` — every column on that row
describes the portfolio. `FALSE` — every column describes the benchmark. It is not a filter:
**both sides are pulled**, and the flag is what lets one output row carry the fund and the
benchmark side by side.

There is one exception. **`ContriB_TE` is common to both sides** and is summed across them
without filtering.

| Quantity | Rows summed |
|---|---|
| Portfolio volatility, `ContriB_PfVol` and its systematic/specific split | `IsPortfolio = TRUE` only |
| Portfolio weights, market value, durations, ratings, curve and model fields | `IsPortfolio = TRUE` only |
| Benchmark volatility, `ContriB_BmVol`, benchmark weights | `IsPortfolio = FALSE` only |
| **Tracking error — `ContriB_TE`, `ContriB_SysTE`, `ContriB_SpecTE`** | **both, unfiltered** |

Crossed with the two COB dates, that gives the four-way split — Pf/Bm × current/prior — that
makes `ActiveWeight` and every `Chg_` column computable without a `FULL OUTER JOIN`.

It also does two smaller jobs. It sits in the de-duplication key, so a security held by both
the fund and the benchmark keeps two distinct rows rather than one overwriting the other. And
descriptors prefer the portfolio row and fall back to the benchmark row, so a name held only
in the index still carries its sector, rating and identifier and shows up as
`HoldingStatus = BENCHMARK_ONLY` — a real underweight the commentary must account for.

### Tracking error is inherently two-sided

`ContriB_TE` appears on both the portfolio and the benchmark rows, and the two offset — a
real run showed the portfolio side alone at 819.99 bps against a total of 247.70 bps, so the
benchmark rows carried roughly -572 bps. **Only the total is meaningful.** There is no
portfolio-only tracking error to compare it against, and the query no longer emits one.

That still leaves one thing to confirm on the first run: whether 247.70 bps is what the risk
system itself reports for this fund. The sum is only as good as the assumption that these are
contributions that add to the total.

### Two more assumptions, both now checked

`ISPORTFOLIO_SIDES` (Seq 5) in the preflight reports the row counts and non-null contribution
counts on each side, and fails on either of these rather than leaving them silent:

**A NULL `IsPortfolio` is treated as the portfolio side.** The column is `NULLABLE`, and both
queries read `IFNULL(IsPortfolio, TRUE) AS is_pf`. If NULLs appear, those rows count as fund
holdings and inflate every contribution. The check `FAIL`s on any NULL, which is what makes
the default defensible.

**Benchmark rows are assumed to carry `ContriB_BmVol`.** If they exist but do not, the
benchmark volatility columns come back empty and the check `WARN`s.

## Units

Source values are already in **percentage points**: a stored `0.27` means 0.27%. Every
output column says which unit it is in, so nothing downstream has to guess.

| Suffix | Meaning | Example |
|---|---|---|
| `_Pct_<COB>` | A level, in percent | `PortfolioVol_Pct_24082026` = `12.7290` → 12.7290% |
| `_PctPts` | An absolute change, in percentage points | `Chg_ContriB_PfVol_PctPts` = `+1.1000` → +1.1000 pp |
| `_bps_<COB>` | Tracking error, in basis points | `PortfolioTE_bps_24082026` = `386.8` → 386.8 bps |
| `RelChg_..._Pct` | A **relative** change, in percent | `RelChg_PortfolioVol_Pct` = `+3.8` → up 3.8% |

Volatility and weights are carried in percent; tracking error is converted to basis points
(percent × 100). Both get a relative change alongside the absolute one, so commentary can
say *"volatility rose 3.8%, from 12.2600% to 12.7290%"* and *"tracking error rose 11.1%,
from 348.0 bps to 386.8 bps"* without doing any arithmetic of its own.

`RelChg_` columns are blank where the prior value is zero or the position is new — there is
nothing to compare against. Do not read blank as zero.

---

## Derivatives use notional, not market weight

A future or swap carries almost no market value — only margin and unrealised P&L — so its
market weight understates the fund's real exposure, often by a factor of ten. The extract
resolves this on every row rather than leaving it to the reader:

| Column | |
|---|---|
| `ExposureWeight_Pct_<COB>` | Notional for derivative lines, market weight for everything else. **This is the weight to drill down on.** |
| `ExposureBasis` | `Notional` or `Market` — which one the row used. |
| `IsDerivative` | `Y` / `N`. |
| `NotionalWeightBuy_Pct_<COB>` / `NotionalWeightSell_Pct_<COB>` | The two legs, for swaps and forwards. |

Derivative lines are Future, Swap, Forward, Option, FX Forward, CDS and Swaption, plus
anything whose `AssetClassification` contains "Derivative".

`DriverTag` is classified on exposure weight, so `VOL_UP_ON_WEIGHT_UP` on a future means
the notional rose, not the market value. Driver selection also measures against exposure —
otherwise a derivatives overlay passes through unselected while the weight-coverage test
still reads as satisfied.

The case from the dummy data: US 10Y NOTE FUTURE SEP26 moved from 0.220% to 0.350% on
market weight — a rounding difference — while its **notional went 3.500% to 9.600%, up
174.3%**. That is what explains the +0.2800 pp it added to portfolio volatility.

---

## Column naming

Dated columns end in **`_Curr`** or **`_Prev`**. The names are identical on every run; the
dates themselves ride along as data:

```
ValuationDate_Curr        2026-08-24
ValuationDate_Prev        2026-08-12
ContriB_PfVol_Pct_Curr    2.9500
ContriB_PfVol_Pct_Prev    1.8500
Chg_ContriB_PfVol_PctPts  1.1000
RelChg_ContriB_PfVol_Pct  59.4595
```

An earlier version stamped the real COB into every alias (`ContriB_PfVol_Pct_24082026`),
which needed `EXECUTE IMMEDIATE` because BigQuery cannot parameterise an identifier. That is
gone. Both queries are now **plain SQL** — one `WITH … SELECT` you can read top to bottom,
run a CTE at a time, and debug in the console. Comment out the final `SELECT` and put
`SELECT * FROM pivot LIMIT 50` in its place to inspect any stage.

The trade is that the column headers no longer carry the dates. `ValuationDate_Curr` and
`ValuationDate_Prev` do, on every row, and the commentary prompt reads them from there.

## What the query computes

**Volatility and contribution** — `ContriB_PfVol` per date and its change; the systematic
and specific splits; `PctShare_PfVol` (this name's share of total portfolio vol) and the
change in that share; `PctOfPortfolioVolChg` — *what fraction of the portfolio's entire
volatility move this one security explains*. Plus `Rank_AbsChg_ContriB_PfVol` so the CSV
opens on the biggest movers.

**Benchmark and tracking error** — `ContriB_BmVol`, `ContriB_TE` and its systematic and
specific splits, `ActiveWeight` per date and its change.

**Exposure** — market weight (portfolio and benchmark side), market value, notional
weight, effective / modified / spread duration, and `DurationContrib` (weight × effective
duration).

**Model and data-quality change flags** — `Y` / `N` / `N/A` for `YieldCurveChanged`,
`VolatilityModelChanged`, `ModelNameChanged`, `ModelDateChanged`,
`ModellyingTypeCodeChanged`, `UsedDataChanged`, `DataPointsChanged`, `IdTypeChanged`,
`RatingChanged`, `SecuritySectorChanged`, `CountryOfRiskChanged`, plus `Chg_ModelLagDays`
and the roll-up `AnyModelInputChanged`.

`N/A` means the holding is absent on one of the two dates, so an entry or exit is never
misreported as a methodology change.

**The AI hook** — two columns exist purely to keep the LLM honest:

- `DriverTag` — each row pre-classified as `NEW_POSITION`, `EXITED_POSITION`,
  `MODEL_INPUT_CHANGED`, `RATING_MIGRATION`, `VOL_UP_ON_WEIGHT_UP`, `VOL_UP_ON_RISK_UP`
  (weight flat or down but contribution up — *the security itself got riskier*),
  `VOL_DOWN_ON_WEIGHT_DOWN`, `VOL_DOWN_ON_RISK_DOWN`, `BENCHMARK_ONLY`, `IMMATERIAL`.
- `CommentaryNote` — a generated factual sentence stitching the numbers together. The model
  rewrites it; it does not compute it.

On the `PORTFOLIO` row the query adds
`VolChg_From_ModelInputChanges` — how much of the move came from names whose risk model
inputs changed rather than from the market.

---

## Writing the commentary

`SKILL.md` turns the extract into a CRO note: what changed, who moved it, why they moved, and
what the rest of the book did.

Send **one message**: paste `PROMPT_TO_PASTE.txt` (the instruction block on its own, generated
from `SKILL.md` by `make_paste_file.py`), then the ask, then the XML underneath it. Nothing is
attached — the whole message is about 3,100 + 5,000 tokens.

### What comes back

Text, one block per fund:

| | |
|---|---|
| Heading | fund name, fund code, the two dates, the benchmark |
| What changed | the lead metric, both levels, its relative move, how many names carry it |
| Risers | one short paragraph each, contribution level → level, and one cause |
| Offsets | opened by quoting the arithmetic against the headline |
| Residual | `All other names net <all_other> <unit>.` |
| Second metric | one or two sentences |
| Worth noting | material flags only, omitted entirely when nothing clears the bar |

Where `breadth` is `BROAD` the risers and offsets are replaced by one sentence and a table.

**No file is produced** — no Excel, no CSV. That is deliberate: building a file was what
displaced the commentary in earlier runs.

### The cause ladder

Applied per named driver, **first match wins** — one cause per name, never a list.

| | Test | Reads as |
|---|---|---|
| 1 | `active_weight_change` present | the position size moved — say which side did it: the fund traded, the index re-weighted, or both moved together and the active position closed |
| 2 | absent, but `te_rel_pct` large | the position did not move, so the security itself got riskier |
| 3 | absent, a model attribute present | rating move (with notches and grades; a rating-driven curve re-map is **one event, not two**), curve change, estimation window, duration |
| 4 | none of the above | state the change, say the cause is not in the extract |

Rung 2 is why the materiality gate matters. Without it every driver carries an active weight
change of 0.006% and the ladder never reaches rung 3, so a downgrade gets told as a trade.

### What the XML contains at each level

| Level | Scope |
|---|---|
| `<fund>` and its children | computed over **every** security in the fund |
| `<reconciliation>` | the headline over every security, split into named and unnamed |
| `<drivers>` | **only** the selected names — six or seven of eighteen to twenty-four |

The fund figures are complete. The drivers are a selection, and the reconciliation says
exactly what the selection leaves out, in the same units, as a number the commentary quotes.

Embedding the full portfolio was considered and rejected: a 214-name fund would be ~89 KB
(~21,000 tokens) and the 4,900-name export ~2 MB (~482,000 tokens), which reverses the change
that stopped the ingestion loop.

### Directional selection, and why the residual is named

Risers and offsets are chosen **separately**. Each side takes names in size order until
`side_target` (85%) of that side is named, capped at `max_named_per_side` (4). Everything not
named — both sides, and every security below the cut — lands in `all_other`, which is the
headline **less** the two named sides, so the three parts always sum to it exactly.

A single ranked list of absolute movers does not work: it fills with risers and leaves the
reader unable to see why the fund moved less than the risers did. Measured on the fixture:

| Fund | Names | Shown | `named_up` | `named_down` | `all_other` | Residual | Breadth |
|---|---|---|---|---|---|---|---|
| EQ_GLOBAL | 22 | 6 | +86.0 | −47.0 | −0.2 | 0.5% | CONCENTRATED |
| FI_CORE | 18 | 7 | +97.0 | −23.0 | −2.8 | 3.9% | CONCENTRATED |
| MA_BAL | 18 | 6 | +116.0 | −21.0 | +8.5 | 8.2% | CONCENTRATED |
| AC_CORE | 24 | 10 | +48.5 | 0.0 | +52.6 | 52.0% | BROAD |

The cap was set from this table. At two per side MA_BAL left 44.9% unexplained, which is not
"adding up ballpark"; at four the side target binds first on every concentrated fund, so the
cap only ever rescues the broad one. It costs nothing where it does not bite.

`AC_CORE` exists only to exercise the `BROAD` branch — the other three funds all sit at 66-71%
top-three share, so before it was added the concentrated path was the only one the fixture ever
tested. Its 52% residual is the correct answer for a fund whose move is genuinely spread, and
the commentary says so instead of pretending ten names explain it.

### Tracking error leads

Where `PortfolioTE_bps` is populated on both dates, `lead_metric` is `TE`: tracking error opens
the block, drivers are ranked on `AbsChg_ContriB_TE_bps`, and the reconciliation is in basis
points. Where it is blank — no benchmark attached — volatility leads and the absence is stated
once. Both numbers appear on every driver either way.

### Why the prompt became a skill

Three rewrites, each fixing what the last one exposed.

**The first version returned an Excel workbook and no commentary**, and took about fifteen
minutes for one fund. At 15,029 tokens the output contract made the model write the commentary
*twice* — a full draft, a ten-dimension self-review, then a revised short and long version — and
two of the critical rules ordered pandas use and a file. GPT-5 follows instructions literally,
so the tool work came first and the prose lost. Cutting to ~3,100 tokens fixed that.

**The second version produced commentary that was accurate and unusable.** It mandated one
paragraph per driver in rank order, which on eight drivers is eight paragraphs of identical
shape — *name, ID, line, asset class, it added X bps and Y%* — the extract read aloud in
sentences. It also never reconciled: the drivers summed to +44.0 bps against a fund change of
+38.8 and nothing named the gap.

**The third version is this one.** The diagnosis was that the XML, not the wording, was the
constraint. A sentence like *"NVIDIA's contribution rose from 62.0 to 115.0 bps as its active
weight went from −0.099% to +1.679%"* needs contribution **levels** on both dates and **active
weight** on both dates. The XML carried `te_change_bps` and two raw weights and nothing else,
so the model could not write more than "added 53.0 bps" however it was instructed. Every
missing field was already computed in the 203-column extract — they were dropped when the XML
was narrowed to stop the ingestion loop, and narrowing took the causal chain with it.

So the fix was in the SQL, not the prompt: restore the levels, add active weight, emit the
curve and rating names rather than a Y/N flag, and compute the reconciliation server-side so
the model never adds anything up. The skill then only has to read.

### What is still enforced

Every number read from a named column and never computed. No cause from outside the data.
Blank is never zero — and an absent `active_weight_change` is a *finding*, meaning the weight
did not move, which is usually the most interesting thing about that name. Derivatives quoted
on notional. No "pp" anywhere. No filler words. Materiality thresholds on every fund-level
fact, so nothing is written to report that a figure did not change.

The one rule that was **removed**: the guard telling the model never to sum the drivers. It
was correct for the previous design, where the shown drivers genuinely did not add to the
headline and nothing explained the difference. With `<reconciliation>` the arithmetic is meant
to close, and is given rather than computed.

## Caveats — read before quoting any number

**1. `SUM(ContriB_PfVol)` is treated as total portfolio volatility.**
That holds only if these are true marginal contributions that sum to the total. **On the
first run, check `PortfolioVol_Pct_Curr` on the `PORTFOLIO` row against the risk
system's own reported portfolio volatility.** If they disagree, every derived percentage
here — `PctShare_PfVol`, `PctOfPortfolioVolChg`, the whole summary — is wrong, even though
`Recon_Verdict` will still say `PASS`. `Recon_Verdict` proves the arithmetic is internally
additive; it does not prove the base figure means what we assume.

**2. `YieldCurveChanged` does not mean rates moved.**
`CurrentYieldCurve` is a `STRING` holding the curve **name** assigned to the security. The
flag means *the curve mapping changed* — a reclassification or a model change. Actual
tenor-level rate moves are not in this table. Wiring in real curve levels needs a second
table; that is a follow-on.

**3. Benchmark and TE columns may be entirely empty.**
In the sampled portfolio every `ContriB_BmVol`, `ContriB_TE`, `ContriB_SysTE` and
`ContriB_SpecTE` was `NULL`. `00_preflight_checks.sql` tells you upfront whether they will
populate for your portfolios, so an empty column is not mistaken for a data error.

**4. Additive vs level columns behave differently on entries and exits.**
Additive quantities — contributions, weights, market values, `DurationContrib` — treat a
missing side as **zero**, so a new position shows its full contribution as the change and
`SUM(Chg_*)` reconciles to the portfolio total. Level quantities — durations,
`MissingAssetPercent`, `ModelLagDays` — stay **NULL**, because "the change in duration of a
position that did not exist" is not a meaningful number. `HoldingStatus` disambiguates.

**5. Four source fields are numerics stored as `STRING`.**
`MissingAssetPercent`, `EffectiveDuration`, `ModifiedDuration`, `EffectiveSpreadDuration`.
The query `SAFE_CAST`s them, which means an unparseable value becomes `NULL` **silently**
rather than erroring. If a duration column looks unexpectedly sparse, that is why.

**6. `ContriB_SysPfVol` and `ContriB_SysTE` are `FLOAT`; their siblings are `BIGNUMERIC`.**
BigQuery will not mix the two in arithmetic. Everything is cast to `FLOAT64` early. If you
extend the query, keep doing that.

**7. Rows are de-duplicated to the latest `JobExecutionID`.**
A COB reloaded after a correction leaves both versions in the table. The query keeps the
latest job per natural key; preflight tells you when that happened.

---

## Troubleshooting

**`KEY_COLLISION` fails in preflight.** The extract keys on
`(PortfolioCode, SecurityCode)`. A `FAIL` means one security appears under more than one
`CompositionCode` on the same side of the same date, so the pivot would silently drop rows.
Fix: add `CompositionCode` to the `GROUP BY` in the `pivot` CTE and to the final output.

**`COVERAGE` fails.** One of the two COB dates has no rows for that portfolio. The extract
would read as "every position is new". Pick a date that exists — `Job history` in the
console, or widen the preflight to list available `ValuationDate`s.

**`Recon_Verdict` says `FAIL`.** The per-security changes do not sum to the portfolio
change. Usually a key collision (see above) or a `SAFE_CAST` silently nulling values. Do
not proceed to commentary.

**"Duplicate column name" error.** The two COB dates are the same. The scripts guard
against this with an explicit `RAISE`, so you should see that message instead.

**You edited a query and want to check it before pasting.**

```bash
python3 validate_sql.py --curr 2026-08-24 --prev 2026-08-12
```

It performs the same substitution BigQuery will, writes `_materialised_*.sql` you can read
as plain SQL, and checks for stray placeholders, unbalanced parens, unterminated literals,
duplicate output aliases, and unsupplied parameters. **Structure only** — it cannot verify
that a column exists or that types line up. That is what preflight is for.

---

## Provenance

Schema and grain were read from a screen recording of the BigQuery console
(`IMG_2905.MOV`, 24 Aug 2026), not from an exported schema. The fast-scrolling section
around `ModifiedDuration → EffectiveSpreadDuration → AssetClassification` was recovered
frame by frame. **`00_preflight_checks.sql` is the confirmation that the 56 columns and
their types are right** — if a column name is wrong, that is where it surfaces, as an
"Unrecognized name" error naming the field.
