# Risk Contribution Extract — 2-COB Portfolio Drill-Down

Parameterised BigQuery extract over
`hsbc-237274-amgrisk-prod.elmo.risk_contribution`.

Feed it **two COB dates** and **three portfolio codes**; it returns an analysis-ready CSV
with every metric carried for both dates side by side, the period-over-period calculations
embedded in the query, and a pre-classified driver for each position so an LLM can write
commentary over verified numbers rather than inferring them.

Nothing runs from this machine. You run the queries yourself, export the results, and hand
them to the model.

---

## Quick reference — what to run, what to upload

**Two queries. One upload.**

| # | Run this | Then | Upload? |
|---|---|---|---|
| 1 | `00_preflight_checks.sql` | Read the `Verdict` column on screen. `FAIL` on `COVERAGE`, `KEY_COLLISION` or `ISPORTFOLIO_SIDES` → stop. | **No** — a go / no-go check, not data. |
| 2 | `risk_drilldown.sql` | Save results → CSV. Returns the **commentary view** by default (~10-60 KB). | **Yes** — this is the only file you attach. |

Both take the same two dates and portfolio codes, in the three `DECLARE` lines at the top.

Then: attach that one CSV, paste `PROMPT_TO_PASTE.txt`, paste the ask from step 4 of the
runbook at the top of `commentary_prompt.md`.

**Do not upload** `schema_risk_contribution.csv` (it describes the raw source table, not this
extract), `commentary_prompt.md` (it is pasted as text, not attached), or anything in
`dummy_data/` or `_retired/`.

---


## Three views, and why XML is the default

`risk_drilldown.sql` ends with three statements. **XML runs by default.** The narrow CSV and
the full 212-column audit extract sit below it, commented out.

| View | Shape | Size (3-fund fixture) |
|---|---|---|
| **XML** (default) | one row, one column — the whole document | **12 KB** |
| Narrow CSV | 26 rows x 63 columns | 10 KB |
| Full audit extract | 61 rows x 212 columns | 91 KB |

**Copy the XML cell and paste it into the chat under the prompt. Do not save it and attach
it.** An attachment goes through the host's document pipeline — schema inspection, chunking,
"Reading All Documents" — which is what has been losing the instructions. Pasted text lands
straight in the context window.

### Why not a spreadsheet

A run against the 7 MB, 203-column CSV never produced commentary: the host cycled
`Planning the analysis → Recalling exec_N → Inspecting schema → Reading All Documents →
Planning the analysis` for five minutes. Narrowing to 63 columns stopped the loop, but a CSV
is still routed through the same tabular path — and the flat shape was working against it:

| | |
|---|---|
| Blank cells in the narrow CSV | **38%** (618 of 1,638) |
| Columns populated on *both* row types | **27** — every security row repeated the fund's TE, volatility, dates, benchmark and model lag |
| Structure linking a security to its fund | none, beyond a shared `PortfolioCode` |

A chunk of security rows carried the fund's headline numbers twenty-five times over, with
nothing marking them as fund-level. Nesting fixes all three: fund figures appear once, drivers
sit inside the fund they belong to, and nothing is emitted empty.

### The document

```xml
<risk_extract prev_cob="2026-06-30" curr_cob="2026-07-31">
<fund code="EQ_GLOBAL" name="Global Equity Fund" benchmark="MSCI_ACWI" lead_metric="TE">
  <coverage names_shown="8" total_names="22" pct_of_gross_movement="96.5"/>
  <checks recon="PASS" benchmark_changed="N" modelled_weight_pct="100.0" .../>
  <tracking_error unit="bps" prev="348.0" curr="386.8" change="38.8" relative_pct="11.1"/>
  <volatility unit="pct" prev="12.2600" curr="12.7290" change="0.4690" relative_pct="3.8"/>
  ...
  <drivers>
    <driver rank="1" id="US67066G1040" line="Ordinary" asset_class="Equity"
            te_change_bps="53.0" vol_change_pct="1.1000" ...>NVIDIA CORP</driver>
  </drivers>
</fund>
</risk_extract>
```

**Absence carries meaning; nothing is ever emitted empty.** No `benchmark_weight_*` means the
benchmark does not hold the security. No `exposure_weight_curr` means it was sold. No
`<tracking_error>` means no benchmark is attached.

Two details that are easy to get wrong and are covered by `xml_escape()` and `num()`:

- **Escaping is not optional.** The fixture contains `SPDR S&P 500 ETF TRUST` — a bare `&`
  makes the document unparseable. Verified by round-tripping it through `xml.etree`.
- **Fixed decimals, not `%g`.** `348.0` must not arrive as `348`, and `1.1000` must not arrive
  as `1.1` — the commentary quotes what it is given.

### Output is prose, not tables

One text block per fund, headed by fund name and code: a summary of at most 20 lines, then one
short paragraph per driver in rank order, then the coverage line. The earlier tabular format
was introduced to cut runtime; the runtime problem is now solved upstream by the SQL-side
selection and the inline paste, so the tables were dropped.

---

## One query, two levels

`risk_drilldown.sql` returns both the fund totals and the security detail in one result set.
Tell them apart with **`RowType`**:

| `RowType` | Rows | Notes |
|---|---|---|
| `PORTFOLIO` | one per fund | `SecurityName` reads `PORTFOLIO TOTAL`, `SecurityCode` blank, `Line` and `AssetClassification` read `ALL` |
| `SECURITY` | one per holding | fund-level columns (`Turnover_…`, `SecuritiesDowngraded`, `Recon_…`) are blank |

### Why this replaced the two-file design

The split version ran two separate aggregations over the same table — one grouped by
`PortfolioCode` for the fund totals, one grouped by `(PortfolioCode, SecurityCode)` for the
detail. They disagreed on a real fund by `Recon_Diff_PctPts = 0.0136`, which tripped the
reconciliation gate and killed the entire commentary run.

The cause: a `SecurityCode` can appear more than once on the same side of the same COB —
fund-of-funds sleeves under different `CompositionCode`s. The fund-level aggregate **summed**
those rows. The per-security pivot collapsed them with `MAX(IF(...))`, keeping one and
dropping the rest. The gap was exactly the dropped contributions.

Two fixes, both structural:

1. **Additive quantities now `SUM` across duplicate rows** instead of `MAX` — contributions,
   weights, market values, notionals. A security row is the whole holding, all sleeves
   combined. `DUPLICATE_SECURITY` (Seq 11) in the preflight reports how much of the fund sits
   in duplicated codes, so you know when a row is a combination.
2. **The fund row is built by aggregating the security rows**, in the same query, rather than
   by re-reading the source. The total is a `SUM` over exactly the rows it is meant to
   reconcile against, so the two cannot disagree.

`Recon_Diff_PctPts` is still emitted on the `PORTFOLIO` row. It is now structurally zero, and
kept as a tripwire: a non-zero value means something between the pivot and the output dropped
or duplicated a row.

**Identifiers are never picked with `MAX`.** Where several source rows collapse into one
security row, descriptors are taken with
`ARRAY_AGG(x ORDER BY is_curr DESC, is_pf DESC, mkt_wt DESC LIMIT 1)` — the current COB,
portfolio side, largest holding. Deterministic and meaningful, rather than alphabetical.

---

## Weight scale — the source stores fractions

`MarketWeight` and the notional weights are **fractions** in the source table. A real run
summed the portfolio side to `0.9295`, i.e. 92.95%. The `ContriB_*` family is **not** on that
scale — those are already percentage points, where `0.27` means `0.27%`.

So the query multiplies weights by 100 and leaves contributions alone. The preflight prints
the raw sum alongside the scaled one, so the assumption can be re-confirmed per fund rather
than taken on trust.

**Weights are not expected to reach 100%.** Cash, unmodelled assets and look-through gaps
leave a shortfall. `WEIGHT_COMPLETENESS` treats **90% or above as `OK`**, below 90% as a
`WARN` the commentary must disclose, and above 105% as a `FAIL` — that would mean the scale
assumption or the load is wrong.

## Load selection — only the latest job is used

The same COB can be loaded more than once, so both queries filter to a single load before
anything else happens:

```sql
latest_job AS (
  SELECT ValuationDate, PortfolioCode, MAX(JobExecutionID) AS max_job
  FROM base
  GROUP BY ValuationDate, PortfolioCode
),
```

Rows are then kept only where `JobExecutionID = max_job`. Every earlier job is dropped
whole, not merged. `MAX(JobExecutionID)` is taken **per `ValuationDate` × `PortfolioCode`**,
not once across the extract — the 24 Aug load and the 12 Aug load are different jobs and each
date keeps its own latest.

A second `ROW_NUMBER()` over the natural key
(`ValuationDate`, `PortfolioCode`, `CompositionCode`, `IsPortfolio`, `SecurityCode`) ordered
by `ImportDateTime DESC` sits behind that, to catch the same job inserting an identical key
twice.

### Why the latest *load*, not the latest version of each row

An earlier version of this query de-duplicated row by row —
`ROW_NUMBER() OVER (PARTITION BY <natural key> ORDER BY JobExecutionID DESC)`. That reads as
the same thing and is not.

If job 100 loads 5 positions and a re-run as job 101 carries only 3, row-level picking keeps
the 3 corrected rows from job 101 **and the 2 stale rows from job 100**:

| | Positions | Jobs present | Total vol |
|---|---|---|---|
| Row-level dedup | 5 | 100 **and** 101 | 15.3 |
| Latest job only | 3 | 101 | 6.3 |

The row-level result is a portfolio blended across two model vintages. It looks complete, and
it still reconciles — the contributions sum to their own total regardless of which vintage
they came from — so `Recon_Verdict` says `PASS` and nothing flags it.

That is why the extract now takes the load whole, and why `PARTIAL_RELOAD` exists in the
preflight: it compares the row count of the latest job against the largest earlier job for
the same COB and portfolio, and warns when the latest is smaller. Selecting the latest load
is the right default, but if a re-run was genuinely partial you need to know before you use
the numbers — that is a judgement call, not something the query should make silently.

---


## Commentary shape

**Tracking error leads where it exists.** If `PortfolioTE_bps` is populated on both dates and
the benchmark did not change, the first sentence of both forms is about tracking error,
securities are ranked by `AbsChg_ContriB_TE_bps`, and the coverage loop closes on
`Chg_PortfolioTE_bps`. Volatility is the supporting number. Where tracking error is blank —
no benchmark attached — volatility leads and the absence is stated once. Both numbers appear
in every security sentence either way; only the order and the ranking change.

**Nothing is written that did not move a risk number.** Each portfolio-level fact — fund
size, turnover, concentration, systematic/specific, derivatives, duration — has a materiality
test in the prompt, and fails silently. There is no "concentration was broadly stable"
sentence, because a CRO reads absence as nothing to report. The only things written
regardless are the gate lines and the model staleness line, which are controls rather than
narrative.

**No "pp".** Everything that is a percentage is written with a `%` sign, and the sentence
carries whether the move is absolute or relative:

- relative — *Volatility rose 3.8%, from 12.2600% to 12.7290%.*
- absolute — *NVIDIA CORP added 1.1000% to portfolio volatility, taking its contribution from
  1.8500% to 2.9500%.*

Tracking error stays in basis points. `pp` does not appear anywhere in the output — the
column headers in the tables name the unit instead (`dTE_bps`, `dVol_pct`).

---


## How `IsPortfolio` is used

`IsPortfolio` says **whose numbers the row carries**. `TRUE` — every column on that row
describes the portfolio. `FALSE` — every column describes the benchmark. It is not a filter:
**both sides are pulled**, and the flag is what lets one output row carry the fund and the
benchmark side by side.

There is one exception. **`ContriB_TE` is common to both sides** and is summed across them
without filtering.

| Quantity | Rows summed |
|---|---|
| Portfolio volatility, `ContriB_PfVol` and its systematic/specific split | `IsPortfolio = TRUE` only |
| Portfolio weights, market value, durations, ratings, curve and model fields | `IsPortfolio = TRUE` only |
| Benchmark volatility, `ContriB_BmVol`, benchmark weights | `IsPortfolio = FALSE` only |
| **Tracking error — `ContriB_TE`, `ContriB_SysTE`, `ContriB_SpecTE`** | **both, unfiltered** |

Crossed with the two COB dates, that gives the four-way split — Pf/Bm × current/prior — that
makes `ActiveWeight` and every `Chg_` column computable without a `FULL OUTER JOIN`.

It also does two smaller jobs. It sits in the de-duplication key, so a security held by both
the fund and the benchmark keeps two distinct rows rather than one overwriting the other. And
descriptors prefer the portfolio row and fall back to the benchmark row, so a name held only
in the index still carries its sector, rating and identifier and shows up as
`HoldingStatus = BENCHMARK_ONLY` — a real underweight the commentary must account for.

### Tracking error is inherently two-sided

`ContriB_TE` appears on both the portfolio and the benchmark rows, and the two offset — a
real run showed the portfolio side alone at 819.99 bps against a total of 247.70 bps, so the
benchmark rows carried roughly -572 bps. **Only the total is meaningful.** There is no
portfolio-only tracking error to compare it against, and the query no longer emits one.

That still leaves one thing to confirm on the first run: whether 247.70 bps is what the risk
system itself reports for this fund. The sum is only as good as the assumption that these are
contributions that add to the total.

### Two more assumptions, both now checked

`ISPORTFOLIO_SIDES` (Seq 5) in the preflight reports the row counts and non-null contribution
counts on each side, and fails on either of these rather than leaving them silent:

**A NULL `IsPortfolio` is treated as the portfolio side.** The column is `NULLABLE`, and both
queries read `IFNULL(IsPortfolio, TRUE) AS is_pf`. If NULLs appear, those rows count as fund
holdings and inflate every contribution. The check `FAIL`s on any NULL, which is what makes
the default defensible.

**Benchmark rows are assumed to carry `ContriB_BmVol`.** If they exist but do not, the
benchmark volatility columns come back empty and the check `WARN`s.

## Units

Source values are already in **percentage points**: a stored `0.27` means 0.27%. Every
output column says which unit it is in, so nothing downstream has to guess.

| Suffix | Meaning | Example |
|---|---|---|
| `_Pct_<COB>` | A level, in percent | `PortfolioVol_Pct_24082026` = `12.7290` → 12.7290% |
| `_PctPts` | An absolute change, in percentage points | `Chg_ContriB_PfVol_PctPts` = `+1.1000` → +1.1000 pp |
| `_bps_<COB>` | Tracking error, in basis points | `PortfolioTE_bps_24082026` = `386.8` → 386.8 bps |
| `RelChg_..._Pct` | A **relative** change, in percent | `RelChg_PortfolioVol_Pct` = `+3.8` → up 3.8% |

Volatility and weights are carried in percent; tracking error is converted to basis points
(percent × 100). Both get a relative change alongside the absolute one, so commentary can
say *"volatility rose 3.8%, from 12.2600% to 12.7290%"* and *"tracking error rose 11.1%,
from 348.0 bps to 386.8 bps"* without doing any arithmetic of its own.

`RelChg_` columns are blank where the prior value is zero or the position is new — there is
nothing to compare against. Do not read blank as zero.

---

## Derivatives use notional, not market weight

A future or swap carries almost no market value — only margin and unrealised P&L — so its
market weight understates the fund's real exposure, often by a factor of ten. The extract
resolves this on every row rather than leaving it to the reader:

| Column | |
|---|---|
| `ExposureWeight_Pct_<COB>` | Notional for derivative lines, market weight for everything else. **This is the weight to drill down on.** |
| `ExposureBasis` | `Notional` or `Market` — which one the row used. |
| `IsDerivative` | `Y` / `N`. |
| `NotionalWeightBuy_Pct_<COB>` / `NotionalWeightSell_Pct_<COB>` | The two legs, for swaps and forwards. |

Derivative lines are Future, Swap, Forward, Option, FX Forward, CDS and Swaption, plus
anything whose `AssetClassification` contains "Derivative".

`DriverTag` is classified on exposure weight, so `VOL_UP_ON_WEIGHT_UP` on a future means
the notional rose, not the market value. The coverage loop in the commentary prompt also
measures against exposure — otherwise a derivatives overlay passes through uncovered while
the weight-coverage test still reads as satisfied.

The case from the dummy data: US 10Y NOTE FUTURE SEP26 moved from 0.220% to 0.350% on
market weight — a rounding difference — while its **notional went 3.500% to 9.600%, up
174.3%**. That is what explains the +0.2800 pp it added to portfolio volatility.

---

## Column naming

Dated columns end in **`_Curr`** or **`_Prev`**. The names are identical on every run; the
dates themselves ride along as data:

```
ValuationDate_Curr        2026-08-24
ValuationDate_Prev        2026-08-12
ContriB_PfVol_Pct_Curr    2.9500
ContriB_PfVol_Pct_Prev    1.8500
Chg_ContriB_PfVol_PctPts  1.1000
RelChg_ContriB_PfVol_Pct  59.4595
```

An earlier version stamped the real COB into every alias (`ContriB_PfVol_Pct_24082026`),
which needed `EXECUTE IMMEDIATE` because BigQuery cannot parameterise an identifier. That is
gone. Both queries are now **plain SQL** — one `WITH … SELECT` you can read top to bottom,
run a CTE at a time, and debug in the console. Comment out the final `SELECT` and put
`SELECT * FROM pivot LIMIT 50` in its place to inspect any stage.

The trade is that the column headers no longer carry the dates. `ValuationDate_Curr` and
`ValuationDate_Prev` do, on every row, and the commentary prompt reads them from there.

## What the query computes

**Volatility and contribution** — `ContriB_PfVol` per date and its change; the systematic
and specific splits; `PctShare_PfVol` (this name's share of total portfolio vol) and the
change in that share; `PctOfPortfolioVolChg` — *what fraction of the portfolio's entire
volatility move this one security explains*. Plus `Rank_AbsChg_ContriB_PfVol` so the CSV
opens on the biggest movers.

**Benchmark and tracking error** — `ContriB_BmVol`, `ContriB_TE` and its systematic and
specific splits, `ActiveWeight` per date and its change.

**Exposure** — market weight (portfolio and benchmark side), market value, notional
weight, effective / modified / spread duration, and `DurationContrib` (weight × effective
duration).

**Model and data-quality change flags** — `Y` / `N` / `N/A` for `YieldCurveChanged`,
`VolatilityModelChanged`, `ModelNameChanged`, `ModelDateChanged`,
`ModellyingTypeCodeChanged`, `UsedDataChanged`, `DataPointsChanged`, `IdTypeChanged`,
`RatingChanged`, `SecuritySectorChanged`, `CountryOfRiskChanged`, plus `Chg_ModelLagDays`
and the roll-up `AnyModelInputChanged`.

`N/A` means the holding is absent on one of the two dates, so an entry or exit is never
misreported as a methodology change.

**The AI hook** — two columns exist purely to keep the LLM honest:

- `DriverTag` — each row pre-classified as `NEW_POSITION`, `EXITED_POSITION`,
  `MODEL_INPUT_CHANGED`, `RATING_MIGRATION`, `VOL_UP_ON_WEIGHT_UP`, `VOL_UP_ON_RISK_UP`
  (weight flat or down but contribution up — *the security itself got riskier*),
  `VOL_DOWN_ON_WEIGHT_DOWN`, `VOL_DOWN_ON_RISK_DOWN`, `BENCHMARK_ONLY`, `IMMATERIAL`.
- `CommentaryNote` — a generated factual sentence stitching the numbers together. The model
  rewrites it; it does not compute it.

On the `PORTFOLIO` row the query adds
`VolChg_From_ModelInputChanges` — how much of the move came from names whose risk model
inputs changed rather than from the market.

---

## Writing the commentary

`commentary_prompt.md` turns the extract into a CRO note: a summary of at most 20 lines, then
two or three tables that paste straight into Excel.

Send **one message**: paste `PROMPT_TO_PASTE.txt` (the instruction block on its own, generated
by `make_paste_file.py`), then the ask, then the XML underneath it. Nothing is attached.

### What comes back

Text, one block per fund:

| | |
|---|---|
| Heading | fund name, fund code, the two dates, the benchmark |
| Summary | at most 20 lines, plain sentences, lead metric first |
| Drivers | one short paragraph each, in rank order |
| Coverage line | how many names, and how much of gross movement they explain |

**No file is produced** — no Excel, no CSV, no tables. That is deliberate: building a file was
what displaced the commentary in earlier runs.

### What the XML contains at each level

| Level | Scope |
|---|---|
| `<fund>` and its children | computed over **every** security in the fund |
| `<drivers>` | **only** the selected names — 8 of 22 in the fixture |

The fund figures are complete. The drivers are a selection, and `<coverage>` says how big a
selection: `names_shown`, `total_names`, `pct_of_gross_movement`.

**The drivers do not sum to the fund change, and are not meant to.** On the fixture the eight
shown names total 44.0 bps against a fund change of 38.8 — the fourteen below the cut net to
−5.2. The prompt states this explicitly in two places, because a model that checks its own
arithmetic would otherwise find the gap and either flag an inconsistency it cannot explain or
silently "correct" a figure.

Embedding the full portfolio was considered and rejected: a 214-name fund would be ~89 KB
(~21,000 tokens) and the 4,900-name export ~2 MB (~482,000 tokens), which reverses the change
that stopped the ingestion loop.

### The 95% rule

Only the names explaining **95% of gross movement** in the leading risk metric are listed.
No tail row, no "not itemised" line.

Gross, not net, is the denominator. In the test funds the net change is only 0.12 to 0.68 of
the gross — positions offset each other heavily. Against the net, 95% would be reached in two
or three names while two large offsetting positions stayed invisible. Against gross it takes
seven to nine names on a twenty-name fund. Measured on the fixture:

| Fund | Names | Reaching 95% of gross ΔTE | Net ΔTE | Gross ΔTE |
|---|---|---|---|---|
| EQ_GLOBAL | 22 | 8 (96.5%) | +38.8 bps | 149.2 bps |
| FI_CORE | 18 | 7 (97.1%) | +71.2 bps | 123.6 bps |
| MA_BAL | 18 | 8 (97.9%) | +103.5 bps | 151.1 bps |

There is a 25-row cap. The coverage line always states what was actually achieved:

```
Top 8 of 22 names, 96.5% of gross tracking error movement. Net change +38.8 bps.
```

### Tracking error leads

Where `PortfolioTE_bps` is populated on both dates and the benchmark did not change, tracking
error is the first line of the summary and the ranking key for Table B, with volatility as the
supporting number. Where tracking error is blank, volatility leads and the absence is stated
once. Both numbers appear in every driver row either way.

### Why the prompt was rewritten

The previous version returned an Excel workbook and no commentary, and took about fifteen
minutes for one fund. The format was not the cause — volume and a conflict were.

At 15,029 tokens the output contract made the model write the commentary **twice**: a full
draft, a ten-dimension self-review, then a revised short form and long form, the long form
being nine sections with a paragraph per named security. Then it built a workbook. Two of the
critical rules ordered pandas use and a file. GPT-5 follows instructions literally, so the tool
work came first and the prose lost.

The rewrite is **3,107 tokens**. Removed: the workbook, the draft-then-review cycle, the long
form, the per-figure grounding list, five of the six examples. The coverage loop — previously
"recompute after each security you add", an iterative calculation the model had to simulate —
is now a single `cumsum`.

The peer review was not dropped so much as folded in: six self-check items the model applies
as it writes, rather than a second pass over a finished draft. Same intent — catch the lead
that is not the real reason, the methodology artefact told as a market story, the offsetting
pair quietly omitted — without generating everything twice.

### What is still enforced

Every number read from a named column and never computed. No cause from outside the data.
Blank is never zero. Every security row names SecurityName, IdUsedInAnalytics, Line and
AssetClassification. Derivatives quoted on notional. No "pp" anywhere. No filler words.
Materiality thresholds on every fund-level fact, so nothing is written to report that a figure
did not change.

## Caveats — read before quoting any number

**1. `SUM(ContriB_PfVol)` is treated as total portfolio volatility.**
That holds only if these are true marginal contributions that sum to the total. **On the
first run, check `PortfolioVol_Pct_Curr` on the `PORTFOLIO` row against the risk
system's own reported portfolio volatility.** If they disagree, every derived percentage
here — `PctShare_PfVol`, `PctOfPortfolioVolChg`, the whole summary — is wrong, even though
`Recon_Verdict` will still say `PASS`. `Recon_Verdict` proves the arithmetic is internally
additive; it does not prove the base figure means what we assume.

**2. `YieldCurveChanged` does not mean rates moved.**
`CurrentYieldCurve` is a `STRING` holding the curve **name** assigned to the security. The
flag means *the curve mapping changed* — a reclassification or a model change. Actual
tenor-level rate moves are not in this table. Wiring in real curve levels needs a second
table; that is a follow-on.

**3. Benchmark and TE columns may be entirely empty.**
In the sampled portfolio every `ContriB_BmVol`, `ContriB_TE`, `ContriB_SysTE` and
`ContriB_SpecTE` was `NULL`. `00_preflight_checks.sql` tells you upfront whether they will
populate for your portfolios, so an empty column is not mistaken for a data error.

**4. Additive vs level columns behave differently on entries and exits.**
Additive quantities — contributions, weights, market values, `DurationContrib` — treat a
missing side as **zero**, so a new position shows its full contribution as the change and
`SUM(Chg_*)` reconciles to the portfolio total. Level quantities — durations,
`MissingAssetPercent`, `ModelLagDays` — stay **NULL**, because "the change in duration of a
position that did not exist" is not a meaningful number. `HoldingStatus` disambiguates.

**5. Four source fields are numerics stored as `STRING`.**
`MissingAssetPercent`, `EffectiveDuration`, `ModifiedDuration`, `EffectiveSpreadDuration`.
The query `SAFE_CAST`s them, which means an unparseable value becomes `NULL` **silently**
rather than erroring. If a duration column looks unexpectedly sparse, that is why.

**6. `ContriB_SysPfVol` and `ContriB_SysTE` are `FLOAT`; their siblings are `BIGNUMERIC`.**
BigQuery will not mix the two in arithmetic. Everything is cast to `FLOAT64` early. If you
extend the query, keep doing that.

**7. Rows are de-duplicated to the latest `JobExecutionID`.**
A COB reloaded after a correction leaves both versions in the table. The query keeps the
latest job per natural key; preflight tells you when that happened.

---

## Troubleshooting

**`KEY_COLLISION` fails in preflight.** The extract keys on
`(PortfolioCode, SecurityCode)`. A `FAIL` means one security appears under more than one
`CompositionCode` on the same side of the same date, so the pivot would silently drop rows.
Fix: add `CompositionCode` to the `GROUP BY` in the `pivot` CTE and to the final output.

**`COVERAGE` fails.** One of the two COB dates has no rows for that portfolio. The extract
would read as "every position is new". Pick a date that exists — `Job history` in the
console, or widen the preflight to list available `ValuationDate`s.

**`Recon_Verdict` says `FAIL`.** The per-security changes do not sum to the portfolio
change. Usually a key collision (see above) or a `SAFE_CAST` silently nulling values. Do
not proceed to commentary.

**"Duplicate column name" error.** The two COB dates are the same. The scripts guard
against this with an explicit `RAISE`, so you should see that message instead.

**You edited a query and want to check it before pasting.**

```bash
python3 validate_sql.py --curr 2026-08-24 --prev 2026-08-12
```

It performs the same substitution BigQuery will, writes `_materialised_*.sql` you can read
as plain SQL, and checks for stray placeholders, unbalanced parens, unterminated literals,
duplicate output aliases, and unsupplied parameters. **Structure only** — it cannot verify
that a column exists or that types line up. That is what preflight is for.

---

## Provenance

Schema and grain were read from a screen recording of the BigQuery console
(`IMG_2905.MOV`, 24 Aug 2026), not from an exported schema. The fast-scrolling section
around `ModifiedDuration → EffectiveSpreadDuration → AssetClassification` was recovered
frame by frame. **`00_preflight_checks.sql` is the confirmation that the 56 columns and
their types are right** — if a column name is wrong, that is where it surfaces, as an
"Unrecognized name" error naming the field.
