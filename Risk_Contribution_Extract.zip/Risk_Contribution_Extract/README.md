# Risk Contribution Extract — 2-COB Portfolio Drill-Down

Parameterised BigQuery extract over
`hsbc-237274-amgrisk-prod.elmo.risk_contribution`.

Feed it **two COB dates** and **three portfolio codes**; it returns an analysis-ready CSV
with every metric carried for both dates side by side, the period-over-period calculations
embedded in the query, and a pre-classified driver for each position so an LLM can write
commentary over verified numbers rather than inferring them.

Nothing runs from this machine. You paste, you run, you export.

---

## Files

| File | Purpose |
|---|---|
| `schema_risk_contribution.csv` | All 56 source columns — name, type, mode, and the traps. Reference only. |
| `00_preflight_checks.sql` | **Run first.** Validates the assumptions the extract rests on. |
| `risk_contribution_pairwise.sql` | **The main query.** One row per portfolio × security, ~133 columns. |
| `01_portfolio_summary.sql` | One row per portfolio. Reconciliation check + top-level commentary context. |
| `validate_sql.py` | Local structural check on the templated SQL. Run before pasting if you edit either query. |
| `commentary_prompt.md` | **The commentary prompt.** Takes the two CSVs, produces short-form and long-form CRO commentary. |
| `dummy_data/` | Three synthetic funds (equity, fixed income, multi asset) in the exact output format, for building and testing the prompt without production data. |

---

## How to run

1. **`00_preflight_checks.sql`** — edit the two dates and three portfolio codes, Run.
   Read every `Verdict`. A `FAIL` on `KEY_COLLISION` or `COVERAGE` means stop; see
   *Troubleshooting* below.

2. **`risk_contribution_pairwise.sql`** — same three lines, Run.
   Then **Save results → CSV**.

3. **`01_portfolio_summary.sql`** — same three lines, Run.
   **Check `Recon_Verdict` says `PASS`** before you trust anything in the detail CSV.
   Save results → CSV as well; this is the top-level context for the commentary prompt.

Only these three lines are ever edited, and they are identical in all three files:

```sql
DECLARE cob_curr        DATE          DEFAULT DATE '2026-08-24';
DECLARE cob_prev        DATE          DEFAULT DATE '2026-08-12';
DECLARE portfolio_codes ARRAY<STRING> DEFAULT ['PF_A','PF_B','PF_C'];
```

`portfolio_codes` is an array — pass one code or ten, three is just the stated case.

---

## Units

Source values are already in **percentage points**: a stored `0.27` means 0.27%. Every
output column says which unit it is in, so nothing downstream has to guess.

| Suffix | Meaning | Example |
|---|---|---|
| `_Pct_<COB>` | A level, in percent | `PortfolioVol_Pct_24082026` = `12.7290` → 12.7290% |
| `_PctPts` | An absolute change, in percentage points | `Chg_ContriB_PfVol_PctPts` = `+1.1000` → +1.1000 pp |
| `_bps_<COB>` | Tracking error, in basis points | `PortfolioTE_bps_24082026` = `386.8` → 386.8 bps |
| `RelChg_..._Pct` | A **relative** change, in percent | `RelChg_PortfolioVol_Pct` = `+3.8` → up 3.8% |

Volatility and weights are carried in percent; tracking error is converted to basis points
(percent × 100). Both get a relative change alongside the absolute one, so commentary can
say *"volatility rose 3.8%, from 12.2600% to 12.7290%"* and *"tracking error rose 11.1%,
from 348.0 bps to 386.8 bps"* without doing any arithmetic of its own.

`RelChg_` columns are blank where the prior value is zero or the position is new — there is
nothing to compare against. Do not read blank as zero.

---

## Derivatives use notional, not market weight

A future or swap carries almost no market value — only margin and unrealised P&L — so its
market weight understates the fund's real exposure, often by a factor of ten. The extract
resolves this on every row rather than leaving it to the reader:

| Column | |
|---|---|
| `ExposureWeight_Pct_<COB>` | Notional for derivative lines, market weight for everything else. **This is the weight to drill down on.** |
| `ExposureBasis` | `Notional` or `Market` — which one the row used. |
| `IsDerivative` | `Y` / `N`. |
| `NotionalWeightBuy_Pct_<COB>` / `NotionalWeightSell_Pct_<COB>` | The two legs, for swaps and forwards. |

Derivative lines are Future, Swap, Forward, Option, FX Forward, CDS and Swaption, plus
anything whose `AssetClassification` contains "Derivative".

`DriverTag` is classified on exposure weight, so `VOL_UP_ON_WEIGHT_UP` on a future means
the notional rose, not the market value. The coverage loop in the commentary prompt also
measures against exposure — otherwise a derivatives overlay passes through uncovered while
the weight-coverage test still reads as satisfied.

The case from the dummy data: US 10Y NOTE FUTURE SEP26 moved from 0.220% to 0.350% on
market weight — a rounding difference — while its **notional went 3.500% to 9.600%, up
174.3%**. That is what explains the +0.2800 pp it added to portfolio volatility.

---

## Column naming

Dated columns carry the **real COB in ddmmyyyy**. Computed and delta columns keep **static
names**:

```
ContriB_PfVol_24082026      ContriB_PfVol_12082026      Chg_ContriB_PfVol
MarketWeight_Pf_24082026    MarketWeight_Pf_12082026    Chg_MarketWeight_Pf
YieldCurve_24082026         YieldCurve_12082026         YieldCurveChanged
```

BigQuery cannot parameterise identifiers, so each script builds its own column aliases
from the date parameters and runs itself via `EXECUTE IMMEDIATE`. You still only edit the
`DECLARE` block.

**Consequence:** the dated column names change every run. Anything downstream must match
them **by prefix**, never by fixed position or hardcoded name.

---

## What the query computes

**Volatility and contribution** — `ContriB_PfVol` per date and its change; the systematic
and specific splits; `PctShare_PfVol` (this name's share of total portfolio vol) and the
change in that share; `PctOfPortfolioVolChg` — *what fraction of the portfolio's entire
volatility move this one security explains*. Plus `Rank_AbsChg_ContriB_PfVol` so the CSV
opens on the biggest movers.

**Benchmark and tracking error** — `ContriB_BmVol`, `ContriB_TE` and its systematic and
specific splits, `ActiveWeight` per date and its change.

**Exposure** — market weight (portfolio and benchmark side), market value, notional
weight, effective / modified / spread duration, and `DurationContrib` (weight × effective
duration).

**Model and data-quality change flags** — `Y` / `N` / `N/A` for `YieldCurveChanged`,
`VolatilityModelChanged`, `ModelNameChanged`, `ModelDateChanged`,
`ModellyingTypeCodeChanged`, `UsedDataChanged`, `DataPointsChanged`, `IdTypeChanged`,
`RatingChanged`, `SecuritySectorChanged`, `CountryOfRiskChanged`, plus `Chg_ModelLagDays`
and the roll-up `AnyModelInputChanged`.

`N/A` means the holding is absent on one of the two dates, so an entry or exit is never
misreported as a methodology change.

**The AI hook** — two columns exist purely to keep the LLM honest:

- `DriverTag` — each row pre-classified as `NEW_POSITION`, `EXITED_POSITION`,
  `MODEL_INPUT_CHANGED`, `RATING_MIGRATION`, `VOL_UP_ON_WEIGHT_UP`, `VOL_UP_ON_RISK_UP`
  (weight flat or down but contribution up — *the security itself got riskier*),
  `VOL_DOWN_ON_WEIGHT_DOWN`, `VOL_DOWN_ON_RISK_DOWN`, `BENCHMARK_ONLY`, `IMMATERIAL`.
- `CommentaryNote` — a generated factual sentence stitching the numbers together. The model
  rewrites it; it does not compute it.

At portfolio level, `01_portfolio_summary.sql` adds `PortfolioCommentaryBrief` and
`VolChg_From_ModelInputChanges` — how much of the move came from names whose risk model
inputs changed rather than from the market.

---

## Writing the commentary

`commentary_prompt.md` takes the two exported CSVs and produces commentary for a CRO —
short form (key drivers only, under 120 words per fund) and long form (portfolio → Line →
asset class → security).

It works top-down: portfolio volatility and tracking error first, then a Line-level split,
then individual securities in rank order of `AbsChg_ContriB_PfVol`. It keeps naming
securities until four conditions all hold — no unnamed security moved volatility by 0.05 or
more, the unexplained residual is at or below 0.01, and named securities cover more than
half of both the fund-side and benchmark-side weight change. Whatever is left goes into one
explicit "not itemised" line, so the parts always sum back to `Chg_PortfolioVol`.

Every sentence carrying a number must name the security, its `IdUsedInAnalytics`
(the ISIN where one exists, the internal code otherwise), its `Line`, its
`AssetClassification`, and which risk number moved. The prompt bans the usual filler
outright — a word list, not a style hint — and forbids explaining any move by something
outside the file, since the extract contains no market data.

### How it is wired

The prompt is split into a static instruction block (everything between `<<<SYSTEM` and
`SYSTEM>>>`) and the volatile CSV data. The instruction block goes in the developer/system
message byte-identical every run; the data goes in the user turn inside `<data>` tags. That
ordering is what makes the ~9.7K-token instruction block cacheable — prefix caching is
byte-exact, so a fund name or timestamp interpolated into the instructions would invalidate
it on every call.

Target model is the current GPT-5.x reasoning model, at `reasoning.effort = high`. Two
things to know: reasoning models take **no `temperature` or `top_p`** — the "temperature 0
for factual work" reflex does not apply, and determinism comes from the rules themselves —
and the prompt is written to be free of internal contradictions, because GPT-5 spends
reasoning tokens reconciling conflicting instructions rather than following them.

Run **one fund per request**. Batching costs the model its full reasoning budget on each
fund's coverage loop, and the cached prefix makes the extra calls cheap.

Output is five XML-delimited blocks: `<analysis>` (gate results, the coverage table with
running residual, a column citation for every figure), `<draft>`, `<peer_review>`, then the
final `<short_form>` and `<long_form>`. The first three are the audit trail and can be
dropped before the note goes out.

### The peer review pass

After drafting, the prompt changes role and reviews its own work as a peer senior risk
manager with 30+ years in buy-side risk. Ten dimensions, each requiring a **quoted sentence**
from the draft and a severity — BLOCKER, FIX or NOTE. Every BLOCKER and FIX must be applied
before the final forms are emitted, and a blanket "accurate and complete" verdict is
forbidden.

This catches what the mechanical checks cannot. The worked example in the prompt is a real
case: the draft commentary for EQ_GLOBAL leads with a trading story, and every number in it
is correct — but **70.4% of that fund's volatility move comes from one name whose modelling
type and observation count both changed**. It passes every unit, column and banned-word
check and is still the wrong story. The review catches it, and the revised lead opens on the
model input change instead.

Self-critique in a single call tends toward self-ratification. If the note carries real
weight, run the review as a second independent call — fresh context, given only the data and
the draft, with no knowledge that it wrote the draft. The prompt splits cleanly at
`<peer_review_protocol>` for that.

### What it checks before it writes

Four gates, each backed by a column, because any of them can silently invalidate the
commentary:

| Gate | Column | Consequence |
|---|---|---|
| Reconciliation | `Recon_Verdict` | FAIL → no commentary for that fund. |
| Benchmark identity | `BenchmarkChanged` | Changed → tracking error is measured against two different indices and is not comparable. |
| Weight completeness | `SumMarketWeight_Pct`, `MaxMissingAssetPercent_Pct` | Weights off 100, or missing assets → contributions are understated, and it says so. |
| Model staleness | `ModelLagDays_<COB>` | Non-zero → mandatory line saying the numbers reflect market structure as at the model date. |

### The drill-down dimensions

Portfolio → Line → asset class → **currency** → security. Currency is included whenever the
fund holds more than one, because a Line-only view hides it entirely in a global fund.

Duration gets its own sentence in the portfolio section for any fund holding bonds, ahead
of the security detail — for a fixed income fund a duration extension is usually *the*
reason volatility moved, and burying it in a security paragraph is the classic mistake.

The prompt also requires four readings a risk manager would make automatically and a
generic summariser would not:

- **Fund size against turnover.** If the fund grew 15% on 6 pp of turnover, the weight
  moves are mechanical, not decisions. `RelChg_FundMarketValue_Pct` vs
  `Turnover_ExposureWeight_PctPts`.
- **Volatility against tracking error.** They can move in opposite directions — more
  volatile while moving *closer* to the benchmark. When the signs differ it must be said.
- **Systematic against specific.** Which kind of risk changed, without naming factors the
  file does not contain.
- **Concentration.** `Chg_Top5ShareOfVol_PctPts` is a finding in its own right.

### Three causes the flags alone would have hidden

**Spread duration** sits alongside effective duration, not inside it. A fund can shorten
rate duration while extending credit duration — de-risking on one measure, the opposite on
the other. `WavgSpreadDuration_<COB>` and `SpreadDurationContrib_<COB>` make both visible,
and the prompt requires spread duration and `RatingDirection` be read together.

**A downgrade re-maps the yield curve.** The curve change is the *mechanism* by which the
rating move hits volatility, not a separate methodology change that happens to coincide.
`RatingDrivenCurveChange` = `Y` marks these, `RatingDirection` and `RatingNotchesDowngraded`
give direction and size, and `DriverTag` returns `RATING_DRIVEN_CURVE_CHANGE` — ordered
*ahead* of the generic `MODEL_INPUT_CHANGED`, which was previously swallowing the credit
cause. In the dummy data, Verizon is downgraded BBB+ → BBB and moves from the USD_CORP_BBB+
curve to USD_CORP_BBB, on a weight that barely changed.

**A changed estimation window moves volatility on its own.** `DataPoints` is the observation
count behind the vol estimate. `Chg_DataPoints` and `RelChg_DataPoints_Pct` measure it, and
`ESTIMATION_WINDOW_CHANGED` tags the case where nothing else changed. In the dummy data one
holding's window halves from 250 to 120 observations and accounts for **34.1% of that fund's
entire volatility move** — measurement, not market.

`VolatilityModel` is carried as `VolatilityModel_RefOnly_<COB>` and excluded from every
flag, tag and roll-up. The prompt forbids mentioning it.

### Testing it

`dummy_data/` holds a synthetic extract in the exact output format: three funds — equity
only, fixed income, multi asset — 58 securities, entries and exits, yield curve changes, a
rating migration, a proxy-model change. It reconciles exactly (`Recon_Diff` = 0 for all
three), so the coverage loop can be exercised end to end.

```bash
python3 dummy_data/make_dummy_data.py
```

Regenerate it after any change to the main query — the generator reads the column list out
of `risk_contribution_pairwise.sql` and fails loudly if the two drift apart.

The worked example at the end of the prompt is built from this data, and every figure in it
was checked against the file.

---

## Caveats — read before quoting any number

**1. `SUM(ContriB_PfVol)` is treated as total portfolio volatility.**
That holds only if these are true marginal contributions that sum to the total. **On the
first run, check `PortfolioVol_<COB>` in `01_portfolio_summary.sql` against the risk
system's own reported portfolio volatility.** If they disagree, every derived percentage
here — `PctShare_PfVol`, `PctOfPortfolioVolChg`, the whole summary — is wrong, even though
`Recon_Verdict` will still say `PASS`. `Recon_Verdict` proves the arithmetic is internally
additive; it does not prove the base figure means what we assume.

**2. `YieldCurveChanged` does not mean rates moved.**
`CurrentYieldCurve` is a `STRING` holding the curve **name** assigned to the security. The
flag means *the curve mapping changed* — a reclassification or a model change. Actual
tenor-level rate moves are not in this table. Wiring in real curve levels needs a second
table; that is a follow-on.

**3. Benchmark and TE columns may be entirely empty.**
In the sampled portfolio every `ContriB_BmVol`, `ContriB_TE`, `ContriB_SysTE` and
`ContriB_SpecTE` was `NULL`. `00_preflight_checks.sql` tells you upfront whether they will
populate for your portfolios, so an empty column is not mistaken for a data error.

**4. Additive vs level columns behave differently on entries and exits.**
Additive quantities — contributions, weights, market values, `DurationContrib` — treat a
missing side as **zero**, so a new position shows its full contribution as the change and
`SUM(Chg_*)` reconciles to the portfolio total. Level quantities — durations,
`MissingAssetPercent`, `ModelLagDays` — stay **NULL**, because "the change in duration of a
position that did not exist" is not a meaningful number. `HoldingStatus` disambiguates.

**5. Four source fields are numerics stored as `STRING`.**
`MissingAssetPercent`, `EffectiveDuration`, `ModifiedDuration`, `EffectiveSpreadDuration`.
The query `SAFE_CAST`s them, which means an unparseable value becomes `NULL` **silently**
rather than erroring. If a duration column looks unexpectedly sparse, that is why.

**6. `ContriB_SysPfVol` and `ContriB_SysTE` are `FLOAT`; their siblings are `BIGNUMERIC`.**
BigQuery will not mix the two in arithmetic. Everything is cast to `FLOAT64` early. If you
extend the query, keep doing that.

**7. Rows are de-duplicated to the latest `JobExecutionID`.**
A COB reloaded after a correction leaves both versions in the table. The query keeps the
latest job per natural key; preflight tells you when that happened.

---

## Troubleshooting

**`KEY_COLLISION` fails in preflight.** The extract keys on
`(PortfolioCode, SecurityCode)`. A `FAIL` means one security appears under more than one
`CompositionCode` on the same side of the same date, so the pivot would silently drop rows.
Fix: add `CompositionCode` to the `GROUP BY` in the `pivot` CTE and to the final output.

**`COVERAGE` fails.** One of the two COB dates has no rows for that portfolio. The extract
would read as "every position is new". Pick a date that exists — `Job history` in the
console, or widen the preflight to list available `ValuationDate`s.

**`Recon_Verdict` says `FAIL`.** The per-security changes do not sum to the portfolio
change. Usually a key collision (see above) or a `SAFE_CAST` silently nulling values. Do
not proceed to commentary.

**"Duplicate column name" error.** The two COB dates are the same. The scripts guard
against this with an explicit `RAISE`, so you should see that message instead.

**You edited a query and want to check it before pasting.**

```bash
python3 validate_sql.py --curr 2026-08-24 --prev 2026-08-12
```

It performs the same substitution BigQuery will, writes `_materialised_*.sql` you can read
as plain SQL, and checks for stray placeholders, unbalanced parens, unterminated literals,
duplicate output aliases, and unsupplied parameters. **Structure only** — it cannot verify
that a column exists or that types line up. That is what preflight is for.

---

## Provenance

Schema and grain were read from a screen recording of the BigQuery console
(`IMG_2905.MOV`, 24 Aug 2026), not from an exported schema. The fast-scrolling section
around `ModifiedDuration → EffectiveSpreadDuration → AssetClassification` was recovered
frame by frame. **`00_preflight_checks.sql` is the confirmation that the 56 columns and
their types are right** — if a column name is wrong, that is where it surfaces, as an
"Unrecognized name" error naming the field.
