import json, base64, subprocess, time, sys, requests, websocket
HTML = sys.argv[1]; OUT = sys.argv[2]
port = 9351
chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
p = subprocess.Popen([chrome, "--headless=new", "--disable-gpu", "--no-sandbox", "--remote-allow-origins=*",
                      f"--remote-debugging-port={port}", "--user-data-dir=/private/tmp/claude-501/cdpprof_fi", "about:blank"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
tab = None
for _ in range(60):
    try:
        tabs = requests.get(f"http://127.0.0.1:{port}/json").json()
        tab = [t for t in tabs if t["type"]=="page"][0]; break
    except Exception: time.sleep(0.5)
ws = websocket.create_connection(tab["webSocketDebuggerUrl"], timeout=300)
i = [0]
def cmd(method, params=None):
    i[0]+=1
    ws.send(json.dumps({"id":i[0],"method":method,"params":params or {}}))
    while True:
        m = json.loads(ws.recv())
        if m.get("id")==i[0]: return m.get("result",{})
cmd("Page.enable"); cmd("Page.navigate", {"url":"file://"+HTML}); time.sleep(6)
FOOT = ('<div style="width:100%;font-family:Helvetica,Arial,sans-serif;font-size:7pt;color:#8a8f98;padding:0 16mm;display:flex;justify-content:space-between;">'
        '<span>Fixed Income Strategy Playbook &mdash; companion to the HSBC AM VP Governance guide</span><span class="pageNumber"></span></div>')
res = cmd("Page.printToPDF", {"printBackground":True,"displayHeaderFooter":True,"headerTemplate":'<div style="font-size:0px;">&nbsp;</div>',
     "footerTemplate":FOOT,"paperWidth":8.27,"paperHeight":11.69,"marginTop":0.62,"marginBottom":0.62,"marginLeft":0.60,"marginRight":0.60})
open(OUT,"wb").write(base64.b64decode(res["data"])); ws.close(); p.terminate(); print("written", OUT)
